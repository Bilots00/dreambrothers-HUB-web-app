/* ===========================================================================================
   LA REVISIONE DELLA SERA (0.9.225)

   Dal sistema di Davy Fogarty (fondatore di The Oodie, video «The Last 10% Is Why You're Still
   Average»): il segreto non e' la pianificazione, e' la revisione. Ogni sera tre domande sul
   giorno appena finito, e per quello che ti ha interrotto non «domani mi impegno di piu'»: si
   cambia il sistema (si blocca, si spegne, si delega, si elimina).

   Sulla scena del Genio, una domanda alla volta, con i dati veri di oggi accanto alla domanda:
     1. Durante i blocchi di lavoro profondo eri davvero concentrato? (le sessioni di Full Focus
        di oggi, quante finite e quante interrotte, e il tempo sulle app che distraggono)
     2. Hai lavorato su cose ad alta leva o solo su quelle facili? (la priorita' di oggi: fatta
        o no, e le cose chiuse)
     3. Cosa, di preciso, ti ha interrotto?
     4. Cosa cambi nel sistema, da domani? (dipende dalla risposta 3)
   Si salva in fl_revisioni ([{ giorno, focus, leva, interruzione, contromisura, testo }]) e la
   legge anche il tuo agente personale. Si apre dalla vista Roadmap della Mappa (la card della sera).
   =========================================================================================== */
const RV_KEY = 'fl_revisioni';
const RV = { passo: '', storia: [], r: {}, dati: null, opz: [] };
function rvOggi(){ try{ return (typeof mtKey === 'function') ? mtKey(Date.now()) : new Date().toISOString().slice(0, 10); }catch(_){ return new Date().toISOString().slice(0, 10); } }
function rvLista(){ try{ return JSON.parse(localStorage.getItem(RV_KEY) || '[]') || []; }catch(_){ return []; } }
function rvFattaOggi(){ const g = rvOggi(); return rvLista().some(function(x){ return x.giorno === g; }); }
/** I giorni di fila con la revisione fatta, fino a oggi o a ieri. */
function rvSerie(){
  const l = rvLista(); const fatti = {}; l.forEach(function(x){ fatti[x.giorno] = 1; });
  let n = 0, d = new Date(); if (!fatti[rvOggi()]) d.setDate(d.getDate() - 1);
  while (true){ const k = (typeof mtKey === 'function') ? mtKey(d.getTime()) : d.toISOString().slice(0, 10); if (!fatti[k]) break; n++; d.setDate(d.getDate() - 1); }
  return n;
}
function rvOre(min){ min = Math.round(min || 0); if (min < 60) return min === 1 ? '1 minuto' : min + ' minuti'; const h = Math.floor(min / 60), m = min % 60; return (h === 1 ? '1 ora' : h + ' ore') + (m ? ' e ' + m + (m === 1 ? ' minuto' : ' minuti') : ''); }

/* ---------- i dati veri di oggi ---------- */
async function rvRaccogli(){
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const out = { ff: { n: 0, finite: 0, mollate: 0, min: 0 }, prio: '', prioFatta: false, chiuse: [], app: [] };
  try{
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
      if (!x || x.meditazione || x.at < d0.getTime()) return;
      out.ff.n++; if (x.ok) out.ff.finite++; else out.ff.mollate++;
      out.ff.min += (x.spentMs || 0) / 60000;
    });
  }catch(_){ }
  try{
    const g = rvOggi();
    const righe = (typeof stRigheDi === 'function') ? stRigheDi(g) : [];
    out.prio = (typeof stPriorita === 'function') ? String(stPriorita(g, righe) || '').replace(/^[☐☑•\-]\s*/, '') : '';
    const fatte = (typeof stDone === 'function') ? stDone().filter(function(x){ return x.day === g; }) : [];
    out.chiuse = fatte.map(function(x){ return x.text; });
    const n = function(t){ return String(t || '').trim().toLowerCase(); };
    out.prioFatta = !!out.prio && out.chiuse.some(function(t){ return n(t) === n(out.prio); });
  }catch(_){ }
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps){
      const r = await NATIVE.getTopApps({ from: d0.getTime(), to: Date.now(), limit: 40, icons: 0 });
      let cats = {}; try{ cats = (typeof insCats === 'function') ? insCats(null) : {}; }catch(_){ }
      const noti = (typeof PRC_DISTR !== 'undefined') ? PRC_DISTR : [];
      out.app = ((r && r.apps) || []).filter(function(x){ return cats[x.packageName] === 'distr' || (!cats[x.packageName] && noti.indexOf(x.packageName) >= 0); })
        .map(function(x){ return { pkg: x.packageName, nome: x.label || x.appName || x.packageName, min: Math.round((x.ms || 0) / 60000) }; })
        .filter(function(x){ return x.min >= 5; }).sort(function(a, b){ return b.min - a.min; }).slice(0, 2);
    }
  }catch(_){ }
  return out;
}

/* ---------- la scena ---------- */
async function rvApri(){
  try{ RV_DA.tab = localStorage.getItem('fl_tab') === 'insights' ? 'insights' : ''; }catch(_){ RV_DA.tab = ''; }
  if (typeof GN === 'undefined' || typeof gnVai !== 'function'){ toast('Il Genio non è pronto, riprova'); return; }
  RV.r = {}; RV.storia = []; RV.visti = {}; RV.bozze = {}; RV.cvRegistrata = false;
  RV.dati = await rvRaccogli();
  RV.corta = false;
  RV.passo = rvPrimoPasso();
  /* 0.9.322: "Riprendi da dove avevi lasciato" (dream-storia.js): le risposte tornano al loro posto */
  const rip = RV_RIPRESA; RV_RIPRESA = null;
  if (rip){
    RV.r = rip.r || {}; RV.storia = rip.storia || []; RV.visti = rip.visti || {}; RV.bozze = rip.bozze || {}; RV.scrivoPer = rip.scrivoPer || '';
    RV.passo = /^cv(Cosa|Scrivo|Scopri)$/.test(rip.passo) ? 'cvRivela' : rip.passo;
  }
  GN.on = true; GN.modo = 'rv'; GN.audio = true; GN.storia = [];
  RV.giorno = rvOggi(); RV.apertaAt = Date.now();
  goId('s-genio');
  rvBarra();
  GN.step = ''; gnVai('rv');
}
/* 0.9.322, Andrea: "se esco a meta' non deve ricominciare da capo: puo' scegliere se riprendere, come su Netflix". Ogni passo
   della sera si segna qui, per quel giorno. La revisione finita cancella il segno. */
const RV_RIP_K = 'fl_rv_ripresa';
let RV_RIPRESA = null;
function rvRipSalva(){
  try{
    if (!RV.passo || RV.passo === 'fine' || !RV.storia.length) return;
    localStorage.setItem(RV_RIP_K, JSON.stringify({ g: rvOggi(), at: Date.now(), passo: RV.passo, storia: RV.storia, r: RV.r, visti: RV.visti, bozze: RV.bozze, scrivoPer: RV.scrivoPer || '' }));
  }catch(_){ }
}
function rvRipLeggi(){
  try{
    const o = JSON.parse(localStorage.getItem(RV_RIP_K) || 'null'); if (!o) return null;
    if (o.g !== rvOggi() || rvFattaOggi()){ localStorage.removeItem(RV_RIP_K); return null; }
    return o;
  }catch(_){ return null; }
}
function rvRipVia(){ try{ localStorage.removeItem(RV_RIP_K); }catch(_){ } }
/* 0.9.280, Andrea: "la revisione comincia sempre dal controllo dell'umore, con le stesse faccine della
   scorciatoia; poi, se vuole, un pensiero sulla giornata. Se le ha gia' fatte tutte e due, si saltano. E
   l'ultima domanda e' sugli imprevisti, da mandare al Genio perche' ricalcoli la roadmap". */
function rvUmoreOggi(){ try{ return (typeof umLeggi === 'function' && typeof umGiorno === 'function') ? (umLeggi(umGiorno(0)) || {}) : {}; }catch(_){ return {}; } }
/* 0.9.335, Andrea: "la revisione della sera piu' breve se ho appena fatto il Rientra in rotta o ho gia' chiesto il controllo
   della rotta": le domande sulla giornata le ho gia' fatte li'. Restano l'umore, l'imprevisto e la prima cosa di domani. */
function rvGiaFattoOggi(){
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  try{ if (typeof rnLista === 'function' && rnLista().some(function(x){ return x && x.at >= d0.getTime(); })) return true; }catch(_){ }
  try{ if (localStorage.getItem('fl_ctl_giorno') === new Date().toDateString()) return true; }catch(_){ }
  return false;
}
function rvPrimoPasso(){
  const u = rvUmoreOggi();
  if (typeof umScrivi === 'function' && !u.sodd) return 'umore';
  if (rvGiaFattoOggi()){ RV.corta = true; return 'imprevisto'; }
  /* 0.9.301: dopo l'umore la rivelazione di dove e' andato il tempo (conversa.js), con Premium prima una domanda di
     consapevolezza e dopo la chat con il tuo agente personale; senza, il Genio a opzioni riparte dal pensiero o dal focus */
  if (typeof cvInizio === 'function') return cvInizio('rv');
  if (typeof umScrivi === 'function' && !String(u.nota || '').trim()) return 'pensiero';
  return 'focus';
}
function rvUmore(n){
  try{ umScrivi(umGiorno(0), { sodd: n }); gnAu.scelta(n - 1); flVibra(14); }catch(_){ }
  if (rvGiaFattoOggi()){ RV.corta = true; rvVai('imprevisto'); return; }
  if (typeof cvInizio === 'function'){ rvVai(cvInizio('rv')); return; }
  rvVai(String(rvUmoreOggi().nota || '').trim() ? 'focus' : 'pensiero');
}
function rvPensieroOk(salta){
  const a = document.getElementById('rvPensiero'); const t = a ? a.value.trim() : '';
  if (!salta && t){ try{ umScrivi(umGiorno(0), { nota: t.slice(0, 400) }); }catch(_){ } }
  rvVai('focus');
}
function rvImprevisto(si){
  if (!si){ RV.r.imprevisto = ''; rvVai(rvDomaniTask() ? 'domani' : 'fine'); return; }
  rvVai('imprevistoScrivo');
}
function rvImprevistoOk(){
  const a = document.getElementById('rvImpr'); const t = a ? a.value.trim() : '';
  /* 0.9.310: mai obbligatorio. A campo vuoto si va avanti senza imprevisto */
  RV.r.imprevisto = t; rvVai(rvDomaniTask() ? 'domani' : 'fine');
}
/* l'imprevisto va al Genio come bozza: il messaggio parte solo quando lo mandi tu */
function rvImprevistoAlGenio(){
  const t = RV.r.imprevisto || '';
  rvChiudi();
  const testo = 'Oggi c\'è stato un imprevisto: ' + t + '\nRicalcola la mia roadmap tenendone conto: sposta o cambia le tappe che non reggono più.';
  if (typeof agApri === 'function'){ Promise.resolve(agApri()).then(function(){ try{ AG.vista = 'chat'; agPaint(); }catch(_){ } }); setTimeout(function(){ try{ agBozza(testo); }catch(_){ } }, 900); }
}
function rvBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const p = { umore: 0.06, cvDomanda: 0.08, cvCosa: 0.085, cvScrivo: 0.09, cvScopri: 0.1, cvRivela: 0.12, cvFuturo: 0.14, cvChat: 0.3, pensiero: 0.14, focus: 0.24, leva: 0.42, inter: 0.58, sistema: 0.72, scrivo: 0.6, imprevisto: 0.86, imprevistoScrivo: 0.92, fine: 1 }[RV.passo] || 0.2;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = Math.round(p * 100) + '%';
  if (txt) txt.textContent = 'La revisione della sera';
}
function rvVai(p){ RV.storia.push(RV.passo); RV.passo = p; rvRipSalva(); rvBarra(); GN.step = ''; gnVai('rv'); }
/* 0.9.340, Andrea: "ho toccato indietro alla fine e la revisione e' sparita": indietro torna sempre alla domanda di prima */
function rvIndietro(){ if (!RV.storia.length){ rvChiudi(); return true; } RV.passo = RV.storia.pop(); rvBarra(); GN.step = ''; gnVai('rv'); return true; }
function rvChiudi(){
  /* la scelta fatta sulla prima cosa di domani (tutorial, domanda, tre passi, punto) parte solo adesso, a giornata chiusa */
  const azione = RV.passo === 'fine' ? RV.dopoAzione : '';
  RV.dopoAzione = '';
  if (azione) setTimeout(function(){ rvDomaniAzione(azione); }, 250);
  rvRipSalva();
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home'); try{ switchTab(RV_DA.tab || 'mappa'); }catch(_){ } RV_DA.tab = '';
  try{ if (typeof rvCardPaint === 'function') rvCardPaint(); }catch(_){ }
  try{ rvOvunquePaint(); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
}
const RV_DA = { tab: '' };
function rvCarte(voci, scrivo){
  RV.opz = voci;
  return '<div class="gn-carta"><div class="gn-cards' + (voci.length % 2 ? ' dispari' : '') + '">' + voci.map(function(o, i){
    return '<button type="button" class="gn-card" onclick="event.stopPropagation();rvScegli(' + i + ')"><span>' + o[1] + '</span><b>' + gnEsc(o[2]) + '</b></button>';
  }).join('') + '</div></div>'
    + (scrivo ? '<button type="button" class="gn-link rng-mio" onclick="event.stopPropagation();rvScrivo()">✍️ Lo scrivo io</button>' : '');
}
function rvVisto(righe){ return righe.length ? '<div class="rng-visto">' + righe.map(function(r){ return '<div class="rng-v"><span>' + r[0] + '</span><p>' + gnEsc(r[1]) + '</p></div>'; }).join('') + '</div>' : ''; }
/* 0.9.276, Andrea: "gli hai mostrato due dati e poi la domanda, tutto insieme: zero one element one focus".
   Prima una schermata con i dati della giornata, poi la domanda da sola. */
function rvDati(p, titolo, v){
  if (!v.length || RV.visti[p]) return false;
  gnDomanda('pensa', titolo, rvVisto(v) + '<div class="or-grid one"><button type="button" class="or-a main" data-p="' + p + '" onclick="event.stopPropagation();rvDatiOk(this)">Avanti</button></div>');
  return true;
}
function rvDatiOk(b){ RV.visti[b.getAttribute('data-p')] = 1; GN.step = ''; gnVai('rv'); }
/* 0.9.282, Andrea: "scrivo un pensiero, vado avanti, torno indietro e il campo e' vuoto". Il testo resta: la bozza di
   ogni campo (o, per il pensiero, quello gia' salvato oggi) torna dentro quando la domanda si ridisegna. */
function rvBozza(k, v){ RV.bozze = RV.bozze || {}; RV.bozze[k] = v; rvRipSalva(); }
function rvRiempi(giri){
  const b = RV.bozze || {};
  const campi = [['rvPensiero', b.pensiero || (rvUmoreOggi().nota || '')], ['rvImpr', b.impr || RV.r.imprevisto || ''], ['rvTesto', b.scrivo || '']];
  let trovato = false;
  campi.forEach(function(c){ const t = document.getElementById(c[0]); if (t){ trovato = true; if (!t.value && c[1]) t.value = c[1]; } });
  if (!trovato && (giri || 0) < 20) setTimeout(function(){ rvRiempi((giri || 0) + 1); }, 250);
}
function rvEntra(){
  setTimeout(rvRiempi, 300);
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo'); }
  if (typeof cvEntra === 'function' && cvEntra('rv')) return;
  const d = RV.dati || { ff: { n: 0 }, app: [], chiuse: [] }, p = RV.passo;
  if (p === 'umore'){
    const V = (typeof UM_VOCI !== 'undefined') ? UM_VOCI : ['Malissimo', 'Storta', 'Così così', 'Bene', 'Benissimo'];
    const E = (typeof UM_EMOJI !== 'undefined') ? UM_EMOJI : ['😫', '😕', '😐', '🙂', '🤩'];
    gnDomanda('pensa', 'Prima di tutto: *come ti senti oggi*?',
      '<div class="gn-carta"><div class="rv-facce">' + V.map(function(v, i){ return '<button type="button" onclick="event.stopPropagation();rvUmore(' + (i + 1) + ')"><span>' + E[i] + '</span><small>' + gnEsc(v) + '</small></button>'; }).join('') + '</div></div>');
    return;
  }
  if (p === 'pensiero'){
    gnDomanda('pensa', 'Vuoi lasciare *un pensiero* sulla tua giornata?',
      '<textarea class="gn-area" id="rvPensiero" rows="4" oninput="rvBozza(\'pensiero\',this.value)" placeholder="Com\u2019è andata, cosa ti porti a casa…" onclick="event.stopPropagation()"></textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvPensieroOk(false)">Salva</button>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();rvPensieroOk(true)">Salta</button></div>');
    return;
  }
  if (p === 'imprevisto'){
    gnDomanda('pensa', (RV.corta ? 'Oggi hai già fatto il punto con me, quindi ti chiedo solo due cose.\n\n' : '') + 'Oggi c\u2019è stato *un imprevisto*, o sta arrivando qualcosa che cambia i tuoi piani?',
      rvCarte([['no', '🛡️', 'No, tutto come previsto'], ['si', '⚠️', 'Sì, lo dico al Genio']], false));
    return;
  }
  /* 0.9.329, Andrea: "prima di chiudere, la prima cosa da fare domani: la vede, si prepara, fa domande, la scompone o guarda il tutorial. Domattina e' gia' pronto" */
  if (p === 'domani'){
    const t = rvDomaniTask();
    if (!t){ rvVai('fine'); return; }
    gnDomanda('rivela', 'Prima di chiudere, guarda *la prima cosa di domani*.',
      '<div class="rv-dom"><small>Domani si comincia da qui</small><b>' + gnEsc(t) + '</b></div>'
      + '<div class="or-grid quattro"><button type="button" class="or-a" onclick="event.stopPropagation();rvDomaniVia(\'scomponi\')">Scomponila in 3 passi</button>'
      + '<button type="button" class="or-a" onclick="event.stopPropagation();rvDomaniVia(\'tutorial\')">Guarda un tutorial</button>'
      + '<button type="button" class="or-a" onclick="event.stopPropagation();rvDomaniVia(\'domanda\')">Ho una domanda</button>'
      /* 0.9.331, Andrea: come dal pannello di pianificazione */
      + (typeof pkPuntoApri === 'function' ? '<button type="button" class="or-a" onclick="event.stopPropagation();rvDomaniVia(\'prenota\')">Prenota il punto</button>' : '') + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rvVai(\'fine\')">Ci sono, chiudo la giornata</button></div>');
    return;
  }
  if (p === 'imprevistoScrivo'){
    gnDomanda('pensa', 'Raccontamelo: *cosa è successo*, o cosa arriva?',
      '<textarea class="gn-area" id="rvImpr" rows="4" oninput="rvBozza(\'impr\',this.value);rvCampoBtn(this,\'rvImprOk\',\'Confermo\')" placeholder="Per esempio: questa settimana lavoro di sera, ho due giorni in meno…" onclick="event.stopPropagation()"></textarea><div class="or-grid one"><button type="button" class="or-a" id="rvImprOk" onclick="event.stopPropagation();rvImprevistoOk()">Salta</button></div>',
      function(){ const a = document.getElementById('rvImpr'); if (a) a.focus(); });
    return;
  }
  if (p === 'focus'){
    const v = [];
    if (d.ff.n) v.push(['⏱️', 'Oggi hai fatto ' + (d.ff.n === 1 ? 'una sessione' : d.ff.n + ' sessioni') + ' di Full Focus, per ' + rvOre(d.ff.min) + (d.ff.mollate ? ': ' + (d.ff.mollate === 1 ? 'una interrotta' : d.ff.mollate + ' interrotte') + '.' : ', tutte finite.')]);
    else v.push(['⏱️', 'Oggi non hai fatto sessioni di Full Focus.']);
    if (d.app[0]) v.push(['📱', 'Sul telefono: ' + rvOre(d.app[0].min) + ' su ' + d.app[0].nome + (d.app[1] ? ' e ' + rvOre(d.app[1].min) + ' su ' + d.app[1].nome : '') + '.']);
    if (rvDati('focus', 'Ecco *la tua giornata*.', v)) return;
    gnDomanda('pensa', 'Durante i blocchi di lavoro profondo di oggi, *eri davvero concentrato*?',
      rvCarte([['si', '🎯', 'Sì, quasi sempre'], ['meta', '🌗', 'A metà'], ['poco', '🌫️', 'Poco'], ['nessuno', '🚫', 'Oggi niente lavoro profondo']], false));
    return;
  }
  if (p === 'leva'){
    const v = [];
    if (d.prio) v.push([d.prioFatta ? '✅' : '⭕', 'La priorità di oggi era "' + d.prio + '": ' + (d.prioFatta ? 'l’hai chiusa.' : 'non è ancora chiusa.')]);
    try{ if (typeof pntRigheSera === 'function') pntRigheSera().forEach(function(x){ v.push(x); }); }catch(_){ }
    if (d.chiuse.length) v.push(['📋', 'Cose chiuse oggi: ' + d.chiuse.length + (d.chiuse.length === 1 ? ' (' + d.chiuse[0] + ').' : ', fra cui "' + d.chiuse[0] + '".')]);
    if (rvDati('leva', 'Ecco *cosa hai chiuso* oggi.', v)) return;
    gnDomanda('pensa', 'Oggi hai lavorato sulle cose *ad alta leva*, quelle che avvicinano davvero il sogno, o solo su quelle facili?',
      rvCarte([['alta', '🚀', 'Sulla cosa più importante'], ['media', '🧩', 'Su cose utili, non le più importanti'], ['facili', '🪶', 'Sulle cose facili'], ['nessuna', '⏸️', 'Su niente del piano']], true));
    return;
  }
  if (p === 'inter'){
    const a = d.app[0];
    gnDomanda('pensa', 'Cosa, *di preciso*, ti ha interrotto oggi?',
      rvCarte([['app', '📱', a ? a.nome : 'Un’app'], ['notifiche', '🔔', 'Le notifiche'], ['persone', '🗣️', 'Persone o telefonate'], ['testa', '💭', 'I miei pensieri, le idee nuove'], ['energia', '🪫', 'Mi mancava l’energia'], ['niente', '🛡️', 'Niente, è filato liscio']], true));
    return;
  }
  if (p === 'sistema'){
    const k = RV.r.inter, app = (d.app[0] && d.app[0].nome) || 'quell’app';
    const l = {
      app: [['blocca', '🛡️', 'Blocco ' + app + ' nelle ore di lavoro'], ['stanza', '📵', 'Telefono in un’altra stanza durante i blocchi'], ['elimina', '🗑️', 'Tolgo ' + app + ' dal telefono']],
      notifiche: [['silenzio', '🔕', 'Lavoro solo in Full Focus, notifiche chiuse'], ['automatizza', '⚙️', 'Spengo le notifiche che non servono'], ['finestre', '🪟', 'Rispondo ai messaggi in due finestre fisse']],
      persone: [['avviso', '🚪', 'Avviso prima: "adesso non ci sono"'], ['delega', '🤝', 'Delego quello che può fare qualcun altro'], ['finestre', '🪟', 'Telefonate e messaggi in due finestre fisse']],
      testa: [['caveau', '🔒', 'Le idee nuove nel caveau, subito'], ['scrivo', '✍️', 'Scrivo i pensieri che girano, e torno'], ['respiro', '🌬️', 'Dieci minuti di respiro prima del blocco']],
      energia: [['mattina', '🌅', 'Il blocco difficile quando ho più energia'], ['sonno', '🌙', 'Stasera a letto prima'], ['corto', '✂️', 'Blocchi più corti, con le pause']]
    }[k] || [['uguale', '🛡️', 'Tengo il sistema com’è: funziona'], ['alza', '📈', 'Domani alzo l’asticella di un blocco']];
    gnDomanda('pensa', 'Non serve più forza di volontà: serve un sistema migliore. *Cosa cambi* da domani?', rvCarte(l, true));
    return;
  }
  if (p === 'scrivo'){
    gnDomanda('pensa', 'Scrivilo *con parole tue*.', '<textarea class="gn-area" id="rvTesto" rows="4" oninput="rvBozza(\'scrivo\',this.value);rvCampoBtn(this,\'rvTestoOk\',\'Confermo\')" placeholder="Scrivi qui…" onclick="event.stopPropagation()"></textarea><div class="or-grid one"><button type="button" class="or-a" id="rvTestoOk" onclick="event.stopPropagation();rvScrivoOk()">Salta</button></div>',
      function(){ const a = document.getElementById('rvTesto'); if (a) a.focus(); });
    return;
  }
  if (p === 'fine'){ rvFine(); return; }
}
function rvScegli(i){
  const o = RV.opz[i]; if (!o) return;
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  const p = RV.passo;
  if (p === 'focus'){ RV.r.focus = o[0]; RV.r.focusTesto = o[2]; rvVai('leva'); return; }
  if (p === 'leva'){ RV.r.leva = o[0]; RV.r.levaTesto = o[2]; rvVai('inter'); return; }
  if (p === 'inter'){ RV.r.inter = o[0]; RV.r.interTesto = o[2]; rvVai(o[0] === 'niente' ? 'sistema' : 'sistema'); return; }
  if (p === 'sistema'){ RV.r.sistema = o[0]; RV.r.sistemaTesto = o[2]; rvVai('imprevisto'); return; }
  if (p === 'imprevisto'){ rvImprevisto(o[0] === 'si'); return; }
}
function rvScrivo(){ RV.scrivoPer = RV.passo; rvVai('scrivo'); }
function rvScrivoOk(){
  const a = document.getElementById('rvTesto'); const t = a ? a.value.trim() : '';
  /* 0.9.310: lo scritto e' facoltativo. A campo vuoto la domanda si salta e si va alla prossima */
  const per = RV.scrivoPer;
  RV.passo = RV.storia.pop() || RV.passo;
  if (per === 'leva'){ if (t){ RV.r.leva = 'scritto'; RV.r.levaTesto = t; } rvVai('inter'); return; }
  if (per === 'inter'){ if (t){ RV.r.inter = 'scritto'; RV.r.interTesto = t; } rvVai('sistema'); return; }
  if (t){ RV.r.sistema = 'scritto'; RV.r.sistemaTesto = t; } rvVai('imprevisto');
}
/* il pulsante sotto a un campo facoltativo: "Salta" a campo vuoto, la sua parola quando c'e' del testo */
function rvCampoBtn(a, id, pieno){ const b = document.getElementById(id); if (b) b.textContent = a.value.trim() ? pieno : 'Salta'; }
/* la prima cosa di domani: quella che hai scelto, la prima riga del foglio di domani, la prossima tappa della mappa */
function rvDomaniTask(){
  const pulita = function(s){ return String(s || '').replace(/^[☐☑•\-\s]+/, '').replace(/\s*·\s*(oggi|domani)\s*$/i, '').trim(); };
  try{ const o = (typeof stOne === 'function') ? stOne() : null; if (o && !o.done && o.forDay && typeof mtKey === 'function' && o.forDay > mtKey(Date.now())){ const t = pulita(o.task && (o.task.text || o.task.t || o.task)); if (t) return t; } }catch(_){ }
  try{ const l = (typeof stLines === 'function') ? stLines('tomorrow') : []; if (l.length){ const t = pulita(l[0]); if (t) return t; } }catch(_){ }
  try{ const c = (typeof sdCorrente === 'function') ? sdCorrente() : null, n = c && c.nodo; const t = pulita(n && (n.t || n.titolo || n.nome)); if (t) return t; }catch(_){ }
  try{ const t = pulita((typeof gtPrimaTappa === 'function') ? gtPrimaTappa() : ''); if (t) return t; }catch(_){ }
  return '';
}
function rvSalvaEsito(){
  rvRipVia();
  try{ localStorage.removeItem('fl_rv_rifai'); }catch(_){ }
  const r = RV.r, g = rvOggi();
  const l = rvLista().filter(function(x){ return x.giorno !== g; });
  l.push({ giorno: g, at: Date.now(), focus: r.focusTesto || '', leva: r.levaTesto || '', interruzione: r.interTesto || '', contromisura: r.sistemaTesto || '', imprevisto: r.imprevisto || '', dati: RV.dati });
  try{ localStorage.setItem(RV_KEY, JSON.stringify(l.slice(-120))); }catch(_){ }
}
/* 0.9.340, Andrea: "ero alla parte finale, mi ha portato a una pagina (il tutorial) e la revisione era finita": scegliere cosa
   fare con la prima cosa di domani non chiude piu' la revisione. Si arriva alla pagina finale del diario, e la scelta parte
   quando chiudi la giornata. La richiesta all'agente resta nel campo: parte solo con invio */
const RV_DOPO = { scomponi: 'Chiudi e scomponi la prima cosa', tutorial: 'Chiudi e guarda il tutorial', domanda: 'Chiudi e fai la tua domanda', prenota: 'Chiudi e prenota il punto' };
function rvDomaniVia(k){
  RV.dopoAzione = RV_DOPO[k] ? k : '';
  rvVai('fine');
}
function rvDomaniAzione(k){
  const t = rvDomaniTask();
  (function(){
    if (k === 'tutorial'){ if (typeof aiApri === 'function') aiApri(t); return; }
    if (k === 'prenota'){ if (typeof pkPuntoApri === 'function') pkPuntoApri(); return; }
    if (typeof agApri !== 'function') return;
    agApri();
    setTimeout(function(){
      try{ if (typeof agBozza === 'function') agBozza(k === 'scomponi' ? 'Domani la prima cosa è "' + t + '". Scomponila in 3 passi piccoli, così domattina so già da dove partire.' : 'Domani la prima cosa è "' + t + '". Ho una domanda: '); }catch(_){ }
    }, 300);
  })();
}
function rvFine(){
  rvSalvaEsito();
  const r = RV.r;
  const serie = rvSerie();
  gnDomanda('rivela', 'Revisione fatta. Domani il sistema *lavora per te*.',
    /* 0.9.310: una pagina del diario di viaggio (revisioni-periodo.js, rvdPaginaHtml), non un elenco di domande e risposte */
    (typeof rvdPaginaHtml === 'function'
      ? rvdPaginaHtml({ tipo: 'sera', at: Date.now(), focus: r.focusTesto || '', leva: r.levaTesto || '', interruzione: r.interTesto || '', contromisura: r.sistemaTesto || '' }, serie > 1 ? serie + ' sere di fila con la revisione' : '')
      : '')
    /* 0.9.301: il consenso ai dati anonimi che insegnano al Genio (conversa.js), spento finche' non lo accendi */
    + (typeof cvConsensoHtml === 'function' ? cvConsensoHtml() : '')
    + '<div class="or-grid one">'
    + (r.imprevisto ? '<button type="button" class="or-a main" onclick="event.stopPropagation();rvImprevistoAlGenio()">Fai ricalcolare la rotta al Genio</button>' : '')
    /* 0.9.242: la sera si prenota domani (prenota.js): i passi importanti a un'ora precisa */
    + (typeof pkPuntoApri === 'function' ? '<button type="button" class="or-a' + (r.imprevisto ? '' : ' main') + '" onclick="event.stopPropagation();pkPuntoApri()">Prenota il punto di domani</button>' : '')
    + '<button type="button" class="or-a' + (typeof pkPuntoApri === 'function' && !RV.dopoAzione ? '' : ' main') + '" onclick="event.stopPropagation();rvChiudi()">' + (RV.dopoAzione ? RV_DOPO[RV.dopoAzione] : 'Chiudi la giornata') + '</button></div>');
  try{ flVibra([20, 40, 30]); }catch(_){ }
}
/** Per il tuo agente personale: le ultime revisioni della sera. */
function rvPerAgente(){
  const l = rvLista().slice(-5); if (!l.length) return '';
  /* 0.9.310: i campi vuoti (domande saltate, o la sera fatta dentro una revisione di periodo) non si scrivono */
  return 'Revisioni della sera (Fogarty): ' + l.map(function(x){
    return x.giorno + (x.inclusaIn ? ' (dentro la revisione di periodo)' : '') + ' ' + [['concentrazione', x.focus], [x.inclusaIn ? 'ha funzionato' : 'lavoro', x.leva], [x.inclusaIn ? 'gli ha fatto perdere tempo' : 'interruzione', x.interruzione], ['da domani', x.contromisura], ['imprevisto', x.imprevisto]]
      .filter(function(c){ return c[1]; }).map(function(c){ return c[0] + ' "' + c[1] + '"'; }).join(', ');
  }).join('; ') + '.';
}

/* ---------- la card nella Mappa (vista Roadmap): dalle 17 in poi, finche' non e' fatta ----------
   0.9.235, Andrea: finche' la revisione e' da fare, la card compare nella Roadmap, nella Mappa (sopra al
   pannello di pianificazione), in START (sotto alle nuvole) e in Dream; fatta, sparisce ovunque e resta
   solo quella verde in Dream. */
/** 0.9.310: la sera di oggi fatta dentro una revisione di periodo: il nome di quella revisione, o ''. */
function rvInclusaOggi(){ const g = rvOggi(); const x = rvLista().filter(function(v){ return v.giorno === g; }).pop(); return x && x.inclusaIn ? ({ settimana: 'revisione della settimana', mese: 'revisione del mese', trimestre: 'revisione del trimestre', anno: 'revisione dell’anno' }[x.inclusaIn] || '') : ''; }
/* 0.9.340, Andrea: "rimettimi la revisione della sera una tantum adesso, cosi' la rifaccio": una volta sola, per l'amministratore,
   la revisione di oggi si riapre anche prima delle 17. Fatta, il permesso sparisce. */
/* 0.9.347, Andrea: "la revisione della sera di ieri, alle 14 di oggi, e' ancora li'. Quando ti risvegli la mattina non deve piu' esserci,
   altrimenti il Genio fa la revisione del giorno sbagliato. Lo stesso per la settimana: un giorno di ritardo al massimo, poi sparisce".
   Restava aperta la schermata: l'app era in sottofondo dalla sera prima e al ritorno riprendeva da li'. Adesso, quando l'app torna davanti
   (e ogni minuto), una revisione della sera aperta in un giorno passato si chiude dalle 5 del mattino in poi; una revisione di periodo
   si chiude appena il suo periodo non e' piu' quello da rivedere (la settimana: fino a lunedi' compreso). Le risposte date restano. */
function rvScadutaControlla(){
  try{
    if (typeof GN === 'undefined' || !GN.on) return;
    const ora = new Date().getHours();
    if (GN.modo === 'rv' && RV.giorno && RV.giorno !== rvOggi() && ora >= 5){
      rvRipVia(); rvChiudi();
      try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
      if (typeof toast === 'function') toast('La revisione di ieri si è chiusa. Stasera trovi quella di oggi.');
      return;
    }
    if (GN.modo === 'rvp' && typeof RVP !== 'undefined' && RVP.tipo && RVP.periodo && typeof rvpPeriodoDovuto === 'function' && rvpPeriodoDovuto(RVP.tipo) !== RVP.periodo){
      if (typeof rvpChiudi === 'function') rvpChiudi();
      try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
      if (typeof toast === 'function') toast('Il tempo per questa revisione è finito. La prossima arriva da sola.');
    }
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(rvScadutaControlla, 300); });
setInterval(rvScadutaControlla, 60000);
function rvRifai(){ try{ return localStorage.getItem('fl_rv_rifai') === '1'; }catch(_){ return false; } }
setTimeout(function(){
  try{
    if (localStorage.getItem('fl_rv_rifai_340') || !(typeof flAdmin === 'function' && flAdmin())) return;
    localStorage.setItem('fl_rv_rifai_340', '1'); localStorage.setItem('fl_rv_rifai', '1');
    const g = rvOggi(); localStorage.setItem(RV_KEY, JSON.stringify(rvLista().filter(function(x){ return x.giorno !== g; })));
    try{ if (typeof nvsPaint === 'function') nvsPaint(); }catch(_){ }
  }catch(_){ }
}, 2500);
function rvStato(){
  if (rvFattaOggi()) return 'fatta';
  if (rvRifai()) return 'da-fare';
  /* 0.9.310, UNA REVISIONE SOLA: con una revisione di periodo da fare (revisioni-periodo.js) la card della sera non
     compare: quella del periodo la contiene, e fatta lei e' fatta anche la sera */
  try{ if (typeof rvpDovuta === 'function' && rvpDovuta()) return ''; }catch(_){ }
  return new Date().getHours() >= 17 ? 'da-fare' : '';
}
function rvCardHtml(){
  const fatta = rvFattaOggi(), h = new Date().getHours(), serie = rvSerie();
  if (!fatta && h < 17) return '';
  return '<div class="rv-card' + (fatta ? ' fatta' : '') + '" onclick="' + (fatta ? '' : 'rvApri()') + '" role="button"><span class="rv-ico">' + (fatta ? '✅' : '🌙') + '</span><div><small>La revisione della sera</small><b>'
    + (fatta ? 'Fatta. Domani il sistema lavora per te.' : 'Tre domande sulla giornata, e una cosa da cambiare nel sistema.') + '</b>'
    + (serie > 1 ? '<i>' + serie + ' sere di fila</i>' : '') + '</div>' + (fatta ? '' : '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>') + '</div>';
}
function rvCardPaint(){
  /* 0.9.337, Andrea: "le revisioni solo nella scheda Sogno, come prima slide del carosello" */
  ['mppRevisione'].forEach(function(id){ const x = document.getElementById(id); if (x) x.remove(); });
  try{ rvOvunquePaint(); }catch(_){ }
  return;
  const tab = document.getElementById('tab-mappa'); if (!tab) return;
  let h = document.getElementById('mppRevisione');
  const rm = document.getElementById('mppSentiero');
  if (!h){ h = document.createElement('div'); h.id = 'mppRevisione'; h.className = 'mpp-slot'; }
  if (rm && h.nextElementSibling !== rm) rm.parentNode.insertBefore(h, rm);
  let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ }
  h.classList.toggle('mpp-via', v !== 'rotta');
  h.innerHTML = rvStato() === 'da-fare' ? rvCardHtml() : ''; h.hidden = !h.innerHTML;
  try{ rvOvunquePaint(); }catch(_){ }
}
/** Mette uno spazio con id `id` subito prima (o subito dopo) di un elemento. */
function rvSlot(id, rif, dopo){
  if (!rif || !rif.parentNode) return null;
  let h = document.getElementById(id);
  if (!h){ h = document.createElement('div'); h.id = id; h.className = 'rv-slot'; }
  if (dopo){ if (rif.nextElementSibling !== h) rif.parentNode.insertBefore(h, rif.nextSibling); }
  else if (h.nextElementSibling !== rif) rif.parentNode.insertBefore(h, rif);
  return h;
}
function rvOvunquePaint(){
  /* 0.9.337, Andrea: "le revisioni (sera, settimana, mese, trimestre, anno) solo in Sogno, come prima slide grande del carosello
     dove c'e' la tua storia". Le card piccole nelle altre schede si tolgono; la slide la disegna nvsPaint (dream-storia.js). */
  ['mppRevMia', 'stRevisione', 'nvRevisione', 'insRevisione'].forEach(function(id){ const x = document.getElementById(id); if (x) x.remove(); });
  try{ if (typeof nvsPaint === 'function' && document.getElementById('nvsCar')) nvsPaint(NVS.rientro); }catch(_){ }
  return;
  const st = rvStato(); const card = st ? rvCardHtml() : '';
  /* la Mappa, vista "pianifica tu": sopra al pannello di pianificazione */
  const mia = rvSlot('mppRevMia', document.getElementById('mppFoglio'), false);
  if (mia){ let v = 'rotta'; try{ v = (typeof mppVistaCur === 'function') ? mppVistaCur() : 'rotta'; }catch(_){ } mia.classList.toggle('mpp-via', v !== 'mia'); mia.innerHTML = st === 'da-fare' ? card : ''; mia.hidden = !mia.innerHTML; }
  /* START: sotto alle nuvole */
  const sta = rvSlot('stRevisione', document.getElementById('stHero'), true);
  if (sta){ const hs = st === 'da-fare' ? card : ''; if (sta._html !== hs){ sta._html = hs; sta.innerHTML = hs; } sta.hidden = !hs; }
  /* Dream: sopra alla lettura del Genio. Se l'episodio di oggi e' fatto e non c'e' da rientrare in
     rotta, la card da fare prende il posto della lettura (lo fa nvPaint in rotta-tab.js) */
  const top = document.getElementById('nvTop');
  const dr = rvSlot('nvRevisione', top, false);
  if (dr){ const gia = top && top.querySelector('.rv-card'); const hd = (st === 'fatta' || (st === 'da-fare' && !gia)) ? card : ''; if (dr._html !== hd){ dr._html = hd; dr.innerHTML = hd; } dr.hidden = !hd; }
  /* la prossima mossa (0.9.237) sta subito sotto alla lettura del Genio */
  try{ const mo = document.getElementById('nvMossa'); if (mo && top && top.nextElementSibling !== mo) top.parentNode.insertBefore(mo, top.nextSibling); }catch(_){ }
  /* il Report: niente (0.9.235, Andrea aveva scritto Report al posto di Roadmap) */
  const rep = document.getElementById('insRevisione'); if (rep) rep.remove();
}

/* 0.9.234, Andrea: la stessa card anche in cima al Report. Compare dalle 17 finche' la revisione non
   e' fatta; poi resta solo quella verde "Fatta. Domani il sistema lavora per te." (fino a mezzanotte). */
function rvReportPaint(){ try{ rvOvunquePaint(); }catch(_){ } }
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.rv = { entra: rvEntra };
  if (typeof insRender === 'function'){ const v6 = insRender; window.insRender = insRender = function(){ const r = v6.apply(this, arguments); try{ rvReportPaint(); }catch(_){ } return r; }; }
  if (typeof switchTab === 'function'){ const v7 = switchTab; window.switchTab = switchTab = function(t){ const r = v7.apply(this, arguments); setTimeout(function(){ try{ rvOvunquePaint(); }catch(_){ } }, 80); return r; }; }
  /* i blocchi di START, Mappa e Dream si riordinano da soli: dopo, gli spazi tornano al loro posto */
  if (typeof scsOrdinaBlocchi === 'function'){ const v8 = scsOrdinaBlocchi; window.scsOrdinaBlocchi = scsOrdinaBlocchi = function(){ const r = v8.apply(this, arguments); try{ rvOvunquePaint(); }catch(_){ } return r; }; }
  if (typeof cstOrdinaBlocchi === 'function'){ const v9 = cstOrdinaBlocchi; window.cstOrdinaBlocchi = cstOrdinaBlocchi = function(){ const r = v9.apply(this, arguments); try{ rvOvunquePaint(); }catch(_){ } return r; }; }
  setInterval(function(){ try{ rvReportPaint(); rvCardPaint(); }catch(_){ } }, 60000);
  if (typeof gnChiudiTop === 'function'){ const v = gnChiudiTop; gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'rv'){ rvChiudi(); return; } return v.apply(this, arguments); }; }
  if (typeof gnIndietro === 'function'){ const v2 = gnIndietro; gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rv') return rvIndietro(); return v2.apply(this, arguments); }; }
  if (typeof mppPaint === 'function'){ const v3 = mppPaint; window.mppPaint = mppPaint = function(){ const r = v3.apply(this, arguments); try{ rvCardPaint(); }catch(_){ } return r; }; }
  if (typeof mppApplicaVista === 'function'){ const v4 = mppApplicaVista; window.mppApplicaVista = mppApplicaVista = function(){ const r = v4.apply(this, arguments); try{ rvCardPaint(); }catch(_){ } return r; }; }
  if (typeof rnPerAgente === 'function'){ const v5 = rnPerAgente; window.rnPerAgente = rnPerAgente = function(){ return [v5.apply(this, arguments), rvPerAgente()].filter(Boolean).join(' '); }; }
  const st = document.createElement('style');
  st.textContent = [
    '#mppRevisione{padding:0 16px;margin:8px 0 10px}#mppRevisione[hidden]{display:none}',
    '.rv-slot[hidden]{display:none}#mppRevMia{padding:0 16px;margin:8px 0 10px}#stRevisione{padding:0 16px;margin:10px 0 12px}#nvRevisione{margin:0 0 14px}',
    '.rv-card{display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:20px;background:linear-gradient(135deg,#1E2A5A,#0F2041);color:#fff;cursor:pointer;box-shadow:0 10px 24px rgba(0,20,60,.18)}.rv-card.fatta{cursor:default;background:#EAF6EF;color:#14234A;box-shadow:none}',
    '.rv-card > div{flex:1;min-width:0}.rv-ico{font-size:28px;flex:none}.rv-card small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.rv-card.fatta small{color:#1B9E6A}',
    '.rv-card b{display:block;margin-top:3px;font:700 14.5px/1.4 var(--font-body)}.rv-card i{display:block;margin-top:3px;font:600 12px var(--font-body);font-style:normal;color:#8CC6FF}.rv-card.fatta i{color:#1B9E6A}'
  ].join('');
  document.head.appendChild(st);
})();

(function rvStile(){
  const st = document.createElement('style');
  st.textContent = '.rv-facce{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.rv-facce button{display:flex;flex-direction:column;align-items:center;gap:8px;border:0;border-radius:16px;background:rgba(0,117,227,.08);padding:14px 2px;cursor:pointer}.rv-facce span{font-size:34px;line-height:1}.rv-facce small{font:700 11.5px var(--font-body);color:#0E2350;text-align:center}body.dark .rv-facce small{color:#EEF4FF}body.dark .rv-facce button{background:rgba(255,255,255,.08)}.rv-facce button:active{transform:scale(.94)}';
  document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '.rv-dom{margin:4px 0 18px;padding:18px 16px;border-radius:18px;background:rgba(188,224,255,.14);text-align:center}.rv-dom small{display:block;font:700 12px var(--font-body);letter-spacing:.04em;color:#BCE0FF}.rv-dom b{display:block;margin-top:8px;font:800 19px/1.3 var(--font-display);color:#fff}.rv-dom + .or-grid + .or-grid{margin-top:10px}';
  document.head.appendChild(st);
})();
