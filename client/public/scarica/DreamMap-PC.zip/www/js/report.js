/* ===========================================================================================
   IL REPORT: le categorie, le impostazioni, e l'invito a mettere in ordine

   Tre pezzi che rispondono alla stessa domanda posta a tre altezze diverse.

   1. LE LINGUETTE DELLE CATEGORIE, sotto al grafico. Il grafico dice QUANTO; le linguette
      dicono IN CHE COSA. «Quattro ore» è un numero che non si sa dove mettere; «un'ora e mezza
      di giochi» è una frase su cui si può decidere qualcosa. Sono scorrevoli e ordinate per
      tempo, così la prima che si vede è sempre quella che pesa di più — che è anche l'unica
      che qualcuno guarderà davvero.

   2. LE IMPOSTAZIONI, in una pagina. Erano un menù a tendina di tre voci appeso all'ingranaggio:
      per tre voci andava bene, ma le impostazioni del Report sono quelle che decidono cosa i
      numeri SIGNIFICANO — quali app contano, come sono classificate, cosa viene escluso. Una
      cosa così non sta in un menù che si chiude se sbagli a toccare.

   3. L'INVITO A ORDINARE LE APP, ogni tanto. Senza categorie il Report è un elenco di nomi con
      dei minuti accanto: vero, e inutile. Ma chiederlo al primo avvio vuol dire chiederlo a chi
      non ha ancora capito perché servirebbe. Quindi si chiede dopo, quando ci sono già dati
      veri da mettere in ordine, e si chiede di rado: una volta ogni dieci giorni, mai se non
      c'è niente da ordinare, mai due volte se si è detto di no da poco.

   PERCHÉ LE CATEGORIE SONO GIÀ SCRITTE. `FL_CATS` (categories.js) esiste da prima e serve al
   Blocco rapido: dieci gruppi con dentro i pacchetti delle app più comuni. Riusarlo vuol dire
   che un'app appena installata è già nella sua categoria senza che nessuno la smisti a mano —
   e che una correzione fatta lì vale anche qui.
   =========================================================================================== */

/* ---------------------------------------------------------------------------------------
   1. Le linguette
   --------------------------------------------------------------------------------------- */

/** In quale gruppo di FL_CATS sta questo pacchetto. Vuoto = nessuno. */
function rpCatDi(pkg){
  if (!pkg || typeof FL_CATS === 'undefined') return '';
  for (let i = 0; i < FL_CATS.length; i++){
    if ((FL_CATS[i].apps || []).indexOf(pkg) >= 0) return FL_CATS[i].id;
  }
  return '';
}

function rpCatInfo(id){
  if (id === 'altro') return { id: 'altro', ic: '\u{1F4F1}', name: 'Altro' };
  if (String(id).indexOf('dm-') === 0 && typeof taCat === 'function'){
    const c = taCat(String(id).slice(3));
    return { id: id, ic: c.ic, name: c.l };
  }
  if (typeof FL_CATS === 'undefined') return null;
  return FL_CATS.filter(function(c){ return c.id === id; })[0] || null;
}

/**
 * Le linguette, con i minuti di ognuna.
 *
 * <p>Si disegnano solo se le categorie riconosciute sono almeno due: con una sola la fila
 * diventa un'etichetta che non filtra niente, e una cosa che sembra un comando e non lo è
 * costa più di una cosa che non c'è.</p>
 */
/* ---------------------------------------------------------------------------------------
   DENTRO DREAMMAP NELLE LINGUETTE (tempo-app.js)

   Il tempo passato dentro l'app non e' un'app sola: i giochi col Genio vanno nella linguetta
   dei Giochi, gli amici e la lega in Social, il Full Focus in "Lavoro sul sogno", scegliere
   la musica in "Sistemare l'app". Toccando una linguetta si vede il dettaglio.
   --------------------------------------------------------------------------------------- */
const RP_DM_CAT = { giochi: 'games', social: 'social', altro: 'altro' };
function rpDmChip(cat){ return RP_DM_CAT[cat] || ('dm-' + cat); }
/** Il periodo che il Report sta guardando: il giorno o la settimana. */
function rpPeriodo(){
  try{
    if (typeof INS === 'undefined') return null;
    if (INS.view === 'giorno' && typeof insDayStart === 'function'){
      const da = insAddDays(insDayStart(Date.now()), -INS.dayOff);
      /* 0.9.299: con un'ora scelta sul grafico, solo quell'ora */
      if (INS.oraSel != null && INS.oraSelDay === da){ const s0 = new Date(da); s0.setHours(INS.oraSel, 0, 0, 0); return { da: s0.getTime(), a: s0.getTime() + 3600000 }; }
      return { da: da, a: insAddDays(da, 1) };
    }
    if (INS.view === 'settimana' && typeof insWeekStart === 'function'){
      const da = insAddDays(insWeekStart(Date.now()), -7 * INS.weekOff);
      return { da: da, a: insAddDays(da, 7) };
    }
  }catch(_){ }
  return null;
}
/** Le aree dell'app nel periodo, ognuna con la sua linguetta. */
function rpDentro(){
  const per = rpPeriodo();
  if (!per || typeof taRiassunto !== 'function') return [];
  /* il filtro dei tre puntini (distraente, neutro, produttivo) giudica le app: l'app nostra non ha un giudizio */
  if (typeof INS !== 'undefined' && INS.filter && INS.filter !== 'all') return [];
  try{
    return taRiassunto(per.da, per.a).perArea.filter(function(a){ return a.ms >= 30000; })
      .map(function(a){ return Object.assign({ chip: rpDmChip(a.c) }, a); });
  }catch(_){ return []; }
}
/** I millisecondi dentro l'app che cadono nella linguetta scelta (per il numero grande). */
function rpDentroSelMs(){
  const id = (typeof INS !== 'undefined' && INS.catFiltro) || '';
  if (!id) return 0;
  return rpDentro().filter(function(a){ return a.chip === id; }).reduce(function(t, a){ return t + a.ms; }, 0);
}
/** Il dettaglio della linguetta scelta: le attivita' dentro DreamMap, dalla piu' lunga. */
function rpDentroDettaglio(sel, dentro){
  const qui = dentro.filter(function(a){ return a.chip === sel; });
  if (!qui.length) return '';
  const fmt = (typeof insFmt === 'function') ? insFmt : function(ms){ return Math.round(ms / 60000) + 'm'; };
  const max = qui[0].ms || 1;
  return '<div class="rp-dm"><p class="rp-dm-t">Dentro DreamMap</p>'
    + qui.map(function(a){
        const col = (typeof taCat === 'function') ? taCat(a.c).col : '#0075E3';
        return '<div class="rp-dm-r"><div class="rp-dm-n"><b>' + esc(a.l) + '</b>'
          + '<span class="rp-dm-bar"><i style="width:' + Math.max(3, Math.round(a.ms / max * 100)) + '%;background:' + col + '"></i></span></div>'
          + '<span class="rp-dm-m">' + fmt(a.ms) + '</span></div>';
      }).join('')
    + '</div>';
}

function rpCatChips(apps, totalMs){
  const tot = {};
  (apps || []).forEach(function(a){
    const c = rpCatDi(a.packageName) || 'altro';
    tot[c] = (tot[c] || 0) + (a.ms || 0);
  });
  /* 0.9.299, Andrea: "sotto al grafico ci devono essere le linguette generali, non quelle di DreamMap": le aree
     dentro l'app stanno nel cassetto di DreamMap, nelle app piu' usate (insights.js insIoGruppo) */
  const ids = Object.keys(tot).filter(function(k){ return k !== 'altro'; });
  ids.sort(function(a, b){ return tot[b] - tot[a]; });
  if (tot.altro) ids.push('altro');

  const sel = INS.catFiltro || '';
  /* 0.9.302, Andrea: "la 3m isolata sopra al pannello". Senza app nell'elenco (a mezzanotte e tre c'e' solo
     DreamMap, che sta fuori dalle app piu' usate) restava la sola linguetta del totale: un "3m" orfano che
     ripete il numero grande. La linguetta del totale ha senso solo accanto alle categorie. */
  if (!ids.length && !sel) return '';
  const fmt = (typeof insFmt === 'function') ? insFmt : function(ms){ return Math.round(ms / 60000) + 'm'; };
  /* LA PRIMA LINGUETTA E' IL TOTALE, senza icona e senza nome: e' quella che, toccata, toglie
     la scelta. Non c'e' «Tutto» perche' il totale e' gia' quella cosa. */
  let out = '<button type="button" class="rp-cat' + (sel ? '' : ' on') + '" onclick="rpSetCat(\'\')">'
    + '<b>' + fmt(totalMs || 0) + '</b></button>';
  ids.forEach(function(id){
    const c = rpCatInfo(id);
    if (!c) return;
    out += '<button type="button" class="rp-cat' + (sel === id ? ' on' : '') + '" onclick="rpSetCat(\'' + id + '\')">'
      + c.ic + '<b>' + fmt(tot[id]) + '</b></button>';
  });
  return '<div class="rp-cats">' + out + '</div>';
}

function rpSetCat(id){
  INS.catFiltro = (INS.catFiltro === id) ? '' : id;
  INS.forceRender = true;
  if (typeof insRender === 'function') insRender();
}

/** L'elenco delle app, ridotto alla categoria scelta. */
function rpFiltra(apps){
  const id = INS.catFiltro || '';
  if (!id || !apps) return apps;
  return apps.filter(function(a){ return (rpCatDi(a.packageName) || 'altro') === id; });
}

/* ---------------------------------------------------------------------------------------
   2. La pagina delle impostazioni
   --------------------------------------------------------------------------------------- */

function rpImpostazioni(){
  goId('s-repimp');
  rpImpPaint();
}

/* LA PAGINA MADRE: tre righe, come «Impostazioni approfondimenti» di AppBlock.
   Non e' una questione di somiglianza: le tre righe sono tre domande diverse — cosa viene
   misurato, cosa non deve contare, come ti sei sentito — e impilarle in una pagina sola
   costringeva a leggerle tutte per trovarne una. */
function rpImpPaint(){
  const box = document.getElementById('rpImpBody');
  if (!box) return;
  /* LE TUE, non le ventisette di fabbrica: la riga risponde a «quante ne hai escluse TU».
     Il `small` vuoto nelle altre due righe non e' una svista — e' lui a portare il margine
     automatico che spinge la freccia a destra. */
  const nEx = (typeof insExclMie === 'function') ? insExclMie().length : 0;
  box.innerHTML =
      '<div class="setrow" onclick="rpStatApri()"><span>\u2699\uFE0F</span><b>Cosa misura il report</b>'
    +   '<small></small><span class="chev"></span></div>'
    + '<div class="setrow" onclick="rpEsclApri()"><span class="rp-xico">\u2715</span><b>App escluse</b>'
    +   '<small>' + nEx + '</small><span class="chev"></span></div>'
    + '<div class="setrow" onclick="rpUmoreApri()"><span class="rp-dots"><i></i><i></i></span>'
    +   '<b>Controllo sensazione app</b><small></small><span class="chev"></span></div>'
    + '<div class="setrow" onclick="rpUmoreGiorniApri()"><span>🌤️</span><b>Il tuo umore</b><small>' + (rpUmPromCfg().on ? 'promemoria alle ' + esc(rpUmPromCfg().ora) : '') + '</small><span class="chev"></span></div>'
    + '<div class="spacer"></div>';
}

/* ---------------------------------------------------------------------------------------
   2a. «Impostazioni»: cosa viene misurato

   QUATTRO INTERRUTTORI VERI. Il primo comanda gli altri tre, e spegnerlo non nasconde
   soltanto: ferma anche quello che il motore stava scrivendo. «Statistiche di navigazione»
   spenta ferma il cronometro per sito; «Statistiche in incognito» spenta fa saltare le
   finestre private. La differenza fra questa pagina e un pannello di finte levette e' tutta
   nel fatto che qui sotto c'e' del codice che le legge.
   --------------------------------------------------------------------------------------- */

function rpStatApri(){ goId('s-repstat'); rpStatPaint(); }

/** Il valore di un interruttore. Accese di fabbrica tutte tranne l'incognito. */
function rpStat(k){
  const S = (typeof SETTINGS !== 'undefined' && SETTINGS) ? SETTINGS : {};
  if (k === 'statsIncognito') return S.statsIncognito === true;
  return S[k] !== false;
}

async function rpStatSet(k){
  const patch = {};
  patch[k] = !rpStat(k);
  if (typeof settingsSave === 'function') await settingsSave(patch);
  else if (typeof SETTINGS !== 'undefined') Object.assign(SETTINGS, patch);
  rpStatPaint();
  /* Il Report sta dietro a questa pagina e mostra quello che gli interruttori decidono:
     ridisegnarlo adesso evita che, tornando indietro, resti a schermo la versione di prima. */
  if (typeof INS !== 'undefined'){ INS.forceRender = true; }
}

function rpStatPaint(){
  const box = document.getElementById('rpStatBody');
  if (!box) return;
  const master = rpStat('statsOn');
  const riga = function(k, ico, label, sotto){
    const on = rpStat(k);
    const spento = (k !== 'statsOn' && !master) ? ' rp-off' : '';
    return '<div class="setrow' + spento + '" onclick="rpStatSet(\'' + k + '\')">'
      + '<span>' + ico + '</span><b>' + label + (sotto ? '<i class="rp-sub">' + sotto + '</i>' : '') + '</b>'
      + '<span class="sw' + (on ? ' on' : '') + '" style="margin-left:auto"></span></div>';
  };
  box.innerHTML =
      riga('statsOn', '\u{1F4CA}', 'Statistiche', '')
    + '<div style="height:14px"></div>'
    + riga('statsApps', '\u{1F4F1}', 'Statistiche app', '')
    + riga('statsWeb', '\u{1F310}', 'Statistiche di navigazione', '')
    + riga('statsIncognito', '\u{1F648}', 'Statistiche in incognito', '')
    /* 0.9.280: arrivano dal menu dei tre puntini del pannello "Dove va la tua attenzione?" */
    + '<div style="height:14px"></div>'
    + '<div class="setrow" onclick="rpLockedSet()"><span>\u{1F512}</span><b>Conta il tempo dietro al blocco schermo<i class="rp-sub">Anche il tempo a schermo bloccato entra nel totale</i></b><span class="sw' + ((typeof SC !== 'undefined' && SC.countLocked) ? ' on' : '') + '" style="margin-left:auto"></span></div>'
    + '<div class="setrow" onclick="rpNavSet()"><span>\u{1F5FA}\uFE0F</span><b>Togli Maps e Waze dalla lista<i class="rp-sub">Il navigatore in macchina non conta come distrazione</i></b><span class="sw' + ((typeof scNavNascosti === 'function' && scNavNascosti()) ? ' on' : '') + '" style="margin-left:auto"></span></div>'
    /* 0.9.303: la frase "le statistiche non escono dal dispositivo" e' passata all'informativa sulla privacy
       (legal/privacy.html, "Accesso ai dati di utilizzo"), detta per intero: escono solo con il computer collegato. */
    + rpDueDispHtml()
    + '<div class="spacer"></div>';
}

/* ---------------------------------------------------------------------------------------
   2a-bis. TELEFONO E COMPUTER (0.9.303)

   Andrea: con "Tutti e due insieme" un'ora poteva fare 101 minuti. LA CAUSA: motore-web.js metteva in fila i
   granelli del telefono e quelli del computer e li SOMMAVA, anche quando i due erano accesi nello stesso momento
   (il telefono in mano mentre il computer resta su una pagina). Adesso, di serie, il tempo in cui li usi insieme
   si conta una volta sola (l'unione degli intervalli, mwUnione); i minuti per app restano quelli di ogni app.
   Qui c'e' l'interruttore, e la scelta di quali dati guardare: una sola per telefono e computer (mwSetFonte la
   manda all'altro dispositivo). Le due righe compaiono solo a chi ha davvero due dispositivi collegati.
   --------------------------------------------------------------------------------------- */
function rpDueDispHtml(){
  if (typeof mwDueDispositivi !== 'function' || !mwDueDispositivi()) return '';
  const f = (typeof mwFonte === 'function') ? mwFonte() : 'telefono';
  const unione = (typeof mwUnioneOn === 'function') ? mwUnioneOn() : true;
  const pill = function(k, t){
    return '<button type="button" class="' + (f === k ? 'on' : '') + '" onclick="rpFonteSet(\'' + k + '\')">' + t + '</button>';
  };
  return '<div class="sect rp-sect"><b>Telefono e computer</b></div>'
    + '<div class="rp-fonte" role="group" aria-label="Quali dati mostra il report">'
    +   pill('telefono', '\u{1F4F1} Telefono') + pill('computer', '\u{1F4BB} Computer') + pill('insieme', '\u{1F517} Tutti e due')
    + '</div>'
    + '<p class="hintline rp-fonte-nota">La scelta vale sul telefono e sul computer.</p>'
    + '<div class="setrow' + (f === 'insieme' ? '' : ' rp-off') + '" onclick="rpUnioneSet()"><span>\u23F1\uFE0F</span>'
    +   '<b>Conta una volta sola il tempo in cui usi telefono e computer insieme'
    +   '<i class="rp-sub">' + (f === 'insieme'
          ? 'Se li usi nello stesso momento, quel tempo entra nel totale una volta sola'
          : 'Vale quando guardi i dati di tutti e due insieme') + '</i></b>'
    +   '<span class="sw' + (unione ? ' on' : '') + '" style="margin-left:auto"></span></div>';
}
function rpFonteSet(v){
  if (typeof mwScegli === 'function') mwScegli(v);
  else if (typeof mwSetFonte === 'function') mwSetFonte(v);
  rpStatPaint();
}
function rpUnioneSet(){
  if (typeof mwUnioneSet === 'function') mwUnioneSet(!mwUnioneOn());
  rpStatPaint();
}

async function rpLockedSet(){ if (typeof scLockedToggle === 'function') await scLockedToggle(!(typeof SC !== 'undefined' && SC.countLocked)); rpStatPaint(); }
function rpNavSet(){ if (typeof scNavNascondiSet === 'function') scNavNascondiSet(!scNavNascosti()); rpStatPaint(); }
function rpAppRighe(){
  const nCat = Object.keys((typeof insCats === 'function') ? insCats() : {}).length;
  return ((typeof insPromoHtml === 'function') ? insPromoHtml(false, (nCat ? nCat + ' app già classificate. ' : '') + 'Segna o escludi le tue app per ottenere statistiche migliori', 'insights') : '')
    + '<div class="setrow" onclick="rpAzzeraCat()"><span>↺</span><b>Azzera le categorie</b>'
    +   '<small>' + (nCat ? 'ricomincia da zero' : '') + '</small><span class="chev"></span></div>';
}
function rpAzzeraCat(){
  if (typeof insResetCats === 'function') insResetCats();
  rpUmorePaint();
}

/* ---------------------------------------------------------------------------------------
   2b. «App escluse»: due schede, come su AppBlock

   PERCHE' DUE E NON UNA. Le predefinite e le personalizzate rispondono a due domande
   diverse. Le prime dicono «questo e' il telefono, non una tua abitudine» — e chi le guarda
   le guarda per togliere qualcosa dall'elenco, cioe' per DISFARE una scelta dell'app. Le
   seconde sono le proprie, e chi le guarda vuole aggiungerne. Metterle nella stessa lista
   vorrebbe dire far somigliare una decisione presa da FocusLock a una presa da chi legge.
   --------------------------------------------------------------------------------------- */

const RP_ESCL = { scheda: 'mie', apps: null, inst: null, cerca: false };

function rpEsclApri(){ goId('s-repescl'); rpEsclPaint(); rpEsclCarica(); rpEsclInstallate(); }
/* 0.9.307, Andrea: "App escluse" troppo lenta. Le icone delle escluse si preparano prima (all'avvio e quando
   si apre il Report), nella stessa cache del Report: alla pagina arrivano gia' pronte. */
function rpEsclPrecarica(){
  if (typeof insIconePrecarica !== 'function') return;
  const mie = (typeof insExclMie === 'function') ? insExclMie() : [];
  const pre = (typeof INS_PREDEF !== 'undefined') ? INS_PREDEF : [];
  insIconePrecarica(mie.concat(pre));
}
setTimeout(function(){ try{ rpEsclPrecarica(); }catch(_){ } }, 2500);
document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights') try{ rpEsclPrecarica(); }catch(_){ } });
function rpEsclScheda(k){ RP_ESCL.scheda = k; rpEsclPaint(); }

/** L'elenco installato, una volta sola: serve per i nomi veri al posto dei pacchetti. */
async function rpEsclCarica(){
  if (RP_ESCL.apps || typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInstalledApps) return;
  try{
    const r = await flApps();
    RP_ESCL.apps = (r && r.apps) || [];
  }catch(_){ RP_ESCL.apps = []; }
  rpEsclPaint();
}

/** Il nome vero, o il pacchetto: quello che si sa, mai un'invenzione. */
function rpEsclNome(pkg){
  const a = (RP_ESCL.apps || []).filter(function(x){ return x.packageName === pkg; })[0];
  return (a && a.label) || pkg;
}

function rpEsclRiga(pkg){
  return '<div class="rp-er">'
    + '<span class="rp-ico">?<img class="ub-appico" data-pkg="' + esc(pkg) + '" alt=""></span>'
    + '<b>' + esc(rpEsclNome(pkg)) + '</b>'
    + '<button type="button" class="rp-meno" onclick="rpEsclTogli(\'' + esc(pkg) + '\')" '
    +   'aria-label="Rimetti dentro">−</button></div>';
}

function rpEsclTogli(pkg){
  if (typeof insToggleExcl === 'function') insToggleExcl(pkg);
  if (typeof INS !== 'undefined') INS.forceRender = true;
  if (typeof INS_CACHE !== 'undefined' && INS_CACHE.clear) INS_CACHE.clear();
  rpEsclPaint();
}

function rpEsclPaint(){
  const box = document.getElementById('rpEsclBody');
  if (!box) return;
  const mie = (typeof insExclMie === 'function') ? insExclMie() : [];
  let pre = (typeof insPredefAttive === 'function') ? insPredefAttive() : [];
  /* SOLO QUELLE CHE CI SONO. L'elenco di fabbrica copre Google, Samsung, Xiaomi e Huawei
     insieme: su un telefono solo, meta' di quei nomi sono app che non esistono. Finche' non
     si sa chi e' installato si mostra tutto — meglio una riga di troppo che una mancante —
     e appena si sa, l'elenco si stringe. */
  if (RP_ESCL.inst) pre = pre.filter(function(p){ return RP_ESCL.inst.indexOf(p) >= 0; });
  const k = RP_ESCL.scheda;

  let corpo;
  if (k === 'mie'){
    corpo = mie.length
      ? mie.map(rpEsclRiga).join('')
      : '<div class="rp-vuoto">'
        + '<div class="rp-vart"><i class="a">\u{1F5FA}\uFE0F</i><i class="b">\u{1F3E6}</i>'
        +   '<i class="c">\u{1F3AC}</i><i class="d">\u{1F3B5}</i><i class="e">\u{1F4AC}</i></div>'
        + '<h3>Tieni traccia solo di ciò che conta</h3>'
        + '<p>Escludi le app che non vuoi contare nel Report, come mappe, strumenti bancari o '
        +   'di lavoro.</p>'
        + '<button type="button" class="cta" onclick="rpEsclAggiungi()">+ Aggiungi app da escludere</button>'
        + '</div>';
  } else {
    corpo = pre.length
      ? pre.map(rpEsclRiga).join('')
        + '<p class="hintline" style="padding:14px 2px 0">Sono il telefono, non le tue '
        +   'abitudini: DreamMap non li conta. Tocca il meno per rimetterli nel conto.</p>'
      : '<div class="rp-vuoto"><h3>Nessuna esclusione di fabbrica</h3>'
        + '<p>Le hai rimesse tutte nel conto: da adesso anche il sistema pesa sul tuo tempo di schermo.</p></div>';
  }

  box.innerHTML =
      '<div class="rp-tabs">'
    +   '<button type="button" class="' + (k === 'mie' ? 'on' : '') + '" onclick="rpEsclScheda(\'mie\')">Personalizzate</button>'
    +   '<button type="button" class="' + (k === 'pre' ? 'on' : '') + '" onclick="rpEsclScheda(\'pre\')">Predefinite</button>'
    + '</div>'
    + corpo
    + (k === 'mie' && mie.length
        ? '<button type="button" class="rp-piu" onclick="rpEsclAggiungi()" aria-label="Aggiungi">+</button>'
        : '')
    + '<div class="spacer"></div>';

  if (typeof ubFillIcons === 'function') try{ ubFillIcons(box); }catch(_){ }
  if (k === 'pre') rpEsclInstallate();
}

/* Chi c'e' davvero su questo telefono: se il motore non sa disegnare l'icona di un
   pacchetto, quel pacchetto non e' installato. Una volta per sessione, e mai in anteprima. */
async function rpEsclInstallate(){
  if (RP_ESCL.inst || RP_ESCL.cerca) return;
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getAppIcon) return;
  RP_ESCL.cerca = true;
  const lista = (typeof INS_PREDEF !== 'undefined') ? INS_PREDEF : [];
  /* 0.9.307: tutte insieme e dalla cache delle icone (prima una alla volta, ognuna con la sua attesa) */
  const icone = await Promise.all(lista.map(function(p){
    if (typeof insIcona === 'function') return insIcona(p).catch(function(){ return ''; });
    return NATIVE.getAppIcon({ packageName: p }).then(function(r){ return (r && r.icon) || ''; }).catch(function(){ return ''; });
  }));
  const ci = lista.filter(function(p, i){ return String(icone[i] || '').indexOf('data:image') === 0; });
  RP_ESCL.inst = ci;
  RP_ESCL.cerca = false;
  if (document.getElementById('rpEsclBody')) rpEsclPaint();
}

/* Aggiungere si fa da dove le app sono gia' tutte in fila con i loro minuti: nella pagina
   dove si ordinano. Un secondo elenco di app installate, qui dentro, sarebbe lo stesso
   elenco con un titolo diverso. */
function rpEsclAggiungi(){ rpAddApri(); }

/* ---------------------------------------------------------------------------------------
   2b-bis. «Escludi app»: la pagina di AppBlock

   Barra di ricerca in alto, le categorie a scomparsa con una casella ciascuna, le app
   dentro con la loro casella, «Salva» in fondo. Le categorie sono FL_CATS (categories.js)
   piu' «Altro» per quello che non sta in nessuna: le stesse dieci che il Blocco rapido usa
   da sempre, cosi' un'app e' nella stessa cassetta ovunque la si cerchi.
   --------------------------------------------------------------------------------------- */

const RP_ADD = { apps: null, sel: {}, aperte: {}, q: '' };

function rpAddApri(){
  RP_ADD.sel = {};
  (typeof insExclMie === 'function' ? insExclMie() : []).forEach(function(p){ RP_ADD.sel[p] = true; });
  RP_ADD.aperte = {};
  RP_ADD.q = '';
  goId('s-repadd');
  rpAddPaint();
  rpAddCarica();
}

async function rpAddCarica(){
  if (RP_ADD.apps){ rpAddPaint(); return; }
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInstalledApps){ RP_ADD.apps = []; rpAddPaint(); return; }
  try{
    const r = await flApps();
    RP_ADD.apps = ((r && r.apps) || []).slice().sort(function(a, b){
      return String(a.label || '').localeCompare(String(b.label || ''));
    });
  }catch(_){ RP_ADD.apps = []; }
  rpAddPaint();
}

/** I gruppi: ogni categoria con le sue app installate, e «Altro» in coda. */
function rpAddGruppi(){
  const apps = RP_ADD.apps || [];
  const q = RP_ADD.q.trim().toLowerCase();
  const passa = function(a){
    if (!q) return true;
    return String(a.label || '').toLowerCase().indexOf(q) >= 0 || String(a.packageName || '').toLowerCase().indexOf(q) >= 0;
  };
  const gruppi = [];
  const messe = {};
  ((typeof FL_CATS !== 'undefined') ? FL_CATS : []).forEach(function(c){
    const dentro = apps.filter(function(a){ return (c.apps || []).indexOf(a.packageName) >= 0 && passa(a); });
    dentro.forEach(function(a){ messe[a.packageName] = 1; });
    if (dentro.length) gruppi.push({ id: c.id, ic: c.ic, name: c.name, apps: dentro });
  });
  const altro = apps.filter(function(a){ return !messe[a.packageName] && passa(a); });
  if (altro.length) gruppi.push({ id: 'altro', ic: '\u{1F4F1}', name: 'Altro', apps: altro });
  return gruppi;
}

function rpAddCasella(on, mezzo){
  return '<span class="rp-ck2' + (on ? ' on' : (mezzo ? ' mezzo' : '')) + '">' + (on ? '\u2713' : (mezzo ? '\u2212' : '')) + '</span>';
}

function rpAddPaint(){
  const box = document.getElementById('rpAddBody');
  if (!box) return;
  if (!RP_ADD.apps){
    box.innerHTML = '<p class="hintline" style="padding:16px 2px">Leggo le app installate\u2026</p>';
    return;
  }
  const gruppi = rpAddGruppi();
  const q = RP_ADD.q.trim();
  let html = '';
  gruppi.forEach(function(g){
    const n = g.apps.filter(function(a){ return RP_ADD.sel[a.packageName]; }).length;
    const tutte = n === g.apps.length, mezzo = n > 0 && !tutte;
    const aperto = q ? true : !!RP_ADD.aperte[g.id];
    html += '<div class="rp-g">'
      + '<div class="rp-gr" onclick="rpAddApri2(\'' + g.id + '\')">'
      +   '<span class="rp-gchev' + (aperto ? ' up' : '') + '"></span>'
      +   '<span class="rp-gico">' + g.ic + '</span>'
      +   '<b>' + esc(g.name) + '</b>'
      +   '<span class="rp-gck" onclick="event.stopPropagation();rpAddGruppo(\'' + g.id + '\')">' + rpAddCasella(tutte, mezzo) + '</span>'
      + '</div>'
      + (aperto ? '<div class="rp-gapps">' + g.apps.map(function(a){
          return '<div class="rp-ga" onclick="rpAddToggle(\'' + esc(a.packageName) + '\')">'
            + '<span class="rp-ico"><img class="ub-appico" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
            + '<b>' + esc(a.label || a.packageName) + '</b>'
            + rpAddCasella(!!RP_ADD.sel[a.packageName], false) + '</div>';
        }).join('') + '</div>' : '')
      + '</div>';
  });
  if (!html) html = '<p class="hintline" style="padding:16px 2px">' + (q ? 'Nessuna app con questo nome.' : 'Nessuna app installata da mostrare.') + '</p>';
  html += '<div style="height:90px"></div>';
  box.innerHTML = html;
  if (typeof ubFillIcons === 'function') try{ ubFillIcons(box); }catch(_){ }
}

function rpAddApri2(id){ RP_ADD.aperte[id] = !RP_ADD.aperte[id]; rpAddPaint(); }
function rpAddToggle(pkg){ RP_ADD.sel[pkg] = !RP_ADD.sel[pkg]; rpAddPaint(); }
function rpAddGruppo(id){
  const g = rpAddGruppi().filter(function(x){ return x.id === id; })[0];
  if (!g) return;
  const tutte = g.apps.every(function(a){ return RP_ADD.sel[a.packageName]; });
  g.apps.forEach(function(a){ RP_ADD.sel[a.packageName] = !tutte; });
  rpAddPaint();
}
function rpAddCerca(v){ RP_ADD.q = v || ''; rpAddPaint(); }

/** «Salva»: le caselle diventano l'elenco personale delle escluse, e si torna alle schede. */
function rpAddSalva(){
  const lista = Object.keys(RP_ADD.sel).filter(function(p){ return RP_ADD.sel[p]; });
  try{ localStorage.setItem('fl_ins_excl', JSON.stringify(lista)); }catch(_){ }
  if (typeof INS !== 'undefined') INS.forceRender = true;
  if (typeof INS_CACHE !== 'undefined' && INS_CACHE.clear) INS_CACHE.clear();
  if (typeof toast === 'function') toast(lista.length ? lista.length + (lista.length === 1 ? ' app esclusa' : ' app escluse') : 'Nessuna app esclusa');
  RP_ESCL.scheda = 'mie';
  rpEsclApri();
}

/* ---------------------------------------------------------------------------------------
   2c. «Controllo sensazione app»: la domanda di fine giornata
   --------------------------------------------------------------------------------------- */

const RP_UM_OFF = 'fl_um_off';
function rpUmoreOff(){ try{ return localStorage.getItem(RP_UM_OFF) === '1'; }catch(_){ return false; } }
function rpUmoreApri(){ goId('s-repum'); rpUmorePaint(); }
function rpUmoreSet(){
  try{ localStorage.setItem(RP_UM_OFF, rpUmoreOff() ? '0' : '1'); }catch(_){ }
  if (typeof INS !== 'undefined') INS.forceRender = true;
  rpUmorePaint();
}
function rpUmorePaint(){
  const box = document.getElementById('rpUmBody');
  if (!box) return;
  const on = !rpUmoreOff();
  const tutti = (typeof umTutti === 'function') ? umTutti() : {};
  const giorni = Object.keys(tutti).sort().reverse().slice(0, 7);
  const voci = (typeof UM_VOCI !== 'undefined') ? UM_VOCI : [];
  const emo = (typeof UM_EMOJI !== 'undefined') ? UM_EMOJI : [];
  box.innerHTML =
      '<div class="setrow" onclick="rpUmoreSet()"><span>\u{1F7E2}</span><b>Chiedimi come è andata</b>'
    +   '<span class="sw' + (on ? ' on' : '') + '" style="margin-left:auto"></span></div>'
    + '<p class="hintline" style="padding:10px 2px 18px">Una domanda sola, in fondo al Report del '
    +   'giorno: come ti sei sentito. Non entra nelle previsioni, che restano sui fatti, '
    +   'ma decide come il Genio ti chiede le cose.</p>'
    + '<div class="sect"><b>Le tue app</b></div>'
    + rpAppRighe()
    + '<div class="spacer"></div>';
}
/* ---- L'UMORE, PAGINA SUA (0.9.209): «come ti senti» non e' «come senti le app». Qui il
   promemoria: una notifica al giorno, all'ora che scegli, che apre il controllo dell'umore di
   Dream. 0.9.219: tolto l'elenco «Gli ultimi giorni» (Andrea): una lista di date e faccine
   non la legge nessuno, e l'andamento sta gia' nei grafici di Informazioni sull'umore. ---- */
const RP_UM_PROM = 'fl_umore_promemoria';
function rpUmPromCfg(){ let c = {}; try{ c = JSON.parse(localStorage.getItem(RP_UM_PROM) || '{}') || {}; }catch(_){ } return Object.assign({ on: false, ora: '21:00' }, c); }
function rpUmPromSet(patch){ const c = Object.assign(rpUmPromCfg(), patch || {}); try{ localStorage.setItem(RP_UM_PROM, JSON.stringify(c)); }catch(_){ } rpUmPromArma(); rpUmoreGiorniPaint(); }
function rpUmPromArma(){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.avviso) return;
  const c = rpUmPromCfg();
  if (!c.on){ try{ NATIVE.avvisoAnnulla({ id: 31 }); }catch(_){ } return; }
  const m = /^(\d{2}):(\d{2})$/.exec(c.ora || '21:00') || [0, '21', '00'];
  const d = new Date(); d.setHours(+m[1], +m[2], 0, 0); if (d.getTime() <= Date.now() + 60000) d.setDate(d.getDate() + 1);
  try{ NATIVE.avviso({ id: 31, at: d.getTime(), titolo: 'Come ti senti oggi?', testo: 'Un tocco per dare il voto alla giornata. Il Genio lo usa per capire come parlarti.', apri: 'umore', ripeti: 86400000 }); }catch(_){ }
}
function rpUmoreGiorniApri(){ goId('s-umore-imp'); rpUmoreGiorniPaint(); }
function rpUmoreGiorniPaint(){
  const box = document.getElementById('rpUmGBody'); if (!box) return;
  const c = rpUmPromCfg();
  box.innerHTML = '<div class="sect" style="margin-top:6px"><b>Il promemoria</b></div>'
    + '<div class="setrow" onclick="rpUmPromSet({on:' + (c.on ? 'false' : 'true') + '})"><span>🔔</span><b>Ricordami di dare il voto</b><span class="sw' + (c.on ? ' on' : '') + '" style="margin-left:auto"></span></div>'
    + (c.on ? '<div class="setrow" style="cursor:default"><span>⏰</span><b>Ogni giorno alle</b><input class="fin" type="time" value="' + esc(c.ora) + '" style="margin:0 0 0 auto;width:110px" onchange="rpUmPromSet({ora:this.value})" onclick="try{this.showPicker()}catch(_){}"></div>' : '')
    + '<p class="hintline" style="padding:10px 2px 18px">Il promemoria arriva come notifica sul telefono. Quando tocchi la notifica, DreamMap si apre con le faccine dell’umore già pronte.</p>'
    + '<div class="spacer"></div>';
}

/* 0.9.353, Andrea: "la freccia indietro dell'intestazione e' un chevron, uguale a quelli che cambiano giorno". Le
   intestazioni delle pagine del Report usano la freccia della Timeline; i chevron restano solo per i giorni. */
const RP_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"/><path d="M11 6l-6 6 6 6"/></svg>';
registerScreen('s-repimp',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-home\'); switchTab(\'insights\')" aria-label="Indietro">' + RP_INDIETRO + '</button>'
  + '<b class="blk-title">Impostazioni del report</b></div>'
  + '<div id="rpImpBody"></div>',
  { back: function(){ if (typeof switchTab === 'function') switchTab('insights'); return 's-home'; } });

registerScreen('s-repstat',
  '<div class="topbar"><button class="iconbtn" onclick="rpImpostazioni()" aria-label="Indietro">' + RP_INDIETRO + '</button>'
  + '<b class="blk-title">Cosa misura il report</b></div>'
  + '<div id="rpStatBody"></div>',
  { back: function(){ rpImpostazioni(); return 's-repimp'; } });

registerScreen('s-repescl',
  '<div class="topbar"><button class="iconbtn" onclick="rpImpostazioni()" aria-label="Indietro">' + RP_INDIETRO + '</button>'
  + '<b class="blk-title">App escluse</b></div>'
  + '<div id="rpEsclBody"></div>',
  { back: function(){ rpImpostazioni(); return 's-repimp'; } });

registerScreen('s-repadd',
  '<div class="topbar rp-addbar"><button class="iconbtn" onclick="rpEsclApri()" aria-label="Indietro">' + RP_INDIETRO + '</button>'
  + '<label class="rp-cerca"><span class="lente"></span>'
  +   '<input type="search" placeholder="Filtro applicazioni" autocomplete="off" oninput="rpAddCerca(this.value)"></label></div>'
  + '<h2 class="rp-addh">Escludi app</h2>'
  + '<div id="rpAddBody"></div>'
  + '<div class="rp-addfoot"><button type="button" class="cta" onclick="rpAddSalva()">Salva</button></div>',
  { back: function(){ rpEsclApri(); return 's-repescl'; } });

registerScreen('s-umore-imp',
  '<div class="topbar"><button class="iconbtn" onclick="rpImpostazioni()" aria-label="Indietro">' + RP_INDIETRO + '</button>'
  + '<b class="blk-title">Il tuo umore</b></div>'
  + '<div id="rpUmGBody"></div>',
  { back: function(){ rpImpostazioni(); return 's-repimp'; } });

registerScreen('s-repum',
  '<div class="topbar"><button class="iconbtn" onclick="rpImpostazioni()" aria-label="Indietro">' + RP_INDIETRO + '</button>'
  + '<b class="blk-title">Controllo sensazione app</b></div>'
  + '<div id="rpUmBody"></div>',
  { back: function(){ rpImpostazioni(); return 's-repimp'; } });

/* ---------------------------------------------------------------------------------------
   3. L'invito a ordinare le app

   Le tre condizioni sono tutte necessarie, e ognuna toglie un modo di essere fastidiosi:
     · dieci giorni dall'ultima volta      → non si chiede due volte di seguito;
     · almeno tre app senza categoria      → non si chiede quando non c'è niente da fare;
     · almeno cinque minuti ciascuna       → non si chiede per app aperte per sbaglio.
   --------------------------------------------------------------------------------------- */

const RP_CHIESTO = 'fl_rp_sort_chiesto';
const RP_OGNI_MS = 10 * 86400000;

async function rpForseChiedi(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps) return;
    let ultimo = 0;
    try{ ultimo = +localStorage.getItem(RP_CHIESTO) || 0; }catch(_){ }
    if (Date.now() - ultimo < RP_OGNI_MS) return;

    const to = Date.now(), from = to - 7 * 86400000;
    const r = await NATIVE.getTopApps({ from: from, to: to, limit: 30 });
    const cats = (typeof insCats === 'function') ? insCats() : {};
    const senza = (r.apps || []).filter(function(a){
      return a && !a.self && !cats[a.packageName] && (a.ms || 0) >= 5 * 60000;
    });
    if (senza.length < 3) return;
    rpInvito(senza.length);
  }catch(_){ }
}

const RP_FACCIA = (function(){
  const occhi = '<circle cx="9" cy="10" r="1.6" fill="#001E44"/><circle cx="15" cy="10" r="1.6" fill="#001E44"/>';
  const svg = function(bocca){ return '<svg viewBox="0 0 24 24" width="40" height="40" aria-hidden="true">' + occhi + '<path d="' + bocca + '" fill="none" stroke="#001E44" stroke-width="1.8" stroke-linecap="round"/></svg>'; };
  return { triste: svg('M8.5 17c1-1.6 2.2-2.3 3.5-2.3s2.5.7 3.5 2.3'), neutra: svg('M9 15.5h6'), felice: svg('M8.5 14.5c1 1.6 2.2 2.3 3.5 2.3s2.5-.7 3.5-2.3') };
})();
function rpInvito(n){
  try{ localStorage.setItem(RP_CHIESTO, String(Date.now())); }catch(_){ }
  let w = document.getElementById('rpInvito');
  if (!w){
    w = document.createElement('div');
    w.id = 'rpInvito';
    w.className = 'rp-inv';
    document.body.appendChild(w);
  }
  /* QUATTRO RIGHE IN TUTTO, e il modello è quello di AppBlock — non una mia versione più
     lunga. Un cartello che compare da solo ha due secondi: se in due secondi non si è capito
     cosa chiede, il testo in più non aiuta, peggiora. */
  w.innerHTML = '<div class="rp-inv-in">'
    + '<button type="button" class="rp-inv-x" onclick="rpInvitoChiudi()" aria-label="Chiudi">✕</button>'
    + '<p class="rp-inv-oc">Sensazione app</p>'
    + '<h3>Categorizza le tue app<br>per statistiche migliori</h3>'
    /* 0.9.288, Andrea: "nei pallini mancano le faccine" (come AppBlock): triste per le app che distraggono, neutra per le
       normali, sorridente per le produttive */
    + '<div class="rp-inv-art"><i class="a">' + RP_FACCIA.triste + '</i><i class="b">' + RP_FACCIA.neutra + '</i><i class="c">' + RP_FACCIA.felice + '</i></div>'
    + '<p class="rp-inv-n">' + n + ' app da smistare.</p>'
    + '<button type="button" class="cta" onclick="rpInvitoVai()">Continua</button>'
    + '</div>';
  w.hidden = false;
}

function rpInvitoChiudi(){
  const w = document.getElementById('rpInvito');
  if (w) w.remove();
}
function rpInvitoVai(){
  rpInvitoChiudi();
  if (typeof insSortApps === 'function') insSortApps();
}

/* Solo entrando nel Report, e con calma: due secondi dopo, quando i numeri sono già a schermo.
   Un cartello che arriva prima del contenuto è un cartello che copre quello che si era venuti
   a vedere. */
/* 0.9.305, Andrea: "ogni volta che si apre il Report si apre da solo il popover dell'umore, se oggi non l'ho ancora
   votato; una volta votato, quel giorno non riappare". Solo entrando nel Report da un'altra scheda (non a ogni
   ridisegno), solo se la domanda e' accesa nelle impostazioni del Report e se non c'e' gia' un foglio aperto.
   Quando si apre l'umore, il cartello "Categorizza le tue app" aspetta la prossima volta: due fogli insieme no. */
let RP_TAB_PRIMA = '';
function rpUmoreForse(){
  try{
    if (rpUmoreOff() || typeof umApri !== 'function' || typeof umLeggi !== 'function' || typeof umGiorno !== 'function') return false;
    const tab = document.getElementById('tab-insights'), home = document.getElementById('s-home');
    if (!tab || !tab.classList.contains('on') || (home && !home.classList.contains('active'))) return false;
    if (umLeggi(umGiorno(0)) || document.getElementById('umSheet') || document.getElementById('rpInvito')) return false;
    const fg = document.getElementById('inSheet'); if (fg && !fg.hidden) return false;
    umApri(umGiorno(0), { soloVoto: true });
    return true;
  }catch(_){ return false; }
}
document.addEventListener('fl:tab', function(e){
  const prima = RP_TAB_PRIMA;
  RP_TAB_PRIMA = e.detail;
  if (e.detail !== 'insights' || prima === 'insights') return;
  /* 0.9.326, Andrea: "non immediatamente quando si apre il Report: solo dopo qualche secondo" */
  setTimeout(rpUmoreForse, 6000);
  setTimeout(function(){ if (!document.getElementById('umSheet')) rpForseChiedi(); }, 12000);
});

(function rpStyle(){
  const st = document.createElement('style');
  st.textContent = [
    /* dentro DreamMap, sotto alle linguette */
    '.rp-dm{margin:10px 0 4px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line)}',
    'body.dark .rp-dm{background:#12203A;border-color:#22345A}',
    '.rp-dm-t{margin:0 0 6px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted,#7A8AA3)}',
    '.rp-dm-r{display:flex;align-items:center;gap:12px;padding:7px 0}',
    '.rp-dm-n{flex:1;min-width:0}',
    '.rp-dm-n b{display:block;font:700 13.5px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .rp-dm-n b{color:#fff}',
    '.rp-dm-bar{display:block;height:5px;margin-top:5px;border-radius:99px;background:var(--bg,#EEF2F8);overflow:hidden}',
    'body.dark .rp-dm-bar{background:rgba(255,255,255,.08)}',
    '.rp-dm-bar i{display:block;height:100%;border-radius:99px}',
    '.rp-dm-m{flex:none;font:800 13px var(--font-body);color:var(--navy)}body.dark .rp-dm-m{color:#fff}',
    /* LE LINGUETTE: scorrono e sbordano dai margini, così si vede che continuano. */
    '.rp-cats{display:flex;gap:8px;overflow-x:auto;padding:2px 18px 4px;margin:14px -18px 4px;',
      'scrollbar-width:none}',
    '.rp-cats::-webkit-scrollbar{display:none}',
    '.rp-cat{flex:0 0 auto;display:flex;align-items:center;gap:7px;border:1px solid var(--line);',
      'background:var(--card,#fff);border-radius:99px;padding:9px 14px;cursor:pointer;',
      'font-size:15px;line-height:1}',
    '.rp-cat b{font:700 12.5px var(--font-body);color:var(--navy)}',
    'body.dark .rp-cat b{color:#fff}',
    '.rp-cat i{font-style:normal;font:700 11.5px var(--font-body);color:var(--muted)}',
    /* La scelta ha il BORDO blu, come nel modello: il riempimento pieno faceva sparire
       l'emoji e il numero dentro. */
    '.rp-cat.on{border:2px solid var(--blue);padding:8px 13px}',
    '.rp-cat:first-child{padding-left:16px;padding-right:16px}',

    '.rp-box{background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;overflow:hidden}',
    '.rp-f{display:flex;align-items:center;gap:10px;width:100%;border:0;background:transparent;',
      'padding:14px 16px;font:600 14px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}',
    'body.dark .rp-f{color:#fff}',
    '.rp-f + .rp-f{border-top:1px solid var(--line)}',
    '.rp-ck{margin-left:auto;color:var(--blue);font-weight:800}',

    /* IL CARTELLO. A schermo intero e scuro: è l'unica volta ogni dieci giorni in cui l'app
       chiede qualcosa, e chiederlo in un angolo vorrebbe dire non chiederlo. */
    '.rp-inv{position:fixed;inset:0;z-index:9996;background:#0B1220;display:flex;',
      'align-items:center;justify-content:center;padding:26px}',
    '.rp-inv-in{max-width:360px;text-align:center;color:#fff;position:relative;width:100%}',
    '.rp-inv-x{position:absolute;top:-10px;left:0;width:34px;height:34px;border:0;border-radius:50%;',
      'background:transparent;color:#4FB8FF;font:700 17px var(--font-body);cursor:pointer}',
    '.rp-inv-oc{margin:26px 0 14px;font:700 11px var(--font-body);letter-spacing:.2em;',
      'text-transform:uppercase;color:rgba(200,218,242,.55)}',
    '.rp-inv-in h3{margin:0 0 30px;font:800 25px/1.3 var(--font-display);color:#fff}',
    /* Le tre bolle: lo stesso disegno del filtro in cima al Report — distraente, neutro,
       produttivo — così il cartello mostra già la cosa di cui sta parlando. */
    '.rp-inv-art{display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:26px}',
    '.rp-inv-art i{width:56px;height:56px;border-radius:50%;display:flex;align-items:center;justify-content:center}',
    '.rp-inv-art .a{background:#E63946;transform:translateY(8px)}',
    '.rp-inv-art .b{background:#8CC6FF;transform:translateY(22px)}',
    '.rp-inv-art .c{background:#0075E3}',
    '.rp-inv-n{margin:0 0 22px;font:600 12.5px var(--font-body);color:rgba(200,218,242,.6)}',

    /* LE TRE RIGHE della pagina madre. */
    '.rp-xico{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;',
      'background:#E5515F;color:#fff;font:800 13px var(--font-body)}',
    '.rp-dots{display:block;width:26px;height:26px;position:relative}',
    '.rp-dots i{position:absolute;width:13px;height:13px;border-radius:50%}',
    '.rp-dots i:first-child{left:0;top:7px;background:#0075E3}',
    '.rp-dots i:last-child{right:0;top:2px;background:#E63946}',
    '.setrow b .rp-sub{display:block;font:500 11.5px var(--font-body);color:var(--muted);',
      'font-style:normal;margin-top:2px}',
    /* Spento vuol dire spento: l'interruttore maestro comanda, e i tre sotto devono
       SEMBRARE sotto. Restano toccabili apposta — si tocca per accorgersi. */
    '.setrow.rp-off{opacity:.45}',
    '.rp-info{display:flex;gap:12px;align-items:flex-start;border:1px solid var(--line);',
      'border-radius:16px;padding:14px;margin-top:18px}',
    '.rp-info span{font-size:17px;line-height:1.3;flex:none}',
    '.rp-info p{margin:0;font:500 12.5px/1.6 var(--font-body);color:var(--muted)}',
    /* 0.9.303, Andrea: "le voci sono attaccate al titolo". Fra il titolo della pagina e la prima riga c'era solo il
       margine della barra (10px): adesso lo spazio e' quello di una sezione. */
    '#rpImpBody,#rpStatBody,#rpEsclBody,#rpUmGBody,#rpUmBody{padding-top:18px}',
    '.rp-sect{margin:26px 0 10px;justify-content:center}',
    '.rp-fonte{display:flex;gap:8px;margin:0 0 8px}',
    '.rp-fonte button{flex:1;min-width:0;padding:11px 6px;border-radius:99px;border:1px solid var(--line);background:var(--card,#fff);',
      'color:var(--navy);font:700 13px var(--font-body);cursor:pointer;white-space:nowrap}',
    '.rp-fonte button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    'body.dark .rp-fonte button{background:#12203A;border-color:#22345A;color:#fff}',
    'body.dark .rp-fonte button.on{background:#0075E3;border-color:#0075E3}',
    '.rp-fonte-nota{text-align:center;margin:0 0 14px}',

    /* LE DUE SCHEDE delle app escluse. */
    '.rp-tabs{display:flex;border-bottom:1px solid var(--line);margin:0 -18px 16px}',
    '.rp-tabs button{flex:1;border:0;background:transparent;padding:14px 8px;cursor:pointer;',
      'font:700 13.5px var(--font-body);color:var(--muted);border-bottom:2px solid transparent}',
    '.rp-tabs button.on{color:var(--blue);border-bottom-color:var(--blue)}',
    '.rp-er{display:flex;align-items:center;gap:14px;padding:11px 2px}',
    /* Il segnaposto sta SOTTO all'icona, non al posto suo: quando l'icona vera arriva le si
       appoggia sopra e il punto interrogativo sparisce da solo, senza un secondo disegno. */
    '.rp-er .rp-ico{position:relative;width:38px;height:38px;flex:none;border-radius:9px;',
      'background:var(--bg);display:grid;place-items:center;',
      'font:800 15px var(--font-body);color:var(--muted)}',
    /* PRESENTE MA INVISIBILE, non assente: `display:none` toglie la scatola, e una cosa senza
       scatola non interseca mai lo schermo — l'osservatore che chiede le icone non la vedeva
       e l'icona non arrivava. Con l'opacita' la scatola c'e', e l'icona arriva. */
    '.rp-er img,.rp-ga img{position:absolute;inset:0;width:38px;height:38px;border-radius:9px;opacity:0}',
    '.rp-er img[src],.rp-ga img[src]{opacity:1}',
    '.rp-er b{font:600 14px var(--font-body);color:var(--navy);overflow:hidden;',
      'text-overflow:ellipsis;white-space:nowrap}',
    'body.dark .rp-er b{color:#fff}',
    '.rp-meno{margin-left:auto;flex:none;width:28px;height:28px;border:0;border-radius:50%;',
      'background:#E5515F;color:#fff;font:800 17px/1 var(--font-body);cursor:pointer}',
    /* IL VUOTO NON E' UNA PAGINA BIANCA. Chi arriva qui la prima volta non ha escluso niente:
       e' il momento in cui va spiegato a cosa serve, non quello in cui lasciarlo a guardare
       uno spazio senza righe. */
    '.rp-vuoto{text-align:center;padding:26px 6px 0}',
    '.rp-vart{position:relative;height:118px;margin-bottom:10px}',
    '.rp-vart i{position:absolute;display:grid;place-items:center;width:54px;height:54px;',
      'border-radius:14px;background:var(--card,#fff);border:1px solid var(--line);',
      'font-size:24px;font-style:normal;opacity:.55}',
    '.rp-vart .a{left:22%;top:18px;transform:rotate(-8deg)}',
    '.rp-vart .b{left:45%;top:0;transform:rotate(5deg);opacity:.75}',
    '.rp-vart .c{right:16%;top:20px;transform:rotate(9deg)}',
    '.rp-vart .d{left:36%;top:58px;transform:rotate(-3deg);opacity:.85}',
    '.rp-vart .e{right:24%;top:66px;transform:rotate(7deg);opacity:.4}',
    '.rp-vuoto h3{margin:0 0 8px;font:800 19px/1.3 var(--font-display);color:var(--navy)}',
    'body.dark .rp-vuoto h3{color:#fff}',
    '.rp-vuoto p{margin:0 0 22px;font:500 13px/1.6 var(--font-body);color:var(--muted)}',
    /* LA PAGINA «Escludi app» */
    '.rp-addbar{gap:10px}',
    '.rp-cerca{flex:1;display:flex;align-items:center;gap:8px;border-left:2px solid var(--blue);padding-left:10px}',
    '.rp-cerca .lente{width:16px;height:16px;flex:none;border:2px solid var(--muted);border-radius:50%;position:relative}',
    '.rp-cerca .lente::after{content:"";position:absolute;right:-6px;bottom:-5px;width:7px;height:2px;',
      'background:var(--muted);transform:rotate(45deg)}',
    '.rp-cerca input{flex:1;min-width:0;border:0;background:transparent;font:600 15px var(--font-body);',
      'color:var(--navy);outline:0}',
    'body.dark .rp-cerca input{color:#fff}',
    '.rp-addh{margin:6px 0 14px;font:800 26px var(--font-display);color:var(--navy)}',
    'body.dark .rp-addh{color:#fff}',
    '.rp-g{margin-bottom:4px}',
    '.rp-gr{display:flex;align-items:center;gap:14px;padding:11px 2px;cursor:pointer}',
    '.rp-gchev{width:9px;height:9px;flex:none;border-right:2px solid var(--muted);border-bottom:2px solid var(--muted);',
      'transform:rotate(45deg) translate(-2px,-2px);transition:transform .2s;margin-left:6px}',
    '.rp-gchev.up{transform:rotate(225deg) translate(-1px,-1px)}',
    '.rp-gico{width:44px;height:44px;border-radius:12px;display:grid;place-items:center;font-size:22px;',
      'background:rgba(120,140,170,.16);flex:none}',
    '.rp-gr b{flex:1;min-width:0;font:600 16px var(--font-body);color:var(--navy)}',
    'body.dark .rp-gr b{color:#fff}',
    '.rp-gck{flex:none;padding:4px}',
    '.rp-ck2{display:grid;place-items:center;width:26px;height:26px;border-radius:6px;border:2px solid var(--muted);',
      'font:800 15px/1 var(--font-body);color:#fff;box-sizing:border-box}',
    '.rp-ck2.on{background:var(--blue);border-color:var(--blue)}',
    '.rp-ck2.mezzo{border-color:var(--blue);color:var(--blue)}',
    '.rp-gapps{padding-left:38px}',
    '.rp-ga{display:flex;align-items:center;gap:12px;padding:8px 6px 8px 2px;cursor:pointer}',
    '.rp-ga .rp-ico{position:relative;width:38px;height:38px;flex:none;border-radius:9px;background:var(--bg)}',
    '.rp-ga b{flex:1;min-width:0;font:600 14px var(--font-body);color:var(--navy);overflow:hidden;',
      'text-overflow:ellipsis;white-space:nowrap}',
    'body.dark .rp-ga b{color:#fff}',
    '.rp-addfoot{position:fixed;left:0;right:0;bottom:0;padding:12px 18px calc(16px + env(safe-area-inset-bottom,0px));',
      'background:linear-gradient(180deg,transparent,var(--bg) 40%);z-index:30}',
    '.rp-addfoot .cta{margin:0}',

    '.rp-piu{position:fixed;left:50%;transform:translateX(-50%);bottom:86px;z-index:30;',
      'width:56px;height:56px;border:0;border-radius:50%;background:var(--blue);color:#fff;',
      'font:300 30px/1 var(--font-body);cursor:pointer;box-shadow:0 8px 22px rgba(0,117,227,.45)}'
  ].join('\n');
  document.head.appendChild(st);
})();
