/* ===========================================================================================
   QUELLO CHE HAI IMPOSTATO DEVE RESTARE — anche dove il motore non sa tenerlo

   IL DIFETTO, detto com'è. Sul computer, dentro a «Blocchi e programmi», le parole chiave del
   blocco rapido sparivano a ogni riapertura e l'interruttore «Blocco dei siti porno» tornava
   spento da solo. Sul telefono le stesse cose restavano. Non era un caso e non era la rete.

   LA CAUSA, letta nella tabella dei metodi del programma del computer (FocusLock.dll):
     · `getQuickBlock` NON ESISTE. La schermata chiede al motore che cosa c'è nel blocco
       rapido, il motore non ha quel metodo, e `loadQuick()` esce subito lasciando la
       schermata con le sue liste vuote. Le regole c'erano davvero — stanno scritte in
       rules.json — ma nessuno le sapeva più rileggere: spariva la vista, non il blocco.
     · `blockAdult` e `searchTyping` non compaiono da nessuna parte nel programma del
       computer. Non c'è un posto dove salvarli e non c'è niente che li applichi: quella
       levetta, lì, non poteva funzionare. Mostrarla accesa sarebbe stata una bugia.

   COSA FA QUESTO FILE.
     1. Tiene una copia di quello che è stato chiesto al motore (`fl_regole_cache`), scritta
        dopo ogni scrittura riuscita. Viaggia da sola verso l'altro dispositivo, perché è una
        chiave `fl_` e il backup delle regole le porta tutte.
     2. Quando il motore non sa rispondere, la schermata si riveste con quella copia. Il
        computer torna a mostrare le parole chiave che ha davvero.
     3. Dove la levetta non può fare niente, lo dice invece di fingere. E per i siti per
        adulti offre la cosa vera che il computer sa fare: gli otto domini della categoria
        entrano nel blocco rapido, che il computer applica eccome.
     4. Con l'account collegato, telefono e computer si allineano sull'ultima modifica fatta:
        vince chi ha scritto per ultimo, non chi ha aperto per ultimo.
   =========================================================================================== */

const RC_KEY = 'fl_regole_cache';
const RC_SLOT = 'fl:mobile-rules';
const RC_CAMPI = ['enabled', 'listMode', 'allowApps', 'blockNewlyInstalled', 'blockUnsupportedBrowsers',
                  'blockAdult', 'blockReinstalled', 'blockPurchases', 'searchTyping',
                  'blockLaunch', 'blockNotifications'];
/* Le opzioni che vivono nel servizio di accessibilità di Android e basta. */
const RC_SOLO_TELEFONO = ['blockNewlyInstalled', 'blockUnsupportedBrowsers', 'blockReinstalled',
                          'blockPurchases', 'searchTyping'];
let RC_LETTO = false;

function rcLeggi(){
  try{ return JSON.parse(localStorage.getItem(RC_KEY) || 'null'); }catch(_){ return null; }
}
function rcScrivi(c){
  try{ localStorage.setItem(RC_KEY, JSON.stringify(c)); }catch(_){ }
}
/** Il motore di qui sa raccontare il blocco rapido? Il computer no: e lì sta tutto il guaio. */
function rcMotoreRacconta(){
  try{ return typeof blkHasNative === 'function' && blkHasNative('getQuickBlock'); }catch(_){ return false; }
}
/** Questa opzione, su questo dispositivo, può fare qualcosa? */
function rcOpzioneVale(k){
  if (rcMotoreRacconta()) return true;                 // il telefono le fa tutte
  return RC_SOLO_TELEFONO.indexOf(k) < 0;
}

/* ---------------------------------------------------------------------------------------
   1 · LA COPIA
   --------------------------------------------------------------------------------------- */
function rcAnnota(method, args){
  const a = args || {};
  const c = rcLeggi() || { at: 0, quick: null, extra: null };
  if (method === 'setQuickBlock'){
    c.quick = { enabled: !!a.enabled, apps: a.apps || [], sites: a.sites || [], keywords: a.keywords || [] };
  } else if (method === 'setRulesFull'){
    c.extra = Object.assign({}, c.extra || {});
    RC_CAMPI.forEach(function(k){ if (a[k] !== undefined) c.extra[k] = a[k]; });
  } else return;
  c.at = Date.now();
  rcScrivi(c);
}

/**
 * IL CANCELLO CHE MANCAVA, ed è il guasto più serio dei tre.
 *
 * <p>Sul computer `loadQuick()` esce subito (niente `getQuickBlock`) e lascia le liste del
 * blocco rapido vuote in memoria. Poi basta toccare l'interruttore del blocco rapido: quella
 * schermata rispedisce al motore quello che ha in mano — cioè niente — e le regole vere
 * vengono cancellate. Non «non si salvano»: si perdono. Nel file del computer si vede,
 * cinque parole chiave sparite in un colpo il 22/09.</p>
 *
 * <p>Qui si ferma: una spedizione vuota, partita da un dispositivo che non ha mai potuto
 * leggere la lista, non è una scelta di nessuno. Si rimette la lista buona e si riprova.</p>
 */
function rcSpedizioneSuicida(method, args){
  if (method !== 'setQuickBlock' || rcMotoreRacconta()) return false;
  const a = args || {};
  const vuota = !((a.apps || []).length || (a.sites || []).length || (a.keywords || []).length);
  if (!vuota) return false;
  const c = rcLeggi();
  const q = c && c.quick;
  return !!(q && ((q.apps || []).length || (q.sites || []).length || (q.keywords || []).length));
}

/* L'aggancio: una volta sola, dopo che blocco.js (e regole-sync.js) hanno definito il loro. */
(function rcAggancia(){
  if (typeof blkNative !== 'function' || blkNative.__rc) return;
  const orig = blkNative;
  const wrapped = async function(method, args, silent){
    if (rcSpedizioneSuicida(method, args)){
      const q = rcLeggi().quick;
      QUICK = { enabled: (args && args.enabled) !== undefined ? !!args.enabled : !!q.enabled,
                apps: (q.apps || []).slice(), sites: (q.sites || []).slice(), keywords: (q.keywords || []).slice() };
      arguments[1] = { enabled: QUICK.enabled, apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords };
      const rr = await orig(method, arguments[1], silent);
      if (rr !== null) rcAnnota(method, arguments[1]);
      try{ if (typeof paintQuick === 'function') paintQuick(); }catch(_){ }
      return rr;
    }
    const r = await orig(method, args, silent);
    if (r !== null) rcAnnota(method, args);
    return r;
  };
  wrapped.__rc = true;
  blkNative = wrapped;
})();

/* ---------------------------------------------------------------------------------------
   2 · LA SCHERMATA SI RIVESTE
   --------------------------------------------------------------------------------------- */
function rcVestiQuick(){
  const c = rcLeggi();
  if (!c || !c.quick) return;
  const q = c.quick;
  const quiVuoto = !((QUICK.apps || []).length || (QUICK.sites || []).length || (QUICK.keywords || []).length);
  const laPieno = (q.apps || []).length || (q.sites || []).length || (q.keywords || []).length;
  /* Solo se di qui non è arrivato niente: la parola del motore, quando c'è, vince sempre. */
  if (quiVuoto && laPieno){
    QUICK = { enabled: !!q.enabled, apps: q.apps.slice(), sites: q.sites.slice(), keywords: q.keywords.slice() };
  }
}
function rcVestiExtra(){
  const c = rcLeggi();
  if (!c || !c.extra) return;
  /* Sul telefono il motore risponde per tutto, e la sua parola vince. Qui si riveste solo
     quello che il motore di questo dispositivo non conosce proprio. */
  if (rcMotoreRacconta()) return;
  /* Solo «siti per adulti»: e' l'unica delle cinque che qui si puo' davvero fare, in un altro
     modo. Le altre restano spente, perche' spente sono. */
  if (c.extra.blockAdult !== undefined) EXTRA.blockAdult = c.extra.blockAdult;
}

(function rcVestiAggancia(){
  if (typeof loadQuick === 'function' && !loadQuick.__rc){
    const o = loadQuick;
    loadQuick = async function(){ await o.apply(this, arguments); await rcDaAccount(); rcVestiQuick(); };
    loadQuick.__rc = true;
  }
  if (typeof loadExtra === 'function' && !loadExtra.__rc){
    const o = loadExtra;
    loadExtra = async function(){ await o.apply(this, arguments); rcVestiExtra(); };
    loadExtra.__rc = true;
  }
})();

/* ---------------------------------------------------------------------------------------
   3 · DOVE LA LEVETTA NON PUÒ, LO DICE — e per gli adulti fa la cosa vera
   --------------------------------------------------------------------------------------- */
function rcSitiAdulti(){
  try{
    const c = (typeof FL_CATS !== 'undefined' ? FL_CATS : []).filter(function(x){ return x.id === 'adult'; })[0];
    return (c && c.sites) || [];
  }catch(_){ return []; }
}

/**
 * Sul computer «Blocco dei siti porno» non è una bandiera del motore — non esiste. È però
 * una cosa che il computer sa fare benissimo in un altro modo: bloccare otto domini. Quindi
 * l'interruttore li mette e li toglie dal blocco rapido, e il risultato finisce in rules.json
 * come tutte le altre regole. Fa meno di quello che fa il telefono (che riconosce anche i
 * siti che non sono in nessun elenco) e la schermata lo scrive.
 */
async function rcAdultiComputer(on){
  const lista = rcSitiAdulti();
  if (!lista.length) return false;
  const set = {};
  (QUICK.sites || []).forEach(function(s){ set[s] = 1; });
  lista.forEach(function(s){ if (on) set[s] = 1; else delete set[s]; });
  QUICK.sites = Object.keys(set);
  const ok = await blkNative('setQuickBlock', {
    enabled: QUICK.enabled, apps: QUICK.apps, sites: QUICK.sites, keywords: QUICK.keywords
  });
  if (ok === null) return false;
  if (on && !QUICK.enabled && typeof toast === 'function') toast('Aggiunti al Blocco rapido: accendilo per farli valere');
  return true;
}

(function rcToggleAggancia(){
  if (typeof toggleExtra !== 'function' || toggleExtra.__rc) return;
  const o = toggleExtra;
  const w = async function(key){
    if (key === 'blockAdult' && !rcMotoreRacconta()){
      const next = !EXTRA.blockAdult;
      EXTRA.blockAdult = next;
      ['qkExtra', 'edExtra', 'bpExtra'].forEach(function(id){ try{ renderExtraOptions(id); }catch(_){ } });
      const fatto = await rcAdultiComputer(next);
      if (!fatto){
        EXTRA.blockAdult = !next;
        ['qkExtra', 'edExtra', 'bpExtra'].forEach(function(id){ try{ renderExtraOptions(id); }catch(_){ } });
        return;
      }
      const c = rcLeggi() || { at: 0, quick: null, extra: null };
      c.extra = Object.assign({}, c.extra || {}); c.extra.blockAdult = next; c.at = Date.now();
      rcScrivi(c);
      return;
    }
    if (!rcOpzioneVale(key)){
      if (typeof toast === 'function') toast('Questa opzione vale solo sul telefono');
      return;
    }
    return o.apply(this, arguments);
  };
  w.__rc = true;
  toggleExtra = w;
})();

/* La riga che non può fare niente qui lo scrive sotto al titolo, e la levetta si spegne. */
(function rcRenderAggancia(){
  if (typeof renderExtraOptions !== 'function' || renderExtraOptions.__rc) return;
  const o = renderExtraOptions;
  const w = function(containerId){
    o.apply(this, arguments);
    if (rcMotoreRacconta()) return;
    const box = document.getElementById(containerId);
    if (!box) return;
    const righe = box.querySelectorAll('.blk-opt');
    EXTRA_OPTS.forEach(function(op, i){
      const r = righe[i];
      if (!r) return;
      const small = r.querySelector('.ot small');
      if (op.k === 'blockAdult'){
        if (small) small.textContent = 'Sul computer blocca gli otto siti più grandi, dal Blocco rapido. Il riconoscimento automatico vale sul telefono.';
        return;
      }
      if (RC_SOLO_TELEFONO.indexOf(op.k) < 0) return;
      r.classList.add('blk-opt--no');
      if (small) small.textContent = 'Vale solo sul telefono: qui non c’è niente che possa farlo.';
      const sw = r.querySelector('.switch');
      if (sw){ sw.classList.remove('on'); sw.setAttribute('aria-disabled', 'true'); }
    });
  };
  w.__rc = true;
  renderExtraOptions = w;
})();

/* ---------------------------------------------------------------------------------------
   4 · L'ALLINEAMENTO FRA I DUE DISPOSITIVI
   Vince chi ha scritto per ultimo. La copia viaggia dentro al backup delle regole, che è
   già quello che il computer legge: non serve una riga nuova nell'account.
   --------------------------------------------------------------------------------------- */
async function rcDaAccount(){
  if (RC_LETTO) return;
  RC_LETTO = true;
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return;
    const lista = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups', body: '' });
    const riga = ((lista && lista.backups) || []).filter(function(x){ return x && x.deviceId === RC_SLOT; })[0];
    if (!riga) return;
    const pieno = await NATIVE.accountApi({ method: 'GET', path: '/api/focuslock/backups/' + riga.id, body: '' });
    const web = (pieno && pieno.payload && pieno.payload.web) || null;
    const grezzo = web && web[RC_KEY];
    if (!grezzo) return;
    const la = JSON.parse(grezzo);
    const qui = rcLeggi();
    if (!la || !la.at) return;
    if (qui && (qui.at || 0) >= la.at) return;      // qui è più recente: non si tocca niente
    rcScrivi(la);
  }catch(_){ }
}

(function rcStile(){
  const st = document.createElement('style');
  st.textContent = '.blk-opt--no{opacity:.6}.blk-opt--no .switch{pointer-events:none}';
  document.head.appendChild(st);
})();
