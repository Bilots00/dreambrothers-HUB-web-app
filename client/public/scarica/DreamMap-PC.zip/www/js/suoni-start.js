/* ===========================================================================================
   SUONI PER CONCENTRARSI, A SCHEDE (0.9.311)

   Andrea: la pagina deve essere il ritratto dell'app di riferimento: quattro schede in alto
   (Focus, Relax, Sleep, Meditate), i blocchi di ogni categoria, e quando parte un suono la
   schermata che permette di metterlo nei preferiti.

   COSA C'E' QUI.
   - La pagina a schede, con i disegni dei blocchi generati sul momento (linee nostre, nessuna
     immagine di terzi: si tengono i canvas, quindi cambiare scheda non ricarica niente).
   - La sessione: un flusso di tracce scelte per l'attivita'. Alla fine di una traccia della
     libreria si passa alla successiva con una dissolvenza, invece di ripetere il file: niente
     singhiozzo a ogni giro e niente buffer da cento mega in memoria.
   - La schermata del brano: preferiti, non mi piace, scarica, condividi, tracce simili.
   - Le impostazioni del lettore: livello dell'effetto e generi. Un genere compare solo se
     dentro l'app c'e' davvero qualcosa da ascoltare.

   DA DOVE ARRIVA L'AUDIO.
   - Le tracce della libreria (manifest della web app, effetti.js): ogni notte nuove.
   - Le registrazioni dentro all'APK (audio/nature), che passano dal lettore nativo di sounds.js.
   - Le musiche per la testa di musica.js, in fondo al flusso.

   I PREFERITI RESTANO. Il server cancella le tracce notturne dopo trenta giorni: un preferito
   salva la sua scheda in localStorage e il file nella cache snd-preferiti-1 (sw.js non la
   tocca), quindi continua a suonare anche quando il manifest non lo elenca piu'.
   =========================================================================================== */
const SUO = { tab: 'focus', sess: null, audio: null, blob: '', canvas: {}, coda: [], cop: {}, tr: {}, bozza: null, tic: 0, disegna: false, salvando: {} };
let SUO_INTERNO = false;
const SUO_K = { tab: 'fl_snd_scheda', pref: 'fl_snd_pref', scar: 'fl_snd_scaricati', no: 'fl_snd_no', rec: 'fl_snd_recenti', giorni: 'fl_snd_giorni', set: 'fl_snd_lettore', liberi: 'fl_snd_liberi', sbl: 'fl_snd_sbloccati', box: 'fl_snd_box', serieMax: 'fl_snd_serie_max' };
/* 0.9.315: quante tracce della libreria sono aperte da subito per ogni scopo (focus, study, relax...), e quanti file dei suoni
   sbloccati restano nel telefono (cinque mega l'uno) */
const SUO_LIBERE = 2;
const SUO_FILE_MAX = 30;
const SUO_CACHE = 'snd-preferiti-1';
/* 0.9.318, Andrea: "quando si passa da un suono all'altro non si capisce che si e' cambiato". Si sfuma in uscita, si sta in
   silenzio, si sfuma in entrata. Le tracce sono tagliate per girare in loop e partono gia' a pieno volume: la dissolvenza la mette il lettore. */
/* 0.9.340, Andrea: "i suoni partono a manetta, senza un crescendo": l'entrata dura sei secondi e l'uscita due */
const SUO_USCITA = 2000, SUO_STACCO = 1300, SUO_ENTRATA = 6000;
const SUO_NAP = 20 * 60;       // il pisolino si ferma da solo

const SUO_TAB = [
  /* 0.9.319, Andrea: in italiano (Sonno, Meditazione), e il rosso e il verde piu' vicini ai colori del brand: stessi blu di fondo, con una punta di colore */
  { k: 'focus', n: 'Focus', bg: '#3F0F1F', acc: '#FF5C7A', et: 'AUMENTO LA CONCENTRAZIONE' },
  { k: 'relax', n: 'Relax', bg: '#0F2F66', acc: '#6FB5FF', et: 'RILASSAMENTO IN CORSO' },
  { k: 'sleep', n: 'Sonno', bg: '#04264F', acc: '#8CC6FF', et: 'TI ACCOMPAGNO NEL SONNO' },
  { k: 'meditate', n: 'Meditazione', bg: '#07364A', acc: '#4FD8C4', et: 'MEDITAZIONE IN CORSO' }
];
/* w = blocco largo. scopi e umori scelgono le tracce; natura le registrazioni; art il disegno */
const SUO_ATT = {
  focus: [
    { k: 'deepwork', n: 'Lavoro profondo', d: 'Per i compiti difficili che chiedono concentrazione lunga.', w: 1, ico: 'comprimi', scopi: ['focus', 'work'], umori: ['deep', 'dreamy'], natura: ['rain'], gen: 'focus', art: ['monti', '#0A0A2A', '#12306E', '#E06A9A', '#8CC6FF'] },
    { k: 'motivation', n: 'Motivazione', d: 'Musica che sale, per darti la spinta e tenere il ritmo.', w: 1, ico: 'lampo', scopi: ['work', 'focus'], umori: ['uplifting', 'hopeful'], natura: [], art: ['trattini', '#10161E', '#2A3A4A', '#E8532E', '#F2C14E', '#6FB7C8', '#E8E2D0'] },
    { k: 'creativity', n: 'Creatività', d: 'Musica per far nascere idee e pensieri creativi.', ico: 'atomo', scopi: ['focus', 'study'], umori: ['dreamy', 'hopeful'], natura: ['forest'], art: ['nastri', '#1E2A3A', '#1C2F52', '#F2B01E', '#C2356E', '#41608A'] },
    { k: 'learning', n: 'Studio', d: 'Per leggere, studiare e ricordare.', ico: 'libro', scopi: ['study', 'focus'], umori: ['serene'], natura: ['rain'], art: ['fili', '#060608', '#120E10', '#F0905A', '#8FC7B0', '#E8C8A0'] },
    { k: 'lightwork', n: 'Lavoro leggero', d: 'Per le cose semplici, senza sforzo.', ico: 'lampada', scopi: ['work', 'study'], umori: ['serene', 'hopeful'], natura: ['river'], art: ['onde', '#0C1E20', '#143A3A', '#7FE0B8', '#E8E08A'] },
    { k: 'pref', n: 'Preferiti', d: 'Le tue tracce preferite per concentrarti.', ico: 'cuore', pref: 1, art: ['cuore', '#14060E', '#3A0E24', '#FF5F8A', '#FFB0A0'] }
  ],
  relax: [
    { k: 'recharge', n: 'Ricarica', d: 'Ritrova il centro e recupera energia.', w: 1, ico: 'batteria', scopi: ['relax'], umori: ['hopeful', 'uplifting', 'dreamy'], natura: ['ocean'], gen: 'relax', art: ['onde', '#061238', '#0E2A7A', '#5FA8FF', '#E8F4FF', 1] },
    { k: 'chill', n: 'Tranquillità', d: 'Musica tranquilla da ascoltare senza sforzo.', w: 1, ico: 'poltrona', scopi: ['relax'], umori: ['dreamy', 'serene'], natura: ['fire'], art: ['spettro', '#0A1438', '#101E4E', '#F4E6CE', '#7FA8E0'] },
    { k: 'unwind', n: 'Stacca', d: 'Stacca dopo una giornata piena.', ico: 'panchina', scopi: ['relax', 'meditate'], umori: ['melancholic', 'deep', 'serene'], natura: ['ocean', 'night'], art: ['sfere', '#060E30', '#10226A', '#4FA8F0', '#A8D8FF'] },
    { k: 'destress', n: 'Via lo stress', d: 'Scarica la tensione e rallenta.', ico: 'goccia', scopi: ['relax', 'meditate'], umori: ['serene', 'deep'], natura: ['river', 'rain'], art: ['dune', '#14234A', '#1E3A78', '#E3F1FF', '#8CC6FF'] },
    { k: 'travel', n: 'In viaggio', d: 'Per il viaggio, in macchina o in treno.', ico: 'valigia', scopi: ['relax', 'work'], umori: ['hopeful', 'dreamy'], natura: ['wind'], art: ['strada', '#060A24', '#182050', '#6FA0FF', '#F0D0A0'] },
    { k: 'pref', n: 'Preferiti', d: 'Le tue tracce preferite per rilassarti.', ico: 'cuore', pref: 1, art: ['cuore', '#040A20', '#0C1E50', '#5F9CFF', '#B0E0FF'] }
  ],
  sleep: [
    { k: 'deepsleep', n: 'Sonno profondo', d: 'Per un sonno profondo e riposante.', w: 1, ico: 'zzz', scopi: ['sleep'], umori: ['deep'], natura: ['night'], gen: 'sonno', art: ['onde', '#061238', '#12306E', '#8CC6FF', '#3F9FF4'] },
    { k: 'powernap', n: 'Pisolino', d: 'Venti minuti che ricaricano, poi si ferma da solo.', w: 1, ico: 'pisolino', scopi: ['sleep', 'meditate'], umori: ['serene', 'dreamy'], natura: ['rain'], nap: 1, art: ['nastri', '#08163A', '#14234A', '#3F9FF4', '#E71D4F', '#0F2041'] },
    { k: 'guidedsleep', n: 'Sonno guidato', d: 'Entra nel sonno con una guida.', ico: 'letto', guida: 'distensione', art: ['seno', '#061238', '#0F2A66', '#BCE0FF', '#3F9FF4'] },
    { k: 'winddown', n: 'Verso la calma', d: 'Passa dall’allerta alla calma.', ico: 'tramonto', scopi: ['sleep', 'relax'], umori: ['melancholic', 'serene', 'dreamy'], natura: ['fire', 'night'], art: ['stelle', '#0A1038', '#14305E', '#BCE0FF', '#F0C070'] },
    { k: 'sleepwake', n: 'Dormi e svegliati', d: 'Addormentati e svegliati riposato.', ico: 'alba', scopi: ['sleep'], umori: ['hopeful', 'serene', 'deep'], natura: ['forest'], art: ['punti', '#040A20', '#0F2041', '#8CC6FF', '#FFFFFF'] },
    { k: 'pref', n: 'Preferiti', d: 'Le tue tracce preferite per dormire.', ico: 'cuore', pref: 1, art: ['cuore', '#040A20', '#0C1E50', '#5F9CFF', '#BCE0FF'] }
  ],
  meditate: [
    { k: 'unguided', n: 'Senza guida', d: 'Vai in profondità, senza guida.', w: 1, ico: 'sassi', scopi: ['meditate', 'relax'], umori: ['serene', 'deep'], natura: ['wind', 'river'], art: ['nastri', '#061620', '#0C2E3E', '#3E8E7E', '#3A5AB0', '#8FD0E0'] },
    { k: 'guided', n: 'Con la guida', d: 'Segui una sessione guidata.', ico: 'testa', guida: 'sospiro', art: ['clessidra', '#04161C', '#0A2C30', '#6FE0C0', '#BFF4E4'] },
    { k: 'pref', n: 'Preferiti', d: 'Le tue tracce preferite per meditare.', ico: 'cuore', pref: 1, art: ['cuore', '#04141A', '#0A3038', '#55D6BC', '#BFF4E4'] }
  ]
};
/* densita' e luminosita' sono i parametri veri del motore (shared/music.ts della web app) */
const SUO_PRESET = { focus: [.55, .9, 'alto'], study: [.42, .85, 'medio'], work: [.68, 1, 'alto'], relax: [.62, .9, 'medio'], meditate: [.18, .7, 'basso'], sleep: [.1, .45, 'basso'] };
const SUO_UMORI = { dreamy: ['Sognante', 'Fluttuante'], hopeful: ['Luminoso', 'Fiducioso'], melancholic: ['Malinconico', 'Intimo'], serene: ['Sereno', 'Disteso'], deep: ['Profondo', 'Scuro'], uplifting: ['Energico', 'Incalzante'] };
const SUO_LIVELLI = {
  basso: ['Basso', 'Effetto neurale basso', 'Se sei sensibile ai suoni o ti viene facilmente mal di testa.'],
  medio: ['Medio', 'Effetto neurale medio', 'Il punto di partenza: se non sai quale scegliere, tieni questo.'],
  alto: ['Alto', 'Effetto neurale alto', 'Se fai fatica a restare sul pezzo e vuoi la spinta più forte.']
};
const SUO_NATURA = {
  rain: ['Pioggia', 'gocce'], storm: ['Temporale', 'tuono'], ocean: ['Spiaggia', 'palma'], river: ['Fiume', 'fiume'], wind: ['Vento', 'vento'],
  fire: ['Camino', 'fiamma'], night: ['Suoni della notte', 'luna'], forest: ['Bosco', 'albero']
};
const SUO_MUSICA = [['Atmosferica', 'scintille'], ['Tappeto sonoro', 'drone']];

const SUO_PATH = {
  indietro: '<path d="M15 5l-7 7 7 7"/>', giu: '<path d="M6 9l6 6 6-6"/>', avanti: '<path d="M9 5l7 7-7 7"/>',
  cuffie: '<path d="M4 15v-3a8 8 0 0116 0v3"/><rect x="2.5" y="14" width="4.5" height="7" rx="2"/><rect x="17" y="14" width="4.5" height="7" rx="2"/>',
  disco: '<circle cx="12" cy="12" r="9.5"/><circle cx="12" cy="12" r="2.5"/><path d="M6.5 12a5.5 5.5 0 013-4.9M17.5 12a5.5 5.5 0 01-3 4.9"/>',
  note: '<path d="M8 18V7l9-2v3"/><circle cx="5.5" cy="18" r="2.5"/><circle cx="16" cy="16" r="2.5"/><path d="M18.5 16V9"/><path d="M20 3v3M18.5 4.5h3"/>',
  cuore: '<path d="M12 20.5S3 15 3 8.7A4.7 4.7 0 0112 6.6a4.7 4.7 0 019 2.1C21 15 12 20.5 12 20.5z"/>',
  giudizio: '<path d="M8 4h9.5a1.5 1.5 0 011.5 1.2l1.5 7.3A2 2 0 0118.5 15H14l.7 3.3a2 2 0 01-1.9 2.4L8 14V4z"/><path d="M8 4H4v10h4"/>',
  scarica: '<circle cx="12" cy="12" r="9.5"/><path d="M12 7v9M8 12.5l4 4 4-4"/>',
  fatto: '<circle cx="12" cy="12" r="9.5"/><path d="M7.5 12.5l3 3 6-6.5"/>',
  condividi: '<path d="M14 4l7 6.5-7 6.5v-4C8 13 5 15 3 19c.5-6 4-10.5 11-11V4z"/>',
  info: '<circle cx="12" cy="12" r="9.5"/><path d="M12 11v6"/><circle cx="12" cy="7.5" r=".6" fill="currentColor"/>',
  timer: '<circle cx="12" cy="13.500" r="7.500"/><path d="M12 13.500l3-3M10 3h4"/>', intervalli: '<path d="M20.500 13.500A8.500 8.500 0 1 1 12 5"/><path d="M12 9v4.500l3 2"/><path d="M16 4.500l.01 0M19 7l.01 0M20.500 10l.01 0"/>',
  spunta: '<path d="M5 12.5l5 5 9-10.5"/>', salta: '<path d="M5 5l11 7-11 7V5z"/><path d="M19 5v14"/>', infinito: '<path d="M12 12c-2-3-3.5-4-5.5-4a4 4 0 000 8c2 0 3.5-1 5.5-4zm0 0c2 3 3.5 4 5.5 4a4 4 0 000-8c-2 0-3.5 1-5.5 4z"/>',
  comprimi: '<path d="M3 3l6 6M9 4v5H4M21 3l-6 6M15 4v5h5M3 21l6-6M9 20v-5H4M21 21l-6-6M15 20v-5h5"/>',
  lampo: '<path d="M13 2L5 14h6l-1 8 9-13h-6l1-7z"/>',
  atomo: '<circle cx="12" cy="12" r="1.5"/><ellipse cx="12" cy="12" rx="10" ry="4.2" transform="rotate(45 12 12)"/><ellipse cx="12" cy="12" rx="10" ry="4.2" transform="rotate(-45 12 12)"/>',
  libro: '<path d="M5 3h14v18H7a2 2 0 01-2-2V3z"/><path d="M5 18a2 2 0 012-2h12"/><path d="M10 3v7l2.5-1.5L15 10V3"/>',
  lampada: '<path d="M6 21h10M9 21l2-7 5-3"/><path d="M12 3l7 5-5 6-6-5 4-6z"/>',
  batteria: '<path d="M6 7H4a2 2 0 00-2 2v6a2 2 0 002 2h2M15 7h3a2 2 0 012 2v6a2 2 0 01-2 2h-3M22 10.5v3"/><path d="M12 6l-3 6h4l-2 6"/>',
  poltrona: '<path d="M6 11V8a3 3 0 013-3h6a3 3 0 013 3v3"/><path d="M4 11a2 2 0 012 2v2h12v-2a2 2 0 114 0v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4a2 2 0 012-2z"/>',
  panchina: '<path d="M2 13h11M3 17h9M4 13v6M11 13v6M3 9h9M17 21V11"/><circle cx="17" cy="7" r="4"/>',
  goccia: '<path d="M12 3s5.5 6 5.5 10.5a5.5 5.5 0 01-11 0C6.5 9 12 3 12 3z"/><path d="M4 8c-1.5 2-2 4-2 5.5C2 17 4 20 7 21M20 8c1.5 2 2 4 2 5.5 0 3.5-2 6.5-5 7.5"/>',
  valigia: '<rect x="3" y="8" width="18" height="12" rx="2"/><path d="M9 8V5a1 1 0 011-1h4a1 1 0 011 1v3M8 8v12M16 8v12"/>',
  zzz: '<path d="M11 13h7l-7 8h7M4 5h5l-5 6h5M14 3h4l-4 5h4"/>',
  pisolino: '<circle cx="12" cy="13" r="8.5"/><path d="M8 12c.5.8 1.5.8 2 0M14 12c.5.8 1.5.8 2 0M9.5 16.500c1.5 1 3.5 1 5 0"/><path d="M15 2l-2 3h3l-2 3"/>',
  letto: '<path d="M2 20V9M2 16h20v4M22 16v-3a3 3 0 00-3-3H10v6"/><circle cx="6.5" cy="12" r="2"/>',
  tramonto: '<path d="M4 20h16a4 4 0 00.5-8 6 6 0 00-11.5-1A4.5 4.5 0 004 20z"/><path d="M12 2v2M4.5 5l1.5 1.500M19.5 5L18 6.5"/>',
  alba: '<path d="M2 16h20M5 20h14M7 16a5 5 0 0110 0"/><path d="M12 4v3M4.5 8L6 9.500M19.5 8L18 9.5"/>',
  sassi: '<ellipse cx="12" cy="19" rx="9" ry="2.5"/><ellipse cx="12" cy="13.5" rx="6.5" ry="2.5"/><ellipse cx="12" cy="8.5" rx="4" ry="2"/><path d="M12 6.500V3"/>',
  testa: '<path d="M12 21v-4h-2a2 2 0 01-2-2v-2l-2-1 2-3a6 6 0 0112 1c0 2-1 3-2 4v7"/><path d="M19 6c1 .8 1.5 2 1.5 3M21.5 4c1.5 1.2 2 3 2 5"/>',
  scintille: '<path d="M12 4l1.8 5.200L19 11l-5.2 1.800L12 18l-1.8-5.200L5 11l5.2-1.800L12 4z"/><path d="M19 3v3M17.5 4.500h3M5 17v3M3.5 18.500h3"/>',
  drone: '<circle cx="12" cy="12" r="3"/><path d="M2 12h5M17 12h5"/>',
  gocce: '<path d="M6 5s3 3.3 3 6a3 3 0 01-6 0c0-2.7 3-6 3-6zM18 5s3 3.3 3 6a3 3 0 01-6 0c0-2.7 3-6 3-6zM12 12s3 3.3 3 6a3 3 0 01-6 0c0-2.7 3-6 3-6z"/>',
  tuono: '<path d="M7 16a4.5 4.5 0 01-.5-9 6 6 0 0111.5 1 3.5 3.5 0 01-.5 7"/><path d="M13 12l-3 5h4l-2 5"/>',
  palma: '<path d="M12 21c0-5 .5-9 2-12"/><path d="M14 9c-2-3-6-3-9 0 3 0 6 .5 9 0zM14 9c2-3 6-3 8 0-3 0-5 .5-8 0zM14 9c-1-3 0-5 3-6 .5 2 0 4-3 6z"/><path d="M4 21h16"/>',
  fiume: '<path d="M2 8c3-3 5-3 7 0s5 3 7 0 4-2 6-1M2 13c3-3 5-3 7 0s5 3 7 0 4-2 6-1M2 18c3-3 5-3 7 0s5 3 7 0 4-2 6-1"/>',
  vento: '<path d="M2 9h12a3 3 0 10-3-3M2 14h17a3 3 0 11-3 3M2 19h7"/>',
  fiamma: '<path d="M12 2c1 4 6 6 6 12a6 6 0 01-12 0c0-3 2-4 2-7 2 1 3 2.5 3 4 1-2 1.5-5 1-9z"/>',
  luna: '<path d="M14 3a6 6 0 006 8 8 8 0 11-6-8z"/>',
  albero: '<path d="M12 2l5 7h-3l4 6h-5v7h-2v-7H6l4-6H7l5-7z"/>',
  tazza: '<path d="M4 9h13v6a5 5 0 01-5 5H9a5 5 0 01-5-5V9zM17 10h2a2.5 2.5 0 010 5h-2M8 3v3M12 3v3"/>',
  prec: '<path d="M20 5.500v13a1 1 0 01-1.550.830L8.500 12.830a1 1 0 010-1.660l9.950-6.500A1 1 0 0120 5.500z" fill="currentColor"/><path d="M4.500 5v14"/>',
  succ: '<path d="M4 5.500v13a1 1 0 001.550.830l9.950-6.500a1 1 0 000-1.660L5.550 4.670A1 1 0 004 5.500z" fill="currentColor"/><path d="M19.500 5v14"/>',
  ripeti: '<path d="M17 2l4 4-4 4"/><path d="M3 11V9a3 3 0 013-3h15"/><path d="M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 01-3 3H3"/>',
  casuale: '<path d="M16 3h5v5"/><path d="M4 20L21 3"/><path d="M21 16v5h-5"/><path d="M15 15l6 6"/><path d="M4 4l5 5"/>',
  chiusa: '<rect x="5" y="11" width="14" height="10" rx="2.500"/><path d="M8 11V8a4 4 0 018 0v3"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>'
};
function suoIco(n, s, extra){ return '<svg viewBox="0 0 24 24" width="' + (s || 22) + '" height="' + (s || 22) + '" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"' + (extra || '') + '>' + (SUO_PATH[n] || '') + '</svg>'; }
function suoBarre(l){
  const o = { basso: [1, .3, .3], medio: [1, 1, .3], alto: [1, 1, 1] }[l] || [1, 1, 1];
  return '<svg class="suo-barre" viewBox="0 0 14 14" width="14" height="14" aria-hidden="true"><rect x="1" y="11" width="12" height="2.2" rx="1.1" fill="currentColor" opacity="' + o[0] + '"/><rect x="1" y="6" width="12" height="2.2" rx="1.1" fill="currentColor" opacity="' + o[1] + '"/><rect x="1" y="1" width="12" height="2.2" rx="1.1" fill="currentColor" opacity="' + o[2] + '"/></svg>';
}
const SUO_PLAY = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><path d="M7 4.500v15a1 1 0 001.5.9l12-7.500a1 1 0 000-1.700l-12-7.500A1 1 0 007 4.500z"/></svg>';
const SUO_PAUSA = '<svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor" aria-hidden="true"><rect x="6" y="4" width="4.5" height="16" rx="1.5"/><rect x="13.5" y="4" width="4.5" height="16" rx="1.5"/></svg>';

function suoLs(k, def){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v == null ? def : v; }catch(_){ return def; } }
function suoLsSet(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function suoEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function suoTabDi(k){ return SUO_TAB.filter(function(t){ return t.k === k; })[0] || SUO_TAB[0]; }
function suoAtt(tab, k){
  if (k === 'mix') return { k: 'mix', n: 'Custom ' + suoTabDi(tab).n + ' Mix', d: 'Musica scelta in base allo stile e all’umore della traccia che stai ascoltando.', ico: 'disco' };
  return (SUO_ATT[tab] || []).filter(function(a){ return a.k === k; })[0] || null;
}

/* ---------- il catalogo ---------- */
function suoNormLib(x){
  const p = SUO_PRESET[x.purpose] || SUO_PRESET.focus;
  return { id: x.id, tipo: 'lib', t: x.title, g: 'Atmospheric', bpm: x.bpm, mood: x.mood, scopo: x.purpose, url: x.url, dur: x.durationSec, loop: x.loop, liv: p[2], dens: p[0], lum: p[1], at: Date.parse(x.publishedAt || 0) || 0 };
}
function suoCatalogo(){
  const l = [];
  try{
    const aperte = suoAperte(), visti = {};
    fxItems().forEach(function(x){
      if (!(x && x.kind === 'track' && x.url && SUO_PRESET[x.purpose])) return;
      const t = suoNormLib(x); t.chiusa = !aperte[t.id]; visti[t.id] = 1; l.push(t);
    });
    /* un suono sbloccato resta anche quando il server lo toglie dal catalogo, se il suo file e' nel telefono */
    const sb = suoLs(SUO_K.sbl, {});
    Object.keys(sb).forEach(function(id){ if (!visti[id] && sb[id] && sb[id].f) l.push(Object.assign({}, sb[id], { chiusa: false })); });
  }catch(_){ }
  try{
    const cr = SND.credits || {};
    sndAll().forEach(function(s){
      if (SUO_NATURA[s.id] && cr[s.id] && !(typeof scrSuonoChiuso === 'function' && scrSuonoChiuso(s.id)))
        l.push({ id: s.id, tipo: 'nat', t: s.n, g: SUO_NATURA[s.id][0], desc: s.d, scopo: 'natura' });
      else if (sndGenerato(s.id))
        l.push({ id: s.id, tipo: 'gen', t: s.n, g: 'Drone', desc: s.d, liv: 'medio', scopo: { focus: 'focus', relax: 'relax', sonno: 'sleep' }[s.id] || 'focus' });
    });
  }catch(_){ }
  l.forEach(function(t){ SUO.tr[t.id] = t; });
  return l;
}
/* ---------- i suoni da sbloccare (0.9.315) ----------
   Andrea: "alcuni di ogni categoria aperti, tutti quelli prodotti di notte si sbloccano nel gioco". Per ogni scopo restano aperte
   le SUO_LIBERE tracce piu' vecchie del catalogo (una volta aperta, una traccia non si richiude; se il server la toglie, tocca
   alla successiva). Tutte le altre si aprono con le mystery box. Un preferito o un download restano sempre aperti. */
function suoLibere(){
  const lib = suoLs(SUO_K.liberi, []), per = {};
  fxItems().forEach(function(x){ if (x && x.kind === 'track' && x.url && SUO_PRESET[x.purpose]) (per[x.purpose] = per[x.purpose] || []).push(x); });
  let cambiate = false;
  Object.keys(per).forEach(function(sc){
    const l = per[sc].sort(function(a, b){ return (Date.parse(a.publishedAt || 0) - Date.parse(b.publishedAt || 0)) || String(a.id).localeCompare(String(b.id)); });
    let n = l.filter(function(x){ return lib.indexOf(x.id) >= 0; }).length;
    l.forEach(function(x){ if (n < SUO_LIBERE && lib.indexOf(x.id) < 0){ lib.push(x.id); n++; cambiate = true; } });
  });
  if (cambiate) suoLsSet(SUO_K.liberi, lib.slice(-200));
  return lib;
}
function suoAperte(){
  const a = {};
  suoLibere().forEach(function(id){ a[id] = 1; });
  Object.keys(suoLs(SUO_K.sbl, {})).forEach(function(id){ a[id] = 1; });
  suoLs(SUO_K.scar, []).forEach(function(id){ a[id] = 1; });
  const p = suoLs(SUO_K.pref, {});
  Object.keys(p).forEach(function(k){ (p[k] || []).forEach(function(t){ a[t.id] = 1; }); });
  return a;
}
function suoChiusa(id){ return !suoAperte()[id]; }
function suoChiuse(){ return suoCatalogo().filter(function(t){ return t.tipo === 'lib' && t.chiusa; }); }
function suoQuanteChiuse(){ return suoChiuse().length; }
/* apre una traccia: si preferisce lo scopo con meno musica aperta, a parita' la piu' nuova */
function suoApriTraccia(){
  const cat = suoCatalogo(), chiuse = cat.filter(function(t){ return t.tipo === 'lib' && t.chiusa; });
  if (!chiuse.length) return null;
  const aperte = {};
  cat.forEach(function(t){ if (t.tipo === 'lib' && !t.chiusa) aperte[t.scopo] = (aperte[t.scopo] || 0) + 1; });
  chiuse.sort(function(a, b){ return ((aperte[a.scopo] || 0) - (aperte[b.scopo] || 0)) || ((b.at || 0) - (a.at || 0)); });
  const t = chiuse[0], sb = suoLs(SUO_K.sbl, {});
  sb[t.id] = { id: t.id, tipo: 'lib', t: t.t, g: t.g, bpm: t.bpm, mood: t.mood, scopo: t.scopo, url: t.url, dur: t.dur, loop: t.loop, liv: t.liv, dens: t.dens, lum: t.lum, at: t.at, preso: Date.now(), f: 0 };
  suoLsSet(SUO_K.sbl, sb);
  suoSalvaSbloccata(t.id);
  return t;
}
/* il file resta nel telefono: il server cancella le tracce dopo trenta giorni. Si tengono gli ultimi SUO_FILE_MAX */
async function suoSalvaSbloccata(id){
  const sb0 = suoLs(SUO_K.sbl, {}), t = sb0[id]; if (!t) return;
  if (!(await suoSalvaFile(t))) return;
  const sb = suoLs(SUO_K.sbl, {}); if (sb[id]) sb[id].f = 1;
  const conFile = Object.keys(sb).filter(function(k){ return sb[k].f; }).sort(function(a, b){ return (sb[a].preso || 0) - (sb[b].preso || 0); });
  const via = conFile.slice(0, Math.max(0, conFile.length - SUO_FILE_MAX));
  via.forEach(function(k){ sb[k].f = 0; });
  suoLsSet(SUO_K.sbl, sb);
  via.forEach(function(k){ suoLevaFile(sb[k]); });
}
/* ogni mystery box: la probabilita' cresce con il valore della scatola; la prima apre sempre, e mai tre di fila a vuoto */
function suoTracciaDaBox(tier){
  if (!suoQuanteChiuse()) return null;
  const st = suoLs(SUO_K.box, { n: 0, secche: 0 });
  const pr = { bronzo: .45, argento: .75, oro: 1, leggendario: 1 }[tier] || .6;
  if (!(st.n === 0 || st.secche >= 2 || Math.random() < pr)){ st.secche++; suoLsSet(SUO_K.box, st); return null; }
  const t = suoApriTraccia(); if (!t) return null;
  st.n++; st.secche = 0; suoLsSet(SUO_K.box, st);
  return t;
}
/* il premio di una tappa della roadmap: li' il suono e' il premio intero */
function suoPremioTraccia(){
  const t = suoApriTraccia(); if (!t) return null;
  return { eti: 'RARO', ico: '🎵', t: 'Suono sbloccato: ' + t.t, s: 'Lo ascolti nei Suoni per concentrarsi.' };
}
function suoSblApri(){
  const cat = suoCatalogo().filter(function(t){ return t.tipo === 'lib'; }), chiuse = cat.filter(function(t){ return t.chiusa; }).length, aperte = cat.length - chiuse;
  suoSblChiudi();
  /* 0.9.318, Andrea: le mystery box stanno anche nelle tappe della Roadmap, ma la Roadmap ce l'ha solo chi segue il Genio: chi pianifica da solo vede un pulsante */
  const conRoadmap = typeof sdStradaMia === 'function' && !sdStradaMia() && typeof ozVaiRoadmap === 'function';
  const w = document.createElement('div'); w.id = 'suoSbl'; w.className = 'suo-sbl';
  w.addEventListener('click', function(e){ if (e.target === w) suoSblChiudi(); });
  w.innerHTML = '<div class="suo-sbl-f"><button type="button" class="suo-sbl-x" onclick="suoSblChiudi()" aria-label="Chiudi">' + suoIco('x', 20) + '</button>'
    + '<span class="suo-sbl-i">' + suoIco('chiusa', 30) + '</span><h3>Suoni da sbloccare</h3>'
    + '<div class="suo-sbl-b"><i style="width:' + Math.round(aperte / Math.max(1, cat.length) * 100) + '%"></i></div>'
    + '<p class="suo-sbl-n"><b>' + aperte + '</b> di ' + cat.length + ' suoni aperti</p>'
    + '<p class="suo-sbl-p">' + (conRoadmap ? 'Ogni notte arrivano suoni nuovi. Li apri con le mystery box: finisci una sessione di Full Focus o una tappa della Roadmap.' : 'Ogni notte arrivano suoni nuovi. Li apri con le mystery box: finisci una sessione di Full Focus.') + '</p>'
    + '<button type="button" class="suo-bianco" onclick="suoSblChiudi();if(typeof ffOpen===\'function\')ffOpen()">VAI AL FULL FOCUS</button>'
    + (conRoadmap ? '<button type="button" class="suo-sbl-2" onclick="suoSblChiudi();ozVaiRoadmap()">VAI ALLA ROADMAP</button>' : '')
    + '</div>';
  (document.getElementById('phone') || document.body).appendChild(w);
}
function suoSblChiudi(){ const w = document.getElementById('suoSbl'); if (w) w.remove(); }
/* LA LIBRERIA (0.9.350): due schede, i preferiti della scheda in cui sei (con la riproduzione casuale) e i suoni ancora da sbloccare */
const SUO_LIB = { tab: 'pref' };
function suoLibApri(t){
  SUO_LIB.tab = t === 'chiusi' ? 'chiusi' : 'pref';
  suoSblChiudi();
  const w = document.createElement('div'); w.id = 'suoSbl'; w.className = 'suo-sbl suo-lib';
  w.addEventListener('click', function(e){ if (e.target === w) suoSblChiudi(); });
  (document.getElementById('phone') || document.body).appendChild(w);
  suoLibPaint();
}
function suoLibPaint(){
  const w = document.getElementById('suoSbl'); if (!w || !w.classList.contains('suo-lib')) return;
  const tab = SUO.tab, l = ((suoLs(SUO_K.pref, {})[tab]) || []), nome = (suoTabDi(tab) || {}).n || '';
  const cat = suoCatalogo().filter(function(t){ return t.tipo === 'lib'; }), chiuse = cat.filter(function(t){ return t.chiusa; }).length, aperte = cat.length - chiuse;
  const conRoadmap = typeof sdStradaMia === 'function' && !sdStradaMia() && typeof ozVaiRoadmap === 'function';
  let corpo;
  if (SUO_LIB.tab === 'pref'){
    corpo = l.length
      ? '<button type="button" class="suo-lib-shuf" onclick="suoSblChiudi();suoAvvia(\'' + tab + '\',\'pref\')">' + suoIco('casuale', 20) + '<span>Riproduci tutti in ordine casuale</span></button>'
        + '<div class="suo-lib-l">' + l.map(function(t){ return '<button type="button" class="suo-lib-r" onclick="suoSblChiudi();suoAvvia(\'' + tab + '\',\'pref\',\'' + suoEsc(t.id) + '\')"><span>' + suoIco('cuore', 16, ' class="pieno"') + '</span><b>' + suoEsc(t.t || t.n || t.titolo || 'Traccia') + '</b>' + suoIco('avanti', 16) + '</button>'; }).join('') + '</div>'
      : '<p class="suo-lib-vuoto">Tocca il cuore mentre ascolti una traccia di ' + suoEsc(nome) + ': la ritrovi qui.</p>';
  } else {
    corpo = '<div class="suo-sbl-b"><i style="width:' + Math.round(aperte / Math.max(1, cat.length) * 100) + '%"></i></div>'
      + '<p class="suo-sbl-n"><b>' + aperte + '</b> di ' + cat.length + ' suoni aperti</p>'
      + '<p class="suo-sbl-p">' + (conRoadmap ? 'Ogni notte arrivano suoni nuovi. Li apri con le mystery box: finisci una sessione di Full Focus o una tappa della Roadmap.' : 'Ogni notte arrivano suoni nuovi. Li apri con le mystery box: finisci una sessione di Full Focus.') + '</p>'
      + '<button type="button" class="suo-bianco" onclick="suoSblChiudi();if(typeof ffOpen===\'function\')ffOpen()">VAI AL FULL FOCUS</button>'
      + (conRoadmap ? '<button type="button" class="suo-sbl-2" onclick="suoSblChiudi();ozVaiRoadmap()">VAI ALLA ROADMAP</button>' : '');
  }
  w.innerHTML = '<div class="suo-sbl-f"><button type="button" class="suo-sbl-x" onclick="suoSblChiudi()" aria-label="Chiudi">' + suoIco('x', 20) + '</button>'
    + '<h3 class="suo-lib-h">Libreria</h3>'
    + '<div class="suo-lib-tabs" role="tablist"><button type="button" role="tab" class="' + (SUO_LIB.tab === 'pref' ? 'on' : '') + '" onclick="SUO_LIB.tab=\'pref\';suoLibPaint()">' + suoIco('cuore', 16) + 'Preferiti ' + suoEsc(nome) + '</button>'
    + '<button type="button" role="tab" class="' + (SUO_LIB.tab === 'chiusi' ? 'on' : '') + '" onclick="SUO_LIB.tab=\'chiusi\';suoLibPaint()">' + suoIco('chiusa', 16) + 'Da sbloccare' + (chiuse ? ' · ' + chiuse : '') + '</button></div>'
    + '<div class="suo-lib-c">' + corpo + '</div></div>';
}
(function(){ const st = document.createElement('style'); st.textContent = '.suo-lib .suo-sbl-f{text-align:center}.suo-lib-h{margin:6px 44px 18px!important;font:800 21px var(--font-display);color:#fff}'
  + '.suo-lib-tabs{display:grid;grid-template-columns:1fr 1fr;gap:6px;padding:4px;border-radius:99px;background:rgba(255,255,255,.08);margin:0 0 22px}.suo-lib-tabs button{display:flex;align-items:center;justify-content:center;gap:6px;min-height:40px;border:0;border-radius:99px;background:none;color:rgba(255,255,255,.65);font:800 13px var(--font-body);cursor:pointer}.suo-lib-tabs button.on{background:#fff;color:#001E44}'
  + '.suo-lib-shuf{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:52px;margin:0 0 16px;border:0;border-radius:26px;background:#fff;color:#001E44;font:800 15px var(--font-body);cursor:pointer}'
  + '.suo-lib-l{display:flex;flex-direction:column;gap:8px;max-height:46vh;overflow-y:auto;text-align:left}.suo-lib-r{display:flex;align-items:center;gap:12px;width:100%;padding:13px 14px;border:0;border-radius:16px;background:rgba(255,255,255,.08);color:#fff;cursor:pointer}.suo-lib-r > span{flex:none;color:#E63946}.suo-lib-r b{flex:1;min-width:0;font:700 14.5px var(--font-body);color:#fff;text-align:left}'
  + '.suo-lib-vuoto{margin:8px auto 10px;max-width:28ch;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.75)}';
  document.head.appendChild(st); })();
function suoImpostazioni(){ return Object.assign({ livello: 'medio', adhd: false, generiNo: [], frasi: true, ordine: 'ordine' }, suoLs(SUO_K.set, {})); }
function suoNo(){ return suoLs(SUO_K.no, []); }
function suoMisura(t, att, liv){
  let p = Math.random();
  if ((att.scopi || []).indexOf(t.scopo) === 0) p += 2;
  else if ((att.scopi || []).indexOf(t.scopo) > 0) p += 1;
  if ((att.umori || []).indexOf(t.mood) >= 0) p += 3 - (att.umori || []).indexOf(t.mood) * .5;
  if (t.liv === liv) p += 1.5;
  /* le tracce nuove si sentono prima: e' il bello di averne ogni notte */
  if (t.at && Date.now() - t.at < 7 * 86400000) p += .5;
  return p;
}
/* Il flusso di una sessione: prima la musica adatta, poi le registrazioni dell'attivita', le musiche per la testa in fondo */
function suoFlusso(tab, attK, seme){
  const set = suoImpostazioni(), no = suoNo();
  const att = suoAtt(tab, attK); if (!att) return [];
  if (att.pref){ return (suoLs(SUO_K.pref, {})[tab] || []).filter(function(t){ return no.indexOf(t.id) < 0; }).map(function(t){ SUO.tr[t.id] = t; return t; }); }
  const tutti = suoCatalogo().filter(function(t){ return no.indexOf(t.id) < 0 && !t.chiusa; });
  const passa = function(t){ return set.generiNo.indexOf(t.g) < 0; };
  const costruisci = function(ok){
    let scopi, umori, natura, gen;
    if (att.k === 'mix'){
      const sue = (SUO_ATT[tab] || []).filter(function(a){ return a.scopi; });
      scopi = sue.reduce(function(a, x){ x.scopi.forEach(function(s){ if (a.indexOf(s) < 0) a.push(s); }); return a; }, []);
      umori = seme && seme.mood ? [seme.mood] : []; natura = []; gen = '';
    } else { scopi = att.scopi; umori = att.umori; natura = att.natura || []; gen = att.gen || ''; }
    const m = { scopi: scopi, umori: umori };
    const lib = tutti.filter(function(t){ return t.tipo === 'lib' && scopi.indexOf(t.scopo) >= 0 && ok(t); })
      .map(function(t){ return [suoMisura(t, m, set.livello), t]; }).sort(function(a, b){ return b[0] - a[0]; }).map(function(x){ return x[1]; }).slice(0, 12);
    const nat = tutti.filter(function(t){ return t.tipo === 'nat' && natura.indexOf(t.id) >= 0 && ok(t); });
    const gn = tutti.filter(function(t){ return t.tipo === 'gen' && t.id === gen && ok(t); });
    return lib.concat(nat, gn);
  };
  let l = costruisci(passa);
  if (!l.length) l = costruisci(function(){ return true; });
  if (!l.length) l = tutti.filter(function(t){ return t.tipo !== 'lib'; }).slice(0, 4);
  return l;
}

/* ---------- la pagina a schede ---------- */
function suoApri(){
  SUO.tab = suoLs(SUO_K.tab, SUO.sess ? SUO.sess.tab : 'focus');
  if (!suoTabDi(SUO.tab) || !SUO_ATT[SUO.tab]) SUO.tab = 'focus';
  goId('s-suoni');
  suoPaginaPaint();
  try{ sndCredits(); sndPrefetch(); fxCatalogo(false); }catch(_){ }
  /* si disegnano anche le altre schede: cambiare scheda non deve mai mostrare un'area vuota */
  setTimeout(function(){ SUO_TAB.forEach(function(t){ (SUO_ATT[t.k] || []).forEach(function(a){ suoCanvasDi(t.k, a); }); }); }, 500);
}
function suoScheda(k){
  if (k === SUO.tab) return;
  SUO.tab = k; suoLsSet(SUO_K.tab, k);
  suoPaginaPaint();
  const sc = document.getElementById('suoScorre'); if (sc) sc.scrollTop = 0;
}
function suoBloccoHtml(a){
  const tab = SUO.tab, n = a.pref ? (suoLs(SUO_K.pref, {})[tab] || []).length : 1;
  if (a.pref && !n){
    return '<div class="suo-card suo-vuota" style="--acc:' + suoTabDi(tab).acc + '"><span class="suo-vuota-c">' + suoIco('cuore', 26) + '</span><b>Nessun preferito ' + suoEsc(suoTabDi(tab).n) + ' per ora</b></div>';
  }
  return '<button type="button" class="suo-card' + (a.w ? ' suo-w' : '') + '" data-a="' + a.k + '" style="background:linear-gradient(135deg,' + a.art[1] + ',' + a.art[2] + ')" onclick="suoTocca(\'' + a.k + '\')">'
    + '<span class="suo-card-i">' + suoIco(a.ico, 24) + '</span>'
    + '<span class="suo-card-t"><b>' + suoEsc(a.n) + '</b><small>' + suoEsc(a.d) + '</small></span></button>';
}
function suoPaginaPaint(){
  const host = document.getElementById('suoPag'); if (!host) return;
  const t = suoTabDi(SUO.tab);
  const lista = SUO_ATT[SUO.tab] || [];
  const larghi = lista.filter(function(a){ return a.w; }), metà = lista.filter(function(a){ return !a.w; });
  const rec = suoLs(SUO_K.rec, []).filter(function(r){ return r.tab === SUO.tab && suoAtt(r.tab, r.att); }).slice(0, 3);
  host.style.background = 'linear-gradient(180deg,' + t.bg + ' 0%,#00132B 72%)';
  const chiuse = suoQuanteChiuse();
  host.innerHTML = '<div class="suo-testa"><button type="button" class="suo-ind" onclick="suoEsci()" aria-label="Indietro">' + suoIco('indietro', 24) + '</button>'
      + '<span class="suo-logo">' + suoIco('cuffie', 34) + '</span><span class="suo-ind" aria-hidden="true" style="visibility:hidden"></span></div>'
    + '<div class="suo-schede" role="tablist">' + SUO_TAB.map(function(x){ return '<button type="button" role="tab" aria-selected="' + (x.k === SUO.tab) + '" class="' + (x.k === SUO.tab ? 'on' : '') + '" onclick="suoScheda(\'' + x.k + '\')">' + x.n + '</button>'; }).join('') + '</div>'
    + '<div class="suo-scorre" id="suoScorre">'
      /* 0.9.350, Andrea: "i preferiti non in cima alle schede: in una pagina loro, la Libreria, con Preferiti e Da sbloccare" */
      + larghi.map(suoBloccoHtml).join('')
      + '<div class="suo-griglia">' + metà.map(suoBloccoHtml).join('') + '</div>'
      + (rec.length ? '<h3 class="suo-h">Riparti da una sessione recente</h3>' + rec.map(function(r){
          const a = suoAtt(r.tab, r.att);
          return '<button type="button" class="suo-rip" style="--c:' + suoRipColore(r.tab, r.att) + '" onclick="suoAvvia(\'' + r.tab + '\',\'' + r.att + '\')"><span class="suo-rip-t"><small>' + suoIco('infinito', 16) + ' Infinito</small><b>' + suoEsc(a.n) + '</b></span><span class="suo-rip-p">' + SUO_PLAY + '</span></button>';
        }).join('') : '')
      + (function(){ const np = ((suoLs(SUO_K.pref, {})[SUO.tab]) || []).length; const sotto = [np ? (np === 1 ? '1 preferito' : np + ' preferiti') : 'I tuoi preferiti', chiuse ? chiuse + ' da sbloccare' : ''].filter(Boolean).join(' · ');
          return '<button type="button" class="suo-prog-riga suo-lib-riga" onclick="suoLibApri(\'' + (np ? 'pref' : 'chiusi') + '\')"><i class="suo-pr-i">' + suoIco('cuore', 20) + '</i><span><b>Libreria</b><small>' + suoEsc(sotto) + '</small></span>' + suoIco('avanti', 18) + '</button>'; })()
      + '<button type="button" class="suo-prog-riga" onclick="suoProgApri()"><i class="suo-pr-i"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.500 2"/></svg></i><span><b>Programmi</b><small>I suoni che partono da soli, a un’ora o in un posto</small></span>' + suoIco('avanti', 18) + '</button>'
      /* 0.9.347, Andrea: "la casetta in alto a destra non la voglio li': mettila sotto al pannello Programmi" */
      + '<button type="button" class="suo-prog-riga" onclick="drsIconaHome(\'suoni\',\'Suoni\',\'suoni\',\'🎵\')"><i class="suo-pr-i"><svg viewBox="0 0 24 24" width="23" height="23" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.500 11.500 12 4l8.500 7.500"/><path d="M6 10v9.500h12V10"/><path d="M12 11.500v5M9.500 14h5"/></svg></i><span><b>Aggiungi i Suoni alla Home</b><small>Un’icona sul telefono che apre subito i suoni</small></span>' + suoIco('avanti', 18) + '</button>'
      + '<div class="suo-fondo"></div>'
    + '</div>'
    + '<div id="suoMini"></div>';
  suoAppendiDisegni(); suoMiniPaint();
}
function suoEsci(){ if (typeof navTornaDietro === 'function' && navTornaDietro('s-suoni')) return; goId('s-home'); try{ switchTab('rotta'); }catch(_){ } }
function suoTocca(k){
  const a = suoAtt(SUO.tab, k); if (!a) return;
  if (a.guida){ if (typeof rsApri === 'function') rsApri({ tecnica: a.guida, da: 'suoni' }); return; }
  suoAvvia(SUO.tab, k);
}

/* ---------- i disegni dei blocchi ---------- */
function suoRng(seed){ let a = seed >>> 0; return function(){ a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
function suoHash(s){ let h = 2166136261; s = String(s); for (let i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
function suoHex(c){ const n = parseInt(c.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }
function suoMix(a, b, t, al){ const x = suoHex(a), y = suoHex(b); return 'rgba(' + Math.round(x[0] + (y[0] - x[0]) * t) + ',' + Math.round(x[1] + (y[1] - x[1]) * t) + ',' + Math.round(x[2] + (y[2] - x[2]) * t) + ',' + al + ')'; }
function suoDisegna(cv, art, seed){
  const c = cv.getContext('2d'), W = cv.width, H = cv.height, S = W / 340, r = suoRng(seed);
  const tipo = art[0], c1 = art[3], c2 = art[4], c3 = art[5];
  const fondo = c.createLinearGradient(0, 0, W, H); fondo.addColorStop(0, art[1]); fondo.addColorStop(1, art[2]);
  c.fillStyle = fondo; c.fillRect(0, 0, W, H);
  c.lineCap = 'round'; c.lineJoin = 'round';
  const stelle = function(n, al){ for (let i = 0; i < n; i++){ c.fillStyle = 'rgba(255,255,255,' + (al * r()) + ')'; c.beginPath(); c.arc(r() * W, r() * H, (.3 + r() * 1.1) * S, 0, 7); c.fill(); } };
  const riga = function(f, x0, x1, passo){ c.beginPath(); for (let x = x0; x <= x1; x += passo){ const y = f(x); if (x === x0) c.moveTo(x, y); else c.lineTo(x, y); } c.stroke(); };
  const p1 = r() * 6.3, p2 = r() * 6.3;
  c.globalCompositeOperation = 'lighter';
  if (tipo === 'onde'){
    const N = 90, spesse = art[5] === 1;
    for (let i = 0; i < N; i++){
      const u = i / N; c.strokeStyle = suoMix(c1, c2, u, spesse ? .22 : .3); c.lineWidth = (spesse ? 2.2 : .8) * S;
      riga(function(x){ const k = x / W; return H * (.22 + .5 * u) + H * .16 * Math.sin(k * 5 + p1 + u * 1.6) + H * .07 * Math.sin(k * 11 + p2 - u * 3); }, 0, W, 5 * S);
    }
    stelle(50, .7);
  } else if (tipo === 'monti'){
    for (let i = 0; i < 80; i++){
      const u = i / 80; c.strokeStyle = suoMix(c1, c2, u, .34); c.lineWidth = .8 * S;
      const g = function(x, m, s){ return Math.exp(-Math.pow((x - m) / s, 2)); };
      riga(function(x){ return H * (.98 - u * .28) - H * .5 * (1 - u * .6) * g(x, W * .14, W * .2) - H * .42 * (1 - u * .4) * g(x, W * .74, W * .24) - H * .03 * Math.sin(x / W * 14 + u * 6); }, 0, W, 5 * S);
    }
  } else if (tipo === 'trattini'){
    c.globalCompositeOperation = 'source-over';
    const col = [c1, c2, c3];
    for (let i = 0; i < 1500; i++){
      const x = r() * W, y = r() * H, k = x / W, ang = -.5 + Math.sin(k * 4 + y / H * 4 + p1) * .6, len = (5 + r() * 30) * S, cc = col[Math.floor(r() * 3)];
      c.strokeStyle = suoMix(cc, art[1], r() * .5, .55 + r() * .4); c.lineWidth = (.6 + r() * r() * 7) * S;
      c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(ang) * len, y + Math.sin(ang) * len); c.stroke();
    }
  } else if (tipo === 'nastri'){
    const cols = [c1, c2, c3 || c1];
    for (let b = 0; b < 5; b++){
      const cc = cols[b % 3], y0 = H * (.08 + .2 * b), f = 2.5 + r() * 3, ph = r() * 6.3, inc = (r() - .5) * H * .8;
      for (let i = 0; i < 34; i++){
        const u = i / 34; c.strokeStyle = suoMix(cc, '#FFFFFF', u * .3, .22); c.lineWidth = 1.1 * S;
        riga(function(x){ const k = x / W; return y0 + inc * k + H * .2 * Math.sin(k * f + ph) + u * H * .24 * (.4 + .6 * Math.sin(k * 3 + ph)); }, 0, W, 5 * S);
      }
    }
  } else if (tipo === 'fili'){
    for (let i = 0; i < 90; i++){
      const u = i / 90, cc = u < .5 ? c1 : c2; c.strokeStyle = suoMix(cc, c3 || c1, Math.abs(u - .5), .24); c.lineWidth = .7 * S;
      riga(function(x){ const k = x / W; return H * (1.02 - k * .9) + (u - .5) * H * (1.1 - k * .9) * Math.sin(k * 3 + p1) + H * .05 * Math.sin(k * 9 + u * 5); }, 0, W, 5 * S);
    }
    stelle(70, .8);
  } else if (tipo === 'spettro'){
    const y0 = H * .46, N = Math.floor(W / (3.4 * S));
    for (let i = 0; i < N; i++){
      const k = i / N, g = Math.exp(-Math.pow((k - .4) / .22, 2)), h = H * (.03 + .42 * g * (.25 + r() * .75) + .08 * r() * Math.exp(-Math.pow((k - .72) / .14, 2)));
      c.strokeStyle = suoMix(c1, c2, r() * .4, .85); c.lineWidth = 1.5 * S;
      c.beginPath(); c.moveTo(i * 3.4 * S, y0); c.lineTo(i * 3.4 * S, y0 - h); c.stroke();
      c.strokeStyle = suoMix(c1, c2, .6, .14); c.beginPath(); c.moveTo(i * 3.4 * S, y0); c.lineTo(i * 3.4 * S, y0 + h * .45); c.stroke();
    }
    for (let i = 1; i < 12; i++){ c.strokeStyle = suoMix(c2, c1, i / 12, .28 - i * .018); c.lineWidth = .8 * S; c.beginPath(); c.ellipse(W * .42, y0 + 2, i * 32 * S, i * 5 * S, 0, 0, 7); c.stroke(); }
  } else if (tipo === 'sfere'){
    for (let i = 0; i < 46; i++){
      const u = i / 46; c.strokeStyle = suoMix(c1, c2, u, .25); c.lineWidth = .8 * S;
      c.beginPath(); for (let t = 0; t <= 1.001; t += .02){ const a = t * Math.PI * .9 + u * .8 + p1, R = W * (.15 + t * .7 + u * .3), x = W * .32 + Math.cos(a) * R * .6, y = H * .25 + Math.sin(a) * R; if (t === 0) c.moveTo(x, y); else c.lineTo(x, y); } c.stroke();
    }
    c.globalCompositeOperation = 'source-over';
    [[.6, .62, .22], [.3, .85, .17], [.84, .3, .08]].forEach(function(o){
      const x = W * o[0], y = H * o[1], R = W * o[2], g = c.createRadialGradient(x - R * .3, y - R * .4, R * .1, x, y, R);
      g.addColorStop(0, suoMix(c2, '#FFFFFF', .5, 1)); g.addColorStop(.7, suoMix(c1, c1, 0, 1)); g.addColorStop(1, suoMix(art[2], art[2], 0, .9));
      c.fillStyle = g; c.beginPath(); c.arc(x, y, R, 0, 7); c.fill();
    });
  } else if (tipo === 'dune'){
    c.globalCompositeOperation = 'source-over';
    for (let i = 0; i < 46; i++){
      const u = i / 46, base = H * (.14 + u * .92);
      const f = function(x){ const k = x / W; return base - H * .24 * Math.abs(Math.sin(k * 3 + p1 + u * 1.5)) * (1 - u * .4) - H * .05 * Math.sin(k * 13 + u * 8 + p2); };
      c.fillStyle = suoMix(art[1], art[2], u, 1); c.beginPath(); c.moveTo(0, H); for (let x = 0; x <= W; x += 5 * S) c.lineTo(x, f(x)); c.lineTo(W, H); c.closePath(); c.fill();
      c.strokeStyle = suoMix(c1, c2, u, .75); c.lineWidth = .9 * S; riga(f, 0, W, 5 * S);
    }
  } else if (tipo === 'strada'){
    stelle(90, .8);
    const vx = W * .55, vy = H * .42;
    for (let i = -24; i <= 24; i++){ const u = (i + 24) / 48; c.strokeStyle = suoMix(c1, c2, u, .36); c.lineWidth = .8 * S; c.beginPath(); c.moveTo(vx, vy); c.quadraticCurveTo(vx + i * 8 * S, vy + H * .2, vx + i * 22 * S, H * 1.05); c.stroke(); }
    const g = c.createRadialGradient(vx, vy, 0, vx, vy, W * .5); g.addColorStop(0, suoMix(c2, c2, 0, .55)); g.addColorStop(1, suoMix(c2, c2, 0, 0)); c.fillStyle = g; c.fillRect(0, 0, W, H);
  } else if (tipo === 'cuore'){
    stelle(70, .7);
    const cx = W * .5, cy = H * .42, K = Math.min(W, H) / 40;
    for (let j = 0; j < 22; j++){
      const u = j / 22; c.strokeStyle = suoMix(c1, c2, u, .3); c.lineWidth = 1 * S;
      c.beginPath();
      for (let t = 0; t <= 6.3; t += .05){ const w = 1 + .04 * Math.sin(t * 7 + j * .7), x = cx + 16 * Math.pow(Math.sin(t), 3) * K * w, y = cy - (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)) * K * w; if (t === 0) c.moveTo(x, y); else c.lineTo(x, y); }
      c.closePath(); c.stroke();
    }
  } else if (tipo === 'seno'){
    for (let i = 0; i < 60; i++){
      const u = i / 60; c.strokeStyle = suoMix(c1, c2, u, .36); c.lineWidth = 1 * S;
      riga(function(x){ const k = x / W; return H * (.24 + u * .36) + H * .26 * Math.sin(k * 6.6 + p1 * .1 + 1.2); }, 0, W, 4 * S);
    }
    for (let i = 0; i < 26; i++){ const x = r() * W, y = r() * H, R = (2 + r() * 9) * S; c.fillStyle = suoMix(c1, c2, r(), .14 + r() * .2); c.beginPath(); c.arc(x, y, R, 0, 7); c.fill(); }
  } else if (tipo === 'stelle'){
    stelle(260, .9);
    for (let i = 0; i < 46; i++){
      const u = i / 46; c.strokeStyle = suoMix(c1, c2, u, .3); c.lineWidth = .9 * S;
      riga(function(x){ const k = x / W; return H * (.98 - k * .5) + (u - .5) * H * .3 * (.3 + k) + H * .1 * Math.sin(k * 5 + p1); }, 0, W, 5 * S);
    }
  } else if (tipo === 'punti'){
    for (let i = 0; i < 32; i++){
      const u = i / 32;
      for (let t = 0; t < 1; t += .028){
        const x = W * (.05 + t * 1.05), y = H * (1.05 - t * .95 - u * .5 * (1 - t * .4)) + H * .06 * Math.sin(t * 8 + u * 5), R = (.4 + 1.5 * t * t) * S;
        c.fillStyle = suoMix(c1, c2, t, .22 + t * .6); c.beginPath(); c.arc(x, y, R, 0, 7); c.fill();
      }
    }
  } else if (tipo === 'clessidra'){
    stelle(90, .7);
    for (let i = 0; i < 70; i++){
      const u = i / 70 - .5; c.strokeStyle = suoMix(c1, c2, Math.abs(u) * 2, .3); c.lineWidth = .8 * S;
      c.beginPath();
      for (let y = 0; y <= H; y += 4 * S){ const k = y / H, env = .08 + .92 * Math.pow(Math.abs(k - .52) * 2, 1.4), x = W * (.46 + .1 * Math.sin(k * 4 + 1)) + u * W * 1.1 * env; if (y === 0) c.moveTo(x, y); else c.lineTo(x, y); }
      c.stroke();
    }
  }
  c.globalCompositeOperation = 'source-over';
  /* l'ombra in basso: il testo si legge su qualunque disegno */
  const om = c.createLinearGradient(0, H * .35, 0, H); om.addColorStop(0, 'rgba(6,6,12,0)'); om.addColorStop(1, 'rgba(6,6,12,.8)');
  c.fillStyle = om; c.fillRect(0, 0, W, H);
}
function suoCanvasDi(tab, a){
  if (a.pref && !a.art) return null;
  const k = tab + ':' + a.k;
  if (SUO.canvas[k]) return SUO.canvas[k];
  const dpr = Math.min(window.devicePixelRatio || 1, 2), w = a.w ? 340 : 160, h = a.w ? 190 : 210;
  const cv = document.createElement('canvas'); cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); cv.className = 'suo-card-art';
  SUO.canvas[k] = cv; SUO.coda.push([cv, a.art, suoHash(k)]);
  suoCodaGira();
  return cv;
}
/* un disegno per fotogramma: anche il telefono piu' lento non perde un tocco */
function suoCodaGira(){
  if (SUO.disegna) return; SUO.disegna = true;
  const passo = function(){
    const j = SUO.coda.shift();
    if (!j){ SUO.disegna = false; return; }
    try{ suoDisegna(j[0], j[1], j[2]); j[0].classList.add('pronto'); }catch(e){ console.warn('suoni, disegno:', e); }
    requestAnimationFrame(passo);
  };
  requestAnimationFrame(passo);
}
function suoAppendiDisegni(){
  document.querySelectorAll('#suoPag .suo-card[data-a]').forEach(function(el){
    const a = suoAtt(SUO.tab, el.getAttribute('data-a')); if (!a) return;
    const cv = suoCanvasDi(SUO.tab, a); if (cv) el.insertBefore(cv, el.firstChild);
  });
}
/* la copertina di una traccia: stessa famiglia di disegni, scelta dall'id. Ogni traccia ha sempre la sua */
function suoCopertina(t){
  if (SUO.cop[t.id]) return SUO.cop[t.id];
  const tabk = suoTabDella(t), lista = (SUO_ATT[tabk] || SUO_ATT.focus).filter(function(a){ return a.art && !a.pref; });
  const a = lista[suoHash(t.id) % lista.length];
  const cv = document.createElement('canvas'); cv.width = cv.height = 180;
  try{ suoDisegna(cv, a.art, suoHash(t.id)); SUO.cop[t.id] = cv.toDataURL('image/jpeg', .78); }catch(_){ SUO.cop[t.id] = ''; }
  return SUO.cop[t.id];
}
function suoTabDella(t){
  if (t.scopo === 'relax' || t.scopo === 'sleep' || t.scopo === 'meditate') return t.scopo;
  if (t.scopo === 'natura') return SUO.sess ? SUO.sess.tab : SUO.tab;
  return 'focus';
}

/* ---------- la sessione ---------- */
/* 0.9.315: niente barra del volume nel lettore, come nel riferimento: il volume lo fanno i tasti del telefono */
function suoLivello(){ return 1; }
function suoSegnaGiorno(){
  const oggi = new Date().toISOString().slice(0, 10), g = suoLs(SUO_K.giorni, []);
  if (g.indexOf(oggi) < 0){ g.push(oggi); suoLsSet(SUO_K.giorni, g.slice(-400)); }
}
/* 0.9.315: la serie si misura in settimane di ascolto consecutive: e' il numero accanto alle cuffie */
function suoLunedi(d){ const x = new Date(d); x.setHours(12, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x.toISOString().slice(0, 10); }
function suoSerie(){
  const sett = {};
  suoLs(SUO_K.giorni, []).forEach(function(k){ sett[suoLunedi(k + 'T12:00:00')] = 1; });
  const conta = function(da){ let n = 0; const d = new Date(da); for (;;){ if (!sett[suoLunedi(d)]) break; n++; d.setDate(d.getDate() - 7); } return n; };
  const ora = new Date(), scorsa = new Date(ora.getTime() - 7 * 86400000);
  /* la settimana in corso non spezza la serie finche' non e' finita */
  const att = sett[suoLunedi(ora)] ? conta(ora) : conta(scorsa);
  let max = att;
  Object.keys(sett).forEach(function(k){ max = Math.max(max, conta(k + 'T12:00:00')); });
  max = Math.max(max, +suoLs(SUO_K.serieMax, 0) || 0);
  suoLsSet(SUO_K.serieMax, max);
  return { att: att, max: max };
}
async function suoAvvia(tab, attK, primaTraccia, dietro){
  const att = suoAtt(tab, attK); if (!att) return;
  /* appena installata il manifest non e' ancora arrivato: gli si lasciano due secondi */
  try{ await sndCredits(); if (!fxItems().length) await Promise.race([fxCatalogo(true), new Promise(function(ok){ setTimeout(ok, 2000); })]); }catch(_){ }
  const seme = SUO.sess && SUO.sess.cur;
  const l = suoFlusso(tab, attK, seme);
  if (!l.length){ try{ toast(att.pref ? 'Non hai ancora preferiti qui' : 'Non trovo tracce: controlla la connessione'); }catch(_){ } return; }
  /* 0.9.348: i preferiti suonano in ordine casuale (shuffle), come la playlist dei salvati di Brain.fm */
  if (att.pref && !primaTraccia){ for (let k = l.length - 1; k > 0; k--){ const j = Math.floor(Math.random() * (k + 1)); const x = l[k]; l[k] = l[j]; l[j] = x; } }
  if (suoNativo()) suoFermaWeb(); else suoFermaAudio();
  try{ if (typeof SND !== 'undefined' && SND.vol < 1 && typeof sndVolume === 'function') sndVolume(1); }catch(_){ }
  SUO.sess = { tab: tab, att: attK, flusso: l, i: 0, t0: Date.now(), acc: 0, pausa: false, errori: 0, cur: null, fine: att.nap ? SUO_NAP : 0, storia: [], nativo: !!(SUO.sess && SUO.sess.nativo), firma: (SUO.sess && SUO.sess.firma) || '' };
  SUO.tab = tab; suoLsSet(SUO_K.tab, tab);
  suoSegnaGiorno();
  const r = suoLs(SUO_K.rec, []).filter(function(x){ return !(x.tab === tab && x.att === attK); }); r.unshift({ tab: tab, att: attK, at: Date.now() }); suoLsSet(SUO_K.rec, r.slice(0, 12));
  if (primaTraccia){ const i = l.map(function(x){ return x.id; }).indexOf(primaTraccia); if (i > 0) SUO.sess.i = i; }
  suoSuona(l[SUO.sess.i], false);
  /* 0.9.326: dal Full Focus la playlist suona senza aprire il lettore */
  if (!dietro) suoPlayerApri();
  suoTicParti();
}
function suoSvanisci(a, da, a2, ms, poi){
  const t0 = Date.now();
  const iv = setInterval(function(){
    const u = Math.min(1, (Date.now() - t0) / ms);
    try{ a.volume = Math.max(0, Math.min(1, da + (a2 - da) * u)); }catch(_){ }
    if (u >= 1){ clearInterval(iv); if (poi) poi(); }
  }, 80);
  return iv;
}
async function suoSorgente(t){
  if (typeof caches !== 'undefined'){
    for (const nome of [SUO_CACHE, (typeof FX_CACHE !== 'undefined' ? FX_CACHE : '')]){
      if (!nome) continue;
      try{ const hit = await (await caches.open(nome)).match(t.url); if (hit) return URL.createObjectURL(await hit.blob()); }catch(_){ }
    }
  }
  return t.url;
}
function suoFermaWeb(){
  const a = SUO.audio; SUO.audio = null;
  if (a){ try{ a.ontimeupdate = null; a.onerror = null; a.pause(); a.removeAttribute('src'); a.load(); }catch(_){ } }
}
function suoFermaAudio(){
  suoFermaWeb();
  try{ const n = SUO.sess; if (n && n.nativo){ n.nativo = false; n.firma = ''; NATIVE.soundCommand({ what: 'stop' }); return; } }catch(_){ }
  try{ const s = SUO.sess; if (s && s.cur && s.cur.tipo !== 'lib' && typeof SND !== 'undefined' && SND.id === s.cur.id){ SUO_INTERNO = true; sndStop(); SND.id = 'none'; SND.playing = false; SUO_INTERNO = false; } }catch(_){ SUO_INTERNO = false; }
}
/* IL LETTORE NELLA TENDINA (0.9.318). Andrea: "su brain.fm c'e' il lettore nella tendina e sul blocco schermo, nella nostra app non
   compare un bel niente". Questo lettore suonava con un Audio della pagina, e una WebView non pubblica nessuna sessione multimediale.
   Sul telefono adesso la lista la suona SoundService: tendina, blocco schermo e cuffie comandano davvero, e la pagina segue con
   suoNativoEvento. Se il servizio non riesce (niente rete e traccia non ancora scaricata) la pagina riprende con le sue copie. */
function suoNativo(){ try{ return !SUO.nativoNo && sndNative() && typeof NATIVE.suoLista === 'function'; }catch(_){ return false; } }
function suoVoce(t){ return { id: t.id, t: t.t, url: t.tipo === 'lib' ? t.url : '', asset: t.tipo === 'nat' ? t.id : '', fine: t.loop ? (t.loop.startSec + t.loop.lengthSec) : 0 }; }
async function suoSuonaNativo(t){
  const s = SUO.sess;
  try{ if (typeof fxBranoFerma === 'function') fxBranoFerma(); if (typeof SND !== 'undefined' && SND.id !== 'none'){ SUO_INTERNO = true; sndStop(true); SND.id = 'none'; SND.playing = false; SUO_INTERNO = false; } }catch(_){ SUO_INTERNO = false; }
  suoFermaWeb();
  const vis = s.flusso.filter(function(x){ return x.tipo === 'lib' || x.tipo === 'nat'; });
  const i = Math.max(0, vis.indexOf(t)), casuale = suoImpostazioni().ordine === 'casuale';
  const firma = vis.map(function(x){ return x.id; }).join('|');
  if (s.nativo && s.firma === firma){ await NATIVE.suoVai({ i: i, casuale: casuale }); return; }
  s.firma = firma; s.nativo = true;
  const cop = {}; cop[t.id] = suoCopertina(t);
  await NATIVE.suoLista({ lista: vis.map(suoVoce), i: i, volume: suoLivello(), casuale: casuale, copertine: cop });
  suoCopertineDopo(vis, s);
}
/* le copertine delle altre tracce, una alla volta e senza fretta: servono quando il cambio lo chiede la tendina a schermo spento */
function suoCopertineDopo(vis, s){
  let k = 0;
  const giro = function(){
    if (SUO.sess !== s) return;
    const pezzo = {};
    for (let n = 0; n < 4 && k < vis.length; n++, k++) pezzo[vis[k].id] = suoCopertina(vis[k]);
    try{ NATIVE.suoCopertine({ copertine: pezzo }); }catch(_){ }
    if (k < vis.length) setTimeout(giro, 400);
  };
  setTimeout(giro, 900);
}
/** Quello che dice il servizio: la voce cambiata dalla tendina, la pausa, l'arresto, l'errore. */
function suoNativoEvento(ev){
  const s = SUO.sess; if (!s || !s.nativo) return;
  if (ev.error){ console.warn('lettore: ' + ev.error); SUO.nativoNo = true; s.nativo = false; s.firma = ''; if (s.cur) suoSuona(s.cur, false); return; }
  if (ev.fermo){ if (!s.pausa){ s.acc += (Date.now() - s.t0) / 1000; s.pausa = true; } s.nativo = false; s.firma = ''; suoStatoPaint(); return; }
  if (ev.id && (!s.cur || s.cur.id !== ev.id)){
    const j = s.flusso.map(function(x){ return x.id; }).indexOf(ev.id);
    if (j >= 0){ s.i = j; s.cur = s.flusso[j]; suoPlayerPaint(); suoMiniPaint(); }
  }
  if (!!ev.playing === !!s.pausa){
    if (ev.playing){ s.t0 = Date.now(); s.pausa = false; } else { s.acc += (Date.now() - s.t0) / 1000; s.pausa = true; }
    suoStatoPaint();
  }
}
/* nel browser e sul computer: il lettore di sistema, dove esiste */
function suoMediaWeb(t){
  try{
    if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
    const cop = suoCopertina(t);
    navigator.mediaSession.metadata = new MediaMetadata({ title: t.t, artist: 'DreamMap', artwork: cop ? [{ src: cop, sizes: '180x180', type: 'image/jpeg' }] : [] });
    navigator.mediaSession.setActionHandler('play', function(){ suoPausaSet(false); });
    navigator.mediaSession.setActionHandler('pause', function(){ suoPausaSet(true); });
    navigator.mediaSession.setActionHandler('nexttrack', function(){ suoProssima(false); });
    navigator.mediaSession.setActionHandler('previoustrack', function(){ suoPrecedente(); });
  }catch(_){ }
}
function suoAttendi(ms){ return new Promise(function(ok){ setTimeout(ok, ms); }); }
async function suoSuona(t, dissolvi){
  const s = SUO.sess; if (!s) return;
  s.cur = t; s.cambio = false; s.pausa = false;
  if (t.tipo !== 'gen' && suoNativo()){
    suoPlayerPaint(); suoMiniPaint();
    try{ await suoSuonaNativo(t); return; }
    catch(e){ console.warn('lettore: ' + (e && e.message)); SUO.nativoNo = true; s.nativo = false; s.firma = ''; }
  }
  if (s.nativo){ s.nativo = false; s.firma = ''; try{ NATIVE.soundCommand({ what: 'stop' }); }catch(_){ } }
  /* il titolo cambia subito; il suono vecchio sfuma, poi silenzio, poi quello nuovo sale piano */
  const vec = SUO.audio; SUO.audio = null;
  let attesa = 0;
  if (vec){ vec.ontimeupdate = null; vec.onerror = null; suoSvanisci(vec, vec.volume, 0, SUO_USCITA, function(){ try{ vec.pause(); vec.removeAttribute('src'); vec.load(); }catch(_){ } }); attesa = SUO_USCITA + SUO_STACCO; }
  suoPlayerPaint(); suoMiniPaint();
  if (t.tipo === 'lib'){
    try{ if (typeof fxBranoFerma === 'function') fxBranoFerma(); if (typeof SND !== 'undefined' && SND.id !== 'none'){ SUO_INTERNO = true; sndStop(); SND.id = 'none'; SND.playing = false; SUO_INTERNO = false; attesa = attesa || SUO_STACCO; } }catch(_){ SUO_INTERNO = false; }
    const src = await suoSorgente(t);
    if (attesa) await suoAttendi(attesa);
    if (SUO.sess !== s || s.cur !== t || s.pausa) return;
    const a = new Audio(); a.loop = true; a.preload = 'auto'; a.src = src;
    const liv = suoLivello(); a.volume = 0;
    a.ontimeupdate = function(){
      if (SUO.audio !== a || !SUO.sess || SUO.sess.cambio) return;
      const fine = t.loop ? t.loop.startSec + t.loop.lengthSec : (a.duration || 0);
      if (fine && a.currentTime >= fine - 1) suoProssima(true);
    };
    a.onerror = function(){ if (SUO.audio === a) suoErrore(); };
    SUO.audio = a;
    try{ await a.play(); s.errori = 0; }catch(_){ if (SUO.audio === a) suoErrore(); return; }
    suoSvanisci(a, 0, liv, SUO_ENTRATA);
  } else {
    if (attesa) await suoAttendi(attesa);
    if (SUO.sess !== s || s.cur !== t || s.pausa) return;
    SUO_INTERNO = true;
    try{ if (SND.id === t.id && SND.playing === false) sndPlay(t.id); else if (SND.id !== t.id) sndPlay(t.id); }catch(_){ }
    SUO_INTERNO = false;
    /* le registrazioni durano un minuto e girano da sole: si cambia ogni cinque minuti */
    s.cambioA = Date.now() + 300000;
  }
  suoMediaWeb(t);
}
function suoErrore(){
  const s = SUO.sess; if (!s) return;
  s.errori = (s.errori || 0) + 1;
  if (s.errori >= Math.min(3, s.flusso.length)){
    /* niente rete: si resta con qualcosa dentro all'app, se c'e' */
    const dentro = suoCatalogo().filter(function(t){ return t.tipo === 'nat'; })[0];
    if (dentro && s.cur && s.cur.tipo === 'lib'){ s.flusso = [dentro]; s.i = 0; s.errori = 0; try{ toast('Senza connessione suona una registrazione dell’app'); }catch(_){ } suoSuona(dentro, false); return; }
    try{ toast('Questa traccia adesso non parte: riprova con la connessione'); }catch(_){ }
    suoPausaSet(true); return;
  }
  suoProssima(false);
}
function suoProssima(dissolvi){
  const s = SUO.sess; if (!s || !s.flusso.length) return;
  s.cambio = true;
  (s.storia = s.storia || []).push(s.i); s.storia = s.storia.slice(-30);
  if (suoImpostazioni().ordine === 'casuale' && s.flusso.length > 2){
    let j = s.i; while (j === s.i) j = Math.floor(Math.random() * s.flusso.length);
    s.i = j;
  } else s.i = (s.i + 1) % s.flusso.length;
  suoSuona(s.flusso[s.i], !!dissolvi);
}
function suoPrecedente(){
  const s = SUO.sess; if (!s || !s.flusso.length) return;
  const st = s.storia || [];
  let j = st.length ? st.pop() : (s.i - 1 + s.flusso.length) % s.flusso.length;
  if (j >= s.flusso.length) j = 0;
  s.cambio = true; s.i = j;
  suoSuona(s.flusso[s.i], false);
}
function suoOrdineTocca(){
  const b = suoImpostazioni(); b.ordine = b.ordine === 'casuale' ? 'ordine' : 'casuale';
  suoLsSet(SUO_K.set, b);
  try{ toast(b.ordine === 'casuale' ? 'Riproduzione casuale' : 'Riproduzione in ordine'); }catch(_){ }
  const e = document.getElementById('suoOrdine'); if (e){ e.innerHTML = suoIco(b.ordine === 'casuale' ? 'casuale' : 'ripeti', 28); e.setAttribute('aria-label', b.ordine === 'casuale' ? 'Riproduzione casuale' : 'Riproduzione in ordine'); }
}
function suoSuonaQuesta(id){
  const s = SUO.sess; if (!s) return;
  const i = s.flusso.map(function(t){ return t.id; }).indexOf(id);
  if (i < 0) return;
  s.i = i; suoSuona(s.flusso[i], false);
  const sc = document.getElementById('suoPlayerScorre'); if (sc) sc.scrollTop = 0;
}
function suoTrascorso(){ const s = SUO.sess; if (!s) return 0; return s.acc + (s.pausa ? 0 : (Date.now() - s.t0)) / 1000; }
function suoInPausa(){
  const s = SUO.sess; if (!s) return true;
  if (s.pausa) return true;
  if (s.nativo) return false;
  if (s.cur && s.cur.tipo !== 'lib'){ try{ return !(SND.id === s.cur.id && SND.playing !== false); }catch(_){ return false; } }
  return false;
}
function suoPausaSet(fermo){
  const s = SUO.sess; if (!s) return;
  if (s.cur && s.cur.tipo !== 'gen' && suoNativo()){
    if (fermo === !!s.pausa) return;
    if (fermo){ s.acc += (Date.now() - s.t0) / 1000; s.pausa = true; } else { s.t0 = Date.now(); s.pausa = false; }
    if (s.nativo){ try{ NATIVE.soundCommand({ what: fermo ? 'pause' : 'resume', volume: suoLivello() }); }catch(_){ } }
    else if (!fermo) suoSuona(s.cur, false);
    suoStatoPaint();
    return;
  }
  if (fermo === !!s.pausa && !(s.cur && s.cur.tipo !== 'lib')) return;
  if (fermo){ s.acc += (Date.now() - s.t0) / 1000; s.pausa = true; } else { s.t0 = Date.now(); s.pausa = false; }
  if (s.cur && s.cur.tipo === 'lib'){
    const a = SUO.audio;
    if (a){ try{ if (fermo) a.pause(); else a.play().catch(function(){ suoErrore(); }); }catch(_){ } }
    else if (!fermo) suoSuona(s.cur, false);
  } else if (s.cur){
    SUO_INTERNO = true;
    try{ const suona = SND.id === s.cur.id && SND.playing !== false; if (suona === !!fermo) sndPlay(s.cur.id); }catch(_){ }
    SUO_INTERNO = false;
  }
  suoStatoPaint();
}
function suoPausaTocca(){ suoPausaSet(!suoInPausa()); }
/* Un altro pezzo dell'app ha fatto partire un suono: la sessione finisce, un suono alla volta */
function suoStaccata(){
  if (SUO_INTERNO || !SUO.sess) return;
  const a = SUO.audio; SUO.audio = null;
  if (a){ try{ a.ontimeupdate = null; a.onerror = null; a.pause(); a.removeAttribute('src'); a.load(); }catch(_){ } }
  SUO.sess = null; suoMiniPaint();
}
function suoVolume(){ try{ if (SUO.audio) SUO.audio.volume = suoLivello(); }catch(_){ } }
function suoTicParti(){
  if (SUO.tic) return;
  SUO.tic = setInterval(function(){
    const s = SUO.sess;
    if (!s){ clearInterval(SUO.tic); SUO.tic = 0; return; }
    const tx = suoTempoTesto();
    const a = document.getElementById('suoTempo'); if (a) a.textContent = tx;
    const b = document.getElementById('suoMiniTempo'); if (b) b.textContent = tx;
    /* gli intervalli: finito il lavoro la musica si ferma e parte la pausa; finita la pausa riparte */
    if (s.iv && s.iv.rest){
      if (Date.now() >= s.iv.rest){ s.iv.rest = 0; suoIntervalloSuono(s.iv.suono, 'Si ricomincia'); suoPausaSet(false); s.iv.a = suoTrascorso() + s.iv.lav; suoPlayerPaint(); }
      return;
    }
    if (s.pausa) return;
    if (s.iv && suoTrascorso() >= s.iv.a){ suoPausaSet(true); s.iv.rest = Date.now() + s.iv.pau * 1000; suoIntervalloSuono(s.iv.suono, 'Pausa'); suoPlayerPaint(); return; }
    if (s.fine && suoTrascorso() >= s.fine){ suoPausaSet(true); s.fine = 0; try{ toast('Pisolino finito'); }catch(_){ } return; }
    if (s.cur && s.cur.tipo !== 'lib' && s.cambioA && Date.now() > s.cambioA && s.flusso.length > 1 && !suoInPausa()){ s.cambioA = 0; suoProssima(false); }
  }, 1000);
}
function suoTempoTesto(){
  const s = SUO.sess; if (!s) return '0:00';
  const sec = s.iv ? Math.max(0, Math.floor(s.iv.rest ? (s.iv.rest - Date.now()) / 1000 : s.iv.a - suoTrascorso())) : Math.max(0, Math.floor(s.fine ? s.fine - suoTrascorso() : suoTrascorso()));
  const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), ss = String(sec % 60).padStart(2, '0');
  return h ? h + ':' + String(m).padStart(2, '0') + ':' + ss : m + ':' + ss;
}

/* ---------- il lettore piccolo in fondo alla pagina ---------- */
function suoMiniPaint(){
  const host = document.getElementById('suoMini'); if (!host) return;
  const s = SUO.sess;
  host.classList.toggle('su', !!s);
  if (!s || !s.cur){ host.innerHTML = ''; return; }
  const t = s.cur;
  host.innerHTML = '<div class="suo-mini" role="button" onclick="suoPlayerApri()"><img alt="" src="' + suoCopertina(t) + '">'
    + '<span class="suo-mini-t"><b>' + (t.liv ? suoBarre(t.liv) : '') + '<i>' + suoEsc(t.t) + '</i></b><small>' + suoEsc(t.g) + '</small></span>'
    + '<span class="suo-mini-c">' + (s.fine ? '' : suoIco('infinito', 16)) + '<span id="suoMiniTempo">' + suoTempoTesto() + '</span></span>'
    + '<button type="button" class="suo-mini-p" id="suoMiniP" onclick="event.stopPropagation();suoPausaTocca()" aria-label="' + (suoInPausa() ? 'Riprendi' : 'Pausa') + '">' + (suoInPausa() ? SUO_PLAY : SUO_PAUSA) + '</button></div>';
}

/* ---------- la schermata di quando suona: il tempo, poi il brano con i preferiti ---------- */
function suoEPref(id, tab){ const p = suoLs(SUO_K.pref, {}); return (p[tab] || []).some(function(x){ return x.id === id; }); }
function suoEScaricata(t){ if (!t || t.tipo !== 'lib') return true; return suoLs(SUO_K.scar, []).indexOf(t.id) >= 0; }
function suoTabSess(){ return SUO.sess ? SUO.sess.tab : SUO.tab; }
function suoAzioneHtml(id, ico, testo, on, azione){ return '<button type="button" class="suo-az' + (on ? ' on' : '') + '" id="' + id + '" onclick="' + azione + '">' + ico + '<span>' + testo + '</span></button>'; }
function suoAzioniHtml(t){
  const tab = suoTabSess(), pref = suoEPref(t.id, tab), no = suoNo().indexOf(t.id) >= 0, sc = suoEScaricata(t);
  const inApp = t.tipo !== 'lib';
  return suoAzioneHtml('suoAzNo', suoIco('giudizio', 28), 'Non mi piace', no, "suoNonMiPiace('" + t.id + "')")
    + suoAzioneHtml('suoAzPref', suoIco('cuore', 30, pref ? ' class="pieno"' : ''), pref ? 'Preferito' : 'Preferiti', pref, "suoPreferito('" + t.id + "')")
    + suoAzioneHtml('suoAzScar', suoIco(sc ? 'fatto' : 'scarica', 28), inApp ? 'Nell’app' : (SUO.salvando[t.id] ? 'Scarico…' : (sc ? 'Scaricata' : 'Scarica')), sc, "suoScarica('" + t.id + "')")
    + suoAzioneHtml('suoAzCond', suoIco('condividi', 28), 'Condividi', false, "suoCondividi('" + t.id + "')");
}
function suoLabel(v, soglie){ return v < soglie[0] ? 'Bassa' : (v < soglie[1] ? 'Media' : 'Alta'); }
function suoBarraHtml(tit, val, lbl){ return '<div class="suo-b"><div class="suo-b-t"><h4>' + tit + '</h4><span>' + lbl + '</span></div><div class="suo-b-tr"><i style="width:' + Math.round(Math.max(.06, Math.min(1, val)) * 100) + '%"></i></div></div>'; }
function suoAttivitaDi(t){
  /* in che attivita' sta meglio: serve all'etichetta delle tracce simili e ai due blocchi */
  const tab = suoTabDella(t); let top = null, pt = -1;
  (SUO_ATT[tab] || []).forEach(function(a){
    if (!a.scopi) return;
    let p = a.scopi.indexOf(t.scopo) === 0 ? 2 : (a.scopi.indexOf(t.scopo) > 0 ? 1 : 0);
    p += (a.umori || []).indexOf(t.mood) >= 0 ? 2 : 0;
    p += (a.natura || []).indexOf(t.id) >= 0 ? 3 : 0;
    if (p > pt){ pt = p; top = a; }
  });
  return { tab: tab, att: top };
}
function suoSimileHtml(t, acc){
  const tab = suoTabSess(), pref = suoEPref(t.id, tab), a = suoAttivitaDi(t), sc = suoEScaricata(t);
  return '<div class="suo-sim" role="button" onclick="suoSuonaQuesta(\'' + t.id + '\')"><img alt="" src="' + suoCopertina(t) + '">'
    + '<div class="suo-sim-c"><div class="suo-sim-r"><b>' + (t.liv ? suoBarre(t.liv) : '') + '<i>' + suoEsc(t.t) + '</i></b><em>' + suoEsc(suoTabDi(a.tab).n.toUpperCase()) + '</em></div>'
    + '<small>' + suoEsc(t.g.toUpperCase()) + '</small>'
    + '<div class="suo-sim-r suo-sim-az"><span>'
      + '<button type="button" class="' + (pref ? 'on' : '') + '" onclick="event.stopPropagation();suoPreferito(\'' + t.id + '\')" aria-label="Preferiti">' + suoIco('cuore', 22, pref ? ' class="pieno"' : '') + '</button>'
      + '<button type="button" onclick="event.stopPropagation();suoNonMiPiace(\'' + t.id + '\')" aria-label="Non mi piace">' + suoIco('giudizio', 22) + '</button>'
      + '<button type="button" onclick="event.stopPropagation();suoScarica(\'' + t.id + '\')" aria-label="Scarica">' + suoIco(sc ? 'fatto' : 'scarica', 22) + '</button>'
      + '</span><u style="color:' + acc + '">' + suoEsc(a.att ? a.att.n : '') + '</u></div></div></div>';
}
function suoPlayerApri(){ SUO.dett = false; if (SUO.sess) SUO.sess.fraseT0 = Date.now(); goId('s-suoni-player'); suoPlayerPaint(); }
function suoPlayerChiudi(){ SUO.dett = false; goId('s-suoni'); suoPaginaPaint(); }
/* il disegno a tutto schermo della traccia, della stessa famiglia della copertina */
function suoSfondoDi(t){
  if (SUO.sfondo && SUO.sfondo.id === t.id) return SUO.sfondo.cv;
  const lista = (SUO_ATT[suoTabDella(t)] || SUO_ATT.focus).filter(function(a){ return a.art && !a.pref; });
  const a = lista[suoHash(t.id) % lista.length];
  const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
  const cv = document.createElement('canvas'); cv.width = Math.round((window.innerWidth || 412) * dpr); cv.height = Math.round((window.innerHeight || 915) * dpr);
  try{ suoDisegna(cv, a.art, suoHash(t.id)); }catch(_){ }
  SUO.sfondo = { id: t.id, cv: cv };
  return cv;
}
/* la frase cambia con la traccia: citazioni corte, che stanno grandi al centro */
/* 0.9.318, Andrea: "la frase non deve cambiare ogni volta che si cambia suono". Prima si sceglieva dal nome della traccia.
   Adesso e' una per sessione: la stessa attivita' nello stesso giorno ha la stessa frase. */
function suoFrase(t){
  const s = SUO.sess;
  if (s && s.frase) return s.frase;
  let l = [];
  try{ l = CIT_UNA.concat(CIT_TEMPO).filter(function(x){ return x[0].length <= 110; }); }catch(_){ }
  const f = l.length ? l[suoHash((s ? s.att : t.id) + new Date().toDateString()) % l.length] : null;
  if (s) s.frase = f;
  return f;
}
/* i colori della luce: Deep Work rossa come nel riferimento, le altre di Focus calde, relax e sonno azzurre */
function suoRipColore(tab, att){
  const k = String(att || '').toLowerCase();
  if (tab === 'focus') return /deep/.test(k) ? '230,72,82' : /motiv/.test(k) ? '240,132,60' : '63,159,244';
  if (tab === 'relax') return '46,170,190';
  if (tab === 'sleep') return '58,120,210';
  return '76,190,220';
}
function suoCentroHtml(t){
  const s = SUO.sess, f = suoImpostazioni().frasi && !s.fine && !s.iv ? suoFrase(t) : null;
  if (f){
    /* compare piano dalle nuvole, una volta sola: il lettore si ridisegna a ogni cambio di traccia e la scritta non deve
       rinascere. Se il ridisegno cade a meta' dell'animazione, l'animazione riprende da dove era (delay negativo). */
    const pass = Date.now() - (s.fraseT0 || 0), entra = pass < 3400, dl = entra ? ' style="--d:-' + pass + 'ms"' : '';
    /* 0.9.321, Andrea: "si sbiadisce anche il contenitore". Le due nuvole erano tagliate dal riquadro (overflow) e si vedeva il rettangolo: si sfoca solo il testo */
    return '<p class="suo-fr' + (entra ? ' entra' : '') + '"' + dl + ' onclick="suoTimerApri()">' + suoEsc(f[0]) + '<span class="suo-fr-a">- ' + suoEsc(f[1]) + ' -</span></p>';
  }
  return '<p class="suo-et" id="suoEt">' + ((s.iv && s.iv.rest) ? 'PAUSA' : suoTabDi(s.tab).et) + '</p><div class="suo-tempo" id="suoTempo" role="button" onclick="suoTimerApri()">' + suoTempoTesto() + '</div>' + suoModoHtml();
}
/* 0.9.323, Andrea: "toccando il tempo si apre Timer Settings come su Brain.fm: Infinito, Timer, Intervalli; e sotto al tempo il badge e la Modalita' ADHD" */
function suoModoHtml(){
  const s = SUO.sess, adhd = suoImpostazioni().adhd;
  const modo = s.iv ? [suoIco('intervalli', 19), 'Intervalli ' + Math.round(s.iv.lav / 60) + ' + ' + Math.round(s.iv.pau / 60)] : s.fine ? [suoIco('timer', 19), 'Timer'] : [suoIco('infinito', 19), 'Infinito'];
  return '<button type="button" class="suo-modo" onclick="suoTimerApri()">' + modo[0] + '<span>' + modo[1] + '</span></button>'
    + '<div class="suo-adhd-r"><span>Modalità ADHD</span><button type="button" class="suo-q" onclick="suoAdhdInfo()" aria-label="Cos’è la Modalità ADHD">?</button><button type="button" class="suo-sw' + (adhd ? ' on' : '') + '" onclick="suoAdhdTocca()" aria-label="Modalità ADHD"><i>' + suoIco('lampo', 14) + '</i></button></div>';
}
function suoAdhdInfo(){ try{ toast('Mette per prime le tracce con l’effetto più forte.'); }catch(_){ } }
function suoAdhdTocca(){ const b = suoImpostazioni(); b.adhd = !b.adhd; if (b.adhd) b.livello = 'alto'; suoLsSet(SUO_K.set, b); try{ flVibra(10); }catch(_){ } suoPlayerPaint(); }
const SUO_TM = { tab: 'infinito', frasi: true, min: 60, custom: '', unita: 'min', lav: 25, pau: 5, suono: 'voce' };
function suoTimerApri(){
  const s = SUO.sess; if (!s) return;
  const p = suoLs('fl_suo_timer', {});
  Object.assign(SUO_TM, { min: p.min || 60, custom: '', unita: 'min', lav: p.lav || 25, pau: p.pau || 5, suono: p.suono || 'voce', tab: s.iv ? 'intervalli' : s.fine ? 'timer' : 'infinito', frasi: suoImpostazioni().frasi });
  goId('s-suoni-timer'); suoTimerPaint();
}
function suoTimerTab(k){ SUO_TM.tab = k; try{ flVibra(8); }catch(_){ } suoTimerPaint(); }
function suoTimerPaint(){
  const host = document.getElementById('suoTimer'), s = SUO.sess; if (!host) return;
  const T = SUO_TM, tab = suoTabDi(s ? s.tab : 'focus');
  host.style.background = 'linear-gradient(180deg,' + tab.bg + ' 0%,#00132B 60%)';
  const sel = function(id, v, l){ return '<select id="' + id + '" class="suo-tm-sel" onchange="SUO_TM[\'' + id.slice(5) + '\']=+this.value">' + l.map(function(n){ return '<option value="' + n + '"' + (n === v ? ' selected' : '') + '>' + n + ' minuti</option>'; }).join('') + '</select>'; };
  let c = '';
  if (T.tab === 'infinito'){
    c = '<h2>Riproduzione infinita</h2><p class="suo-tm-p">Ascolti quanto vuoi, senza limiti di tempo.</p>'
      + '<div class="suo-box suo-adhd"><span><b>Mostra le frasi</b><small>Le frasi prendono il posto del tempo.</small></span><button type="button" class="suo-sw' + (T.frasi ? ' on' : '') + '" onclick="SUO_TM.frasi=!SUO_TM.frasi;suoTimerPaint()" aria-label="Mostra le frasi"><i></i></button></div>';
  } else if (T.tab === 'timer'){
    c = '<h2>Imposta il timer</h2><p class="suo-tm-p">Scegli quando fermare la musica.</p>'
      + '<div class="suo-tm-3">' + [60, 90, 120].map(function(n){ return '<button type="button" class="' + (T.min === n && !T.custom ? 'on' : '') + '" onclick="SUO_TM.min=' + n + ';SUO_TM.custom=\'\';suoTimerPaint()">' + n + ' minuti</button>'; }).join('') + '</div>'
      + '<div class="suo-tm-cu"><span>Personalizza</span><input type="number" inputmode="numeric" min="1" id="suoTmCu" value="' + suoEsc(T.custom) + '" oninput="SUO_TM.custom=this.value"><div><button type="button" class="' + (T.unita === 'min' ? 'on' : '') + '" onclick="SUO_TM.unita=\'min\';suoTimerPaint()">min</button><button type="button" class="' + (T.unita === 'ore' ? 'on' : '') + '" onclick="SUO_TM.unita=\'ore\';suoTimerPaint()">ore</button></div></div>';
  } else {
    c = '<h2>Imposta gli intervalli</h2><p class="suo-tm-p">Scegli quanto lavori e quanto riposi.</p>'
      + '<div class="suo-tm-2"><label><span>Lavoro</span>' + sel('suoTmlav', T.lav, [15, 20, 25, 30, 45, 50, 60, 90]) + '</label><label><span>Pausa</span>' + sel('suoTmpau', T.pau, [3, 5, 10, 15, 20, 30]) + '</label></div>'
      + '<p class="suo-tm-l">Il suono che ti avvisa</p><div class="suo-tm-2">' + [['voce', 'Voce'], ['campana', 'Campanella']].map(function(x){ return '<button type="button" class="suo-tm-so' + (T.suono === x[0] ? ' on' : '') + '" onclick="SUO_TM.suono=\'' + x[0] + '\';suoIntervalloSuono(\'' + x[0] + '\',\'Pausa\');suoTimerPaint()"><i>' + SUO_PLAY + '</i>' + x[1] + '</button>'; }).join('') + '</div>';
  }
  host.innerHTML = '<div class="suo-set-top"><button type="button" class="suo-ind" onclick="goId(\'s-suoni-player\');suoPlayerPaint()" aria-label="Indietro">' + suoIco('indietro', 24) + '</button><b>Il timer</b><button type="button" class="suo-tm-i" onclick="suoTimerInfo()" aria-label="Come funziona">i</button></div>'
    + '<div class="suo-tm-tab">' + [['infinito', 'Infinito'], ['timer', 'Timer'], ['intervalli', 'Intervalli']].map(function(x){ return '<button type="button" class="' + (T.tab === x[0] ? 'on' : '') + '" onclick="suoTimerTab(\'' + x[0] + '\')">' + suoIco(x[0] === 'infinito' ? 'infinito' : x[0], 24) + '<span>' + x[1] + '</span></button>'; }).join('') + '</div>'
    + '<div class="suo-tm-c">' + c + '</div>'
    + '<div class="suo-set-b"><button type="button" class="suo-bianco" onclick="suoTimerApplica()">APPLICA</button><button type="button" class="suo-testo" onclick="goId(\'s-suoni-player\');suoPlayerPaint()">ANNULLA</button></div>';
}
function suoTimerInfo(){
  const host = document.getElementById('suoTimer'); if (!host) return;
  const r = function(ico, t, p){ return '<div class="suo-tm-info">' + suoIco(ico, 34) + '<b>' + t + '</b><p>' + p + '</p></div>'; };
  host.innerHTML = '<div class="suo-set-top"><button type="button" class="suo-ind" onclick="suoTimerPaint()" aria-label="Indietro">' + suoIco('indietro', 24) + '</button><b>Come funziona</b><span></span></div>'
    + '<div class="suo-tm-c">' + r('infinito', 'Riproduzione infinita', 'La musica continua senza fermarsi, e il tempo conta in avanti.')
    + r('timer', 'Timer', 'Scegli una durata o scrivi la tua. Allo zero la musica si ferma da sola.')
    + r('intervalli', 'Intervalli', 'Alterni lavoro e pausa. Nella pausa la musica si ferma, e un suono ti dice quando ricominciare.') + '</div>'
    + '<div class="suo-set-b"><button type="button" class="suo-bianco" onclick="suoTimerPaint()">HO CAPITO</button></div>';
}
function suoIntervalloSuono(tipo, parola){
  try{
    if (tipo === 'voce' && 'speechSynthesis' in window){ const u = new SpeechSynthesisUtterance(parola); u.lang = 'it-IT'; window.speechSynthesis.cancel(); window.speechSynthesis.speak(u); return; }
  }catch(_){ }
  try{ if (typeof fxSuona === 'function') fxSuona('fine'); }catch(_){ }
}
function suoTimerApplica(){
  const s = SUO.sess, T = SUO_TM; if (!s){ goId('s-suoni-player'); return; }
  const b = suoImpostazioni();
  if (T.tab === 'infinito'){ s.fine = 0; s.iv = null; if (b.frasi !== T.frasi){ b.frasi = T.frasi; suoLsSet(SUO_K.set, b); } }
  else if (T.tab === 'timer'){
    const cu = parseFloat(T.custom), min = cu > 0 ? (T.unita === 'ore' ? cu * 60 : cu) : T.min;
    s.iv = null; s.fine = suoTrascorso() + Math.max(1, Math.min(1440, min)) * 60; suoLsSet('fl_suo_timer', { min: T.min, lav: T.lav, pau: T.pau, suono: T.suono });
  } else {
    s.fine = 0; s.iv = { lav: T.lav * 60, pau: T.pau * 60, suono: T.suono, a: suoTrascorso() + T.lav * 60, rest: 0 }; suoLsSet('fl_suo_timer', { min: T.min, lav: T.lav, pau: T.pau, suono: T.suono });
  }
  goId('s-suoni-player'); suoPlayerPaint();
}
function suoPlayerPaint(){
  const host = document.getElementById('suoPlayer'); if (!host) return;
  const s = SUO.sess;
  if (!s || !s.cur){ host.innerHTML = ''; return; }
  const scv = document.getElementById('suoPlayerScorre'), su = scv ? scv.scrollTop : 0;
  const t = s.cur, att = suoAtt(s.tab, s.att) || { n: '' }, tab = s.tab;
  const pref = suoEPref(t.id, tab), no = suoNo().indexOf(t.id) >= 0, ord = suoImpostazioni().ordine === 'casuale';
  host.style.background = '#00132B';
  host.innerHTML = '<div class="suo-sf" id="suoSf"></div><div class="suo-pl">'
    + '<button type="button" class="suo-maniglia" onclick="suoPlayerChiudi()" aria-label="Chiudi"><i></i></button>'
    + '<div class="suo-pl-top"><button type="button" class="suo-pl-att" onclick="suoFoglioApri()">' + suoIco(att.ico || 'disco', 24) + '<b>' + suoEsc(att.n) + '</b>' + suoIco('giu', 18) + '</button>'
      + '<button type="button" class="suo-pl-serie" onclick="suoSerieApri()" aria-label="La tua serie di ascolto">' + suoIco('cuffie', 18) + suoSerie().att + '</button>'
      + '<button type="button" class="suo-pl-set" onclick="suoImpApri()" aria-label="Impostazioni del lettore">' + suoIco('note', 26) + '</button></div>'
    + '<div class="suo-centro" id="suoCentro">' + suoCentroHtml(t) + '</div>'
    + '<div class="suo-basso"><div class="suo-meta">'
      + '<button type="button" class="suo-meta-t" onclick="suoDettApri()"><b>' + suoEsc(t.t) + '</b>' + (t.liv ? '<small>' + suoBarre(t.liv) + SUO_LIVELLI[t.liv][1] + '</small>' : '') + '</button>'
      + '<div class="suo-chips"><button type="button" class="suo-chip" onclick="suoDettApri()">' + suoEsc(String(t.g).toUpperCase()) + '</button><button type="button" class="suo-chip ol" onclick="suoDettApri()">+ DETTAGLI</button></div></div>'
    + '<div class="suo-lato">'
      + '<button type="button" id="suoLatoNo" class="' + (no ? 'on' : '') + '" onclick="suoNonMiPiace(\'' + t.id + '\')" aria-label="Non mi piace">' + suoIco('giudizio', 27) + '</button>'
      + '<button type="button" id="suoLatoPref" class="' + (pref ? 'on' : '') + '" onclick="suoPreferito(\'' + t.id + '\')" aria-label="Preferiti">' + suoIco('cuore', 28) + '</button>'
      + '<button type="button" onclick="suoCondividi(\'' + t.id + '\')" aria-label="Condividi">' + suoIco('condividi', 27) + '</button></div></div>'
    + '<div class="suo-com3">'
      + '<button type="button" class="suo-salto" onclick="suoPrecedente()" aria-label="Traccia precedente">' + suoIco('prec', 34) + '</button>'
      + '<button type="button" class="suo-com-p" id="suoPlayerP" onclick="suoPausaTocca()" aria-label="' + (suoInPausa() ? 'Riprendi' : 'Pausa') + '">' + (suoInPausa() ? SUO_PLAY : SUO_PAUSA) + '</button>'
      + '<button type="button" class="suo-salto" onclick="suoProssima(false)" aria-label="Traccia successiva">' + suoIco('succ', 34) + '</button></div>'
    + '<button type="button" class="suo-ordine" id="suoOrdine" onclick="suoOrdineTocca()" aria-label="' + (ord ? 'Riproduzione casuale' : 'Riproduzione in ordine') + '">' + suoIco(ord ? 'casuale' : 'ripeti', 28) + '</button>'
    + '</div><div id="suoDett"></div><div id="suoFoglio"></div><div id="suoSerieF"></div>';
  const sf = document.getElementById('suoSf'); if (sf) sf.appendChild(suoSfondoDi(t));
  if (SUO.dett){ suoDettPaint(false); const e = document.getElementById('suoPlayerScorre'); if (e) e.scrollTop = su; }
}
function suoDettApri(){ SUO.dett = true; suoDettPaint(true); const e = document.getElementById('suoPlayerScorre'); if (e) e.scrollTop = 0; }
function suoDettChiudi(){ SUO.dett = false; const h = document.getElementById('suoDett'); if (h) h.innerHTML = ''; }
function suoDettPaint(entra){
  const host = document.getElementById('suoDett'), s = SUO.sess; if (!host || !s || !s.cur) return;
  const t = s.cur, tab = suoTabDi(s.tab);
  const umori = t.mood && SUO_UMORI[t.mood] ? SUO_UMORI[t.mood].concat(SUO_PRESET[t.scopo] && t.scopo === 'sleep' ? ['Notturno'] : []) : null;
  const simili = s.flusso.filter(function(x){ return x.id !== t.id; }).slice(0, 8);
  const chiuse = suoChiuse().filter(function(x){ return suoTabDella(x) === s.tab; }).slice(0, 3);
  const a0 = suoAttivitaDi(t);
  const altra = suoAltraAttivita(a0);
  host.innerHTML = '<div class="suo-dett' + (entra ? ' in' : '') + '" style="background:linear-gradient(180deg,' + tab.bg + ' 0%,#00132B 60%)"><div class="suo-player-scorre" id="suoPlayerScorre">'
    + '<button type="button" class="suo-maniglia" onclick="suoDettChiudi()" aria-label="Chiudi"><i></i></button>'
    + '<img class="suo-cover" alt="" src="' + suoCopertina(t) + '">'
    + '<h2 class="suo-tit">' + suoEsc(t.t) + '</h2>'
    + (t.liv ? '<p class="suo-sub">' + suoBarre(t.liv) + ' ' + SUO_LIVELLI[t.liv][1] + '</p>' : '')
    + '<p class="suo-sub">' + suoEsc(t.g) + (t.bpm ? ' · ' + t.bpm + ' BPM' : (t.tipo === 'nat' ? ' · Registrazione vera' : '')) + '</p>'
    + '<div class="suo-azioni" id="suoAzioni">' + suoAzioniHtml(t) + '</div>'
    + (umori ? '<h4 class="suo-cap">UMORE</h4><p class="suo-val">' + umori.join(', ') + '</p>' : (t.desc ? '<h4 class="suo-cap">COME SUONA</h4><p class="suo-val">' + suoEsc(t.desc) + '</p>' : ''))
    + '<h4 class="suo-cap">STRUMENTI</h4><p class="suo-val">' + (t.tipo === 'lib' ? 'Pad, piano e campane' : (t.tipo === 'nat' ? 'Registrazione sul campo' : 'Pad e battimenti, servono le cuffie')) + '</p>'
    + (t.dens != null ? suoBarraHtml('COMPLESSITÀ', t.dens / .7, suoLabel(t.dens, [.3, .6])) + suoBarraHtml('LUMINOSITÀ', t.lum / 1.1, suoLabel(t.lum, [.6, .88])) : '')
    + (a0.att ? '<h3 class="suo-h">Attività</h3><div class="suo-att2">' + suoAttBlocco(a0.tab, a0.att) + (altra ? suoAttBlocco(altra.tab, altra.att) : '') + '</div>' : '')
    + (simili.length ? '<h3 class="suo-h">Tracce simili</h3>' + simili.map(function(x){ return suoSimileHtml(x, tab.acc); }).join('') : '')
    + (chiuse.length ? '<h3 class="suo-h">Da sbloccare</h3>' + chiuse.map(function(x){ return '<div class="suo-sim chiusa" role="button" onclick="suoSblApri()"><img alt="" src="' + suoCopertina(x) + '"><div class="suo-sim-c"><div class="suo-sim-r"><b><i>' + suoEsc(x.t) + '</i></b></div><small>' + suoEsc(String(x.g).toUpperCase()) + '</small></div><span class="suo-sim-l">' + suoIco('chiusa', 22) + '</span></div>'; }).join('') : '')
    + '<div class="suo-fondo"></div></div>'
    + '<button type="button" class="suo-bianco suo-chiudi" onclick="suoDettChiudi()">CHIUDI</button></div>';
}
/* ---------- la serie e i traguardi: si aprono dal numero accanto alle cuffie ---------- */
const SUO_SOGLIE = { serie: [5, 10, 25, 52], pref: [5, 10, 25, 50] };
function suoSoglia(l, n){ let s = 0; l.forEach(function(x){ if (n >= x) s = x; }); return s ? { v: s, ok: true } : { v: l[0], ok: false }; }
function suoPrefTot(){ const p = suoLs(SUO_K.pref, {}), id = {}; Object.keys(p).forEach(function(k){ (p[k] || []).forEach(function(t){ id[t.id] = 1; }); }); return Object.keys(id).length; }
function suoBadgeSerie(v){ return '<svg viewBox="0 0 80 84" width="72" height="76" aria-hidden="true"><path d="M40 8l28 16v32L40 72 12 56V24z" fill="#2A2A36" stroke="#D6DAE6" stroke-width="4" stroke-linejoin="round"/><g transform="translate(20 20) rotate(-45)" fill="#fff"><path d="M0-15c5 4 6 10 5 17H-5c-1-7 0-13 5-17z"/><path d="M-5-1l-5 7 5-1zM5-1l5 7-5-1z"/></g><text x="40" y="51" text-anchor="middle" font-family="Montserrat,sans-serif" font-weight="800" font-size="26" fill="#fff">' + v + '</text></svg>'; }
function suoBadgePref(v){ return '<svg viewBox="0 0 80 84" width="72" height="76" aria-hidden="true"><path d="M40 72S8 52 8 28a16 16 0 0132-5 16 16 0 0132 5c0 24-32 44-32 44z" fill="#2A2A36" stroke="#D6DAE6" stroke-width="4" stroke-linejoin="round"/><text x="40" y="47" text-anchor="middle" font-family="Montserrat,sans-serif" font-weight="800" font-size="26" fill="#fff">' + v + '</text></svg>'; }
function suoSerieApri(){
  const host = document.getElementById('suoSerieF'); if (!host) return;
  const se = suoSerie(), a = suoSoglia(SUO_SOGLIE.serie, se.max), b = suoSoglia(SUO_SOGLIE.pref, suoPrefTot());
  host.innerHTML = '<div class="suo-st-sf" onclick="if(event.target===this)suoSerieChiudi()"><div class="suo-st">'
    + '<div class="suo-st-top">' + suoIco('cuffie', 28) + '<span>La tua serie</span><button type="button" onclick="suoSerieChiudi()" aria-label="Chiudi">' + suoIco('x', 26) + '</button></div>'
    + '<div class="suo-st-num"><div><small>ATTUALE</small><b>' + se.att + '</b></div><div><small>LA PIÙ LUNGA</small><b>' + se.max + '</b></div></div>'
    + '<p class="suo-st-p">La serie conta le settimane di ascolto consecutive.</p>'
    + '<h4 class="suo-st-h">Traguardi</h4><div class="suo-st-g">'
    + '<div class="suo-st-t' + (a.ok ? '' : ' no') + '">' + suoBadgeSerie(a.v) + '<b>SERIE</b><small>' + a.v + ' settimane</small></div>'
    + '<div class="suo-st-t' + (b.ok ? '' : ' no') + '">' + suoBadgePref(b.v) + '<b>PREFERITI</b><small>' + b.v + ' tracce</small></div></div>'
    + '<p class="suo-st-c">Condividi i tuoi traguardi!</p>'
    + '<button type="button" class="suo-st-b" onclick="suoCondividiSerie()">' + suoIco('condividi', 22) + 'Condividi</button></div></div>';
}
function suoSerieChiudi(){ const h = document.getElementById('suoSerieF'); if (h) h.innerHTML = ''; }
function suoSerieAperta(){ const h = document.getElementById('suoSerieF'); return !!(h && h.firstChild); }
async function suoCondividiSerie(){
  const se = suoSerie(), np = suoPrefTot();
  const testo = 'Su Dream Map ascolto da ' + se.att + (se.att === 1 ? ' settimana' : ' settimane') + ' di fila, e ho ' + np + (np === 1 ? ' traccia preferita' : ' tracce preferite') + '.';
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'Dream Map' }); return; } }catch(_){ }
  try{ if (navigator.share){ await navigator.share({ title: 'Dream Map', text: testo }); return; } }catch(_){ return; }
  try{ toast('Su questo telefono non si può condividere'); }catch(_){ }
}
function suoAltraAttivita(a0){
  /* il secondo blocco: un'altra attivita' della stessa scheda o, per Focus, una per staccare */
  const per = a0.tab === 'focus' ? 'sleep' : 'focus';
  const a = (SUO_ATT[per] || []).filter(function(x){ return x.scopi && x.w !== 1; })[0] || (SUO_ATT[per] || [])[0];
  return a ? { tab: per, att: a } : null;
}
function suoAttBlocco(tab, a){
  const c = suoTabDi(tab).acc;
  return '<button type="button" class="suo-att-c" style="background:linear-gradient(100deg,rgba(255,255,255,.07) 30%,' + c + '66)" onclick="suoAvvia(\'' + tab + '\',\'' + a.k + '\')"><b>' + suoEsc(a.n) + '</b><span>' + SUO_PLAY + '</span></button>';
}
/* si aggiorna solo cio' che cambia: il tempo e la posizione restano dove sono */
function suoStatoPaint(){
  const p = suoInPausa() ? SUO_PLAY : SUO_PAUSA;
  const a = document.getElementById('suoPlayerP'); if (a) a.innerHTML = p;
  const b = document.getElementById('suoMiniP'); if (b) b.innerHTML = p;
}
async function suoSalvaFile(t){
  if (!t || t.tipo !== 'lib' || !t.url || typeof caches === 'undefined') return t && t.tipo !== 'lib';
  try{
    const c = await caches.open(SUO_CACHE);
    if (await c.match(t.url)) return true;
    const r = await fetch(t.url); if (!r.ok) return false;
    await c.put(t.url, r); return true;
  }catch(_){ return false; }
}
async function suoLevaFile(t){
  if (!t || !t.url || typeof caches === 'undefined') return;
  const p = suoLs(SUO_K.pref, {}), ancora = Object.keys(p).some(function(k){ return (p[k] || []).some(function(x){ return x.id === t.id; }); });
  const sb = suoLs(SUO_K.sbl, {})[t.id];
  if (ancora || suoLs(SUO_K.scar, []).indexOf(t.id) >= 0 || (sb && sb.f)) return;
  try{ await (await caches.open(SUO_CACHE)).delete(t.url); }catch(_){ }
}
function suoPreferito(id){
  const t = SUO.tr[id]; if (!t) return;
  const tab = suoTabSess(), p = suoLs(SUO_K.pref, {}), l = p[tab] || [];
  const i = l.map(function(x){ return x.id; }).indexOf(id);
  if (i >= 0) l.splice(i, 1); else l.unshift(t);
  p[tab] = l; suoLsSet(SUO_K.pref, p);
  if (i >= 0) suoLevaFile(t); else suoSalvaFile(t);
  suoPlayerPaint();
  suoPrefAvviso(i < 0, t, tab);
}
/* 0.9.348, Andrea: "quando aggiungo un suono ai preferiti voglio un avviso come quello del mio tema Shopify quando si tocca il cuore
   della wishlist". Una card che sale dal basso con la copertina, il cuore e "Vedi i preferiti"; dopo tre secondi e mezzo se ne va */
function suoPrefAvviso(aggiunto, t, tab){
  try{
    let w = document.getElementById('suoPrefAv');
    if (!w){ w = document.createElement('div'); w.id = 'suoPrefAv'; w.className = 'suo-prefav'; (document.getElementById('phone') || document.body).appendChild(w); }
    const n = ((suoLs(SUO_K.pref, {})[tab]) || []).length;
    w.innerHTML = '<span class="suo-prefav-c' + (aggiunto ? ' pieno' : '') + '">' + suoIco('cuore', 22, aggiunto ? ' class="pieno"' : '') + '</span>'
      + '<div><b>' + (aggiunto ? 'Aggiunto ai preferiti' : 'Tolto dai preferiti') + '</b><small>' + suoEsc((t && (t.t || t.n || t.titolo)) || '') + (aggiunto ? ' · ' + n + (n === 1 ? ' traccia' : ' tracce') : '') + '</small></div>'
      + (aggiunto ? '<button type="button" onclick="suoPrefVedi(\'' + tab + '\')">Vedi</button>' : '');
    w.classList.remove('in'); void w.offsetWidth; w.classList.add('in');
    try{ if (typeof flVibra === 'function') flVibra(aggiunto ? [10, 30, 10] : 8); }catch(_){ }
    clearTimeout(suoPrefAvviso._t); suoPrefAvviso._t = setTimeout(function(){ w.classList.remove('in'); }, 3500);
  }catch(_){ }
}
function suoPrefVedi(tab){ const w = document.getElementById('suoPrefAv'); if (w) w.classList.remove('in'); try{ if (typeof suoApri === 'function') suoApri(); if (typeof suoScheda === 'function') suoScheda(tab); setTimeout(function(){ suoLibApri('pref'); }, 200); }catch(_){ } setTimeout(function(){ const b = document.getElementById('suoPrefBan'); if (b) b.scrollIntoView({ block: 'center', behavior: 'smooth' }); }, 400); }
/* la playlist dei preferiti, come "Focus Favorites" di Brain.fm: tutti i salvati in ordine casuale, e sotto l'elenco */
function suoPrefBannerHtml(tab){
  const l = ((suoLs(SUO_K.pref, {})[tab]) || []);
  if (!l.length) return '';
  const nome = (suoTabDi(tab) || {}).n || '';
  return '<div class="suo-prefban" id="suoPrefBan"><button type="button" class="suo-prefban-top" onclick="suoAvvia(\'' + tab + '\',\'pref\')"><span class="suo-prefban-t"><b>I tuoi preferiti ' + suoEsc(nome) + '</b><small>Tutte le ' + l.length + ' tracce salvate, in ordine casuale</small></span><span class="suo-prefban-play">' + suoIco('casuale', 24) + '</span></button>'
    + '<div class="suo-prefban-l">' + l.slice(0, 6).map(function(t){ return '<button type="button" class="suo-prefban-r" onclick="suoAvvia(\'' + tab + '\',\'pref\',\'' + suoEsc(t.id) + '\')"><span>' + suoIco('cuore', 16, ' class="pieno"') + '</span><b>' + suoEsc(t.t || t.n || t.titolo || 'Traccia') + '</b></button>'; }).join('') + '</div></div>';
}
function suoNonMiPiace(id){
  const no = suoNo(), i = no.indexOf(id);
  if (i >= 0) no.splice(i, 1); else no.push(id);
  suoLsSet(SUO_K.no, no.slice(-300));
  const s = SUO.sess;
  if (i < 0 && s){
    /* non te la riproponiamo: via dal flusso, e se sta suonando si passa alla prossima */
    const eraQuesta = s.cur && s.cur.id === id;
    if (s.flusso.length > 1){
      s.flusso = s.flusso.filter(function(t){ return t.id !== id; });
      if (eraQuesta){ s.i = Math.max(0, s.i - 1) % s.flusso.length; suoSuona(s.flusso[s.i], false); return; }
      s.i = Math.max(0, s.flusso.map(function(t){ return t.id; }).indexOf(s.cur.id));
    }
  }
  suoPlayerPaint();
}
async function suoScarica(id){
  const t = SUO.tr[id]; if (!t || t.tipo !== 'lib' || SUO.salvando[id]) return;
  const sc = suoLs(SUO_K.scar, []), i = sc.indexOf(id);
  if (i >= 0){ sc.splice(i, 1); suoLsSet(SUO_K.scar, sc); suoLevaFile(t); suoPlayerPaint(); return; }
  SUO.salvando[id] = 1; suoPlayerPaint();
  const ok = await suoSalvaFile(t);
  delete SUO.salvando[id];
  if (ok){ const s2 = suoLs(SUO_K.scar, []); s2.push(id); suoLsSet(SUO_K.scar, s2); }
  else { try{ toast('Non riesco a scaricarla: controlla la connessione'); }catch(_){ } }
  suoPlayerPaint();
}
async function suoCondividi(id){
  const t = SUO.tr[id]; if (!t) return;
  const testo = 'Sto ascoltando ' + t.t + ' su Dream Map';
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: 'Dream Map' }); return; } }catch(_){ }
  try{ if (navigator.share){ await navigator.share({ title: 'Dream Map', text: testo }); return; } }catch(_){ return; }
  try{ toast('Su questo telefono non si può condividere'); }catch(_){ }
}

/* ---------- il foglio delle attivita' ---------- */
function suoFoglioApri(){
  const s = SUO.sess; if (!s) return;
  SUO.bozzaAtt = s.att; suoFoglioPaint();
}
function suoFoglioPaint(){
  const host = document.getElementById('suoFoglio'), s = SUO.sess; if (!host || !s) return;
  const voci = [suoAtt(s.tab, 'mix')].concat((SUO_ATT[s.tab] || []).filter(function(a){ return a.scopi; }));
  const pref = suoAtt(s.tab, 'pref');
  const riga = function(a, nome, ico){
    const on = SUO.bozzaAtt === a.k;
    return '<button type="button" class="suo-fg-r' + (on ? ' on' : '') + '" onclick="SUO.bozzaAtt=\'' + a.k + '\';suoFoglioPaint()"><span class="suo-fg-i">' + suoIco(ico || a.ico, 28) + '</span><span class="suo-fg-t"><b>' + suoEsc(nome || a.n) + '</b>' + (a.k === 'mix' ? '<small>' + suoEsc(a.d) + '</small>' : '') + '</span>' + (on ? suoIco('spunta', 26) : '') + '</button>';
  };
  host.innerHTML = '<div class="suo-fg-sf" onclick="suoFoglioChiudi()"></div><div class="suo-fg"><i class="suo-maniglia-i"></i><h4 class="suo-cap suo-fg-h">ATTIVITÀ</h4>'
    + '<div class="suo-fg-l">' + voci.map(function(a){ return riga(a); }).join('') + (pref ? riga(pref, 'Tutti i preferiti', 'cuore') : '') + '</div>'
    + '<div class="suo-fg-b"><button type="button" class="suo-testo" onclick="suoFoglioChiudi()">ANNULLA</button><button type="button" class="suo-bianco" onclick="suoFoglioApplica()">APPLICA</button></div></div>';
}
function suoFoglioChiudi(){ const h = document.getElementById('suoFoglio'); if (h) h.innerHTML = ''; }
function suoFoglioAperto(){ const h = document.getElementById('suoFoglio'); return !!(h && h.firstChild); }
function suoFoglioApplica(){
  const s = SUO.sess, k = SUO.bozzaAtt; suoFoglioChiudi();
  if (s && k && k !== s.att) suoAvvia(s.tab, k, s.cur && s.cur.tipo === 'lib' ? s.cur.id : '');
}

/* ---------- le impostazioni del lettore ---------- */
function suoGeneriDisponibili(){
  const c = suoCatalogo(), ha = {}; c.forEach(function(t){ ha[t.g] = 1; });
  const mu = SUO_MUSICA.filter(function(g){ return ha[g[0]]; });
  const nat = Object.keys(SUO_NATURA).map(function(k){ return SUO_NATURA[k]; }).filter(function(g){ return ha[g[0]]; });
  return { mu: mu, nat: nat };
}
function suoImpApri(){ SUO.bozza = suoImpostazioni(); goId('s-suoni-set'); suoImpPaint(); const e = document.getElementById('suoSetScorre'); if (e) e.scrollTop = 0; }
function suoImpPaint(){
  const host = document.getElementById('suoSet'), b = SUO.bozza; if (!host || !b) return;
  const tab = suoTabDi(suoTabSess()), g = suoGeneriDisponibili(), mix = SUO.sess && SUO.sess.att === 'mix';
  const scorre = document.getElementById('suoSetScorre'), su = scorre ? scorre.scrollTop : 0;
  const genere = function(x){ const on = b.generiNo.indexOf(x[0]) < 0; return '<button type="button" class="suo-gen' + (on ? ' on' : '') + '" onclick="suoGenereTocca(\'' + suoEsc(x[0]).replace(/'/g, '') + '\')"><span>' + suoIco(x[1], 28) + '</span><b>' + suoEsc(x[0]) + '</b>' + (on ? suoIco('spunta', 22) : '') + '</button>'; };
  const gruppo = function(tit, l, q){ return l.length ? '<div class="suo-gr-t"><b>' + tit + '</b><button type="button" onclick="suoGeneriTutti(\'' + q + '\')">Seleziona tutti</button></div><div class="suo-box">' + l.map(genere).join('') + '</div>' : ''; };
  host.style.background = 'linear-gradient(180deg,' + tab.bg + ' 0%,#00132B 60%)';
  host.innerHTML = '<div class="suo-set-top"><button type="button" class="suo-ind" onclick="goId(\'s-suoni-player\');suoPlayerPaint()" aria-label="Indietro">' + suoIco('indietro', 24) + '</button><b>Impostazioni del lettore</b><button type="button" class="suo-set-i" onclick="suoInfoApri()" aria-label="Spiegazione">' + suoIco('info', 28) + '</button></div>'
    + '<div class="suo-set-scorre" id="suoSetScorre">'
    + '<h3 class="suo-h suo-h0">Livello dell’effetto neurale</h3><p class="suo-p">Scegli quanto forte vuoi l’effetto nelle tracce della sessione.</p>'
    + '<div class="suo-box suo-adhd"><span><b>Modalità ADHD</b><small>Mette per prime le tracce con l’effetto più forte.</small></span><button type="button" class="suo-sw' + (b.adhd ? ' on' : '') + '" onclick="suoAdhd()" aria-label="Modalità ADHD"><i>' + suoIco('lampo', 14) + '</i></button></div>'
    + '<div class="suo-box">' + ['basso', 'medio', 'alto'].map(function(k){ const on = b.livello === k; return '<button type="button" class="suo-liv' + (on ? ' on' : '') + '" onclick="suoLivelloScegli(\'' + k + '\')"><span><b>' + suoBarre(k) + ' ' + SUO_LIVELLI[k][0] + '</b><small>' + SUO_LIVELLI[k][2] + '</small></span>' + (on ? suoIco('spunta', 24) : '') + '</button>'; }).join('') + '</div>'
    + '<h3 class="suo-h">Frasi</h3><div class="suo-box suo-adhd"><span><b>Mostra le frasi</b><small>Una frase al centro della schermata, diversa per ogni traccia. Se la togli, al suo posto vedi il tempo.</small></span><button type="button" class="suo-sw' + (b.frasi ? ' on' : '') + '" onclick="suoFrasiTocca()" aria-label="Mostra le frasi"><i></i></button></div>'
    + '<h3 class="suo-h">Generi</h3><p class="suo-p">Scegli i generi che vuoi sentire mentre ascolti.</p>'
    + (mix ? '<div class="suo-box suo-mix"><div class="suo-mix-i">' + ['albero', 'drone', 'fiume', 'scintille', 'gocce', 'vento', 'luna'].map(function(i, n){ return '<span style="opacity:' + [.3, .55, .8, 1, .8, .55, .3][n] + '">' + suoIco(i, n === 3 ? 40 : 28) + '</span>'; }).join('') + '</div><p><b>' + suoEsc((suoAtt(SUO.sess.tab, 'mix') || {}).n || '') + '</b> ha il suo mix di generi, per un ascolto tutto suo.</p></div>'
          : gruppo('Musica', g.mu, 'mu') + gruppo('Natura', g.nat, 'nat'))
    + '<div class="suo-fondo2"></div></div>'
    + '<div class="suo-set-b"><button type="button" class="suo-bianco" onclick="suoImpApplica()">APPLICA</button><button type="button" class="suo-testo" onclick="goId(\'s-suoni-player\');suoPlayerPaint()">ANNULLA</button></div>';
  const e = document.getElementById('suoSetScorre'); if (e) e.scrollTop = su;
}
function suoFrasiTocca(){ const b = SUO.bozza; b.frasi = !b.frasi; suoImpPaint(); }
function suoAdhd(){ const b = SUO.bozza; b.adhd = !b.adhd; if (b.adhd) b.livello = 'alto'; suoImpPaint(); }
function suoLivelloScegli(k){ const b = SUO.bozza; b.livello = k; if (k !== 'alto') b.adhd = false; suoImpPaint(); }
function suoGenereTocca(n){ const b = SUO.bozza, i = b.generiNo.indexOf(n); if (i >= 0) b.generiNo.splice(i, 1); else b.generiNo.push(n); suoImpPaint(); }
function suoGeneriTutti(q){
  const g = suoGeneriDisponibili(), l = (q === 'mu' ? g.mu : g.nat).map(function(x){ return x[0]; }), b = SUO.bozza;
  b.generiNo = b.generiNo.filter(function(n){ return l.indexOf(n) < 0; }); suoImpPaint();
}
function suoImpApplica(){
  const b = SUO.bozza, g = suoGeneriDisponibili(), tutti = g.mu.concat(g.nat).map(function(x){ return x[0]; });
  if (tutti.length && tutti.every(function(n){ return b.generiNo.indexOf(n) >= 0; })){ try{ toast('Scegli almeno un genere'); }catch(_){ } return; }
  suoLsSet(SUO_K.set, b);
  goId('s-suoni-player');
  const s = SUO.sess;
  if (s){
    /* si riparte da una traccia che rispetta la scelta, solo se quella di adesso non la rispetta */
    const l = suoFlusso(s.tab, s.att, s.cur);
    if (l.length){
      const dentro = s.cur && l.some(function(t){ return t.id === s.cur.id; });
      s.flusso = l;
      if (dentro){ s.i = l.map(function(t){ return t.id; }).indexOf(s.cur.id); suoPlayerPaint(); }
      else { s.i = 0; suoSuona(l[0], false); }
      return;
    }
  }
  suoPlayerPaint();
}
function suoInfoApri(){
  goId('s-suoni-info');
  const host = document.getElementById('suoInfo'); if (!host) return;
  let cred = '';
  try{ const cr = SND.credits || {}, nomi = Object.keys(cr).map(function(k){ return cr[k].author; }).filter(function(v, i, a){ return v && a.indexOf(v) === i; }); if (nomi.length) cred = '<p class="suo-cred">Registrazioni di ' + suoEsc(nomi.join(', ')) + ' · Freesound, CC0.</p>'; }catch(_){ }
  host.style.background = 'linear-gradient(180deg,#1E1A1E 0%,#00132B 70%)';
  host.innerHTML = '<div class="suo-set-top"><button type="button" class="suo-ind" onclick="goId(\'s-suoni-set\')" aria-label="Indietro">' + suoIco('indietro', 24) + '</button><b>Le impostazioni, spiegate</b><span></span></div>'
    + '<div class="suo-set-scorre"><div class="suo-info-b"><span class="suo-info-l">' + suoBarre('basso') + suoBarre('medio') + suoBarre('alto') + '</span><h3>Effetto neurale</h3><p>La forza del battito nascosto dentro la musica. Basso se sei già agitato o sovrastimolato. Alto se ti serve una spinta in più.</p></div>'
    + '<div class="suo-info-b">' + suoIco('scintille', 36) + '<h3>Generi</h3><p>Scegli la musica e i suoni della natura che preferisci. Sentirai solo le tracce che rispettano la tua scelta.</p></div>' + cred + '</div>';
}

/* ---------- i programmi: hanno una pagina loro, in fondo alla scheda ---------- */
function suoProgApri(){ goId('s-suoni-prog'); suoProgPaint(); }
function suoProgPaint(){ const b = document.getElementById('suoProgBody'); if (b && typeof sndProgrammiHtml === 'function') b.innerHTML = sndProgrammiHtml(); }

registerScreen('s-suoni-player', '<div id="suoPlayer" class="suo-sc"></div>', { back: function(){
  if (document.getElementById('suoSbl')){ suoSblChiudi(); return 's-suoni-player'; }
  if (suoSerieAperta()){ suoSerieChiudi(); return 's-suoni-player'; }
  if (suoFoglioAperto()){ suoFoglioChiudi(); return 's-suoni-player'; }
  if (SUO.dett){ suoDettChiudi(); return 's-suoni-player'; }
  setTimeout(suoPaginaPaint, 0); return 's-suoni';
} });
registerScreen('s-suoni-set', '<div id="suoSet" class="suo-sc"></div>', { back: function(){ setTimeout(suoPlayerPaint, 0); return 's-suoni-player'; } });
registerScreen('s-suoni-timer', '<div id="suoTimer" class="suo-sc"></div>', { back: function(){ setTimeout(suoPlayerPaint, 0); return 's-suoni-player'; } });
registerScreen('s-suoni-info', '<div id="suoInfo" class="suo-sc"></div>', { back: 's-suoni-set' });
registerScreen('s-suoni-prog',
  '<div class="topbar"><button class="iconbtn" onclick="suoApri()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg></button><b class="blk-title">Programmi</b></div>'
  + '<div class="al-page" id="suoProgBody"></div><div class="spacer"></div>', { back: 's-suoni' });
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-suoni-prog') suoProgPaint(); });
registerScreen('s-suoni-dentro',
  '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title">Dentro DreamMap</b></div>'
  + '<div class="al-page" id="sndDentroBody"></div><div class="spacer"></div>', { back: 's-newtype' });
(function(){
  const st = document.createElement('style');
  st.textContent = '.sd-d-t{margin:22px 2px 12px;font:800 18px var(--font-display);text-align:center;color:var(--navy)}body.dark .sd-d-t{color:#fff}'
    + '.sd-d-l{display:flex;flex-direction:column;gap:8px}.sd-d-r{display:flex;align-items:center;gap:12px;width:100%;padding:14px;border:1.5px solid var(--line);border-radius:18px;background:var(--card,#fff);color:var(--navy);text-align:left;cursor:pointer}body.dark .sd-d-r{color:#fff}.sd-d-r.on{border-color:#0075E3;box-shadow:0 0 0 1px #0075E3}'
    + '.sd-d-r span{flex:none;font-size:26px;line-height:1}.sd-d-r b{display:block;font:800 15px var(--font-body)}.sd-d-r small{display:block;margin-top:2px;font:500 13px/1.35 var(--font-body);color:var(--muted)}'
    + '.sd-d-c{display:flex;flex-wrap:wrap;justify-content:center;gap:8px}.sd-d-c button{padding:10px 14px;border:1.5px solid #BCE0FF;border-radius:99px;background:var(--card,#fff);color:var(--navy);font:700 14px var(--font-body);cursor:pointer}body.dark .sd-d-c button{background:#14234A;color:#fff;border-color:rgba(188,224,255,.25)}.sd-d-c button.on{background:#0075E3;border-color:#0075E3;color:#fff}'
    + '.sd-d-ok{margin-top:24px}';
  document.head.appendChild(st);
})();

(function(){
  const css = [
    /* la pagina e' scura in entrambi i temi, con il testo bianco fisso: e' il disegno del riferimento */
    '#s-suoni,#s-suoni-player,#s-suoni-set,#s-suoni-info{padding:0;overflow:hidden;background:#00132B}',
    '.suo-sc,.suo-pag{position:absolute;inset:0;display:flex;flex-direction:column;color:#fff;font-family:var(--font-body)}',
    '.suo-sc button,.suo-pag button{font-family:inherit;color:inherit;background:none;border:0;cursor:pointer;-webkit-tap-highlight-color:transparent}',
    /* 0.9.315: la freccia sta alla stessa altezza delle cuffie, con lo stesso margine sopra e di lato; le schede sono centrate,
       con lo stesso margine a sinistra e a destra */
    '.suo-testa{display:grid;grid-template-columns:40px 1fr 40px;align-items:center;justify-items:center;padding:calc(16px + env(safe-area-inset-top)) 16px 2px 10px}',
    '.suo-ind{width:40px;height:40px;display:flex;align-items:center;justify-content:center;color:#fff !important}',
    '.suo-logo{color:#fff;display:flex}',
    '.suo-schede{display:flex;justify-content:safe center;gap:clamp(14px,4.6vw,22px);padding:8px 20px 14px;overflow-x:auto;scrollbar-width:none}.suo-schede::-webkit-scrollbar{display:none}',
    '.suo-schede button{flex:none;white-space:nowrap;padding:4px 0;font:600 clamp(15px,4.5vw,19px) var(--font-display) !important;font-style:normal;letter-spacing:-.01em;color:rgba(255,255,255,.46) !important;transition:color .2s}',
    '.suo-schede button.on{font-weight:800 !important;color:#fff !important}',
    '.suo-scorre{flex:1;min-height:0;overflow-y:auto;scrollbar-width:none;padding:0 16px}',
    '.suo-scorre::-webkit-scrollbar,.suo-player-scorre::-webkit-scrollbar,.suo-set-scorre::-webkit-scrollbar{display:none}',
    '.suo-card{position:relative;display:block;width:100%;overflow:hidden;border-radius:16px;border:1px solid rgba(255,255,255,.14) !important;padding:0;text-align:left;margin:0 0 16px;aspect-ratio:1.8;isolation:isolate}',
    '.suo-griglia{display:grid;grid-template-columns:1fr 1fr;gap:16px}.suo-griglia .suo-card{margin:0;aspect-ratio:.77}',
    '.suo-card-art{position:absolute;inset:0;width:100%;height:100%;z-index:-1;opacity:0;transition:opacity .35s}.suo-card-art.pronto{opacity:1}',
    '.suo-card-i{position:absolute;left:18px;top:18px;display:flex;color:#fff;filter:drop-shadow(0 1px 3px rgba(0,0,0,.5))}',
    '.suo-card-t{position:absolute;left:18px;right:16px;bottom:16px;display:block}',
    '.suo-griglia .suo-card-t{left:16px;right:12px}',
    '.suo-card-t b{display:block;font:800 17px/1.15 var(--font-display);font-style:normal;color:#fff;text-shadow:0 1px 8px rgba(0,0,0,.5)}',
    '.suo-card-t small{display:block;margin-top:6px;font:400 12.5px/1.35 var(--font-body);color:rgba(255,255,255,.76);text-shadow:0 1px 6px rgba(0,0,0,.6)}',
    '.suo-vuota{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;padding:14px;text-align:center;aspect-ratio:.77;background:radial-gradient(90% 34% at 50% 104%,rgba(95,150,240,.55),transparent),#22222E}',
    '.suo-griglia .suo-vuota{display:flex}',
    '.suo-vuota-c{width:48px;height:48px;border-radius:50%;display:flex;align-items:center;justify-content:center;border:1.5px solid var(--acc);background:rgba(255,255,255,.07)}',
    '.suo-vuota b{font:800 15px/1.3 var(--font-display);font-style:normal;color:#fff}',
    '.suo-h{margin:28px 0 14px;font:800 21px var(--font-display);font-style:normal;color:#fff;text-align:left}',
    '.suo-h0{margin-top:6px}',
    /* 0.9.321: come il riferimento: i cerchi di luce sfumano e restano dentro al pannello, e il colore dipende dalla sessione */
    '.suo-modo{display:inline-flex;align-items:center;gap:8px;margin:14px auto 0;padding:9px 18px;border:0;border-radius:99px;background:rgba(255,255,255,.14) !important;color:#fff;font:600 15px var(--font-body);cursor:pointer}',
    '.suo-adhd-r{display:inline-flex;align-items:center;gap:10px;margin:12px auto 0;padding:7px 12px;border-radius:14px;background:rgba(0,0,0,.25);color:#fff;font:600 14px var(--font-body)}.suo-q{width:20px;height:20px;padding:0;border:0;border-radius:50%;background:rgba(255,255,255,.3) !important;color:#14141A;font:800 12px var(--font-body);cursor:pointer}',
    '.suo-centro{display:flex;flex-direction:column;align-items:center}',
    '.suo-tm-i{width:32px;height:32px;padding:0;border:1.5px solid rgba(255,255,255,.8) !important;border-radius:50%;background:none !important;color:#fff;font:800 15px var(--font-body);cursor:pointer}',
    '.suo-tm-tab{display:flex;margin:18px 18px 0;border:1px solid rgba(255,255,255,.2);border-radius:16px}.suo-tm-tab button{flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 4px;border:2px solid transparent;border-radius:16px;background:none !important;color:rgba(255,255,255,.75);font:700 12.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;cursor:pointer}.suo-tm-tab button.on{border-color:#fff;color:#fff;background:rgba(255,255,255,.1) !important}',
    '.suo-tm-c{padding:26px 18px 150px;color:#fff;text-align:center}.suo-tm-c h2{margin:0;font:800 30px var(--font-display);color:#fff}.suo-tm-p{margin:8px 0 24px;font:500 15px var(--font-body);color:rgba(255,255,255,.75)}.suo-tm-c .suo-box{text-align:left}',
    '.suo-tm-3{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.suo-tm-3 button{padding:15px 4px;border:1.5px solid rgba(255,255,255,.28);border-radius:12px;background:none !important;color:#fff;font:600 14px var(--font-body);cursor:pointer}.suo-tm-3 button.on{border-color:#fff;border-width:2px}',
    '.suo-tm-cu{display:flex;align-items:center;gap:10px;margin-top:10px;padding:8px 8px 8px 16px;border:1.5px solid rgba(255,255,255,.28);border-radius:12px;font:600 15px var(--font-body)}.suo-tm-cu span{flex:1;text-align:left}.suo-tm-cu input{width:64px;padding:8px;border:0;border-radius:8px;background:rgba(255,255,255,.12);color:#fff;font:600 15px var(--font-body);text-align:center}.suo-tm-cu div{display:flex;gap:2px}.suo-tm-cu div button{padding:8px 12px;border:0;border-radius:8px;background:rgba(255,255,255,.08) !important;color:rgba(255,255,255,.6);font:600 13px var(--font-body);cursor:pointer}.suo-tm-cu div button.on{background:rgba(255,255,255,.28) !important;color:#fff}',
    '.suo-tm-2{display:grid;grid-template-columns:1fr 1fr;gap:10px}.suo-tm-2 label span{display:block;margin-bottom:8px;font:600 15px var(--font-body)}.suo-tm-sel{width:100%;padding:14px 10px;border:0;border-radius:10px;background:rgba(255,255,255,.14);color:#fff;font:600 15px var(--font-body)}.suo-tm-sel option{color:#111}',
    '.suo-tm-l{margin:24px 0 10px;font:600 15px var(--font-body);text-align:left}.suo-tm-so{display:flex;align-items:center;gap:10px;padding:12px;border:1.5px solid rgba(255,255,255,.28) !important;border-radius:12px;background:none !important;color:#fff;font:600 15px var(--font-body);cursor:pointer}.suo-tm-so.on{border-color:#fff !important;border-width:2px !important;background:rgba(255,255,255,.1) !important}.suo-tm-so i{width:30px;height:30px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:#fff;color:#111}.suo-tm-so i svg{width:15px;height:15px}',
    '.suo-tm-info{text-align:left;margin-bottom:34px}.suo-tm-info b{display:block;margin-top:10px;font:800 24px var(--font-display);color:#fff}.suo-tm-info p{margin:6px 0 0;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.78)}',
    '.suo-rip{position:relative;overflow:hidden;display:flex;align-items:center;width:100%;min-height:80px;padding:12px 18px 12px 18px;margin-bottom:12px;border-radius:16px;border:1px solid rgba(255,255,255,.14) !important;background:rgba(255,255,255,.07) !important;text-align:left}',
    /* 0.9.322, Andrea: "in Brain.fm si vedono gli anelli attorno al pulsante": cerchi a gradini netti, centrati sul pulsante, che svaniscono verso il testo */
    '.suo-rip::before{content:"";position:absolute;right:-90px;top:50%;width:260px;height:260px;margin-top:-130px;border-radius:50%;pointer-events:none;background:radial-gradient(circle closest-side,rgba(var(--c),.92) 0 27%,rgba(var(--c),.66) 27.500% 40%,rgba(var(--c),.44) 40.500% 56%,rgba(var(--c),.26) 56.500% 76%,rgba(var(--c),.12) 76.500% 100%)}',
    '.suo-rip-t{flex:1;min-width:0}.suo-rip-t small{display:flex;align-items:center;gap:6px;font:500 13px var(--font-body);color:rgba(255,255,255,.72)}.suo-rip-t b{display:block;margin-top:6px;font:700 16px var(--font-display);font-style:normal;color:#fff}',
    '.suo-rip-p{position:relative;z-index:1;flex:none;width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#fff;color:#14234A}',
    '.suo-rip-p svg,.suo-att-c span svg{width:20px;height:20px}',
    '.suo-pr-i{flex:none;display:flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:12px;background:rgba(255,255,255,.1);color:#fff;font-style:normal}.suo-prog-riga > span{flex:1;min-width:0}.suo-prog-riga + .suo-prog-riga{margin-top:0}',
    '.suo-prog-riga{display:flex;align-items:center;justify-content:space-between;gap:12px;width:100%;margin-top:26px;padding:18px 4px;border-top:1px solid rgba(255,255,255,.12) !important;text-align:left;color:rgba(255,255,255,.6) !important}',
    '.suo-prog-riga b{display:block;font:700 14px var(--font-body);color:rgba(255,255,255,.86)}.suo-prog-riga small{display:block;margin-top:3px;font:400 12px var(--font-body);color:rgba(255,255,255,.55)}',
    '.suo-fondo{height:calc(96px + env(safe-area-inset-bottom))}',
    '#suoMini{position:absolute;left:8px;right:8px;bottom:calc(10px + env(safe-area-inset-bottom));z-index:3}',
    '.suo-mini{display:flex;align-items:center;gap:12px;padding:8px 10px;border-radius:14px;background:rgba(112,112,118,.72);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);cursor:pointer}',
    '.suo-mini img{width:38px;height:38px;border-radius:7px;object-fit:cover;flex:none}',
    '.suo-mini-t{flex:1;min-width:0}.suo-mini-t b{display:flex;align-items:center;gap:6px;font:600 14.5px var(--font-body);color:#fff}.suo-mini-t i{font-style:normal;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.suo-mini-t small{display:block;margin-top:2px;font:600 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:rgba(255,255,255,.62)}',
    '.suo-mini-c{display:flex;align-items:center;gap:5px;flex:none;padding:7px 8px;border-radius:6px;background:rgba(255,255,255,.14);font:500 13px var(--font-body);color:#fff;font-variant-numeric:tabular-nums}',
    '.suo-mini-p{flex:none;width:38px;height:38px;display:flex;align-items:center;justify-content:center;color:#fff !important}',
    /* il lettore */
    /* 0.9.315: il lettore come il riferimento: il disegno a tutto schermo, la frase al centro, sotto il brano e i comandi */
    '.suo-sf{position:absolute;inset:0;overflow:hidden}.suo-sf canvas{width:100%;height:100%;display:block}',
    '.suo-sf:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(8,8,14,.62),rgba(8,8,14,.42) 38%,rgba(8,8,14,.78))}',
    '.suo-pl{position:relative;z-index:1;flex:1;min-height:0;display:flex;flex-direction:column;padding:calc(8px + env(safe-area-inset-top)) 20px calc(14px + env(safe-area-inset-bottom))}',
    '.suo-centro{flex:1;min-height:0;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:12px 8px}',
    '.suo-fr{margin:0;font:700 clamp(23px,6.6vw,29px)/1.28 var(--font-display);font-style:normal;color:#fff;text-shadow:0 2px 14px rgba(0,0,0,.5)}',
    '.suo-fr-a{display:block;margin-top:14px;font:500 15px var(--font-body);color:rgba(255,255,255,.86)}',
    '.suo-fr.entra{animation:suoFrIn 3.2s cubic-bezier(.22,.7,.2,1) var(--d,0ms) both}',
    '.suo-fr.entra .suo-fr-a{animation:suoFrIn 2.4s cubic-bezier(.22,.7,.2,1) calc(var(--d,0ms) + 1s) both}',
    '@keyframes suoFrIn{0%{opacity:0;filter:blur(18px);transform:translateY(12px) scale(.97)}55%{opacity:.72;filter:blur(5px)}100%{opacity:1;filter:blur(0);transform:none}}',
    '.suo-basso{display:flex;align-items:flex-end;gap:12px}',
    '.suo-meta{flex:1;min-width:0;text-align:left}',
    '.suo-meta-t{display:block;width:100%;padding:0;text-align:left;color:#fff !important}',
    '.suo-meta-t b{display:block;font:800 19px/1.2 var(--font-display);font-style:normal;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.suo-meta-t small{display:flex;align-items:center;gap:7px;margin-top:7px;font:500 13.5px var(--font-body);color:rgba(255,255,255,.88)}',
    '.suo-chips{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}',
    '.suo-chip{padding:7px 13px;border-radius:99px;background:rgba(255,255,255,.18) !important;font:700 11.5px var(--font-body) !important;letter-spacing:.05em;color:#fff !important}',
    '.suo-chip.ol{background:none !important;box-shadow:inset 0 0 0 1px rgba(255,255,255,.4)}',
    '.suo-lato{flex:none;display:flex;flex-direction:column;align-items:center;gap:16px}',
    '.suo-lato button{width:40px;height:40px;display:flex;align-items:center;justify-content:center;color:#fff !important}',
    '.suo-lato button.on svg{fill:#fff}',
    '.suo-com3{display:flex;align-items:center;justify-content:space-between;margin:24px 18px 0}',
    '.suo-com3 .suo-com-p{width:72px;height:72px}.suo-com3 .suo-com-p svg{width:28px;height:28px}',
    '.suo-salto{width:52px;height:52px;display:flex;align-items:center;justify-content:center;color:#fff !important}',
    '.suo-ordine{display:flex;align-self:center;margin-top:12px;padding:8px;color:#fff !important}',
    '.suo-pl-serie{cursor:pointer;color:#fff !important}',
    /* i dettagli del brano: si aprono solo toccando il nome o le etichette */
    '.suo-dett{position:absolute;inset:0;z-index:4;display:flex;flex-direction:column;background:#00132B}',
    '.suo-dett.in{animation:suoSu .25s cubic-bezier(.2,.8,.2,1)}',
    '.suo-player-scorre{flex:1;min-height:0;overflow-y:auto;scrollbar-width:none;padding:calc(8px + env(safe-area-inset-top)) 20px 0}',
    /* la serie e i traguardi */
    '#suoSerieF{position:absolute;inset:0;z-index:6;pointer-events:none}#suoSerieF > *{pointer-events:auto}',
    '.suo-st-sf{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;padding:20px;background:rgba(0,0,0,.66)}',
    '.suo-st{position:relative;width:100%;max-width:400px;max-height:100%;overflow-y:auto;box-sizing:border-box;padding:24px 24px 26px;border-radius:26px;background:#14141C;box-shadow:0 0 0 1px rgba(255,255,255,.2),0 24px 60px rgba(0,0,0,.6);color:#fff;animation:suoSu .22s ease-out}',
    '.suo-st-top{display:flex;align-items:center;gap:12px;font:800 19px var(--font-display);font-style:normal}.suo-st-top button{margin-left:auto;display:flex;padding:4px;color:#fff !important}',
    '.suo-st-num{display:grid;grid-template-columns:1fr 1fr;margin-top:22px;text-align:center}',
    '.suo-st-num small{display:block;font:700 13px var(--font-body);letter-spacing:.1em;color:rgba(255,255,255,.72)}.suo-st-num b{display:block;margin-top:2px;font:800 76px/1.05 var(--font-display);font-style:normal;color:#fff}',
    '.suo-st-p{margin:10px 8px 18px;text-align:center;font:400 14.5px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.suo-st-h{margin:0 0 12px;padding-top:18px;border-top:1px solid rgba(255,255,255,.2);font:800 17px var(--font-display);font-style:normal;color:#fff}',
    '.suo-st-g{display:grid;grid-template-columns:1fr 1fr;gap:12px}',
    '.suo-st-t{padding:14px 8px 12px;border-radius:16px;box-shadow:inset 0 0 0 1px rgba(255,255,255,.2);text-align:center}.suo-st-t.no{opacity:.45}',
    '.suo-st-t svg{display:block;margin:0 auto 8px}',
    '.suo-st-t b{display:block;font:800 13px var(--font-body);letter-spacing:.08em;color:#fff}.suo-st-t small{display:block;margin-top:3px;font:500 13px var(--font-body);color:rgba(255,255,255,.82)}',
    '.suo-st-c{margin:18px 0 12px;text-align:center;font:800 16px var(--font-body);color:#fff}',
    '.suo-st-b{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;padding:15px;border-radius:14px;background:rgba(255,255,255,.12) !important;font:700 15px var(--font-body) !important;color:#fff !important}',
    /* i suoni chiusi */
    '.suo-sim.chiusa img{filter:grayscale(.6) brightness(.6)}.suo-sim.chiusa .suo-sim-c{justify-content:center;gap:6px}',
    '.suo-sim-l{flex:none;align-self:center;margin-right:14px;display:flex;color:rgba(255,255,255,.8)}',
    '.suo-sbl-riga b{color:#fff}',
    '.suo-sbl{position:fixed;inset:0;z-index:9650;display:flex;align-items:flex-end;justify-content:center;background:rgba(0,0,0,.66)}',
    '.suo-sbl-f{position:relative;width:100%;max-width:460px;box-sizing:border-box;padding:26px 22px calc(24px + env(safe-area-inset-bottom));border-radius:26px 26px 0 0;background:linear-gradient(168deg,#123A70,#001E44 62%);color:#fff;text-align:center;animation:suoSu .25s cubic-bezier(.2,.8,.2,1)}',
    '.suo-sbl-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.suo-sbl-i{display:inline-flex;width:62px;height:62px;border-radius:50%;align-items:center;justify-content:center;background:rgba(140,198,255,.16);color:#8CC6FF}',
    '.suo-sbl-f h3{margin:14px 0 16px;font:800 22px var(--font-display);font-style:normal;color:#fff}',
    '.suo-sbl-b{height:10px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}.suo-sbl-b i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,#0075E3,#8CC6FF)}',
    '.suo-sbl-n{margin:10px 0 14px;font:600 14.5px var(--font-body);color:rgba(255,255,255,.86)}.suo-sbl-n b{color:#fff;font-weight:800}',
    '.suo-sbl-p{margin:0 0 20px;font:400 15px/1.5 var(--font-body);color:rgba(255,255,255,.82)}',
    '.suo-sbl-f .suo-bianco{width:100%;border:0;background:#fff;color:#001E44 !important;cursor:pointer}',
    '.snd-sc-tabs{display:flex;justify-content:center;gap:2px;margin:0 0 16px;border-bottom:1.5px solid var(--line,#DCE8F5)}.snd-sc-tabs button{flex:1 1 auto;min-width:0;padding:10px 4px 11px;border:0;border-bottom:3px solid transparent;margin-bottom:-1.5px;background:none;color:var(--muted);font:700 14px var(--font-body);cursor:pointer}.snd-sc-tabs button.on{color:var(--navy);border-bottom-color:#0075E3;font-weight:800}body.dark .snd-sc-tabs button.on{color:#fff}',
    '.snd-sc-mio{display:block;margin:0 auto 22px !important}',
    '.snd-sc-h{margin:22px 0 12px;font:800 15px var(--font-display);color:var(--navy);text-align:center}body.dark .snd-sc-h{color:#fff}.snd-sc-vuoto{margin:6px 8px;font:500 14px/1.4 var(--font-body);color:var(--muted);text-align:center}.snd-sc-mio{border-style:dashed !important;color:#0075E3 !important}body.dark .snd-sc-mio{color:#8CC6FF !important}',
    '.suo-sbl-2{display:block;width:100%;margin-top:12px;padding:17px 22px;box-sizing:border-box;border:2px solid #8CC6FF;border-radius:99px;background:none;color:#fff;font:800 14px var(--font-body);letter-spacing:.14em;text-align:center;cursor:pointer}',
    '.suo-maniglia{display:flex;justify-content:center;width:100%;padding:8px 0 12px}.suo-maniglia i,.suo-maniglia-i{display:block;width:36px;height:4px;border-radius:9px;background:rgba(255,255,255,.4)}',
    '.suo-pl-top{display:flex;align-items:center;gap:10px}',
    '.suo-pl-att{flex:1;min-width:0;display:flex;align-items:center;gap:8px;padding:6px 0;text-align:left;color:#fff !important}.suo-pl-att b{font:700 17px var(--font-display);font-style:normal;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.suo-pl-att svg{flex:none}',
    '.suo-pl-serie{display:flex;align-items:center;gap:6px;padding:7px 12px;border-radius:99px;background:rgba(255,255,255,.12);font:600 14px var(--font-body);flex:none}',
    '.suo-pl-set{flex:none;width:40px;height:40px;display:flex;align-items:center;justify-content:center;color:#fff !important}',
    '.suo-et{margin:22px 0 0;text-align:center;font:700 12.5px var(--font-body);letter-spacing:.16em;color:rgba(255,255,255,.62)}',
    '.suo-tempo{margin:4px 0 0;text-align:center;font:600 76px/1.1 var(--font-display);font-style:normal;letter-spacing:-.02em;font-variant-numeric:tabular-nums;color:#fff}',
    '.suo-com{position:relative;display:flex;justify-content:center;align-items:center;margin-top:12px;min-height:60px}',
    '.suo-com-p{width:60px;height:60px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#fff !important;color:#14141A !important}',
    '.suo-com-s{position:absolute;left:calc(50% + 52px);width:44px;height:44px;display:flex;align-items:center;justify-content:center;color:#fff !important}',
    '.suo-cover{display:block;width:96px;height:96px;margin:26px auto 0;border-radius:14px;object-fit:cover}',
    '.suo-tit{margin:18px 0 10px;text-align:center;font:800 32px/1.12 var(--font-display);font-style:normal;color:#fff}',
    '.suo-sub{display:flex;justify-content:center;align-items:center;gap:7px;margin:0 0 8px;font:500 15px var(--font-body);color:rgba(255,255,255,.88)}',
    '.suo-azioni{display:flex;justify-content:space-between;gap:4px;margin:20px 0 6px}',
    '.suo-az{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;gap:6px;padding:4px 0;color:#fff !important}.suo-az span{font:500 13px var(--font-body);white-space:nowrap}',
    '.suo-az svg.pieno,.suo-sim-az svg.pieno{fill:currentColor}.suo-az.on{color:#fff !important}',
    '#suoAzPref.on svg{fill:#fff}',
    '.suo-cap{margin:22px 0 8px;font:800 12.5px var(--font-body);letter-spacing:.12em;color:rgba(255,255,255,.62)}',
    '.suo-val{margin:0;font:400 15px/1.4 var(--font-body);color:rgba(255,255,255,.92)}',
    '.suo-b{margin-top:22px}.suo-b-t{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px}.suo-b-t h4{margin:0;font:800 12.5px var(--font-body);letter-spacing:.12em;color:rgba(255,255,255,.62)}.suo-b-t span{font:400 14px var(--font-body);color:rgba(255,255,255,.78)}',
    '.suo-b-tr{height:8px;border-radius:9px;background:rgba(255,255,255,.14);overflow:hidden}.suo-b-tr i{display:block;height:100%;border-radius:9px;background:#fff}',
    '.suo-att2{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
    '.suo-att-c{display:flex;align-items:center;justify-content:space-between;gap:8px;min-height:72px;padding:10px 12px 10px 16px;border-radius:14px;border:1px solid rgba(255,255,255,.14) !important;text-align:left}',
    '.suo-att-c b{font:600 14.5px/1.25 var(--font-body);color:#fff}.suo-att-c span{flex:none;width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:#fff;color:#001E44}',
    '.suo-sim{display:flex;min-height:92px;margin-bottom:12px;border-radius:14px;overflow:hidden;border:1px solid rgba(255,255,255,.12);background:rgba(255,255,255,.07);cursor:pointer}',
    '.suo-sim img{width:88px;flex:none;object-fit:cover}',
    '.suo-sim-c{flex:1;min-width:0;padding:10px 12px;display:flex;flex-direction:column;justify-content:space-between}',
    '.suo-sim-r{display:flex;align-items:center;justify-content:space-between;gap:8px}',
    '.suo-sim-r b{display:flex;align-items:center;gap:6px;min-width:0;font:500 15px var(--font-body);color:#fff}.suo-sim-r b i{font-style:normal;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.suo-sim-r em{flex:none;padding:3px 8px;border-radius:99px;background:rgba(255,255,255,.14);font:700 10.5px var(--font-body);font-style:normal;letter-spacing:.04em;color:#fff}',
    '.suo-sim-c small{display:block;font:500 11px var(--font-body);letter-spacing:.06em;color:rgba(255,255,255,.62)}',
    '.suo-sim-az span{display:flex;gap:12px}.suo-sim-az button{display:flex;padding:2px;color:rgba(255,255,255,.86) !important}.suo-sim-az u{font:500 12.5px var(--font-body);text-decoration:none;white-space:nowrap}',
    '.suo-bianco{display:block;border-radius:99px;background:#fff !important;color:#111 !important;font:800 14px var(--font-body) !important;letter-spacing:.14em;padding:17px 22px;text-align:center}',
    '.suo-chiudi{position:absolute;left:18px;right:18px;bottom:calc(14px + env(safe-area-inset-bottom));z-index:2}',
    '.suo-testo{padding:16px 18px;font:800 14px var(--font-body) !important;letter-spacing:.14em;color:#fff !important}',
    '#suoFoglio{position:absolute;inset:0;z-index:5;pointer-events:none}#suoFoglio > *{pointer-events:auto}',
    '.suo-fg-sf{position:absolute;inset:0;background:rgba(0,0,0,.6)}',
    '.suo-fg{position:absolute;left:0;right:0;bottom:0;max-height:82%;display:flex;flex-direction:column;border-radius:24px 24px 0 0;background:#1C1C20;padding:10px 0 calc(10px + env(safe-area-inset-bottom));animation:suoSu .25s cubic-bezier(.2,.8,.2,1)}',
    '@keyframes suoSu{from{transform:translateY(40px);opacity:.4}to{transform:none;opacity:1}}',
    '.suo-maniglia-i{margin:0 auto}.suo-fg-h{margin:16px 24px 8px}',
    '.suo-fg-l{flex:1;min-height:0;overflow-y:auto;padding:0 24px}',
    '.suo-fg-r{display:flex;align-items:center;gap:14px;width:100%;padding:13px 0;text-align:left;color:#fff !important}.suo-fg-i{flex:none;display:flex;width:32px;justify-content:center}.suo-fg-t{flex:1;min-width:0}.suo-fg-t b{display:block;font:500 17px var(--font-body)}.suo-fg-t small{display:block;margin-top:5px;font:400 13px/1.35 var(--font-body);color:rgba(255,255,255,.6)}',
    '.suo-fg-b{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px 2px;border-top:1px solid rgba(255,255,255,.12);margin-top:6px}.suo-fg-b .suo-testo{flex:1}.suo-fg-b .suo-bianco{flex:1.2}',
    /* le impostazioni */
    '.suo-set-top{display:grid;grid-template-columns:44px 1fr 44px;align-items:center;padding:calc(14px + env(safe-area-inset-top)) 12px 8px}.suo-set-top .suo-ind{position:static}.suo-set-top b{text-align:center;font:700 17px var(--font-display);font-style:normal;color:#fff}.suo-set-i{display:flex;justify-content:center;color:#fff !important}',
    '.suo-set-scorre{flex:1;min-height:0;overflow-y:auto;scrollbar-width:none;padding:6px 20px 0}',
    '.suo-p{margin:-6px 0 14px;font:400 14.5px/1.4 var(--font-body);color:rgba(255,255,255,.72)}',
    '.suo-box{border:1px solid rgba(255,255,255,.18);border-radius:18px;background:rgba(255,255,255,.04);overflow:hidden;margin-bottom:14px}',
    '.suo-adhd{display:flex;align-items:center;gap:12px;padding:16px 16px 16px 18px}.suo-adhd span{flex:1;min-width:0}.suo-adhd span b{display:block;font:600 16px var(--font-body);color:#fff}.suo-adhd small{display:block;margin-top:4px;font:400 13px/1.35 var(--font-body);color:rgba(255,255,255,.7)}',
    '.suo-sw{flex:none;width:52px;height:30px;border-radius:99px;background:rgba(255,255,255,.2) !important;position:relative;transition:background .2s;padding:0}.suo-sw.on{background:linear-gradient(90deg,#0075E3,#3F9FF4) !important}',
    '.suo-sw i{position:absolute;left:3px;top:3px;width:24px;height:24px;border-radius:50%;background:#fff;color:#14141A;display:flex;align-items:center;justify-content:center;transition:left .2s}.suo-sw.on i{left:25px}',
    '.suo-liv{display:flex;align-items:center;gap:12px;width:100%;padding:14px 16px 14px 18px;border-top:1px solid rgba(255,255,255,.16) !important;text-align:left;color:#fff !important}.suo-liv:first-child{border-top:0 !important}.suo-liv.on{background:rgba(255,255,255,.1) !important}',
    '.suo-liv span{flex:1;min-width:0}.suo-liv b{display:flex;align-items:center;gap:8px;font:600 16px var(--font-body)}.suo-liv small{display:block;margin-top:5px;font:400 13px/1.35 var(--font-body);color:rgba(255,255,255,.7)}',
    '.suo-gr-t{display:flex;justify-content:space-between;align-items:center;margin:18px 0 12px}.suo-gr-t b{font:700 16px var(--font-body);color:#fff}.suo-gr-t button{font:400 14px var(--font-body);text-decoration:underline;color:rgba(255,255,255,.76) !important;padding:2px}',
    '.suo-gen{display:flex;align-items:center;gap:14px;width:100%;padding:13px 16px;border-top:1px solid rgba(255,255,255,.16) !important;text-align:left;color:rgba(255,255,255,.5) !important}.suo-gen:first-child{border-top:0 !important}.suo-gen.on{color:#fff !important}.suo-gen span{flex:none;display:flex;width:32px;justify-content:center}.suo-gen b{flex:1;font:500 16px var(--font-body)}',
    '.suo-mix{padding:18px 16px;text-align:center}.suo-mix-i{display:flex;justify-content:center;align-items:center;gap:8px;margin-bottom:12px}.suo-mix p{margin:0;font:400 15px/1.45 var(--font-body);color:rgba(255,255,255,.9)}',
    '.suo-fondo2{height:calc(160px + env(safe-area-inset-bottom))}',
    '.suo-set-b{position:absolute;left:18px;right:18px;bottom:calc(6px + env(safe-area-inset-bottom));display:flex;flex-direction:column;align-items:center;gap:2px;padding-top:14px;background:linear-gradient(180deg,rgba(10,10,15,0),#00132B 22%)}.suo-set-b .suo-bianco{width:100%}',
    '.suo-info-b{margin:14px 0 36px;color:#fff}.suo-info-b h3{margin:12px 0 8px;font:800 19px var(--font-display);font-style:normal;color:#fff}.suo-info-b p{margin:0;font:400 15px/1.45 var(--font-body);color:rgba(255,255,255,.86)}',
    '.suo-info-l{display:flex;gap:10px;color:#fff}.suo-info-l svg{width:26px;height:26px}',
    '.suo-cred{margin:0 0 20px;font:400 12px/1.5 var(--font-body);color:rgba(255,255,255,.5)}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();

(function(){ const st = document.createElement('style'); st.textContent = '.suo-prefban{margin:6px 0 22px;border-radius:20px;overflow:hidden;background:linear-gradient(135deg,rgba(230,57,70,.28),rgba(0,117,227,.22));border:1px solid rgba(255,255,255,.14)}'
  + '.suo-prefban-top{display:flex;align-items:center;gap:12px;width:100%;padding:18px;border:0;background:none;color:#fff;text-align:left;cursor:pointer}.suo-prefban-t{flex:1;min-width:0}.suo-prefban-t b{display:block;font:800 18px/1.25 var(--font-display);color:#fff}.suo-prefban-t small{display:block;margin-top:4px;font:500 13px var(--font-body);color:rgba(255,255,255,.75)}'
  + '.suo-prefban-play{flex:none;width:52px;height:52px;border-radius:50%;background:#fff;color:#001E44;display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 8px rgba(255,255,255,.12)}'
  + '.suo-prefban-l{display:flex;flex-direction:column;border-top:1px solid rgba(255,255,255,.12)}.suo-prefban-r{display:flex;align-items:center;gap:10px;padding:12px 18px;border:0;border-bottom:1px solid rgba(255,255,255,.08);background:none;color:#fff;text-align:left;cursor:pointer}.suo-prefban-r span{color:#FF8A94;display:flex}.suo-prefban-r b{font:600 14.5px var(--font-body);color:#fff}'
  + '.suo-prefav{position:fixed;left:16px;right:16px;bottom:calc(24px + env(safe-area-inset-bottom));z-index:10060;display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:18px;background:#fff;box-shadow:0 14px 34px rgba(0,19,43,.35);transform:translateY(140%);opacity:0;transition:transform .35s cubic-bezier(.2,.9,.3,1.2),opacity .25s;pointer-events:none}'
  + '.suo-prefav.in{transform:none;opacity:1;pointer-events:auto}.suo-prefav-c{flex:none;width:40px;height:40px;border-radius:50%;background:#FFE3E6;color:#E63946;display:flex;align-items:center;justify-content:center}.suo-prefav div{flex:1;min-width:0}.suo-prefav b{display:block;font:800 14.5px var(--font-body);color:#001E44}.suo-prefav small{display:block;margin-top:2px;font:500 12.5px var(--font-body);color:#5A6B85;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}'
  + '.suo-prefav button{flex:none;padding:9px 14px;border:0;border-radius:99px;background:#0075E3;color:#fff;font:800 13px var(--font-body);cursor:pointer}.suo-prefav .pieno{fill:currentColor}'; document.head.appendChild(st); })();
