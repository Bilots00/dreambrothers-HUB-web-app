/* ===========================================================================================
   IL RESPIRO (0.9.210, rifatto nella 0.9.220): la respirazione per la performance e il sonno

   PERCHE'. La respirazione lenta (sei-dieci respiri al minuto) stimola il nervo vago, il freno
   del sistema nervoso: il battito rallenta, la pressione scende, e con la pratica scende anche
   il cortisolo. La respirazione rapida e profonda fa il contrario: accende l'allarme, e di giorno
   si puo' usare apposta per svegliare corpo e testa. Il perche' sta nell'Academy, moduli «Il
   respiro che calma» e «Il respiro per la performance».

   DUE CATEGORIE (0.9.220, richiesta di Andrea con il prompt di Google AI Mode):
     1. Performance, SOLO da seduti o sdraiati: il respiro che sveglia (Huberman Focus,
        iperventilazione ciclica: tre giri di trenta respiri, apnea a polmoni vuoti con il
        cronometro che sale, un respiro pieno trattenuto quindici secondi), il respiro quadrato
        (box breathing 4-4-4-4, da cinque a dieci minuti) e il 4-2. Prima di ognuno, l'avviso di
        sicurezza da confermare: chi iperventila in piedi puo' svenire (meno anidride carbonica,
        i vasi del cervello si stringono, la pressione cade quando ci si alza).
     2. Recupero e sonno: il 4-7-8 di Andrew Weil (esattamente quattro cicli, l'aria fuori dalla
        bocca con un soffio), il sospiro ciclico di Huberman (da uno a cinque minuti) e il 4-6.

   IL MOTORE. Ogni esercizio diventa una lista di passi ({ f: parola, s: secondi, a: animazione }).
   Un passo senza secondi e' l'apnea: il cronometro sale finche' tocchi «Devo respirare» (al
   massimo tre minuti). Il fiore si apre mentre inspiri, resta aperto mentre trattieni a polmoni
   pieni, si chiude mentre espiri; l'anello intorno si riempie con il passo. A ogni cambio di fase
   un suono breve (si spegne dall'altoparlante in alto) e una vibrazione.

   IL GENIO CONSIGLIA. Tre domande (cosa vuoi ottenere, quanto tempo hai, dove sei) piu' l'ora del
   giorno, che l'app sa da sola. Mai un respiro che sveglia in piedi o la sera. Il respiro
   consigliato dal Genio si apre per tutti quella volta, come quello proposto dall'Oracolo.

   LE STATISTICHE: le sessioni finite, i minuti, e le apnee a polmoni vuoti, giro per giro.
   Tutto in fl_respiro: [{ k, sec, at, apnee: [secondi], carb }].

   IL CARBURANTE (0.9.220, Andrea: «ogni singolo esercizio di respirazione deve impattare sul
   carburante, in base al tempo della sessione»). Ogni sessione ricarica la riserva di dopamina
   con lo stesso metro delle task chiuse nel tempo (carburante.js, fcAggiungi): mezzo punto a
   minuto, almeno un punto. Vale anche una sessione interrotta, se e' durata almeno un minuto.
   Tetto: 10 punti al giorno dal respiro (venti minuti), perche' la riserva misuri la giornata
   e non si gonfi ripetendo l'esercizio.
   =========================================================================================== */
const RS = { tecnica: 'rilassamento', durata: 60, giri: 3, libera: '', dopo: null, timer: 0, da: '', passi: [], i: -1, t0: 0, inizio: 0, apnee: [], audio: null };
const RS_CATEGORIE = [
  { k: 'performance', t: 'Performance', s: 'Per accendere testa e corpo di giorno. Solo da seduti o sdraiati.' },
  { k: 'recupero', t: 'Recupero e sonno', s: 'Per spegnere l’allarme del corpo e prepararti a dormire.' }
];
const RS_TECNICHE = [
  /* ---- 1. Performance ---- */
  /* 0.9.309: colori solo del brand (prima arancione, lilla e verde acqua). `breve` e' la riga del foglio, `s` sta dietro
     a "Scopri di più"; `dopo` e' il consiglio di una riga che chiude la sessione (prima `fine`, tre frasi insieme). */
  { k: 'attivante', cat: 'performance', seduto: true, t: 'Il respiro che sveglia', ritmo: 'Huberman Focus, a giri', col: '#FF6B76',
    breve: 'Trenta respiri profondi, poi l’apnea a polmoni vuoti. Sveglia corpo e testa.',
    s: 'Trenta respiri profondi e veloci, poi l’aria fuori e l’apnea finché ti è comodo, poi un respiro pieno trattenuto. Sveglia corpo e testa quando sei scarico. Solo di giorno.',
    giri: true, mostra: [['Respira a fondo', '30 volte', 'in'], ['Aria fuori, ferma', 'finché ti è comodo', 'out'], ['Inspira e trattieni', '15 secondi', 'tieni']],
    avviso: 'Non farlo in gravidanza, con problemi al cuore o con l’epilessia. Se ti gira la testa o senti formicolii forti, fermati e respira normalmente.',
    dopo: 'Adesso fai il lavoro più difficile della giornata.' },
  { k: 'concentrazione', cat: 'performance', seduto: true, t: 'Il respiro quadrato', ritmo: 'Box breathing 4-4-4-4', col: '#8CC6FF',
    breve: 'Quattro fasi da quattro secondi: la testa resta lucida e ferma.',
    s: 'Quattro fasi uguali da quattro secondi. Lo usano i Navy SEAL americani per restare lucidi sotto pressione: ferma la testa senza addormentarla.',
    fasi: [['Inspira', 4, 'in'], ['Trattieni', 4, 'pieno'], ['Espira', 4, 'out'], ['Trattieni', 4, 'vuoto']],
    durate: [[300, '5', 'min'], [480, '8', 'min'], [600, '10', 'min']],
    dopo: 'Torna al lavoro adesso, prima che arrivi una notifica.' },
  { k: 'motivazione', cat: 'performance', seduto: true, t: 'La carica breve', ritmo: 'Respirazione 4-2', col: '#3F9FF4',
    breve: 'Respiri più rapidi per svegliarti in un paio di minuti.',
    s: 'Respiri più rapidi per svegliare il corpo e l’attenzione quando sei scarico e hai solo un paio di minuti.',
    fasi: [['Inspira', 4, 'in'], ['Espira', 2, 'out']],
    durate: [[60, '1', 'min'], [120, '2', 'min'], [180, '3', 'min']],
    dopo: 'Alzati piano e comincia dalla cosa più piccola.' },
  /* ---- 2. Recupero e sonno ---- */
  { k: 'distensione', cat: 'recupero', t: 'Il 4-7-8 per dormire', ritmo: 'Andrew Weil, quattro cicli', col: '#BCE0FF',
    breve: 'Il respiro che prepara il corpo a dormire, in poco più di un minuto.',
    s: 'Quattro secondi dentro dal naso, sette col fiato trattenuto, otto fuori dalla bocca con un soffio. Esattamente quattro cicli, poco più di un minuto.',
    fasi: [['Inspira dal naso', 4, 'in'], ['Trattieni', 7, 'pieno'], ['Soffia fuori dalla bocca', 8, 'out', 'soffio']], cicli: 4,
    dopo: 'Adesso spegni lo schermo e resta al buio.' },
  { k: 'sospiro', cat: 'recupero', t: 'Il sospiro ciclico', ritmo: 'Huberman, da 1 a 5 minuti', col: '#7FD1FF',
    breve: 'Due inspirazioni e un’espirazione lunga: il modo più rapido di calmarti.',
    s: 'Due inspirazioni dal naso, la seconda più corta, poi un’espirazione lunga dalla bocca. Il modo più rapido di abbassare l’agitazione. Cinque minuti al giorno migliorano l’umore.',
    fasi: [['Inspira dal naso', 2, 'in'], ['Inspira ancora', 1, 'in'], ['Espira lento', 6, 'out']],
    durate: [[60, '1', 'min'], [180, '3', 'min'], [300, '5', 'min']], libera: true,
    dopo: 'Quando l’agitazione torna, rifai un minuto di sospiro ciclico.' },
  { k: 'rilassamento', cat: 'recupero', t: 'Il rilassamento', ritmo: 'Respirazione 4-6', col: '#F6CCE4',
    breve: 'Espirazioni più lunghe delle inspirazioni: mente e corpo rallentano.',
    s: 'Calma mente e corpo con espirazioni più lunghe delle inspirazioni.',
    fasi: [['Inspira', 4, 'in'], ['Espira', 6, 'out']], libera: true,
    dopo: 'Resta così ancora un momento, prima di riprendere.' }
];
/* 0.9.309, Andrea: "durante Trattieni l'anello fa lo stesso movimento di quando si inspira, e i colori sono uguali".
   Ogni fase ha il suo segno, uguale per tutte le tecniche: inspira = il fiore si apre e l'anello si riempie in azzurro;
   trattieni = tutto fermo, anello bianco che pulsa piano; espira = il fiore si chiude e l'anello si svuota in rosa. */
const RS_FASE_COL = { in: '#8CC6FF', tieni: '#FFFFFF', out: '#F6A5B5' };
const RS_FASE_ICO = {
  in: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v4M12 17.5v4M2.5 12h4M17.5 12h4"/><path d="M10 4.6l2 2 2-2M10 19.4l2-2 2 2M4.6 10l2 2-2 2M19.4 10l-2 2 2 2"/></svg>',
  in2: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="14" r="3"/><path d="M10 5.5v4M10 18.5v3M2 14h4M14 14h3"/><path d="M8.2 7.7l1.8 1.8 1.8-1.8"/><path d="M19 3v6M16 6h6"/></svg>',
  tieni: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M9.5 8.5v7M14.5 8.5v7"/></svg>',
  out: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h16a3 3 0 1 1-3 3"/><path d="M3 16h7"/></svg>'
};
const RS_X = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>';
/** La fase di un passo, per il segno visivo: in, tieni, out */
function rsFaseK(p){ return (p.apnea || p.a === 'pieno' || p.a === 'vuoto') ? 'tieni' : (p.a === 'out' ? 'out' : 'in'); }
const RS_AVVISO = 'Esegui questo esercizio esclusivamente da seduto o sdraiato in un luogo sicuro. Non praticare mai in piedi, in acqua, sotto la doccia o alla guida di un veicolo.';
const RS_APNEA_MAX = 180;
const RS_CARB_MAX_GIORNO = 10;
const RS_ICO = {
  rilassamento: '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2"><circle cx="16" cy="16" r="13"/><circle cx="16" cy="19" r="8"/><circle cx="16" cy="22" r="3.5"/></svg>',
  concentrazione: '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="6" y="6" width="20" height="20" rx="3"/><path d="M11 16h10M16 11v10"/></svg>',
  distensione: '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M22 5a11 11 0 1 0 5 15A9 9 0 0 1 22 5z"/></svg>',
  motivazione: '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M16 3l3 8 8-3-3 8 5 5-8 1-1 8-4-6-6 4 1-8-8-3 7-4-2-8 8 4z"/></svg>',
  sospiro: '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 12c4-5 8-5 12 0s8 5 12 0"/><path d="M4 20c4-5 8-5 12 0s8 5 12 0"/></svg>',
  attivante: '<svg viewBox="0 0 32 32" width="30" height="30" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><path d="M18 3L7 18h8l-2 11 12-16h-8z"/></svg>'
};
const RS_VENTO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h16a3 3 0 1 1-3 3"/><path d="M3 16h7"/></svg>';
const RS_CHEV = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>';
const RS_LUCCHETTO = '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/></svg>';
const RS_AUDIO_ON = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16 9a4 4 0 0 1 0 6M18.5 6.5a8 8 0 0 1 0 11"/></svg>';
const RS_AUDIO_OFF = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16 10l5 5M21 10l-5 5"/></svg>';
function rsEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function rsPremium(){ try{ return !!(typeof Premium !== 'undefined' && Premium.isPremium && Premium.isPremium()); }catch(_){ return false; } }
function rsTec(k){ return RS_TECNICHE.filter(function(t){ return t.k === k; })[0] || RS_TECNICHE[RS_TECNICHE.length - 1]; }
function rsChiusa(t){ return !t.libera && !rsPremium() && RS.libera !== t.k; }
function rsFiore(cls){
  let p = ''; for (let i = 0; i < 8; i++) p += '<i style="--r:' + (i * 45) + 'deg"></i>';
  return '<div class="rsp-fiore ' + (cls || '') + '"><div class="rsp-petali">' + p + '</div><b class="rsp-cuore"></b></div>';
}
/** «1 minuto e 5 secondi», «45 secondi»: il tempo detto a voce */
function rsTempoVoce(sec){
  sec = Math.round(sec || 0);
  const m = Math.floor(sec / 60), s = sec % 60;
  const ms = m ? (m === 1 ? '1 minuto' : m + ' minuti') : '';
  const ss = s ? (s === 1 ? '1 secondo' : s + ' secondi') : '';
  return ms && ss ? ms + ' e ' + ss : (ms || ss || '0 secondi');
}
function rsMmss(sec){ sec = Math.max(0, Math.round(sec)); return Math.floor(sec / 60) + ':' + String(sec % 60).padStart(2, '0'); }

registerScreen('s-respiro',
  '<div class="rsp-pag"><div class="rsp-top"><button class="iconbtn rsp-back" onclick="rsIndietro()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg></button></div>'
  + '<div id="rsBody"></div></div>', { back: function(){ const f = document.getElementById('rsFoglio'); if (f){ rsFoglioChiudi(); return 's-respiro'; } setTimeout(rsDopoUscita, 0); return 's-home'; } });

/** Apre la pagina dei respiri. opz: { tecnica, durata, giri, dopo (funzione), libera (la tecnica che si apre per tutti), da, consiglio } */
function rsApri(opz){
  opz = opz || {};
  RS.dopo = typeof opz.dopo === 'function' ? opz.dopo : null;
  RS.libera = opz.libera || '';
  RS.da = opz.da || '';
  /* 0.9.224: il foglio dell'esercizio scelto l'ultima volta restava nella pagina: rientrando si
     riapriva il box breathing invece della scelta. Si riparte sempre dalla scelta. */
  rsFoglioChiudi();
  goId('s-respiro'); rsPaint();
  try{ const sc = document.getElementById('s-respiro'); if (sc) sc.scrollTop = 0; }catch(_){ }
  if (opz.tecnica) setTimeout(function(){ rsScegli(opz.tecnica, opz.durata, opz.giri); }, 250);
}
/** Dalla slide delle sfide e dalle scorciatoie della scheda Sogno: il Genio consiglia il respiro */
function rsConsiglioApri(da){ RSG.da = da || 'dream'; RS.da = RSG.da; rsConsiglio(); }
function rsIndietro(){ rsFoglioChiudi(); goId('s-home'); rsDopoUscita(); }
function rsDopoUscita(){
  if (RS.dopo){ const f = RS.dopo; RS.dopo = null; try{ f(false); }catch(_){ } return; }
  /* aperto da un blocco guidato della pagina Suoni: si torna li' */
  if (RS.da === 'suoni' && typeof suoApri === 'function'){ RS.da = ''; suoApri(); return; }
  try{ if (RS.da === 'dream') switchTab('rotta'); }catch(_){ }
}
function rsVoceHtml(t){
  return '<button type="button" class="rsp-voce" onclick="rsScegli(\'' + t.k + '\')"><span class="rsp-ico" style="color:' + t.col + '">' + RS_ICO[t.k] + '</span>'
    + '<div><b>' + rsEsc(t.t) + '</b><small>' + rsEsc(t.ritmo) + '</small></div>'
    + (rsChiusa(t) ? '<span class="rsp-lucchetto" aria-label="Con Premium">' + RS_LUCCHETTO + '</span>' : '<span class="rsp-chev">' + RS_CHEV + '</span>') + '</button>';
}
function rsPaint(){
  const h = document.getElementById('rsBody'); if (!h) return;
  h.innerHTML = rsFiore('gira')
    + '<h2 class="rsp-h">Inizia la tua esperienza</h2><p class="rsp-p">Su cosa vorresti concentrarti?</p>'
    + '<button type="button" class="rsp-genio" onclick="RSG.da=\'respiro\';rsConsiglio()"><img src="img/genio/genio-pensa.png" alt=""><div><b>Quale respiro ti serve adesso?</b><small>Dimmi cosa vuoi ottenere, quanto tempo hai e dove sei: il Genio sceglie il respiro giusto.</small></div><span class="rsp-chev">' + RS_CHEV + '</span></button>'
    + RS_CATEGORIE.map(function(c){
        return '<div class="rsp-cat"><h3>' + c.t + '</h3><p>' + c.s + '</p></div>'
          + '<div class="rsp-lista">' + RS_TECNICHE.filter(function(t){ return t.cat === c.k; }).map(rsVoceHtml).join('') + '</div>';
      }).join('')
    + rsStatHtml();
}

/* ---- le statistiche ---- */
function rsStorico(){ try{ return JSON.parse(localStorage.getItem('fl_respiro') || '[]') || []; }catch(_){ return []; } }
/* 0.9.309, Andrea: "pannello brutto, muro di testo, arancione fuori brand". Nella pagina dei respiri restano tre
   numeri grandi; il resto (grafici a 7 e 30 giorni, apnea nel tempo, tecniche) sta nella pagina "I tuoi respiri",
   fatta come la pagina dell'umore (umore.js, umInfoPaint: stesse classi umi-*). */
function rsApneaRecord(l){
  const tutte = (l || rsStorico()).reduce(function(a, x){ return a.concat(x.apnee || []); }, []);
  return tutte.length ? Math.max.apply(null, tutte) : 0;
}
/** I minuti detti con un numero: "<1" sotto il minuto, mai zero se hai respirato */
function rsMinNum(sec){ return !sec ? '0' : (sec < 60 ? '<1' : String(Math.round(sec / 60))); }
function rsStatHtml(){
  const l = rsStorico();
  if (!l.length) return '<div class="rsp-stat vuoto"><h3>I tuoi respiri</h3><p>Finisci il primo respiro: qui vedrai sessioni, minuti e apnea migliore.</p></div>';
  const tot = l.reduce(function(a, x){ return a + (x.sec || 0); }, 0);
  const rec = rsApneaRecord(l);
  const tec = Object.keys(l.reduce(function(a, x){ a[x.k] = 1; return a; }, {})).length;
  const tile = function(e, n, t){ return '<div><span class="rsp-stat-e">' + e + '</span><b>' + n + '</b><small>' + t + '</small></div>'; };
  return '<button type="button" class="rsp-stat" onclick="rspStatApri()"><h3>I tuoi respiri</h3><div class="rsp-stat-num">'
    + tile('🫁', l.length, l.length === 1 ? 'sessione' : 'sessioni')
    + tile('⏱️', rsMinNum(tot), 'minuti')
    + (rec ? tile('🏆', rsMmss(rec), 'apnea migliore') : tile('🌬️', tec, tec === 1 ? 'tecnica' : 'tecniche'))
    + '</div><span class="rsp-stat-link">Guarda i tuoi progressi' + RS_CHEV + '</span></button>';
}

/* ---- la pagina "I tuoi respiri" ---- */
const RSP_STAT = { giorni: 7 };
registerScreen('s-respiro-stat',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-respiro\')" aria-label="Indietro"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 6l-6 6 6 6"/></svg></button><b class="blk-title">I tuoi respiri</b></div>'
  + '<div class="al-page" id="rspStatBody"></div><div class="spacer"></div>', { back: 's-respiro' });
function rspStatApri(){ goId('s-respiro-stat'); rspStatPaint(); try{ document.getElementById('s-respiro-stat').scrollTop = 0; }catch(_){ } }
function rspStatGiorni(n){ RSP_STAT.giorni = n; rspStatPaint(); }
/** I giorni del periodo, dal piu' vecchio a oggi: { d, sec, n } */
function rspPeriodo(n, da){
  const l = rsStorico(), out = [];
  for (let i = (da || 0) + n - 1; i >= (da || 0); i--){
    const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i);
    const a = d.getTime(), b = a + 86400000;
    const del = l.filter(function(x){ return x.at >= a && x.at < b; });
    out.push({ d: d, sec: del.reduce(function(s, x){ return s + (x.sec || 0); }, 0), n: del.length });
  }
  return out;
}
function rspDalAl(a, b){
  if (typeof umDalAl === 'function') return umDalAl(a, b);
  return 'Dal ' + a.getDate() + '/' + (a.getMonth() + 1) + ' al ' + b.getDate() + '/' + (b.getMonth() + 1);
}
function rspStatPaint(){
  const host = document.getElementById('rspStatBody'); if (!host) return;
  const l = rsStorico();
  const n = RSP_STAT.giorni;
  const giorni = rspPeriodo(n, 0);
  const secP = giorni.reduce(function(a, g){ return a + g.sec; }, 0), nP = giorni.reduce(function(a, g){ return a + g.n; }, 0);
  const G = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];
  const alto = Math.max(60, Math.max.apply(null, giorni.map(function(g){ return g.sec; })));
  let grafico = '';
  if (n === 7){
    grafico = '<div class="umi-c7 rsps-c7">' + giorni.map(function(g, i){
      const h = g.sec ? Math.max(22, g.sec / alto * 100) : 0;
      return '<div class="umi-col"><div class="umi-track">' + (g.sec ? '<div class="umi-fill rsps-fill" data-h="' + h + '" style="--d:' + (i * 70) + 'ms"><span>' + rsMinNum(g.sec) + '</span></div>' : '') + '</div><small>' + G[g.d.getDay()] + '</small></div>';
    }).join('') + '</div>';
  } else {
    const W = 300, H = 150, x0 = 8, x1 = 292, yb = 128, yt = 10;
    const bw = (x1 - x0) / n;
    let svg = '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + yb + '" y2="' + yb + '" class="umi-griglia"/>';
    giorni.forEach(function(g, i){
      const x = x0 + i * bw;
      if (g.sec){ const h = Math.max(4, g.sec / alto * (yb - yt)); svg += '<rect class="rsps-bar" x="' + (x + bw * 0.18).toFixed(1) + '" y="' + (yb - h).toFixed(1) + '" width="' + (bw * 0.64).toFixed(1) + '" height="' + h.toFixed(1) + '" rx="2.5" style="--d:' + (i * 25) + 'ms"/>'; }
      if (i % 7 === 0) svg += '<text x="' + (x + bw / 2).toFixed(1) + '" y="' + (H - 4) + '" class="umi-asse c">' + g.d.getDate() + '</text>';
    });
    grafico = '<svg class="umi-c30" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Minuti di respiro negli ultimi 30 giorni">' + svg + '</svg>';
  }
  const boxes = '<div class="umi-box blu"><small>Sessioni</small><b>' + nP + '</b></div>'
    + '<div class="umi-box rosa"><small>Minuti di respiro</small><b>' + rsMinNum(secP) + '</b></div>';
  /* l'apnea a polmoni vuoti, sessione dopo sessione (da sempre, non solo nel periodo) */
  const conApnea = l.filter(function(x){ return x.apnee && x.apnee.length; });
  let apnea;
  if (!conApnea.length){
    apnea = '<div class="umi-card umi-centro"><h4>La tua apnea a polmoni vuoti</h4><p class="umi-p">Fai il respiro che sveglia: qui vedrai la tua apnea crescere, sessione dopo sessione.</p>'
      + '<button type="button" class="cta rsps-cta" onclick="goId(\'s-respiro\');rsScegli(\'attivante\')">Prova il respiro che sveglia</button></div>';
  } else {
    const rec = rsApneaRecord(l);
    const ult = conApnea.slice(-12);
    const migl = ult.map(function(x){ return Math.max.apply(null, x.apnee); });
    const top = Math.max(60, Math.ceil(Math.max.apply(null, migl) / 30) * 30);
    const W = 300, H = 170, x0 = 44, x1 = 286, yt = 14, yb = 140;
    const y = function(s){ return yb - s / top * (yb - yt); };
    const x = function(i){ return ult.length === 1 ? (x0 + x1) / 2 : x0 + i * (x1 - x0) / (ult.length - 1); };
    let svg = '';
    for (let s = 0; s <= top; s += top / 2){ svg += '<line x1="' + x0 + '" x2="' + x1 + '" y1="' + y(s).toFixed(1) + '" y2="' + y(s).toFixed(1) + '" class="umi-griglia"/><text x="' + (x0 - 6) + '" y="' + (y(s) + 4).toFixed(1) + '" class="umi-asse rsps-y">' + rsMmss(s) + '</text>'; }
    if (ult.length > 1) svg += '<polyline class="umi-linea rsps-linea" points="' + migl.map(function(s, i){ return x(i).toFixed(1) + ',' + y(s).toFixed(1); }).join(' ') + '"/>';
    migl.forEach(function(s, i){ svg += '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(s).toFixed(1) + '" r="5.5" class="rsps-punto' + (s === rec ? ' massimo' : '') + '"/>'; });
    [0, ult.length - 1].filter(function(v, i, a){ return a.indexOf(v) === i; }).forEach(function(i){ const d = new Date(ult[i].at); svg += '<text x="' + x(i).toFixed(1) + '" y="' + (H - 6) + '" class="umi-asse" text-anchor="' + (ult.length === 1 ? 'middle' : (i ? 'end' : 'start')) + '">' + d.getDate() + '/' + (d.getMonth() + 1) + '</text>'; });
    apnea = '<div class="umi-card umi-centro"><h4>La tua apnea a polmoni vuoti</h4><small class="umi-range">Ogni punto è l’apnea migliore di una sessione del respiro che sveglia</small>'
      + '<div class="rsps-massimo"><span>🏆</span><b>' + rsMmss(rec) + '</b><small>la più lunga di sempre</small></div>'
      + '<svg class="umi-c30" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="La tua apnea migliore, sessione dopo sessione">' + svg + '</svg>'
      + '<p class="umi-p rsps-nota">Con la pratica di solito si allunga: non forzarla mai.</p></div>';
  }
  /* le tecniche che fai di piu' */
  const conta = {}; l.forEach(function(x){ conta[x.k] = (conta[x.k] || 0) + 1; });
  const tecn = Object.keys(conta).sort(function(a, b){ return conta[b] - conta[a]; }).slice(0, 3);
  const tecHtml = tecn.length ? '<div class="umi-card umi-centro"><h4>Le tecniche che fai di più</h4><div class="umi-top">' + tecn.map(function(k){ const t = rsTec(k);
      return '<div><span class="rsps-ico" style="color:' + t.col + '">' + RS_ICO[t.k] + '</span><b>' + rsEsc(t.t) + '</b><i>' + (conta[k] === 1 ? '1 volta' : conta[k] + ' volte') + '</i></div>'; }).join('') + '</div></div>' : '';
  host.innerHTML = '<div class="umi-tabs"><button type="button" class="' + (n === 7 ? 'on' : '') + '" onclick="rspStatGiorni(7)">7 giorni</button><button type="button" class="' + (n === 30 ? 'on' : '') + '" onclick="rspStatGiorni(30)">30 giorni</button></div>'
    + '<div class="umi-card umi-centro"><h4>Quanto hai respirato</h4><small class="umi-range">' + rspDalAl(giorni[0].d, giorni[giorni.length - 1].d) + '</small>'
    +   grafico + (n === 7 ? '<small class="rsps-leg">Minuti di respiro al giorno</small>' : '') + '<div class="umi-boxes">' + boxes + '</div></div>'
    + apnea + tecHtml;
  requestAnimationFrame(function(){ requestAnimationFrame(function(){ host.querySelectorAll('.umi-fill').forEach(function(f){ f.style.height = f.getAttribute('data-h') + '%'; }); }); });
}

/* ---- la scelta ---- */
function rsScegli(k, durata, giri){
  const t = rsTec(k);
  if (rsChiusa(t)){
    try{ flVibra(12); }catch(_){ }
    if (typeof pwUpsellApri === 'function') pwUpsellApri(); else if (typeof go === 'function') go(11);
    return;
  }
  RS.tecnica = t.k;
  if (t.giri){
    /* chi passa ancora la durata in secondi (135 = un giro) ottiene i giri giusti */
    const g = giri || (durata ? (durata <= 5 ? durata : Math.round(durata / 135)) : 0);
    if (g) RS.giri = Math.max(1, Math.min(3, g));
  } else if (durata) RS.durata = durata;
  RS.scopri = false;
  rsMusicaPrepara();
  rsFoglio();
}
function rsFoglioW(){
  let w = document.getElementById('rsFoglio');
  if (!w){ w = document.createElement('div'); w.id = 'rsFoglio'; w.className = 'rsp-foglio-w'; w.addEventListener('click', function(e){ if (e.target === w) rsFoglioChiudi(); }); (document.getElementById('s-respiro') || document.body).appendChild(w); }
  return w;
}
function rsFoglio(){
  const t = rsTec(RS.tecnica);
  const w = rsFoglioW();
  let scelta = '';
  if (t.giri){
    scelta = '<h4>Quanti giri?</h4><div class="rsp-durate">' + [1, 2, 3].map(function(g){ return '<button type="button" class="' + (RS.giri === g ? 'on' : '') + '" onclick="RS.giri=' + g + ';rsFoglio()"><b>' + g + '</b><small>' + (g === 1 ? 'giro' : 'giri') + '</small></button>'; }).join('') + '</div>'
      + '<p class="rsp-nota">Un giro dura circa tre minuti. Tre giri sono il protocollo completo.</p>';
  } else if (t.cicli){
    scelta = '<p class="rsp-nota">Sempre ' + (t.cicli === 4 ? 'quattro' : t.cicli) + ' cicli, non di più: ' + rsTempoVoce(rsGiro(t) * t.cicli) + ' in tutto.</p>';
  } else {
    const durate = t.durate || [[30, '30', 'sec'], [60, '1', 'min'], [120, '2', 'min']];
    if (t.durate && durate.every(function(d){ return d[0] !== RS.durata; })) RS.durata = durate[0][0];
    const mia = !t.durate && durate.every(function(d){ return d[0] !== RS.durata; });
    scelta = '<h4>Scegli la durata</h4><div class="rsp-durate">' + durate.map(function(d){ return '<button type="button" class="' + (RS.durata === d[0] ? 'on' : '') + '" onclick="RS.durata=' + d[0] + ';rsFoglio()"><b>' + d[1] + '</b><small>' + d[2] + '</small></button>'; }).join('')
      + (t.durate ? '' : '<button type="button" class="rsp-piu' + (mia ? ' on' : '') + '" onclick="rsDurataMia()">' + (mia ? '<b>' + Math.round(RS.durata / 60) + '</b><small>min</small>' : '<b>＋</b>') + '</button>') + '</div>';
  }
  /* 0.9.309, Andrea: "troppo testo, non si vede il velo ne' la X, la stessa icona tre volte". Una riga di descrizione,
     il resto dietro a "Scopri di più"; ogni fase con il suo segno e il suo colore, gli stessi della sessione. */
  const fase = function(k, nome, quanto){ return '<div class="rsp-fase f-' + (k === 'in2' ? 'in' : k) + '"><span class="rsp-fase-i">' + RS_FASE_ICO[k] + '</span><small>' + rsEsc(nome) + '</small><b>' + rsEsc(quanto) + '</b></div>'; };
  let primaIn = false;
  const fasi = t.mostra ? t.mostra.map(function(f){ return fase(f[2], f[0], f[1]); })
    : t.fasi.map(function(f){ let k = rsFaseK({ a: f[2] }); if (k === 'in'){ if (primaIn) k = 'in2'; primaIn = true; } else primaIn = false; return fase(k, f[0], f[1] + (f[1] === 1 ? ' secondo' : ' secondi')); });
  const piu = rsEsc(t.s) + (t.avviso ? '<br><br>' + rsEsc(t.avviso) : '');
  w.innerHTML = '<div class="rsp-foglio" role="dialog" aria-label="' + rsEsc(t.t) + '"><button type="button" class="rsp-x" onclick="rsFoglioChiudi()" aria-label="Chiudi">' + RS_X + '</button>'
    + '<span class="rsp-ico grande" style="color:' + t.col + '">' + RS_ICO[t.k] + '</span><h3>' + rsEsc(t.t) + '</h3><p class="rsp-breve">' + rsEsc(t.breve || t.s) + '</p>'
    + '<button type="button" class="rsg-info rsp-scopri" aria-expanded="' + (RS.scopri ? 'true' : 'false') + '" onclick="RS.scopri=!RS.scopri;rsgInfo(this)">'
    +   '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 10.5v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="7.3" r="1.3" fill="currentColor"/></svg>'
    +   '<span>' + (RS.scopri ? 'Mostra meno' : 'Scopri di più') + '</span></button>'
    + '<div class="rsg-perche-w rsp-piu-w"' + (RS.scopri ? '' : ' hidden') + '><p class="rsg-perche">' + piu + '</p></div>'
    + '<div class="rsp-fasi">' + fasi.join('') + '</div>'
    + (t.seduto ? '<p class="rsp-avviso">Si fa solo da seduti o sdraiati</p>' : '')
    + '<i class="rsp-riga"></i>' + scelta
    + '<button type="button" class="cta rsp-via" onclick="rsPrimaDiIniziare()">Inizia la sessione</button></div>';
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
function rsDurataMia(){
  const v = prompt('Quanti minuti? (da 3 a 20)', '5'); if (v === null) return;
  const n = Math.round(+String(v).replace(',', '.') || 0);
  if (n < 3 || n > 20){ toast('Scegli fra 3 e 20 minuti'); return; }
  RS.durata = n * 60; rsFoglio();
}
function rsFoglioChiudi(){ const w = document.getElementById('rsFoglio'); if (w) w.remove(); }

/* ---- l'avviso di sicurezza: prima di ogni esercizio della categoria Performance ---- */
function rsPrimaDiIniziare(){
  const t = rsTec(RS.tecnica);
  rsAudioPronto();
  if (!t.seduto){ rsVia(); return; }
  const w = rsFoglioW();
  w.innerHTML = '<div class="rsp-foglio rsp-attenzione"><span class="rsp-att-ico"><svg viewBox="0 0 24 24" width="34" height="34" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18v.5"/></svg></span>'
    + '<h3>Attenzione</h3><p class="rsp-att-testo">' + RS_AVVISO + '</p>'
    + (t.avviso ? '<p class="rsp-att-piu">' + rsEsc(t.avviso) + '</p>' : '')
    + '<button type="button" class="cta rsp-via" onclick="rsVia()">Confermo, iniziamo</button>'
    + '<button type="button" class="rsp-annulla" onclick="rsFoglio()">Torna indietro</button></div>';
  w.classList.add('in');
  try{ flVibra(20); }catch(_){ }
}

/* ---- i suoni ----
   0.9.308, Andrea: "non c'e' ancora nessun suono per gli esercizi di respirazione anche se il suono e' attivo". Era una
   sinusoide a 330-523 Hz con il picco a 0,12 (il tic dei trenta respiri a 0,04): l'altoparlante di un telefono quella
   zona quasi non la riproduce, e a quel volume era silenzio. Adesso la guida usa gli effetti della libreria (effetti.js:
   il soffio per inspirare ed espirare, il tocco per trattenere, il premio alla fine), con la copia nell'APK se manca la
   rete; il sintetizzato resta solo come ultimo ripiego, piu' alto e un'ottava sopra. Tace se gli effetti sonori
   dell'app sono spenti; la suoneria in silenzioso non lo ferma, perche' l'altoparlante della sessione lo accendi tu. */
function rsSuonoOn(){
  try{ if (localStorage.getItem('fl_respiro_suono') === '0') return false; }catch(_){ }
  try{ if (typeof fxAppAttivi === 'function' && !fxAppAttivi()) return false; }catch(_){ }
  return true;
}
function rsSuonoCambia(){
  const on = !rsSuonoOn();
  try{ localStorage.setItem('fl_respiro_suono', on ? '1' : '0'); }catch(_){ }
  /* chi accende l'altoparlante della sessione vuole sentire: se gli effetti dell'app erano spenti, si riaccendono */
  if (on && typeof fxAppAttivi === 'function' && !fxAppAttivi()){ try{ localStorage.setItem('fl_effetti', '1'); localStorage.setItem('fl_musica_muto', '0'); }catch(_){ } }
  const b = document.getElementById('rsAudioBtn'); if (b){ b.innerHTML = on ? RS_AUDIO_ON : RS_AUDIO_OFF; b.setAttribute('aria-label', on ? 'Spegni i suoni' : 'Accendi i suoni'); }
  if (on){ rsAudioPronto(); rsSuono('tieni'); rsMusicaVia(); if (RS.timer && RS.i >= 0) rsMusicaPrimoRespiro(); }
  else rsMusicaFerma(400, true);
}
function rsAudioPronto(){
  try{
    if (!RS.audio){ const C = window.AudioContext || window.webkitAudioContext; if (C) RS.audio = new C(); }
    if (RS.audio && RS.audio.state === 'suspended') RS.audio.resume();
  }catch(_){ }
}
function rsSuono(tipo){
  if (!tipo || !rsSuonoOn() || document.hidden) return;
  const ev = { in: 'respiro-in', out: 'respiro-out', soffio: 'respiro-soffio', pieno: 'respiro-tieni', vuoto: 'respiro-tieni', tieni: 'respiro-tieni', tic: 'respiro-tic', apnea: 'respiro-apnea', fine: 'respiro-fine' }[tipo] || 'respiro-tieni';
  if (typeof fxSuona === 'function' && fxSuona(ev, { forza: true, ripiego: function(){ rsSuonoSintesi(tipo); } })) return;
  rsSuonoSintesi(tipo);
}
/* 0.9.315, Andrea (come l'app di Wim Hof): ogni minuto una campana. Durante l'apnea i minuti si contano dall'inizio dell'apnea
   (e' il tempo che conta), nel resto dell'esercizio dall'ultimo cambio: mai due orologi insieme. */
function rsCampanaBatti(){
  if (!rsSuonoOn()) return;
  rsAudioPronto();
  if (!RS.audio) return;
  try{ rsCampanaSu(RS.audio, RS.audio.destination, RS.audio.currentTime + 0.01); }catch(_){ }
}
/* una campana vera: parziali non armonici che si spengono a tempi diversi, un attacco secco */
function rsCampanaSu(a, uscita, t0){
  [[1, .34, 4.2], [2, .2, 3.1], [2.74, .15, 2.4], [4.1, .09, 1.6], [5.43, .05, 1]].forEach(function(p){
    const o = a.createOscillator(), g = a.createGain();
    o.type = 'sine'; o.frequency.value = 587.33 * p[0];
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(p[1], t0 + 0.012); g.gain.exponentialRampToValueAtTime(0.0001, t0 + p[2]);
    o.connect(g); g.connect(uscita); o.start(t0); o.stop(t0 + p[2] + 0.05);
  });
}
function rsCampanaControlla(ora, p){
  if (!p || !RS.camp) return;
  if (!!p.apnea !== RS.camp.apnea){ RS.camp = { da: RS.t0, n: 0, apnea: !!p.apnea }; return; }
  const n = Math.floor((ora - RS.camp.da) / 60000);
  if (n <= RS.camp.n) return;
  RS.camp.n = n;
  rsCampanaBatti();
  try{ flVibra([20, 40, 20]); }catch(_){ }
  const m = document.getElementById('rsMinuto');
  if (m){
    m.textContent = n === 1 ? '1 minuto' : n + ' minuti';
    /* 0.9.326, Andrea: "deve notificare in quel momento che e' passato un minuto, non restare li' a distrarlo" */
    m.classList.remove('on'); void m.offsetWidth; m.classList.add('on');
    clearTimeout(rsCampanaControlla._t);
    rsCampanaControlla._t = setTimeout(function(){ try{ m.classList.remove('on'); m.textContent = ''; }catch(_){ } }, 2600);
  }
}
function rsSuonoSintesi(tipo){
  rsAudioPronto();
  if (!RS.audio) return;
  try{
    const a = RS.audio, t0 = a.currentTime + 0.01;
    const g = a.createGain(); g.connect(a.destination);
    if (tipo === 'soffio'){
      /* il «whoosh» del 4-7-8: rumore filtrato che sale e si spegne */
      const n = Math.floor(a.sampleRate * 1.4), buf = a.createBuffer(1, n, a.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
      const src = a.createBufferSource(); src.buffer = buf;
      const f = a.createBiquadFilter(); f.type = 'bandpass'; f.frequency.setValueAtTime(500, t0); f.frequency.linearRampToValueAtTime(1500, t0 + 1.2); f.Q.value = 0.8;
      g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(0.45, t0 + 0.25); g.gain.exponentialRampToValueAtTime(0.0001, t0 + 1.35);
      src.connect(f); f.connect(g); src.start(t0); src.stop(t0 + 1.4);
      return;
    }
    /* un'ottava sopra e tre volte piu' forte di prima: sotto i 500 Hz l'altoparlante del telefono quasi non suona */
    const note = { in: [660, 1046, 0.45, 0.4], out: [1046, 660, 0.45, 0.4], pieno: [880, 880, 0.25, 0.3], vuoto: [588, 588, 0.25, 0.3], tieni: [880, 880, 0.25, 0.3], tic: [1320, 1320, 0.06, 0.2], apnea: [784, 524, 0.7, 0.4], fine: [1046, 1568, 1.1, 0.4] }[tipo] || [880, 880, 0.2, 0.3];
    const o = a.createOscillator(); o.type = 'triangle';
    o.frequency.setValueAtTime(note[0], t0); o.frequency.exponentialRampToValueAtTime(note[1], t0 + note[2]);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(note[3], t0 + 0.04); g.gain.exponentialRampToValueAtTime(0.0001, t0 + note[2] + 0.15);
    o.connect(g); o.start(t0); o.stop(t0 + note[2] + 0.2);
  }catch(_){ }
}

/* ---- la musica di sottofondo (0.9.311) ----
   Andrea: "con il suono attivo c'e' solo il segnale delle fasi, nessuna musica. Come l'app Wim Hof". Sotto ai segnali suona
   una traccia lenta della libreria (pad e note lente, nessuna batteria: server/music/engine.ts), che parte col primo
   respiro e sfuma alla fine. Si scelgono le tracce gia' nella Cache API di effetti.js (senza rete, senza consumare dati),
   altrimenti si ascolta dalla rete e se ne salva una per la prossima volta. Se la traccia non parte (niente rete, nessuna
   copia), o finche' non e' pronta, suona un pad morbido generato qui: dall'inizio del primo respiro la musica c'e' sempre.
   Il tag <audio> e non un buffer: una traccia di cinque minuti decodificata pesa cento MB.
   Le tracce sono a -18,5 LUFS (misurato con ffmpeg): a 0,45 stanno a -25,5, circa cinque dB sotto ai segnali.
   Si spegne con l'altoparlante della sessione, si ferma con l'app in secondo piano e durante una telefonata, e riprende
   al rientro. Gli altri suoni dell'app (la pioggia, una traccia dalla pagina Suoni) tacciono e tornano a fine sessione. */
const RS_MUSICA_VOL = 0.45;
const RS_MUSICA_INGRESSO = 3000;
const RS_MUSICA_TIENI = 3;       /* quante tracce tenere pronte nel telefono per il respiro */
const RSM = { a: null, blob: '', scelta: null, vol: 0, fade: 0, viva: false, muta: false, pad: null, sndPrima: '', branoPrima: '' };
/* gli accordi del pad (note in Hz): caldi, senza tensione. Sopra i 200 Hz, perche' l'altoparlante del telefono li suoni */
const RS_PAD_ACCORDI = [
  [174.61, 261.63, 329.63, 392.0, 523.25],
  [220.0, 261.63, 329.63, 392.0, 440.0],
  [196.0, 293.66, 392.0, 440.0, 493.88],
  [261.63, 329.63, 392.0, 493.88, 587.33]
];
const RS_PAD_PASSO = 11;         /* secondi fra un accordo e il successivo */
const RS_PAD_VOL = 0.7;          /* misurato su file: -25,5 LUFS, come la traccia al volume di RS_MUSICA_VOL */
/** Le tracce adatte, nell'ordine in cui si preferiscono: meditazione, poi rilassamento (per il 4-7-8 prima il sonno) */
function rsMusicaTracce(){
  if (typeof fxItems !== 'function') return [];
  const ordine = RS.tecnica === 'distensione' ? ['sleep', 'meditate', 'relax'] : ['meditate', 'relax'];
  const peso = function(x){ return ordine.indexOf(x.purpose); };
  return fxItems().filter(function(x){ return x && x.kind === 'track' && x.url && peso(x) >= 0 && x.mood !== 'melancholic' && (!x.bpm || x.bpm <= 70); })
    .sort(function(a, b){ return (peso(a) - peso(b)) || (Date.parse(b.publishedAt || 0) - Date.parse(a.publishedAt || 0)); });
}
function rsMusicaBlobVia(){ if (RSM.blob){ try{ URL.revokeObjectURL(RSM.blob); }catch(_){ } RSM.blob = ''; } }
/** Si apre il foglio dell'esercizio: quando si tocca Inizia, la traccia e' gia' pronta. Il tocco deve trovare gia' l'indirizzo. */
async function rsMusicaPrepara(){
  try{
    if (typeof fxCatalogo === 'function') await fxCatalogo(false);
    const l = rsMusicaTracce(); if (!l.length) return;
    RSM.scelta = l[0];
    if (typeof caches === 'undefined') return;
    const c = await caches.open(FX_CACHE);
    const pronte = [];
    for (const x of l){ if (await c.match(x.url)) pronte.push(x); }
    let ultima = ''; try{ ultima = localStorage.getItem('fl_respiro_brano') || ''; }catch(_){ }
    const x = pronte.filter(function(t){ return t.id !== ultima; })[0] || pronte[0];
    if (x && !RSM.a){
      const hit = await c.match(x.url);
      if (hit){ const blob = await hit.blob(); if (!RSM.a){ rsMusicaBlobVia(); RSM.blob = URL.createObjectURL(blob); RSM.scelta = x; } }
    }
    /* una traccia nuova alla volta, finche' non ce ne sono abbastanza; mai con il risparmio dati */
    let risparmio = false; try{ risparmio = !!(navigator.connection && navigator.connection.saveData); }catch(_){ }
    if (pronte.length < RS_MUSICA_TIENI && !risparmio){
      const nuova = l.filter(function(t){ return pronte.indexOf(t) < 0; })[0];
      if (nuova) fetch(nuova.url).then(function(r){ if (r.ok) return c.put(nuova.url, r); }).catch(function(){ });
    }
  }catch(_){ }
}
function rsMusicaAltriFerma(){
  try{ if (typeof FX !== 'undefined' && FX.branoId){ RSM.branoPrima = FX.branoId; fxBranoFerma(); } }catch(_){ }
  try{ if (typeof SND !== 'undefined' && SND.id !== 'none' && SND.playing){ RSM.sndPrima = SND.id; sndStop(); SND.id = 'none'; SND.playing = false; } }catch(_){ }
}
function rsMusicaAltriRiprendi(){
  const snd = RSM.sndPrima, br = RSM.branoPrima; RSM.sndPrima = ''; RSM.branoPrima = '';
  try{ if (snd && typeof sndPlay === 'function') sndPlay(snd); else if (br && typeof fxBrano === 'function') fxBrano(br); }catch(_){ }
}
/** Dentro al tocco su Inizia: il telefono fa partire un <audio> solo se il play nasce da un gesto. A volume zero fino al primo respiro. */
function rsMusicaVia(){
  if (!rsSuonoOn() || RSM.a) return;
  rsMusicaAltriFerma();
  const x = RSM.scelta || rsMusicaTracce()[0];
  const src = RSM.blob || (x && x.url) || '';
  if (!src) return;
  const a = new Audio();
  a.loop = true; a.preload = 'auto'; a.volume = 0; a.src = src;
  RSM.a = a; RSM.vol = 0;
  /* la traccia arriva a sessione gia' iniziata (rete lenta): prende il posto del pad */
  a.addEventListener('playing', function(){ if (RSM.a === a && RSM.viva && !RSM.muta){ rsPadFerma(RS_MUSICA_INGRESSO); rsMusicaVerso(RS_MUSICA_VOL, RS_MUSICA_INGRESSO); } });
  const persa = function(){ if (RSM.a !== a) return; RSM.a = null; try{ a.pause(); a.removeAttribute('src'); a.load(); }catch(_){ } if (RSM.viva && !RSM.muta) rsPadVia(); };
  a.addEventListener('error', persa);
  const pl = a.play();
  if (pl && pl.catch) pl.catch(function(e){ if (!e || e.name !== 'AbortError') persa(); });
  if (x){ try{ localStorage.setItem('fl_respiro_brano', x.id); }catch(_){ } }
}
function rsMusicaPrimoRespiro(){
  if (!rsSuonoOn()) return;
  RSM.viva = true; RSM.muta = false;
  const a = RSM.a;
  /* gia' in cache o gia' arrivata: entra piano. Altrimenti il pad, finche' non e' pronta */
  if (a && !a.paused && a.readyState >= 3) rsMusicaVerso(RS_MUSICA_VOL, RS_MUSICA_INGRESSO);
  else rsPadVia();
}
/** Il volume del tag si muove a mano: nell'<audio> non ci sono rampe. Con l'app in secondo piano i timer dormono: li' si ferma e basta. */
function rsMusicaVerso(vol, ms, poi){
  clearInterval(RSM.fade);
  const a = RSM.a;
  if (!a){ if (poi) poi(); return; }
  const da = a.volume, t0 = performance.now();
  RSM.fade = setInterval(function(){
    const k = Math.min(1, (performance.now() - t0) / Math.max(1, ms));
    try{ a.volume = Math.max(0, Math.min(1, da + (vol - da) * k)); }catch(_){ }
    if (k >= 1){ clearInterval(RSM.fade); RSM.fade = 0; if (poi) poi(); }
  }, 50);
}
/** Spegne tutto, sfumando in ms. Da altoparlante (tieniAltri) la pioggia non torna: la sessione non e' finita. */
function rsMusicaFerma(ms, tieniAltri){
  RSM.viva = false; RSM.muta = false;
  const a = RSM.a; RSM.a = null;
  rsPadFerma(ms);
  /* a fine sessione la copia della traccia si butta (il foglio dopo ne prepara un'altra), dall'altoparlante si tiene */
  const blob = tieniAltri ? '' : RSM.blob;
  if (!tieniAltri){ RSM.blob = ''; RSM.scelta = null; }
  const chiudi = function(){
    RSM.uscente = null;
    if (a){ try{ a.pause(); a.removeAttribute('src'); a.load(); }catch(_){ } }
    if (blob){ try{ URL.revokeObjectURL(blob); }catch(_){ } }
    if (!tieniAltri) rsMusicaAltriRiprendi();
  };
  clearInterval(RSM.fade); RSM.fade = 0;
  if (!a || !ms || document.hidden){ chiudi(); return; }
  RSM.uscente = chiudi;
  const da = a.volume, t0 = performance.now();
  const iv = setInterval(function(){
    const k = Math.min(1, (performance.now() - t0) / ms);
    try{ a.volume = Math.max(0, da * (1 - k)); }catch(_){ }
    if (k >= 1 || !RSM.uscente){ clearInterval(iv); if (RSM.uscente) chiudi(); }
  }, 50);
}
/** Con l'app dietro o durante una telefonata tace, e riprende appena si puo': la chiama il giro della sessione e il cambio di visibilita'. */
function rsMusicaVeglia(){
  if (!RSM.viva) return;
  let telefonata = false; try{ telefonata = !!(typeof FX !== 'undefined' && FX.chiamata); }catch(_){ }
  const deveTacere = document.hidden || telefonata;
  if (deveTacere === RSM.muta) return;
  RSM.muta = deveTacere;
  const a = RSM.a;
  if (deveTacere){
    clearInterval(RSM.fade); RSM.fade = 0;
    if (a){ try{ a.pause(); }catch(_){ } }
    if (RSM.pad){ try{ RS.audio.suspend(); }catch(_){ } }
    return;
  }
  if (RSM.pad){ try{ RS.audio.resume(); }catch(_){ } }
  if (a){
    try{ a.volume = 0; const pl = a.play(); if (pl && pl.catch) pl.catch(function(){ }); }catch(_){ }
    rsMusicaVerso(RS_MUSICA_VOL, 1500);
  }
}
/* il pad di ripiego: un accordo ogni RS_PAD_PASSO secondi, che entra ed esce piano e si sovrappone al successivo */
function rsPadAccordo(ctx, uscita, t, note){
  const d = RS_PAD_PASSO * 2 + 2;
  note.forEach(function(f, i){
    const g = ctx.createGain();
    const liv = 0.052 - i * 0.004;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(liv, t + RS_PAD_PASSO * 0.9);
    g.gain.setValueAtTime(liv, t + RS_PAD_PASSO * 1.1);
    g.gain.linearRampToValueAtTime(0, t + d);
    g.connect(uscita);
    [[-5, 'triangle'], [5, 'sine']].forEach(function(v){
      const o = ctx.createOscillator(); o.type = v[1]; o.frequency.value = f; o.detune.value = v[0];
      o.connect(g); o.start(t); o.stop(t + d + 0.1);
    });
  });
}
/** Filtro morbido, una coda d'eco che fa da stanza, il volume generale. Vale anche per il contesto offline della prova. */
function rsPadCatena(ctx, dest, liv){
  const master = ctx.createGain(); master.gain.value = liv; master.connect(dest);
  const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 1500; lp.Q.value = 0.3;
  lp.connect(master);
  const dl = ctx.createDelay(1.5); dl.delayTime.value = 0.61;
  const fb = ctx.createGain(); fb.gain.value = 0.38;
  lp.connect(dl); dl.connect(fb); fb.connect(lp);
  return { master: master, ingresso: lp };
}
function rsPadVia(){
  if (RSM.pad) return;
  rsAudioPronto();
  const ctx = RS.audio; if (!ctx) return;
  try{
    const c = rsPadCatena(ctx, ctx.destination, 0);
    const t0 = ctx.currentTime + 0.05;
    c.master.gain.setValueAtTime(0, t0);
    c.master.gain.linearRampToValueAtTime(RS_PAD_VOL, t0 + 2);
    const pad = { c: c, n: 0, prossimo: t0, iv: 0 };
    const semina = function(){
      if (RSM.pad !== pad) return;
      /* si programma in anticipo: con il telefono occupato i timer ritardano, le note no */
      while (pad.prossimo < ctx.currentTime + RS_PAD_PASSO){
        rsPadAccordo(ctx, c.ingresso, pad.prossimo, RS_PAD_ACCORDI[pad.n % RS_PAD_ACCORDI.length]);
        pad.n++; pad.prossimo += RS_PAD_PASSO;
      }
    };
    RSM.pad = pad;
    semina();
    pad.iv = setInterval(semina, 2000);
  }catch(_){ RSM.pad = null; }
}
function rsPadFerma(ms){
  const pad = RSM.pad; if (!pad) return;
  RSM.pad = null;
  clearInterval(pad.iv);
  const ctx = RS.audio;
  try{
    if (ctx.state === 'suspended') ctx.resume();
    const g = pad.c.master.gain, t = ctx.currentTime, d = Math.max(0.05, (ms || 0) / 1000);
    g.cancelScheduledValues(t); g.setValueAtTime(g.value, t); g.linearRampToValueAtTime(0, t + d);
    setTimeout(function(){ try{ pad.c.master.disconnect(); }catch(_){ } }, d * 1000 + 100);
  }catch(_){ }
}
/* La chiamata dei sogni non squilla sopra all'esercizio (DreamCall.java). Il telefono riceve "sessione in corso" e il
   rinnovo ogni minuto: se la pagina muore, dopo tre minuti l'avviso scade da solo. Con l'app dietro si toglie subito. */
const RS_SESSIONE_MS = 180000;
function rsChiamateFerme(on){
  RS.vivo = on ? Date.now() : 0;
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.dcSessione){ const r = NATIVE.dcSessione({ on: !!on, ms: RS_SESSIONE_MS }); if (r && r.catch) r.catch(function(){ }); } }catch(_){ }
}
document.addEventListener('visibilitychange', function(){
  /* stava sfumando e l'app va dietro: i timer dormono, si chiude subito */
  if (document.hidden && RSM.uscente) RSM.uscente();
  if (!RS.timer) return;
  rsMusicaVeglia();
  rsChiamateFerme(!document.hidden);
});

/* ---- il motore a passi ---- */
function rsGiro(t){ return (t.fasi || []).reduce(function(a, f){ return a + f[1]; }, 0); }
/** La sessione in passi: { f: parola, s: secondi (null = apnea a cronometro), a: animazione, suono, conta, giro } */
function rsPassi(t){
  const p = [];
  if (t.giri){
    for (let g = 1; g <= RS.giri; g++){
      for (let b = 1; b <= 30; b++){
        p.push({ f: 'Inspira a fondo', s: 1.5, a: 'in', suono: 'tic', conta: b, giro: g });
        p.push({ f: 'Espira', s: 1.5, a: 'out', suono: '', conta: b, giro: g });
      }
      p.push({ f: 'Fuori l’aria: resta senza respirare', s: null, a: 'vuoto', suono: 'apnea', giro: g, apnea: true });
      /* 0.9.309: "Inspira a fondo e trattieni" era un passo solo di 15 secondi con l'anello che si riempiva come
         un'inspirazione: adesso sono due fasi vere, inspira (3 s) e trattieni (15 s, tutto fermo) */
      p.push({ f: 'Inspira a fondo', s: 3, a: 'in', suono: 'in', giro: g });
      p.push({ f: 'Trattieni', s: 15, a: 'pieno', suono: 'pieno', giro: g });
      p.push({ f: g < RS.giri ? 'Espira: butta fuori l’aria' : 'Espira e torna a respirare normalmente', s: 4, a: 'out', suono: 'out', giro: g });
    }
    return rsSegmenti(p);
  }
  const giro = rsGiro(t);
  const cicli = t.cicli || Math.max(1, Math.round(RS.durata / giro));
  for (let c = 1; c <= cicli; c++) t.fasi.forEach(function(f){ p.push({ f: f[0], s: f[1], a: f[2] || 'in', suono: f[3] || f[2] || 'tieni', ciclo: c, cicli: cicli }); });
  return rsSegmenti(p);
}
/** Le fasi uguali di fila (le due inspirazioni del sospiro ciclico) sono un'unica corsa dell'anello:
    fk = in|tieni|out, segPrima = secondi gia' fatti nella corsa, segTot = secondi della corsa, segPos = 0 per il primo */
function rsSegmenti(p){
  let g = [];
  const chiudi = function(){
    const tot = g.reduce(function(a, x){ return a + (x.s || 0); }, 0);
    /* 0.9.311: le tacche sull'anello, dove finisce un'inspirazione e comincia la successiva (frazioni del giro) */
    const tacche = (g.length > 1 && g[0].fk === 'in') ? g.slice(1).map(function(x){ return x.segPrima / tot; }) : null;
    g.forEach(function(x){ x.segTot = tot; x.segTacche = tacche; });
    g = [];
  };
  p.forEach(function(x){
    x.fk = rsFaseK(x);
    const prev = g[g.length - 1];
    if (prev && prev.fk === x.fk && x.fk !== 'tieni' && x.s && prev.s && !x.conta){ x.segPrima = prev.segPrima + prev.s; x.segPos = g.length; g.push(x); }
    else { chiudi(); x.segPrima = 0; x.segPos = 0; g.push(x); }
  });
  chiudi();
  return p;
}
/* 0.9.311, Andrea (761.jpg): nel sospiro ciclico "Inspira dal naso" e "Inspira ancora" corrono sullo stesso anello e niente
   le separa. La tacca segna il punto dove finisce la prima (2 secondi su 3: a due terzi del giro) e resta finche'
   durano le inspirazioni. L'anello e' ruotato di -90 gradi: nel disegno l'angolo zero e' il punto di partenza, in alto. */
function rsTaccheDisegna(p){
  const g = document.getElementById('rsTacche'); if (!g) return;
  const l = (p && p.segTacche) || [];
  const k = l.join(',');
  if (g.getAttribute('data-k') === k) return;
  g.setAttribute('data-k', k);
  g.innerHTML = l.map(function(f){
    const a = 2 * Math.PI * f, c = Math.cos(a), s = Math.sin(a), r0 = 127, r1 = 153;
    const xy = 'x1="' + (150 + r0 * c).toFixed(1) + '" y1="' + (150 + r0 * s).toFixed(1) + '" x2="' + (150 + r1 * c).toFixed(1) + '" y2="' + (150 + r1 * s).toFixed(1) + '"';
    return '<line class="rsp-tacca-a" ' + xy + '/><line class="rsp-tacca" ' + xy + '/>';
  }).join('');
}
function rsVia(){
  rsFoglioChiudi();
  rsAudioPronto();
  rsMusicaVia();
  const t = rsTec(RS.tecnica);
  let s = document.getElementById('rsSessione');
  if (!s){ s = document.createElement('div'); s.id = 'rsSessione'; s.className = 'rsp-sess'; document.body.appendChild(s); }
  const C = 2 * Math.PI * 140;
  s.innerHTML = '<div class="rsp-sess-top"><span id="rsResta"></span><div><button type="button" id="rsAudioBtn" class="rsp-audio" onclick="rsSuonoCambia()" aria-label="' + (rsSuonoOn() ? 'Spegni i suoni' : 'Accendi i suoni') + '">' + (rsSuonoOn() ? RS_AUDIO_ON : RS_AUDIO_OFF) + '</button><button type="button" onclick="rsFine(false)">Termina</button></div></div>'
    + '<div class="rsp-anello-w"><svg class="rsp-anello" viewBox="0 0 300 300"><circle cx="150" cy="150" r="140" class="rsp-anello-bg"/><circle cx="150" cy="150" r="140" id="rsAnello" class="rsp-anello-on" style="stroke-dasharray:' + C.toFixed(1) + ';stroke-dashoffset:' + C.toFixed(1) + '"/><g id="rsTacche"></g></svg>' + rsFiore('respira') + '</div>'
    + '<div class="rsp-minuto" id="rsMinuto"></div><div class="rsp-sess-fase"><b id="rsFase">Pronti</b><span id="rsSec"></span><small id="rsConta"></small></div>'
    + '<button type="button" class="rsp-respiro-ora" id="rsApneaBtn" onclick="rsApneaStop()" hidden>Devo respirare</button>';
  s.hidden = false;
  RS.passi = rsPassi(t); RS.i = -1; RS.apnee = [];
  RS.inizio = Date.now(); RS.t0 = Date.now() + 1500; RS.camp = { da: RS.t0, n: 0, apnea: false };
  clearInterval(RS.timer); RS.timer = setInterval(rsTick, 100);
  try{ flSchermoAcceso('respiro', true); }catch(_){ }
  rsChiamateFerme(true);
}
function rsPassa(ora){
  RS.i++;
  const p = RS.passi[RS.i]; if (!p) return;
  RS.t0 = ora;
  rsTaccheDisegna(p);
  if (RS.i === 0) rsMusicaPrimoRespiro();
  /* 0.9.309: la fase decide il segno visivo (vedi RS_FASE_COL): data-fase sulla sessione colora anello, fiore e parola */
  const ses = document.getElementById('rsSessione');
  if (ses){ ses.setAttribute('data-fase', p.fk); ses.setAttribute('data-polmoni', p.a === 'vuoto' ? 'vuoti' : 'pieni'); }
  const fi = document.querySelector('#rsSessione .rsp-fiore');
  if (fi){
    /* trattieni: il fiore resta com'e' (niente transizione, niente giro dei petali) */
    if (p.fk !== 'tieni') fi.style.transitionDuration = (p.s || 1.2) + 's';
    if (p.fk === 'in'){ fi.classList.add('aperto'); fi.classList.toggle('piu', p.segPos > 0); }
    else if (p.fk === 'out') fi.classList.remove('aperto', 'piu');
  }
  const ab = document.getElementById('rsApneaBtn'); if (ab) ab.hidden = !p.apnea;
  rsSuono(p.suono);
  /* nei trenta respiri veloci la vibrazione ad ogni respiro e' troppa: vibra al primo e ai cambi veri */
  try{ if (!p.conta || (p.conta === 1 && p.a === 'in')) flVibra(p.apnea ? [30, 60, 30] : (p.a === 'pieno' || p.a === 'vuoto' ? 8 : 16)); }catch(_){ }
}
function rsApneaStop(){
  const p = RS.passi[RS.i]; if (!p || !p.apnea) return;
  const sec = Math.round((Date.now() - RS.t0) / 100) / 10;
  RS.apnee.push(Math.round(sec));
  rsPassa(Date.now());
}
function rsTick(){
  const t = rsTec(RS.tecnica);
  const ora = Date.now();
  const fe = document.getElementById('rsFase'), se = document.getElementById('rsSec'), ce = document.getElementById('rsConta'), re = document.getElementById('rsResta');
  /* la sessione e' sparita senza passare da rsFine (la pagina ridisegnata): musica e chiamate non restano appese */
  if (!fe){ clearInterval(RS.timer); RS.timer = 0; rsMusicaFerma(300); rsChiamateFerme(false); return; }
  rsMusicaVeglia();
  if (ora - (RS.vivo || 0) >= 60000 && !document.hidden) rsChiamateFerme(true);
  if (ora < RS.t0 && RS.i < 0){ fe.textContent = 'Pronti'; if (se) se.textContent = ''; return; }
  if (RS.i < 0) rsPassa(RS.t0);
  let p = RS.passi[RS.i];
  /* un passo a tempo che e' finito lascia il posto al successivo (anche piu' d'uno, se il telefono ha dormito) */
  while (p && p.s && ora - RS.t0 >= p.s * 1000){ const fineP = RS.t0 + p.s * 1000; rsPassa(fineP); p = RS.passi[RS.i]; }
  if (!p){ rsFine(true); return; }
  rsCampanaControlla(ora, p);
  const fatto = (ora - RS.t0) / 1000;
  const an = document.getElementById('rsAnello');
  const C = 2 * Math.PI * 140;
  if (p.apnea){
    if (fatto >= RS_APNEA_MAX){ RS.apnee.push(RS_APNEA_MAX); rsPassa(ora); toast('Tre minuti: adesso respira'); return; }
    fe.textContent = 'Aria fuori: resta così';
    se.textContent = rsMmss(fatto);
    /* l'apnea e' una fase ferma: l'anello resta vuoto e pulsa piano, sale solo il cronometro */
    if (an) an.style.strokeDashoffset = C.toFixed(1);
  } else {
    fe.textContent = p.f;
    se.textContent = p.conta ? String(p.conta) : String(Math.max(1, Math.ceil(p.s - fatto)));
    if (an){
      /* inspira: l'anello si riempie (anche attraverso due inspirazioni di fila); espira: si svuota;
         trattieni: fermo, pieno a polmoni pieni e vuoto a polmoni vuoti */
      const pr = Math.min(1, ((p.segPrima || 0) + fatto) / (p.segTot || p.s));
      const pieno = p.fk === 'in' ? pr : (p.fk === 'out' ? 1 - pr : (p.a === 'vuoto' ? 0 : 1));
      an.style.strokeDashoffset = (C * (1 - pieno)).toFixed(1);
    }
  }
  /* 0.9.348, Andrea: "Giro 2 di 2 c'e' gia' in alto a sinistra: sotto al tempo e' una ripetizione, e va pure a capo. E 'Il primo traguardo
     e' un minuto' sconcentra: al massimo qualche secondo e poi sparisce". Sotto al tempo restano solo il conto dei respiri e, per pochi
     secondi, le frasi dell'apnea; il giro sta solo in alto */
  if (ce) ce.textContent = p.giro ? (p.conta ? 'Respiro ' + p.conta + ' di 30' : (p.apnea ? (fatto < 4 ? 'Il primo traguardo è un minuto' : (fatto >= 60 && fatto < 65 ? 'Oltre il minuto: fermati quando vuoi' : '')) : '')) + (t.giri ? '' : ' · Giro ' + p.giro + ' di ' + RS.giri)
    : (p.cicli ? 'Ciclo ' + p.ciclo + ' di ' + p.cicli : '');
  if (re){
    if (t.giri) re.textContent = 'Giro ' + p.giro + ' di ' + RS.giri;
    else { let resta = p.s - fatto; for (let k = RS.i + 1; k < RS.passi.length; k++) resta += RS.passi[k].s || 0; re.textContent = rsMmss(resta); }
  }
}
function rsFine(finita){
  clearInterval(RS.timer); RS.timer = 0;
  rsMusicaFerma(finita ? 3500 : 900);
  rsChiamateFerme(false);
  try{ flSchermoAcceso('respiro', false); }catch(_){ }
  const s = document.getElementById('rsSessione'); if (!s) return;
  if (!finita){
    /* anche chi si ferma prima ha respirato: conta, se e' durata almeno un minuto o ci sono apnee */
    if (RS.apnee.length || Date.now() - RS.inizio >= 61000){ rsSalva(); if (RS.salita && typeof fcSalitaApri === 'function'){ const x = RS.salita; RS.salita = null; s.remove(); rsPaint(); fcSalitaApri(x.da, x.a, 'Il respiro ha ricaricato il carburante', 'Anche una sessione interrotta conta, per i minuti che hai fatto.'); return; } }
    s.remove(); rsPaint(); return;
  }
  const t = rsTec(RS.tecnica);
  const salvato = rsSalva(), sec = salvato.sec;
  rsSuono('fine');
  try{ flVibra([20, 40, 60]); }catch(_){ }
  /* 0.9.309, Andrea: "troppo testo insieme" (durata, carburante in un box, tre frasi di consiglio). Adesso una cosa
     per volta, come le slide del report settimanale (settimana.js: stesse barre in alto .wk-prog, stessa entrata .wk-uno,
     stesso "Tocca per continuare" .wk-tap): 1) Fatto e la durata, 2) solo nel respiro che sveglia, le apnee, 3) il
     consiglio per dopo e Continua. Il carburante non sta qui: lo mostra subito dopo la lancetta che sale (fcSalitaApri). */
  const nome = rsEsc(t.t.toLowerCase().replace(/^il |^la /, ''));
  const giriTxt = RS.giri === 1 ? 'Un giro' : (RS.giri === 2 ? 'Due giri' : 'Tre giri');
  const sl = [];
  sl.push(rsFiore('fermo') + '<h2>Fatto</h2><p class="rsp-fine-dur">' + (t.giri ? giriTxt + ' del respiro che sveglia, in ' + rsTempoVoce(sec) + '.' : rsTempoVoce(sec) + ' di ' + nome + '.') + '</p>');
  if (t.giri && RS.apnee.length){
    const l = rsStorico();
    const tutte = l.reduce(function(a, x){ return a.concat(x.apnee || []); }, []);
    const record = Math.max.apply(null, tutte);
    const oggi = Math.max.apply(null, RS.apnee);
    sl.push('<h3>Le tue apnee a polmoni vuoti</h3>'
      + '<div class="rsp-fine-apnee">' + RS.apnee.map(function(a, i){ return '<div' + (a === oggi ? ' class="top"' : '') + '><b>' + rsMmss(a) + '</b><small>Giro ' + (i + 1) + '</small></div>'; }).join('') + '</div>'
      + '<p>' + (tutte.length <= RS.apnee.length ? 'È la tua prima misura: da qui si parte.' : (oggi >= record ? '🏆 È la più lunga di sempre.' : 'La più lunga di sempre resta ' + rsTempoVoce(record) + '.')) + '</p>');
  }
  sl.push('<span class="rsp-fine-ico" style="color:' + t.col + '">' + RS_ICO[t.k] + '</span><p class="rsp-fine-dopo">' + rsEsc(t.dopo) + '</p>');
  RS.fine = { sl: sl, i: 0 };
  s.innerHTML = '<div class="rsp-fine"><div class="rsp-fine-top"><div class="wk-prog" id="rsFineProg"></div></div><div class="rsp-fine-body" id="rsFineBody"></div></div>';
  rsFineTocchi(s.firstChild);
  rsFineVai(0);
}
/** Una slide della fine sessione: i pezzi entrano uno dopo l'altro; sull'ultima c'e' Continua */
function rsFineVai(i){
  const F = RS.fine; if (!F) return;
  if (i < 0) return;
  if (i >= F.sl.length) return;
  F.i = i;
  const ult = i === F.sl.length - 1;
  const pr = document.getElementById('rsFineProg');
  if (pr) pr.innerHTML = F.sl.map(function(_, k){ return '<i class="' + (k <= i ? 'on' : '') + '"></i>'; }).join('');
  const b = document.getElementById('rsFineBody'); if (!b) return;
  b.innerHTML = '<div class="rsp-fatto">' + F.sl[i] + '</div>'
    + (ult ? '<button type="button" class="cta rsp-via rsp-fine-cta" onclick="rsDopo()">' + (RS.dopo ? 'Torna alla tappa' : 'Continua') + '</button>'
           : '<button type="button" class="wk-tap rsp-fine-tap" onclick="rsFineVai(RS.fine.i + 1)">Tocca per continuare</button>');
  let k = 0;
  Array.prototype.forEach.call(b.querySelectorAll('.rsp-fatto > *'), function(el){ el.style.setProperty('--i', String(k++)); el.classList.add('wk-uno'); });
  const c = b.querySelector('.rsp-fine-cta'); if (c){ c.style.setProperty('--i', String(k)); c.classList.add('wk-uno'); }
}
/* come nel report: un tocco sul terzo sinistro torna indietro, altrove va avanti; i pulsanti restano pulsanti */
function rsFineTocchi(box){
  if (!box) return;
  box.addEventListener('click', function(e){
    if (e.target && e.target.closest && e.target.closest('button')) return;
    const F = RS.fine; if (!F) return;
    const r = box.getBoundingClientRect();
    rsFineVai(F.i + ((e.clientX - r.left) < r.width / 3 ? -1 : 1));
  });
}
function rsSalva(){
  const sec = Math.max(1, Math.round((Date.now() - RS.inizio) / 1000));
  const t = rsTec(RS.tecnica);
  const c = rsCarburante(sec);
  const v = { k: RS.tecnica, sec: sec, at: Date.now() };
  if (RS.apnee.length) v.apnee = RS.apnee.slice();
  if (c.dato) v.carb = c.dato;
  try{ const l = rsStorico(); l.push(v); localStorage.setItem('fl_respiro', JSON.stringify(l.slice(-200))); }catch(_){ }
  RS.salita = null;
  if (c.dato && typeof fcAggiungi === 'function'){ fcAggiungi(c.dato, 'Respiro guidato: ' + t.t.toLowerCase(), rsTempoVoce(sec)); try{ if (FC_ULTIMA.at && Date.now() - FC_ULTIMA.at < 3000) RS.salita = { da: FC_ULTIMA.da, a: FC_ULTIMA.a }; }catch(_){ } }
  return { sec: sec, carb: c.dato, tetto: c.tetto };
}
/** Il carburante di una sessione: mezzo punto a minuto (almeno uno), dentro al tetto del giorno. */
function rsCarburante(sec){
  const premio = Math.max(1, Math.round(Math.round(sec / 60) / 2));
  const d0 = new Date(); d0.setHours(0, 0, 0, 0);
  const gia = rsStorico().filter(function(x){ return x.at >= d0.getTime(); }).reduce(function(a, x){ return a + (x.carb || 0); }, 0);
  const dato = Math.max(0, Math.min(premio, RS_CARB_MAX_GIORNO - gia));
  return { dato: dato, tetto: !dato };
}
function rsDopo(){
  /* 0.9.224: prima la lancetta del carburante che sale, poi si va avanti */
  if (RS.salita && typeof fcSalitaApri === 'function'){ const x = RS.salita; RS.salita = null; fcSalitaApri(x.da, x.a, 'Il respiro ha ricaricato il carburante', 'Il respiro lento abbassa l’allarme del corpo: la riserva di dopamina si ricarica invece di consumarsi.', rsDopo); return; }
  const s = document.getElementById('rsSessione'); if (s) s.remove();
  RS.fine = null;
  const f = RS.dopo; RS.dopo = null;
  if (f){ goId('s-home'); try{ f(true); }catch(_){ } return; }
  /* si torna alla pagina dei respiri, con le statistiche aggiornate */
  goId('s-respiro'); rsPaint();
}

/* ===========================================================================================
   IL GENIO CONSIGLIA IL RESPIRO: cosa vuoi ottenere, quanto tempo hai, dove sei, e l'ora.
   Le regole vengono dalle lezioni «Il respiro per la performance»: mai iperventilare in piedi,
   mai respiri che svegliano la sera, a stomaco pieno meglio la carica breve.
   =========================================================================================== */
const RSC = { obiettivo: '', tempo: 0, dove: '' };
const RSC_OBIETTIVI = [['focus', '🎯', 'Concentrarmi'], ['calma', '🌊', 'Calmarmi'], ['energia', '⚡', 'Svegliarmi'], ['sonno', '🌙', 'Dormire']];
const RSC_TEMPI = [[2, '⏱️', 'Uno o due minuti'], [5, '🕔', 'Cinque minuti'], [10, '🕙', 'Dieci minuti']];
const RSC_DOVE = [['casa', '🛋️', 'Sul divano o a letto'], ['scrivania', '💻', 'Alla scrivania'], ['piedi', '🚶', 'In piedi o fuori casa']];
function rscFascia(h){ if (h == null) h = new Date().getHours(); return h >= 5 && h < 12 ? 'mattina' : (h < 18 && h >= 12 ? 'giorno' : (h >= 18 && h < 22 ? 'sera' : 'notte')); }
/** Il consiglio: { k, durata, giri, perche, nota } oppure { k: '', perche } se in quel posto non c'e' un respiro adatto */
function rsConsiglia(obiettivo, tempo, dove, ora){
  const h = (ora == null) ? new Date().getHours() : ora;
  const fascia = rscFascia(h);
  const tardi = fascia === 'sera' || fascia === 'notte';
  const piedi = dove === 'piedi';
  const pranzo = h >= 13 && h < 16;
  if (obiettivo === 'sonno'){
    if (piedi) return { k: 'sospiro', durata: 60, perche: 'In piedi trattenere il fiato può farti girare la testa: il sospiro ciclico si fa anche camminando.' };
    if (tempo >= 5) return { k: 'sospiro', durata: 300, perche: 'In uno studio di Stanford del 2023 è stato il respiro che ha migliorato di più l’umore e abbassato di più l’agitazione.' };
    return { k: 'distensione', perche: 'L’espirazione lunga dalla bocca rallenta il battito e prepara il corpo a dormire.' };
  }
  if (obiettivo === 'calma'){
    if (tempo <= 2 || piedi) return { k: 'sospiro', durata: 60, perche: 'È il modo più rapido di abbassare l’agitazione, anche in piedi: in un minuto si sente.' };
    if (tempo >= 10) return { k: 'rilassamento', durata: 600, perche: 'Con l’espirazione più lunga dell’inspirazione il battito rallenta e il corpo esce dalla modalità di allarme.' };
    return { k: 'sospiro', durata: 300, perche: 'In uno studio di Stanford del 2023 è stato il respiro che ha abbassato di più l’agitazione.' };
  }
  if (obiettivo === 'focus'){
    if (piedi || tempo <= 2) return { k: 'sospiro', durata: 60, perche: piedi ? 'Il respiro quadrato si fa da seduti: in piedi, il sospiro ciclico calma l’agitazione che ti disperde la testa.' : 'In due minuti il respiro quadrato non fa in tempo: il sospiro ciclico calma la testa in un minuto.', nota: piedi ? 'Quando ti siedi, prova cinque minuti di respiro quadrato.' : '' };
    return { k: 'concentrazione', durata: tempo >= 10 ? 600 : 300, perche: 'Quattro secondi per ogni fase tengono la testa ferma e lucida: lo usano i Navy SEAL prima dei momenti difficili.' };
  }
  /* energia */
  if (piedi) return { k: '', perche: 'In piedi i respiri che svegliano possono farti svenire. Siediti e torna qui, oppure fai cinque minuti di camminata veloce alla luce del giorno: sveglia il corpo senza rischi.', siediti: true };
  if (tardi && tempo <= 2) return { k: 'sospiro', durata: 60, perche: 'A quest’ora un respiro che sveglia ti ruberebbe il sonno: il sospiro ciclico scarica la giornata senza toccarlo.', nota: 'Se hai cinque minuti, il respiro quadrato ti tiene lucido senza accendere l’allarme.' };
  if (tardi) return { k: 'concentrazione', durata: 300, perche: 'A quest’ora un respiro che sveglia ti ruberebbe il sonno: il respiro quadrato ti tiene lucido senza agitarti.' };
  if (tempo <= 2) return { k: 'motivazione', durata: 120, perche: 'Quattro secondi dentro e due fuori: il corpo si sveglia in due minuti.' };
  if (pranzo) return { k: 'motivazione', durata: 180, perche: 'Con il pranzo nello stomaco i respiri profondi danno fastidio: la carica breve sveglia lo stesso.', nota: 'Il momento migliore per il respiro che sveglia è prima di pranzo, verso le dodici e mezza.' };
  return { k: 'attivante', giri: tempo >= 10 ? 3 : 2, perche: 'Il picco di adrenalina accende corpo e testa per il lavoro più difficile, e da seduti è sicuro.', nota: fascia === 'mattina' ? 'Se non hai ancora mangiato, dopo bevi un bicchiere d’acqua e mangia qualcosa entro un paio d’ore.' : '' };
}
/* IL GENIO CONSIGLIA, UNA DOMANDA ALLA VOLTA (0.9.221). Nella 0.9.220 le tre domande stavano
   insieme in un foglio: Andrea, «se gliele poni tutte e tre insieme lo mandi in tilt, sembra che
   nessuna sia importante». Adesso e' la scena del Genio di sempre (s-genio: il cielo scuro, la
   nuvoletta, il pannello bianco con le carte): cosa vuoi ottenere, poi quanto tempo hai, poi dove
   sei, poi il respiro giusto con il perche'. L'ora del giorno la legge l'app da sola. */
const RSG = { passo: '', storia: [], da: '', ris: null };
function rsConsiglio(){
  RSC.obiettivo = ''; RSC.tempo = 0; RSC.dove = ''; RSG.ris = null;
  rsFoglioChiudi();
  if (!RSG.da) RSG.da = RS.da || 'respiro';
  if (typeof GN === 'undefined' || typeof gnVai !== 'function'){ toast('Il Genio non è pronto, riprova'); return; }
  GN.on = true; GN.modo = 'rs'; GN.audio = true; GN.storia = [];
  RSG.storia = []; RSG.passo = 'obiettivo';
  goId('s-genio');
  rsgBarra();
  GN.step = ''; gnVai('rs');
}
function rsgBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const p = { obiettivo: 0.2, tempo: 0.45, dove: 0.7, fine: 1, siediti: 0.85 }[RSG.passo] || 0.2;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  if (bar) bar.style.width = Math.round(p * 100) + '%';
  if (txt) txt.textContent = 'Il respiro giusto';
}
function rsgVai(p){ RSG.storia.push(RSG.passo); RSG.passo = p; rsgBarra(); GN.step = ''; gnVai('rs'); }
function rsgIndietro(){
  if (!RSG.storia.length){ rsgChiudi(); return true; }
  RSG.passo = RSG.storia.pop(); rsgBarra(); GN.step = ''; gnVai('rs'); return true;
}
function rsgEsci(){
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = '';
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
}
function rsgChiudi(){
  const da = RSG.da; RSG.da = '';
  rsgEsci();
  if (da === 'dream'){ goId('s-home'); try{ switchTab('rotta'); }catch(_){ } return; }
  goId('s-respiro'); rsPaint();
}
function rsgCarte(voci, chiave){
  return '<div class="gn-carta"><div class="gn-cards' + (voci.length % 2 ? ' dispari' : '') + '">' + voci.map(function(o, i){
    return '<button type="button" class="gn-card" onclick="event.stopPropagation();rsgScegli(\'' + chiave + '\',' + i + ')"><span>' + o[1] + '</span><b>' + gnEsc(o[2]) + '</b></button>';
  }).join('') + '</div></div>';
}
function rsgScegli(chiave, i){
  try{ gnAu.scelta(i); flVibra(14); }catch(_){ }
  if (chiave === 'obiettivo'){ RSC.obiettivo = RSC_OBIETTIVI[i][0]; rsgVai('tempo'); return; }
  if (chiave === 'tempo'){ RSC.tempo = RSC_TEMPI[i][0]; rsgVai('dove'); return; }
  RSC.dove = RSC_DOVE[i][0]; rsgVai('fine');
}
function rsgEntra(){
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.add('con-top', 'molte', 'carte'); sc.classList.remove('apertura', 'volo'); }
  const p = RSG.passo;
  if (p === 'obiettivo'){ gnDomanda('pensa', 'Scegliamo insieme il respiro giusto. Con questo respiro, *cosa vuoi ottenere* adesso?', rsgCarte(RSC_OBIETTIVI, 'obiettivo')); return; }
  if (p === 'tempo'){ gnDomanda('pensa', 'Per il respiro, *quanto tempo hai* adesso?', rsgCarte(RSC_TEMPI, 'tempo')); return; }
  if (p === 'dove'){ gnDomanda('pensa', 'E *dove sei* in questo momento? Alcuni respiri si fanno solo da seduti.', rsgCarte(RSC_DOVE, 'dove')); return; }
  const c = rsConsiglia(RSC.obiettivo, RSC.tempo, RSC.dove);
  RSG.ris = c;
  if (!c.k){
    gnDomanda('pensa', c.perche,
      '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();RSC.dove=\'scrivania\';rsgVai(\'fine\')">Adesso mi siedo</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();rsgChiudi()">Non ora</button>');
    return;
  }
  const t = rsTec(c.k);
  /* 0.9.306, Andrea: nella card solo il nome e la durata, detti una volta ("Huberman, da 1 a 5 minuti, 5 minuti" era
     la stessa cosa due volte). Il perche' (lo studio, la regola di sicurezza) sta dietro a "Scopri di più": il focus
     della schermata e' il respiro da fare */
  let quanto = c.giri ? (c.giri === 1 ? 'un giro' : c.giri + ' giri') : (t.cicli ? 'quattro cicli' : rsTempoVoce(c.durata));
  quanto = quanto.charAt(0).toUpperCase() + quanto.slice(1);
  try{ gnAu.rivela && gnAu.rivela(); }catch(_){ }
  gnDomanda('rivela', 'Il respiro giusto per te, adesso, è *' + t.t.toLowerCase() + '*.',
    '<div class="rsg-ris"><span class="rsp-ico" style="color:' + (t.k === 'attivante' ? '#E63946' : '#0075E3') + '">' + RS_ICO[t.k] + '</span><div><b>' + gnEsc(t.t) + '</b><small>' + quanto + '</small></div></div>'
    + (c.perche ? '<button type="button" class="rsg-info" aria-expanded="false" onclick="event.stopPropagation();rsgInfo(this)">'
        + '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 10.5v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="7.3" r="1.3" fill="currentColor"/></svg>'
        + '<span>Scopri di più</span></button>'
        + '<div class="rsg-perche-w" hidden><p class="rsg-perche">' + gnEsc(c.perche) + '</p>' + (c.nota ? '<p class="rsg-nota">' + gnEsc(c.nota) + '</p>' : '') + '</div>' : '')
    + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();rsgVia()">Inizia</button></div>'
    + '<button type="button" class="gn-link" onclick="event.stopPropagation();rsgChiudi()">Non ora</button>');
}
/** "Scopri di più": il perche' del respiro si apre e si chiude sotto alla card */
function rsgInfo(b){
  const w = b && b.nextElementSibling; if (!w) return;
  const apri = w.hidden;
  w.hidden = !apri;
  b.setAttribute('aria-expanded', apri ? 'true' : 'false');
  const s = b.querySelector('span'); if (s) s.textContent = apri ? 'Mostra meno' : 'Scopri di più';
  try{ flVibra(8); }catch(_){ }
}
function rsgVia(){
  const c = RSG.ris; if (!c) return;
  const da = RSG.da === 'dream' ? 'dream' : (RS.da || '');
  RSG.da = '';
  rsgEsci();
  /* il respiro scelto dal Genio si apre per tutti, quella volta */
  rsApri({ tecnica: c.k, durata: c.durata, giri: c.giri, libera: c.k, da: da });
}
/* l'aggancio alla scena del Genio */
(function(){
  if (typeof GN_PASSI !== 'undefined') GN_PASSI.rs = { entra: rsgEntra };
  if (typeof gnChiudiTop === 'function'){
    const vero = gnChiudiTop;
    gnChiudiTop = function(){ if (typeof GN !== 'undefined' && GN.modo === 'rs'){ rsgChiudi(); return; } return vero.apply(this, arguments); };
  }
  if (typeof gnIndietro === 'function'){
    const vero2 = gnIndietro;
    gnIndietro = function(){ if (typeof GN !== 'undefined' && GN.on && GN.modo === 'rs') return rsgIndietro(); return vero2.apply(this, arguments); };
  }
})();

(function(){
  const css = [
    '#s-respiro{background:#081129;padding:0}.rsp-pag{min-height:100%;flex:1;background:radial-gradient(120% 60% at 50% 0%,#2F6FD6 0%,#1F3F8F 26%,#2B2F7A 44%,#0B1530 72%);color:#fff;padding-bottom:40px}',
    '.rsp-top{padding:calc(env(safe-area-inset-top,0px) + 8px) 12px 0}.rsp-back{color:#fff !important;background:rgba(255,255,255,.08) !important}',
    '.rsp-fiore{position:relative;width:210px;height:210px;margin:6px auto 18px}.rsp-petali{position:absolute;inset:0}.rsp-petali i{position:absolute;left:50%;top:50%;width:92px;height:150px;margin:-75px 0 0 -46px;border-radius:50% 50% 50% 50% / 60% 60% 40% 40%;background:linear-gradient(180deg,rgba(191,224,255,.92),rgba(110,139,255,.38));transform:rotate(var(--r)) translateY(-34px);transform-origin:50% 50%;mix-blend-mode:screen;opacity:.75}',
    '.rsp-cuore{position:absolute;left:50%;top:50%;width:96px;height:96px;margin:-48px 0 0 -48px;border-radius:50%;background:radial-gradient(circle at 50% 45%,#fff 0%,#EAF4FF 55%,#BFDFFF 100%);box-shadow:0 0 40px rgba(191,224,255,.6)}',
    '.rsp-fiore.gira .rsp-petali{animation:rsGira 24s linear infinite}@keyframes rsGira{to{transform:rotate(360deg)}}',
    '.rsp-h{margin:0;text-align:center;font:700 26px var(--font-body);color:#fff}.rsp-p{margin:8px 0 22px;text-align:center;font:500 15.5px var(--font-body);color:rgba(255,255,255,.72)}',
    '.rsp-genio{display:flex;align-items:center;gap:14px;width:calc(100% - 40px);margin:0 20px 8px;padding:14px 16px;border:0;border-radius:20px;background:#fff;color:#14234A;text-align:left;cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.35)}.rsp-genio img{width:54px;height:54px;object-fit:contain;flex:none}.rsp-genio > div{flex:1}.rsp-genio b{display:block;font:800 16px/1.3 var(--font-body);color:#14234A}.rsp-genio small{display:block;margin-top:4px;font:500 13px/1.45 var(--font-body);color:#4A5A78}.rsp-genio .rsp-chev{color:#14234A}',
    '.rsp-cat{padding:26px 22px 12px}.rsp-cat h3{margin:0;font:800 19px var(--font-body);color:#fff}.rsp-cat p{margin:4px 0 0;font:500 13.5px/1.45 var(--font-body);color:rgba(255,255,255,.66)}',
    '.rsp-lista{display:flex;flex-direction:column;gap:12px;padding:0 20px}.rsp-voce{display:flex;align-items:center;gap:16px;width:100%;padding:18px 18px;border:1px solid rgba(255,255,255,.22);border-radius:18px;background:rgba(0,0,0,.35);color:#fff;text-align:left;cursor:pointer}.rsp-voce > div{flex:1}.rsp-voce b{display:block;font:600 16px var(--font-body)}.rsp-voce small{display:block;margin-top:3px;font:500 14px var(--font-body);color:rgba(255,255,255,.7)}',
    '.rsp-ico{display:inline-flex;width:34px;justify-content:center}.rsp-ico.grande svg{width:52px;height:52px}.rsp-chev{display:inline-flex;color:rgba(255,255,255,.6)}.rsp-lucchetto{width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;color:#fff}',
    '.rsp-stat{display:block;width:calc(100% - 40px);margin:30px 20px 0;padding:20px 16px 16px;border:1px solid rgba(188,224,255,.28);border-radius:22px;background:rgba(255,255,255,.08);color:#fff;text-align:center;cursor:pointer;font:inherit}',
    '.rsp-stat h3{margin:0 0 16px;font:800 19px var(--font-body);color:#fff;text-align:center}.rsp-stat.vuoto p{margin:0;font:500 14.5px/1.5 var(--font-body);color:rgba(255,255,255,.75);text-align:center}',
    '.rsp-stat-num{display:flex;gap:10px}.rsp-stat-num > div{flex:1;min-width:0;display:flex;flex-direction:column;align-items:center;gap:4px;padding:14px 6px 12px;border-radius:16px;background:rgba(8,17,41,.45)}',
    '.rsp-stat-e{width:38px;height:38px;border-radius:50%;background:#fff;display:flex;align-items:center;justify-content:center;font-size:20px;margin-bottom:4px}',
    '.rsp-stat-num b{font:800 24px/1.1 var(--font-display,var(--font-body));color:#fff;font-variant-numeric:tabular-nums;white-space:nowrap}.rsp-stat-num small{font:600 12px/1.3 var(--font-body);color:rgba(255,255,255,.7)}',
    '.rsp-stat-link{display:flex;align-items:center;justify-content:center;gap:2px;margin-top:16px;font:700 15px var(--font-body);color:#8CC6FF}.rsp-stat-link svg{width:18px;height:18px}',
    '.rsp-foglio-w{position:fixed;inset:0;z-index:9993;display:flex;align-items:flex-end;background:rgba(1,6,20,0);transition:background .25s}.rsp-foglio-w.in{background:rgba(1,6,20,.8)}',
    '.rsp-foglio{position:relative;width:100%;max-width:520px;max-height:calc(100vh - 24px);overflow-y:auto;margin:0 auto;padding:28px 22px calc(env(safe-area-inset-bottom,0px) + 22px);border-radius:28px 28px 0 0;background:#22376B;border:1px solid rgba(188,224,255,.38);border-bottom:0;box-shadow:0 -14px 44px rgba(0,0,0,.55);color:#fff;text-align:center;transform:translateY(100%);transition:transform .32s cubic-bezier(.2,1,.3,1)}.rsp-foglio-w.in .rsp-foglio{transform:none}',
    '.rsp-x{position:absolute;top:14px;right:14px;width:42px;height:42px;border-radius:50%;border:1px solid rgba(255,255,255,.35);background:rgba(255,255,255,.18);color:#fff;display:flex;align-items:center;justify-content:center;padding:0;cursor:pointer}',
    '.rsp-foglio h3{margin:8px 0 8px;font:700 22px var(--font-body);color:#fff}.rsp-foglio p{margin:0 auto 22px;max-width:34ch;font:500 15px/1.5 var(--font-body);color:rgba(255,255,255,.82)}',
    '.rsp-foglio .rsp-breve{margin-bottom:10px}.rsp-foglio .rsp-scopri{margin:0 auto 14px}.rsp-foglio .rsp-piu-w{margin:0 0 18px;background:rgba(8,17,41,.35)}.rsp-foglio .rsp-piu-w p{max-width:none;margin:0}',
    '.rsp-fasi{display:flex;justify-content:center;gap:8px;margin-top:8px}.rsp-fase{flex:1;max-width:120px;display:flex;flex-direction:column;align-items:center;gap:6px;padding:14px 6px 12px;border-radius:18px;background:rgba(8,17,41,.4)}',
    '.rsp-fase-i{width:44px;height:44px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin-bottom:2px}.rsp-fase small{font:600 13px/1.3 var(--font-body);color:rgba(255,255,255,.8)}.rsp-fase b{font:800 14.5px/1.25 var(--font-body);color:#fff}',
    '.rsp-fase.f-in .rsp-fase-i{background:rgba(140,198,255,.2);color:#8CC6FF}.rsp-fase.f-tieni .rsp-fase-i{background:rgba(255,255,255,.18);color:#fff}.rsp-fase.f-out .rsp-fase-i{background:rgba(246,165,181,.2);color:#F6A5B5}',
    '.rsp-riga{display:block;height:1px;background:rgba(255,255,255,.18);margin:22px 0}.rsp-foglio h4{margin:0 0 18px;font:700 18px var(--font-body);color:#fff}',
    '.rsp-durate{display:flex;justify-content:center;gap:14px;margin-bottom:22px}.rsp-durate button{width:72px;height:72px;border-radius:50%;border:1px solid rgba(255,255,255,.28);background:rgba(8,17,41,.4);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer}.rsp-durate button b{font:700 17px var(--font-body)}.rsp-durate button small{font:500 13px var(--font-body);color:rgba(255,255,255,.8)}.rsp-durate button.on{border-color:#fff;background:#fff;color:#0E2350}.rsp-durate button.on small{color:#0E2350}.rsp-piu b{font-size:26px !important}',
    '.rsp-foglio .rsp-nota{margin:-6px auto 22px;font-size:13.5px}',
    '.rsp-foglio .rsp-avviso{display:inline-block;margin:16px auto 0;max-width:none;padding:7px 14px;border-radius:99px;background:rgba(230,57,70,.22);font:700 13px/1.3 var(--font-body);color:#FFC9CE;text-align:center}',
    '.rsp-attenzione{background:#2A1416}.rsp-att-ico{display:inline-flex;width:64px;height:64px;border-radius:50%;align-items:center;justify-content:center;background:rgba(230,57,70,.18);color:#FF6B76}.rsp-attenzione h3{text-transform:uppercase;letter-spacing:.08em;color:#FF8A93}',
    '.rsp-foglio .rsp-att-testo{max-width:none;font:700 16.5px/1.5 var(--font-body);color:#fff;margin-bottom:14px}.rsp-foglio .rsp-att-piu{max-width:none;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.7)}',
    '.rsp-via{width:100%;margin:0;background:#E63946 !important;color:#fff !important;border-radius:99px}.rsp-via[hidden]{display:none}',
    '.rsp-annulla{display:block;width:100%;margin-top:8px;padding:12px;border:0;background:transparent;color:rgba(255,255,255,.75);font:600 15px var(--font-body);cursor:pointer}',
    '.rsg-ris{display:flex;align-items:center;gap:14px;padding:14px 16px;border-radius:18px;background:#fff;color:#0E2350;text-align:left;margin:2px 0 10px}.rsg-ris .rsp-ico svg{width:34px;height:34px}.rsg-ris b{display:block;font:800 17px/1.3 var(--font-body);color:#0E2350}.rsg-ris small{display:block;margin-top:3px;font:600 13px var(--font-body);color:#4A5A78}',
    '.rsg-info{display:flex;align-items:center;justify-content:center;gap:7px;margin:4px auto 12px;padding:8px 14px;border:0;border-radius:99px;background:rgba(140,198,255,.14);color:#BCE0FF;font:700 13.5px var(--font-body);cursor:pointer}',
    '.rsg-info svg{flex:none}',
    '.rsg-perche-w{margin:0 0 14px;padding:14px 16px;border-radius:16px;background:rgba(140,198,255,.12);border:1px solid rgba(140,198,255,.28);text-align:center;animation:gnIn .3s ease-out both}.rsg-perche-w[hidden]{display:none}',
    '.rsg-perche{margin:0;text-align:center;font:600 14.5px/1.5 var(--font-body);color:#EAF3FF}.rsg-nota{margin:10px 0 0;text-align:center;font:600 13px/1.45 var(--font-body);color:#CDE6FF}',
    '.rsp-sess{position:fixed;inset:0;z-index:9996;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(120% 70% at 50% 30%,#2F6FD6 0%,#23397F 34%,#1E2363 52%,#081129 82%);color:#fff;text-align:center;padding:20px}',
    '.rsp-sess-top{position:absolute;top:calc(env(safe-area-inset-top,0px) + 16px);left:18px;right:18px;display:flex;justify-content:space-between;align-items:center}.rsp-sess-top > div{display:flex;gap:8px;align-items:center}.rsp-sess-top span{font:700 16px var(--font-body);font-variant-numeric:tabular-nums;color:rgba(255,255,255,.8)}.rsp-sess-top button{border:1px solid rgba(255,255,255,.3);border-radius:99px;background:transparent;color:#fff;padding:8px 16px;font:600 14px var(--font-body);cursor:pointer}.rsp-sess-top .rsp-audio{padding:7px 9px;display:inline-flex}',
    '.rsp-anello-w{position:relative;width:300px;height:300px;display:flex;align-items:center;justify-content:center}.rsp-anello{position:absolute;inset:0;transform:rotate(-90deg);overflow:visible}.rsp-anello circle{fill:none;stroke-width:7}.rsp-anello-bg{stroke:rgba(255,255,255,.12)}.rsp-anello-on{stroke:#8CC6FF;stroke-linecap:round;transition:stroke-dashoffset .12s linear,stroke .4s}',
    '.rsp-sess[data-fase="in"] .rsp-anello-on{stroke:#8CC6FF}.rsp-sess[data-fase="out"] .rsp-anello-on{stroke:#F6A5B5}.rsp-sess[data-fase="tieni"] .rsp-anello-on{stroke:#fff;transition:none;animation:rsPulsa 1.6s ease-in-out infinite}',
    '.rsp-anello .rsp-tacca{stroke:#fff;stroke-width:4.5;stroke-linecap:round}.rsp-anello .rsp-tacca-a{stroke:#0E2350;stroke-width:10;stroke-linecap:round}',
    '.rsp-sess[data-fase="tieni"][data-polmoni="vuoti"] .rsp-anello-bg{animation:rsPulsaBg 1.6s ease-in-out infinite}',
    '@keyframes rsPulsa{0%,100%{stroke-width:7;stroke-opacity:1}50%{stroke-width:11;stroke-opacity:.6}}@keyframes rsPulsaBg{0%,100%{stroke:rgba(255,255,255,.14);stroke-width:7}50%{stroke:rgba(255,255,255,.55);stroke-width:11}}',
    '.rsp-sess[data-fase="in"] #rsFase{color:#BCE0FF}.rsp-sess[data-fase="out"] #rsFase{color:#F6CCE4}.rsp-sess[data-fase="tieni"] #rsFase{color:#fff}',
    '.rsp-sess .rsp-cuore{transition:box-shadow .8s ease}.rsp-sess[data-fase="in"] .rsp-cuore{box-shadow:0 0 46px rgba(140,198,255,.85)}.rsp-sess[data-fase="out"] .rsp-cuore{box-shadow:0 0 46px rgba(246,165,181,.9)}.rsp-sess[data-fase="tieni"] .rsp-cuore{box-shadow:0 0 0 6px rgba(255,255,255,.35),0 0 50px rgba(255,255,255,.75)}',
    '.rsp-sess[data-fase="tieni"] .rsp-petali{animation-play-state:paused !important}',
    '.rsp-fiore.respira{margin:0;width:240px;height:240px;transform:scale(.62);transition-property:transform;transition-timing-function:ease-in-out}.rsp-fiore.respira.aperto{transform:scale(1.02)}.rsp-fiore.respira.aperto.piu{transform:scale(1.12)}.rsp-fiore.respira .rsp-petali{animation:rsGira 40s linear infinite}',
    '.rsp-sess-fase{margin-top:22px;min-height:120px}.rsp-sess-fase b{display:block;font:700 26px/1.25 var(--font-body);max-width:320px}.rsp-sess-fase span{display:block;margin-top:6px;font:600 44px var(--font-body);font-variant-numeric:tabular-nums;color:rgba(255,255,255,.85)}.rsp-sess-fase small{display:block;margin-top:4px;font:600 13.5px var(--font-body);color:rgba(255,255,255,.62)}',
    '.rsp-respiro-ora{margin-top:10px;padding:16px 30px;border:0;border-radius:99px;background:#fff;color:#14234A;font:800 17px var(--font-body);cursor:pointer;box-shadow:0 10px 30px rgba(0,0,0,.4)}.rsp-respiro-ora[hidden]{display:none}',
    '.rsp-fatto{max-width:360px;display:flex;flex-direction:column;align-items:center}.rsp-fatto h2{margin:0 0 12px;font:700 30px var(--font-body)}.rsp-fatto h3{margin:0 0 22px;font:700 22px/1.3 var(--font-body);color:#fff}.rsp-fatto p{margin:0;font:500 17px/1.5 var(--font-body);color:rgba(255,255,255,.85)}.rsp-fatto p b{color:#fff}',
    '.rsp-fine{position:absolute;inset:0;display:flex;flex-direction:column;padding:calc(env(safe-area-inset-top,0px) + 18px) 22px calc(env(safe-area-inset-bottom,0px) + 22px);cursor:pointer;-webkit-tap-highlight-color:transparent}',
    '.rsp-fine-top{display:flex;flex:0 0 auto}.rsp-fine-body{flex:1;min-height:0;display:flex;flex-direction:column;align-items:center;justify-content:center}.rsp-fine-body .rsp-fatto{margin:auto 0}',
    '.rsp-fine-dur{font-size:18px !important}.rsp-fine-dopo{max-width:300px !important;font:700 23px/1.4 var(--font-body) !important;color:#fff !important;text-wrap:balance}',
    '.rsp-fine-ico{width:84px;height:84px;border-radius:50%;background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;margin-bottom:26px}.rsp-fine-ico svg{width:44px;height:44px}',
    '.rsp-fine-apnee{display:flex;gap:12px;justify-content:center;margin-bottom:22px}.rsp-fine-apnee div{min-width:86px;padding:14px 10px;border-radius:18px;background:rgba(255,255,255,.1);display:flex;flex-direction:column;align-items:center;gap:4px}.rsp-fine-apnee div.top{background:#fff}.rsp-fine-apnee b{font:800 26px var(--font-body);font-variant-numeric:tabular-nums;color:#fff}.rsp-fine-apnee small{font:600 12.5px var(--font-body);color:rgba(255,255,255,.7)}.rsp-fine-apnee div.top b{color:#0E2350}.rsp-fine-apnee div.top small{color:#005BB0}',
    '.rsp-fine-cta{flex:0 0 auto;width:100%;max-width:360px;margin-top:auto !important}.rsp-fine-tap{margin-top:auto}',
    '.rsps-fill{background:#3F9FF4}.rsps-fill span{font:800 13px var(--font-body);color:#005BB0}',
    '.rsps-leg{display:block;margin-top:4px;font:600 12px var(--font-body);color:var(--muted);text-align:center}',
    '.rsps-bar{fill:#3F9FF4;transform-box:fill-box;transform-origin:50% 100%;animation:rspsSu .8s cubic-bezier(.25,1,.35,1) both;animation-delay:var(--d,0ms)}@keyframes rspsSu{from{transform:scaleY(0)}to{transform:scaleY(1)}}',
    '.rsps-y{text-anchor:end}.rsps-linea{stroke:#0075E3}body.dark .rsps-linea{stroke:#8CC6FF}.rsps-punto{fill:#0075E3;stroke:#fff;stroke-width:2}body.dark .rsps-punto{fill:#8CC6FF;stroke:#141C2C}.rsps-punto.massimo{fill:#E63946}body.dark .rsps-punto.massimo{fill:#FF6B76}',
    '.rsps-massimo{display:flex;flex-direction:column;align-items:center;gap:2px;margin:4px 0 10px}.rsps-massimo span{font-size:26px}.rsps-massimo b{font:800 34px/1.1 var(--font-display,var(--font-body));color:#E63946;font-variant-numeric:tabular-nums}body.dark .rsps-massimo b{color:#FF6B76}.rsps-massimo small{font:600 13px var(--font-body);color:var(--muted)}',
    '.rsps-nota{margin-bottom:0 !important}.rsps-cta{background:#0075E3 !important;color:#fff !important;border-radius:50px}',
    '.rsps-ico{width:38px;height:38px;flex:none;border-radius:50%;background:#0E2350;display:flex;align-items:center;justify-content:center}.rsps-ico svg{width:22px;height:22px}',
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
(function(){
  const st = document.createElement('style');
  st.textContent = '@keyframes rspMinuto{0%{opacity:0;transform:translateY(6px)}15%,75%{opacity:1;transform:none}100%{opacity:0}}.rsp-minuto{min-height:24px;opacity:0;text-align:center;font:600 15px var(--font-body);color:#fff}.rsp-minuto.on{animation:rspMinuto 2.6s ease both}'
    /* 0.9.348, Andrea: "1 minuto e' troppo attaccato al cerchio": una pillola staccata dal cerchio, che compare e sparisce */
    + '.rsp-minuto{display:table;margin:22px auto 10px;padding:7px 16px;border-radius:99px;background:rgba(140,198,255,.2);border:1px solid rgba(200,239,253,.35);font:800 15px var(--font-body)}.rsp-minuto:empty{visibility:hidden}';
  document.head.appendChild(st);
})();
