/* ===========================================================================================
   FULLFOCUS — una sessione di lavoro profondo, alla Forest.

   Si sceglie un tag (Lavoro, Studio…), si scrive a cosa si dedica il tempo, si imposta il
   timer e si parte: una pianta cresce dentro la sfera finché il tempo scade. Se la sessione
   è "intensiva", lasciare l'app fa appassire la pianta; in alternativa l'utente può scegliere
   un elenco di app consentite e, per la durata della sessione, il motore blocca tutto il
   resto (la stessa allowlist del Blocco rapido, armata e poi rimessa com'era).

   Ogni minuto portato a termine vale una moneta (+25% in intensiva). Le monete comprano
   alberi veri: 2500 per albero, al massimo cinque per persona, piantati da Tree-Nation
   attraverso il nostro server (rotta /api/focuslock/plant). I suoni sono sintetizzati qui
   con Web Audio: niente file, niente licenze, e ogni livello ne sblocca uno.
   =========================================================================================== */

const FF_TAG_DEFAULTS = [
  { id: 'lavoro', name: 'Lavoro', col: '#F5A623' }, { id: 'studio', name: 'Studio', col: '#5B8DEF' },
  { id: 'social', name: 'Social', col: '#E58FB5' }, { id: 'riposo', name: 'Riposo', col: '#E5515F' },
  { id: 'intr', name: 'Intrattenimento', col: '#4CD39A' }, { id: 'altro', name: 'Altro', col: '#4CD39A' },
  { id: 'sport', name: 'Sport', col: '#3FC7C9' },
  /* MEDITAZIONE: nessuna app consentita, telefono intoccato. Nello storico e negli insight e'
     un'altra cosa dal lavoro: ha il suo bonus (vedi dopamina-config.js). */
  { id: 'meditazione', name: 'Meditazione', col: '#3F9FF4' }
];
/* I nomi e gli sblocchi restano qui; il suono lo fa sounds.js. Via il rumore bianco: era il
   più aspro di tutti, ed è proprio quello che dopo dieci minuti fa male alle orecchie. */
/* Gli stessi file della tendina nella scheda Sveglia (sounds.js): registrazioni vere, CC0.
   Gli sblocchi per livello restano quelli di prima. */
const FF_SOUNDS = [
  { id: 'none',      name: 'Silenzio',        grant: null },
  { id: 'rain',      name: 'Pioggia',         grant: null },
  { id: 'ocean',     name: 'Onde del mare',   grant: null },
  { id: 'storm',     name: 'Temporale',       grant: 'sound:white' },
  { id: 'wind',      name: 'Vento',           grant: 'sound:wind' },
  { id: 'fire',      name: 'Camino',          grant: 'sound:fire' },
  { id: 'river',     name: 'Ruscello',        grant: 'sound:night' },
  { id: 'night',     name: "Notte d'estate",  grant: 'sound:night' },
  { id: 'forest',    name: 'Bosco',           grant: 'sound:cafe' }
];
const FF_GRACE_MS = 10000;      // i dieci secondi per annullare senza conseguenze
const FF_TREE_COST = 2500;
const FF_TREE_CAP = 5;
const FF = { pref: null, run: null, tick: null, audio: null, nodes: [], trees: null };

function ffRead(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function ffWrite(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(_){ } }
function ffPref(){
  if (!FF.pref) FF.pref = Object.assign({ tag: 'lavoro', intent: '', minutes: 30, intensive: true, mode: 'allow', sound: 'none', suonoAuto: false, fuori: 'pausa', fuoriMin: 5, company: 'solo', allow: [], allowSites: [], allowWords: [], returnTo: '' }, ffRead('fl_ff_pref', {}));
  if (FF.pref.sound === 'cafe') FF.pref.sound = 'none';
  return FF.pref;
}
function ffSavePref(){
  ffWrite('fl_ff_pref', FF.pref);
  /* le app consentite dei programmi automatici sono le stesse del timer */
  try{ if (typeof ffcProgrammi === 'function' && ffcProgrammi().length) ffcPush(); }catch(_){ }
}
function ffTags(){
  const l = ffRead('fl_ff_tags', null) || FF_TAG_DEFAULTS.slice();
  /* chi ha gia' personalizzato le etichette non avrebbe mai visto la Meditazione */
  if (!l.some(function(x){ return x && x.id === 'meditazione'; })) l.push(FF_TAG_DEFAULTS.filter(function(x){ return x.id === 'meditazione'; })[0]);
  return l;
}
const FF_TAG_ICO = { lavoro: '💼', studio: '📚', social: '💬', riposo: '😴', intr: '🎬', altro: '✨', meditazione: '🧘' };
function ffTagIco(t){ return (t && (t.ico || FF_TAG_ICO[t.id])) || '🎯'; }
function ffTag(){ const t = ffTags(); return t.filter(x => x.id === ffPref().tag)[0] || t[0]; }
function ffCoins(){ return +(ffRead('fl_coins', 0)) || 0; }
function ffAddCoins(n){ ffWrite('fl_coins', ffCoins() + n); }
function ffHist(){ return ffRead('fl_ff_hist', []); }
function ffFmt(ms){ const s = Math.max(0, Math.round(ms / 1000)); const m = Math.floor(s / 60), r = s % 60; return (m < 10 ? '0' : '') + m + ':' + (r < 10 ? '0' : '') + r; }

/* ---------------------------------------------------------------------------------------
   Screens
   --------------------------------------------------------------------------------------- */
registerScreen('s-fullfocus', `
  <div class="ff-top">
    <button class="iconbtn ff-back" onclick="ffClose()">‹</button>
    <button type="button" class="ff-coins" onclick="ngApri()" aria-label="Apri il negozio">🪙 <b id="ffCoins">0</b></button>
    <button type="button" class="ff-forestbtn" onclick="ffForestOpen()" aria-label="Il tuo cielo">⭐</button>
    <div class="ff-sndlbl" id="ffSndLbl" hidden></div>
    <button type="button" class="ff-sndtop" id="ffSndTop" hidden aria-label="Suono di sottofondo"
      onpointerdown="ffSndDown(event)" onpointerup="ffSndUp(event)" onpointercancel="ffSndCancel()" oncontextmenu="return false">🔊</button>
  </div>
  <div class="ff-tagrow" onclick="ffTagsOpen()"><i id="ffTagDot"></i><b id="ffTagName">Lavoro</b><span class="ff-chev"></span></div>
  <div class="ff-intent" onclick="ffIntentOpen()"><span id="ffIntent">Dedicherò questo tempo a…</span></div>
  <div class="ff-sfera"><div class="ff-ball"><div class="ff-plant" id="ffPlant"></div></div><div class="ff-stand"></div></div>
  <div class="ff-status" id="ffStatus" hidden></div>
  <button type="button" class="ff-time" id="ffTime" onclick="ffTempoTocca()">20:00</button>
  <button class="ff-cta" id="ffCta" onclick="ffPrimary()">Accendi la tua stella</button>
  <!-- 0.9.353, Andrea: "tre pulsanti sono troppi, e Ho finito prima sempre in vista invita a barare". Restano lo stop e la pausa
       (senza la pausa nelle impostazioni, solo lo stop). "Ho finito prima" si offre toccando il tempo, o dallo stop dopo un tempo credibile -->
  <div class="ff-run" id="ffRun" hidden>
    <button type="button" class="ff-rb" onclick="ffGiveUp()" aria-label="Rinuncia">
      <svg viewBox="0 0 24 24" width="22" height="22"><rect x="7" y="7" width="10" height="10" rx="2" fill="currentColor"/></svg></button>
    <button type="button" class="ff-rb" id="ffPause" onclick="ffPauseToggle()" aria-label="Pausa">
      <svg viewBox="0 0 24 24" width="22" height="22"><rect x="8" y="6" width="3.2" height="12" rx="1.2" fill="currentColor"/><rect x="12.8" y="6" width="3.2" height="12" rx="1.2" fill="currentColor"/></svg></button>
  </div>
  <div class="spacer"></div>
`, { back: 's-home', hero: true });

/* LA PAGINA DEL RISULTATO.
   Prima il verdetto compariva come una riga sulla schermata del timer, sotto alla sfera: uno
   guardava il pulsante, non la frase. Adesso e' una pagina sua, con l'albero grande quanto e'
   arrivato a crescere — piu' minuti, piu' albero — e un solo pulsante per uscire. E' la sola
   schermata dell'app che si prende tutto lo schermo per dire una cosa sola, ed e' giusto che
   sia questa: e' il momento in cui la sessione diventa un ricordo. */
registerScreen('s-ff-done', '<div class="ffd" id="ffDone"></div>', { back: function(){ ffDopoScrigno(); return 's-fullfocus'; } });

/* 0.9.315, Andrea (ritratto della schermata finale di Forest): la pianta in una card con i minuti, il tag e "Aggiungi note
   alla sessione"; sotto il pulsante per tornare alla pagina del Full Focus e "Prenditi una pausa". Le note restano nella
   storia delle sessioni (fl_ff_hist, campo nota) e il tuo agente personale le legge (agDati, noteSessioni). */
const FFD_MATITA = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h16"/><path d="M14.5 5.5l4 4L9 19H5v-4z"/></svg>';
function ffSpeso(run){ return Math.max(0, (run.endAt - run.startAt) - Math.max(0, run.endAt - Date.now()) - (run.pausaTot || 0)); }
function ffDoneOpen(ok, run, coins, at){
  const spent = ffSpeso(run);
  const frac = Math.max(0, Math.min(1, spent / Math.max(1, run.minutes * 60000)));
  const stage = ok ? 4 : Math.max(0, Math.min(4, Math.floor(frac * 5)));
  const mins = Math.round(spent / 60000);
  const rare = typeof lvHas === 'function' && lvHas('plant:rare');
  const host = document.getElementById('ffDone');
  FF.fatta = { at: at || 0 };
  goId('s-ff-done');
  if (!host) return;
  let tag = ''; try{ const t = ffTags().filter(function(x){ return x.id === run.tag; })[0]; tag = t ? t.name : ''; }catch(_){ }
  FF.dopo = { ok: ok, run: run, coins: coins, spent: spent, stage: stage, mins: mins, rare: rare, tag: tag };
  ffPremioPaint();
}
/* 0.9.326, Andrea: "Forest mostra prima il premio, poi con Continua la nota: noi tutto insieme. Deve essere diviso come una mystery box, con i suoni come in un videogioco".
   Se ci si arrende: la stella spoglia sotto la luce, il tempo con i secondi, e poi la nota. */
function ffPremioPaint(){
  const d = FF.dopo, host = document.getElementById('ffDone'); if (!d || !host) return;
  const min = d.mins, durata = min >= 1 ? (min === 1 ? '1 minuto' : min + ' minuti') : ffFmt(d.spent);
  const scintille = '<i class="ffz-s a"></i><i class="ffz-s b"></i><i class="ffz-s c"></i><i class="ffz-s d"></i>';
  const stella = '<div class="ffz-luce"></div><div class="ffz-st' + (d.ok ? '' : ' spoglia') + '">' + (d.ok ? ffPlantSvg(4, d.rare) : ffPlantSvg(Math.max(1, d.stage), d.rare)) + scintille + '</div>';
  if (d.ok){
    host.innerHTML = '<div class="ffz ok"><div class="ffz-c">' + stella
      + '<p class="ffz-t">Ottimo! Oggi hai mantenuto la concentrazione per ' + esc(durata) + '.</p>'
      + (d.coins ? '<div class="ffz-mon"><span class="ffz-mon-i">🪙</span><b>Monete</b><span class="ffz-mon-n" id="ffzMon">+0</span></div>' : '') + '</div>'
      + '<button type="button" class="ffz-cta" onclick="ffDonePasso2()">Continua</button>'
      /* 0.9.333, Andrea (ritratto di Forest): dopo il premio si puo' raddoppiarlo con un annuncio, o triplicarlo con Premium */
      + (d.coins && !d.boost ? '<button type="button" class="ffz-cta ffz-pot" id="ffzPot" onclick="ffBoostApri()">Potenzia le ricompense<i></i><i></i><i></i></button>' : '') + '</div>';
    try{ if (typeof fxSuona === 'function') fxSuona('fine'); }catch(_){ }
    try{ flVibra([20, 40, 30]); }catch(_){ }
    if (d.coins) setTimeout(function(){
      try{ if (typeof fxSuona === 'function') fxSuona('moneta'); }catch(_){ }
      const t0 = performance.now(), dur = 800;
      const giro = function(t){ const e = document.getElementById('ffzMon'); if (!e) return; const u = Math.min(1, (t - t0) / dur); e.textContent = '+' + Math.round(d.coins * u); if (u < 1) requestAnimationFrame(giro); };
      requestAnimationFrame(giro);
    }, 650);
    return;
  }
  host.innerHTML = '<div class="ffz no"><div class="ffz-testa">' + (d.tag ? '<b>' + esc(d.tag) + '</b>' : '') + (d.run.intent ? '<small>' + esc(d.run.intent) + '</small>' : '') + '</div><div class="ffz-c">' + stella
    + '<p class="ffz-t">Va bene, la prossima volta andrà meglio.</p>'
    + '<p class="ffz-tempo"><span>⏱</span>' + ffFmt(d.spent) + '</p></div>'
    + '<button type="button" class="ffz-cta" onclick="ffDonePasso2()">Continua</button></div>';
  try{ if (typeof fxSuona === 'function') fxSuona('sbagliata'); }catch(_){ }
}
function ffPremiumHa(){ try{ return (typeof ngPremium === 'function') ? !!ngPremium() : (typeof adsUserIsPremium === 'function' && adsUserIsPremium()); }catch(_){ return false; } }
function ffBoostApri(){
  try{ flVibra(10); if (typeof fxSuona === 'function') fxSuona('scelta'); }catch(_){ }
  const w = document.createElement('div'); w.id = 'ffzBoost';
  /* il video c'e' solo quando gli annunci sono pronti davvero (serve l'account AdMob con il messaggio di consenso): chi ha creato l'app vede comunque il pulsante */
  let pronti = false; try{ pronti = !!adsState.initialized; }catch(_){ }
  let admin = false; try{ admin = typeof flAdmin === 'function' && flAdmin(); }catch(_){ }
  const annuncio = admin || (!ffPremiumHa() && pronti && typeof adsRicompensaPossibile === 'function' && adsRicompensaPossibile());
  /* 0.9.352, Andrea: "sotto si intravede l'altra schermata, il premio non si vede, e '3x monete con Premium' non vuol dire niente".
     Fondo pieno, al centro le monete guadagnate, sotto le due scelte che dicono per intero cosa ricevi */
  const m = Math.max(0, Math.round((FF.dopo && FF.dopo.coins) || 0));
  const mon = function(x){ return x === 1 ? '1 moneta' : x + ' monete'; };
  w.innerHTML = '<div class="ffzb-c"><div class="ffzb-premio"><span class="ffzb-moneta" aria-hidden="true">🪙</span><small>Hai guadagnato</small><b>' + mon(m) + '</b><p>Vuoi moltiplicarle?</p></div>'
    + '<button type="button" class="ffzb-b plus" onclick="ffBoostPremium()"><span class="ffzb-m v">3×</span><span class="ffzb-t"><b>Triplicale con Premium</b><small>Ricevi ' + mon(m * 3) + ' invece di ' + m + '</small></span></button>'
    + (annuncio ? '<button type="button" class="ffzb-b ann" onclick="ffBoostAnnuncio()"><span class="ffzb-m o">2×</span><span class="ffzb-t"><b>Guarda un annuncio e raddoppiale</b><small>Ricevi ' + mon(m * 2) + ' invece di ' + m + '</small></span></button>' : '')
    + '<button type="button" class="ffzb-no" onclick="ffBoostChiudi()">No, tengo le mie ' + mon(m) + '</button></div>';
  (document.getElementById('phone') || document.body).appendChild(w);
}
function ffBoostChiudi(){ const w = document.getElementById('ffzBoost'); if (w) w.remove(); }
function ffBoostPremium(){
  if (ffPremiumHa()){ ffBoostDai(3); return; }
  ffBoostChiudi();
  if (typeof pfApri === 'function') pfApri();
}
function ffBoostAnnuncio(){
  let pronti = false; try{ pronti = !!adsState.initialized; }catch(_){ }
  if (!pronti && typeof flAdmin === 'function' && flAdmin()){ toast('Gli annunci partono quando AdMob è configurato'); return; }
  ffBoostChiudi();
  if (typeof adsRicompensa === 'function') adsRicompensa(function(){ ffBoostDai(2); });
}
function ffBoostDai(volte){
  const d = FF.dopo; if (!d || d.boost) return;
  ffBoostChiudi();
  d.boost = true;
  const prima = d.coins, extra = prima * (volte - 1);
  ffAddCoins(extra); d.coins = prima * volte;
  try{ if (FF.fatta && FF.fatta.at) ffSegnaRisposta(FF.fatta.at, { coins: d.coins }); }catch(_){ }
  const p = document.getElementById('ffzPot'); if (p) p.remove();
  try{ flVibra([20, 40, 60]); if (typeof fxSuona === 'function') fxSuona('moneta'); }catch(_){ }
  const t0 = performance.now(), dur = 700;
  const giro = function(t){ const e = document.getElementById('ffzMon'); if (!e) return; const u = Math.min(1, (t - t0) / dur); e.textContent = '+' + Math.round(prima + extra * u); if (u < 1) requestAnimationFrame(giro); };
  requestAnimationFrame(giro);
}
function ffDopoScrigno(){
  const a = FF.dopoScr; FF.dopoScr = null;
  if (a){ try{ if (typeof scrDopoSessione === 'function') scrDopoSessione.apply(null, a); }catch(_){ } }
}
function ffDonePasso2(){
  const d = FF.dopo, host = document.getElementById('ffDone'); if (!d || !host) return;
  const ok = d.ok, run = d.run, coins = d.coins, tag = d.tag;
  try{ if (typeof fxSuona === 'function') fxSuona('schermata'); }catch(_){ }
  host.innerHTML =
      '<div class="ffd-card">'
    +   '<div class="ffd-plant' + (ok ? '' : ' spento') + '">' + ffPlantSvg(ok ? 4 : Math.max(1, d.stage), d.rare) + '</div>'
    +   '<div class="ffd-riga"><span class="ffd-pill">' + (d.mins >= 1 ? d.mins + ' m' : ffFmt(d.spent)) + '</span>' + (ok && coins ? '<span class="ffd-pill">🪙 +' + coins + '</span>' : '') + '</div>'
    +   (tag ? '<b class="ffd-tag">' + esc(tag) + '</b>' : '')
    +   (run.intent ? '<p class="ffd-int">' + esc(run.intent) + '</p>' : '')
    +   '<button type="button" class="ffd-nota" id="ffdNota" onclick="ffNotaApri()">' + FFD_MATITA + '<span>Aggiungi note alla sessione</span></button>'
    + '</div>'
    + '<button type="button" class="cta ffd-go" onclick="ffDoneClose()">Torna al Full Focus</button>'
    /* in un ciclo la pausa parte gia' da sola */
    + (ok && run.ciclo ? '' : '<button type="button" class="ffd-pausa" onclick="ffPausaLiberaApri()">Prenditi una pausa</button>');
  /* lo scrigno arriva qui: prima il premio della sessione, poi la sorpresa */
  ffDopoScrigno();
}
function ffDoneClose(){
  goId('s-fullfocus');
  try{ ffPaint(); }catch(_){ }
  /* chi ha toccato "Ho finito prima" l'ha gia' detto: la risposta e' si', e si passa subito alla prossima cosa da fare */
  if (FF.chiedi){ const c = FF.chiedi; FF.chiedi = null; setTimeout(function(){ ffChiediCompletata(c); if (c.prima) ffRispondi(true); }, 350); return; }
  /* nessuna domanda: la fila dei pop-up e' finita. Una sessione chiusa bene con l'intenzione
     prenotata conferma il punto; poi tocca all'Io Futuro. */
  if (typeof pkDopoSessione === 'function') pkDopoSessione();
  if (typeof ifDopoFocus === 'function') ifDopoFocus();
}
/* le note: si salvano mentre scrivi, senza aspettare il pulsante */
function ffNotaLeggi(){ const at = FF.fatta && FF.fatta.at; const x = at ? ffHist().filter(function(e){ return e && e.at === at; })[0] : null; return x ? (x.nota || '') : ''; }
function ffNotaApri(){
  ffSheetOpen('<button type="button" class="ff-nota-x" onclick="ffNotaChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '<div class="ff-sh-title ff-nota-t">Aggiungi note alla sessione</div>'
    + '<p class="ff-nota-p">Il tuo agente personale le legge per capire come aiutarti.</p>'
    + '<textarea class="fin ff-ta" id="ffNotaIn" maxlength="1000" rows="5" placeholder="Com’è andata? Cosa ti ha distratto? Cosa hai finito?">' + esc(ffNotaLeggi()) + '</textarea>'
    + '<button type="button" class="cta" onclick="ffNotaChiudi()">Salva la nota</button>');
  const ta = document.getElementById('ffNotaIn');
  if (ta){ ta.addEventListener('input', ffNotaScrivi); setTimeout(function(){ ta.focus(); }, 120); }
}
function ffNotaScrivi(){
  const ta = document.getElementById('ffNotaIn'), at = FF.fatta && FF.fatta.at; if (!ta || !at) return;
  ffSegnaRisposta(at, { nota: ta.value.trim() });
}
function ffNotaChiudi(){
  ffNotaScrivi();
  ffSheetClose();
  const n = ffNotaLeggi(), b = document.querySelector('#ffdNota span');
  if (b) b.textContent = n ? n : 'Aggiungi note alla sessione';
  const bt = document.getElementById('ffdNota'); if (bt) bt.classList.toggle('scritta', !!n);
}

/* ---------------------------------------------------------------------------------------
   «HAI COMPLETATO LA TASK?»
   L'ultimo passo dopo la piantina e lo scrigno. Si': la priorita' si spunta, e alla riserva
   arriva il bonus di concentrazione piu' quello di completamento. Non ancora: solo il bonus
   di concentrazione, e mai un rimprovero — la concentrazione c'e' stata comunque.
   La risposta e' autodichiarata: resta scritta (completed_self_reported) e un arbitro esterno
   puo' stornare il completamento se la task risulta ancora aperta.
   --------------------------------------------------------------------------------------- */
function ffBonusTxt(v){ return (typeof dpDelta === 'function') ? dpDelta(v) : '+' + v.toFixed(1); }
function ffChiediCompletata(c){
  const vecchio = document.getElementById('ffAsk'); if (vecchio) vecchio.remove();
  const box = document.createElement('div');
  box.id = 'ffAsk'; box.className = 'ff-ask';
  box.innerHTML = '<div class="ff-ask-card">'
    + '<div class="ff-ask-ico">\u2705</div>'
    + '<b class="ff-ask-t">Hai completato la task di questa sessione?</b>'
    + (c.task ? '<p class="ff-ask-task">' + esc(c.task) + '</p>' : '')
    + '<button type="button" class="cta" onclick="ffRispondi(true)">S\u00ec, completata</button>'
    + '<button type="button" class="ff-ask-no" onclick="ffRispondi(false)">Non ancora</button>'
    + '</div>';
  box.dataset.at = String(c.at); box.dataset.min = String(c.min); box.dataset.task = c.task || ''; box.dataset.one = c.daOne ? '1' : ''; box.dataset.stima = String(c.stima || c.min || 0);
  (document.getElementById('phone') || document.body).appendChild(box);
}
function ffSegnaRisposta(at, patch){
  const h = ffHist();
  const x = h.filter(function(e){ return e && e.at === at; })[0];
  if (!x) return;
  Object.assign(x, patch);
  ffWrite('fl_ff_hist', h);
}
function ffRispondi(si){
  const box = document.getElementById('ffAsk');
  if (!box) return;
  const at = +box.dataset.at, min = +box.dataset.min || 0, task = box.dataset.task || '';
  const conc = (typeof dmFFBonus === 'function' && typeof DM_CFG !== 'undefined') ? dmFFBonus(min, DM_CFG) : 0;
  if (si){
    ffSegnaRisposta(at, { completata: true, completed_self_reported: true, task: task, rispostaAt: Date.now() });
    if (box.dataset.one && typeof stOneComplete === 'function') stOneComplete(true);
    ffStimaSegna(task, +box.dataset.stima || 0, min, true);
    /* il punto prenotato dopo la chiamata dei sogni: chiusa in FullFocus, si conferma */
    try{ if (typeof pkConfermaTask === 'function') pkConfermaTask(task, Date.now()); }catch(_){ }
    const tot = conc + ((typeof DM_CFG !== 'undefined') ? DM_CFG.ffCompletata : 0);
    /* 0.9.214: il carburante promesso dal foglio del tempo, se chiusa entro il tempo scelto */
    let carb = 0; try{ if (typeof fcTaskChiusa === 'function') carb = fcTaskChiusa(task, min); }catch(_){ }
    toast(carb ? '⛽ Task chiusa nel tempo: +' + carb + ' carburante' : 'Task completata: riserva di dopamina ' + ffBonusTxt(tot));
    try{ if (typeof fcRidisegna === 'function') fcRidisegna(); }catch(_){ }
    /* la prossima cosa da fare e' gia' pronta: la riga dopo del foglio, o la prossima tappa della roadmap */
    const dopo = ffProssimaTask(task);
    const card0 = box.querySelector('.ff-ask-card');
    if (dopo && card0){
      const p = ffPref(); p.intent = dopo.slice(0, 250); ffSavePref(); try{ ffPaint(); }catch(_){ }
      card0.innerHTML = '<div class="ff-ask-ico">\ud83d\ude80</div><b class="ff-ask-t">Fatto. Adesso tocca a questa</b><p class="ff-ask-task">' + esc(dopo) + '</p>'
        + '<button type="button" class="cta" onclick="ffChiudiDomanda();setTimeout(ffStart,200)">Accendi la prossima stella</button>'
        + '<button type="button" class="ff-ask-no" onclick="ffChiudiDomanda()">Più tardi</button>';
    } else {
      box.remove();
      if (typeof ifDopoFocus === 'function') ifDopoFocus();
    }
  } else {
    ffSegnaRisposta(at, { completata: false, task: task, rispostaAt: Date.now() });
    const card = box.querySelector('.ff-ask-card');
    if (card) card.innerHTML = '<div class="ff-ask-ico">\ud83c\udf31</div>'
      + '<b class="ff-ask-t">' + min + ' minuti di concentrazione vera.</b>'
      + '<p class="ff-ask-task">Quanto ti manca per finirla, secondo te?</p>'
      + '<div class="ff-manca">' + [15, 30, 60].map(function(v){ return '<button type="button" onclick="ffMancaScegli(' + v + ')">' + (v === 60 ? '1 ora' : v + ' min') + '</button>'; }).join('') + '</div>'
      + '<button type="button" class="ff-ask-no" onclick="ffChiudiDomanda()">Non lo so</button>';
    ffStimaSegna(task, +box.dataset.stima || 0, min, false);
  }
  try{ if (typeof dpCalcola === 'function') dpCalcola(true).then(function(){ if (typeof dpRidipingi === 'function') dpRidipingi(); }); }catch(_){ }
}
/* "Il Genio deve imparare a stimare": per ogni task quanto avevi previsto e quanto ci e' voluto davvero */
function ffStime(){ return ffRead('fl_ff_stime', []); }
function ffStimaSegna(task, stima, reale, fatta, manca){
  const l = ffStime(); l.push({ t: String(task || '').slice(0, 120), stima: stima, reale: reale, fatta: !!fatta, manca: manca || 0, at: Date.now() });
  ffWrite('fl_ff_stime', l.slice(-60));
}
function ffMancaScegli(v){
  const l = ffStime(), u = l[l.length - 1]; if (u){ u.manca = v; ffWrite('fl_ff_stime', l); }
  const p = ffPref(); p.minutes = v; ffSavePref(); try{ ffPaint(); }catch(_){ }
  try{ flVibra(10); }catch(_){ }
  ffChiudiDomanda();
}
/* per il tuo agente personale */
function ffStimeTesto(){
  const l = ffStime().slice(-12); if (!l.length) return '';
  return 'QUANTO CI METTE DAVVERO (task a fine sessione di Full Focus: minuti previsti, minuti fatti, esito. Usalo per dare stime giuste):\n' + l.map(function(x){ return '- "' + x.t + '": previsti ' + x.stima + ', fatti ' + x.reale + ', ' + (x.fatta ? 'finita' : 'non finita' + (x.manca ? ', ne mancano ' + x.manca : '')); }).join('\n');
}
function ffProssimaTask(fatta){
  const norm = function(s){ return String(s || '').replace(/^[☐☑•\-\s]+/, '').trim().toLowerCase(); };
  try{
    const righe = (typeof stLines === 'function') ? stLines('today') : [];
    const fatte = (typeof stDone === 'function') ? stDone().map(function(x){ return norm(x.text); }) : [];
    const r = righe.filter(function(x){ return norm(x) !== norm(fatta) && fatte.indexOf(norm(x)) < 0 && !/^☑/.test(x); })[0];
    if (r) return String(r).replace(/^[☐•\-\s]+/, '').trim();
  }catch(_){ }
  try{
    const c = (typeof sdCorrente === 'function') ? sdCorrente() : null, n = c && c.nodo;
    const t = n && typeof sdNomeTappa === 'function' ? sdNomeTappa(n) : '';
    if (t && norm(t) !== norm(fatta)) return String(t).replace(/\s*·\s*(oggi|domani)\s*$/i, '').trim();
  }catch(_){ }
  return '';
}
function ffRipianifica(){
  const box = document.getElementById('ffAsk'); if (box) box.remove();
  goId('s-home');
  if (typeof switchTab === 'function') switchTab('sveglia');
  if (typeof ifDopoFocus === 'function') ifDopoFocus();
}
function ffChiudiDomanda(){
  const box = document.getElementById('ffAsk'); if (box) box.remove();
  if (typeof ifDopoFocus === 'function') ifDopoFocus();
}
/** Lo storno del completamento: lo chiede l'arbitro esterno quando la task risulta ancora aperta. */
function ffStorna(at, motivo){
  const h = ffHist();
  const x = h.filter(function(e){ return e && Math.abs((e.at || 0) - at) < 60000 && e.completata; })[0];
  if (!x || x.stornato) return false;
  x.stornato = { t: Date.now(), motivo: String(motivo || '') };
  ffWrite('fl_ff_hist', h);
  return true;
}

registerScreen('s-ff-forest', `
  <div class="topbar ffo-top"><button class="iconbtn" onclick="goId('s-fullfocus')" aria-label="Indietro">‹</button><b class="blk-title" id="ffoTitolo">La tua foresta</b><span></span></div>
  <div id="ffForestBody"></div>
`, { back: 's-fullfocus' });

registerOverlay('ffSheetWrap', `
  <div class="ff-scrim" onclick="ffSheetClose()"></div>
  <div class="ff-sheet" id="ffSheet"></div>
`);

function ffOpen(){
  ffPref();
  /* Le app installate si leggono ADESSO, non quando si apre l'elenco consentito: leggerle
     costa un secondo abbondante, e un secondo speso mentre la persona guarda il timer non lo
     nota nessuno, mentre lo stesso secondo con il foglio gia' aperto sembra un blocco. */
  if (typeof ffPreloadApps === 'function') ffPreloadApps();
  /* E viceversa: se il foglio e' cambiato da quando la sessione e' stata impostata, comanda
     il foglio — e' li' che si decide cosa fare. */
  /* la cosa rimasta nell'esercizio Taglia e' il compito gia' scritto della prossima sessione */
  try{ if (typeof esTagliaPerFF === 'function') esTagliaPerFF(); }catch(_){ }
  if (typeof stSyncToFF === 'function') stSyncToFF();
  goId('s-fullfocus');
  ffPaint();
  ffResume();
}
function ffClose(){
  if (FF.run && FF.run.mode === 'stay' && FF.run.intensive){ toast('Sessione intensiva in corso: se esci la stella si spegne'); }
  goId('s-home');
}

/* The plant: five stages, from a seed to a flower. The rare one (level 6) has another
   colour and a second bloom. */
/* 0.9.322, Andrea: "cosa c'entrano le piante, se si decolla verso lo spazio? Far brillare il tuo sogno in un cielo stellato,
   insieme alle stelle degli altri sognatori". La sfera e' un pezzo di cielo: un puntino all'inizio, una stella piena alla fine. */
function ffStellaDi(stage, rare){
  const s = [.26, .4, .56, .74, 1][Math.max(0, Math.min(4, stage))], c = rare ? '#FFE9A8' : '#FFFFFF', alone = rare ? '#FFC94D' : '#8CC6FF';
  const g = 'ffAlone' + (rare ? 'R' : 'B');
  return '<defs><radialGradient id="' + g + '"><stop offset="0" stop-color="' + c + '" stop-opacity=".95"/><stop offset=".3" stop-color="' + alone + '" stop-opacity=".55"/><stop offset="1" stop-color="' + alone + '" stop-opacity="0"/></radialGradient></defs>'
    + '<circle cx="100" cy="90" r="' + (88 * s).toFixed(1) + '" fill="url(#' + g + ')"/>'
    + '<g transform="translate(100 90) scale(' + s.toFixed(2) + ')"><path class="ff-st-p" d="M0-78C5-22 22-5 78 0 22 5 5 22 0 78-5 22-22 5-78 0-22-5-5-22 0-78Z" fill="' + c + '"/>'
    + (stage >= 3 ? '<path class="ff-st-p2" d="M0-42C2-10 10-2 42 0 10 2 2 10 0 42-2 10-10 2-42 0-10-2-2-10 0-42Z" fill="' + c + '" transform="rotate(45)" opacity=".75"/>' : '') + '</g>';
}
const FF_ALTRE = [[30, 40], [52, 118], [166, 46], [176, 130], [84, 24], [128, 150], [24, 86], [150, 18], [60, 158], [186, 88]];
function ffCielino(stage){
  return FF_ALTRE.map(function(p, i){ const on = i < (stage + 1) * 2; return '<circle class="ff-altra' + (on ? ' on' : '') + '" style="--d:' + (i * .4).toFixed(1) + 's" cx="' + p[0] + '" cy="' + p[1] + '" r="' + (1.2 + (i % 3) * .5) + '"/>'; }).join('');
}
function ffPlantSvg(stage, rare){
  return '<svg viewBox="0 0 200 180" role="img" aria-label="La tua stella">' + ffCielino(stage) + ffStellaDi(stage, rare) + '</svg>';
}
/* la stella spenta: quello che resta di una sessione mollata */
function ffPlantWithered(){
  return '<svg viewBox="0 0 200 180" role="img" aria-label="Stella spenta">' + ffCielino(0) + '<g transform="translate(100 90) scale(.42)"><path d="M0-78C5-22 22-5 78 0 22 5 5 22 0 78-5 22-22 5-78 0-22-5-5-22 0-78Z" fill="#5B6F8C"/></g></svg>';
}

function ffPaint(){
  const p = ffPref(), tag = ffTag();
  const set = (id, v) => { const e = document.getElementById(id); if (e) e.textContent = v; };
  set('ffCoins', ffCoins());
  set('ffTagName', tag.name);
  const dot = document.getElementById('ffTagDot'); if (dot) dot.style.background = tag.col;
  const it = document.getElementById('ffIntent'); if (it){ it.textContent = p.intent || 'Dedicherò questo tempo a…'; it.classList.toggle('set', !!p.intent); }
  const plant = document.getElementById('ffPlant');
  const rare = typeof lvHas === 'function' && lvHas('plant:rare');
  const cta = document.getElementById('ffCta');
  const runbox = document.getElementById('ffRun');
  const timeBtn = document.getElementById('ffTime');
  if (timeBtn) timeBtn.classList.toggle('running', !!FF.run);
  /* Col timer acceso la pagina si svuota: niente indietro, niente monete, niente foresta.
     Sono tutte porte, e una sessione di concentrazione e' una stanza senza porte. Resta il
     suono, in alto a destra, perche' e' l'unica cosa che puo' servire mentre si lavora. */
  const scr = document.getElementById('s-fullfocus');
  if (scr) scr.classList.toggle('running', !!FF.run && !ffInGrace());
  ffSndLabel();
  if (FF.run){
    const left = ffLeft();
    const prog = 1 - left / (FF.run.minutes * 60000);
    /* LA SFERA SI ACCENDE: come quella del Genio, brilla di piu' man mano che la sessione
       va avanti. E' la stessa idea della Rotta: le azioni giuste illuminano la previsione. */
    if (scr) scr.style.setProperty('--ffglow', String(Math.max(0, Math.min(1, prog))));
    if (plant) plant.innerHTML = ffPlantSvg(Math.min(4, Math.floor(prog * 5)), rare);
    set('ffTime', ffFmt(left));
    const grace = ffInGrace();
    if (cta){
      cta.hidden = !grace;
      cta.textContent = grace ? 'Annulla (' + Math.ceil((FF.run.graceUntil - Date.now()) / 1000) + ')' : '';
      cta.disabled = false;
      cta.classList.toggle('ff-cancel', grace);
    }
    if (runbox) runbox.hidden = grace;
    const pb = document.getElementById('ffPause');
    if (pb){ pb.classList.toggle('on', !!FF.run.pausedAt); pb.hidden = !ffPausaPermessa(); }
  } else {
    if (scr) scr.style.setProperty('--ffglow', '0');
    if (plant && !plant.dataset.hold) plant.innerHTML = ffPlantSvg(0, rare);
    const st0 = document.getElementById('ffStatus'); if (st0){ st0.hidden = true; st0.textContent = ''; }
    set('ffTime', ffFmt(p.minutes * 60000));
    if (cta){ cta.hidden = false; cta.textContent = 'Accendi la tua stella'; cta.disabled = false; cta.classList.remove('ff-cancel'); }
    if (runbox) runbox.hidden = true;
    /* in mezzo a un ciclo: la pausa, e il pulsante per la sessione dopo */
    if (typeof ffcPaint === 'function') ffcPaint();
  }
}
/* Il pulsante fa partire e basta. Il timer si cambia toccando il numero — è lì che va il
   pollice di chi vuole cambiarlo, ed è così che funziona nell'app a cui somiglia. */
function ffPrimary(){
  if (!FF.run && typeof ffcInPausa === 'function' && ffcInPausa()){ ffcProssimaOra(); return; }
  if (!FF.run){ ffStart(); return; }
  /* Dentro ai dieci secondi il pulsante annulla, e non e' una rinuncia: non c'e' niente da
     far appassire, non c'e' niente da segnare. */
  if (ffInGrace()) ffCancelGrace();
}
function ffInGrace(){ return !!(FF.run && FF.run.graceUntil && Date.now() < FF.run.graceUntil); }
/* I minuti che restano, tenendo conto della pausa. */
function ffLeft(){
  if (!FF.run) return 0;
  if (FF.run.pausedAt) return FF.run.endAt - FF.run.pausedAt;
  return FF.run.endAt - Date.now();
}
async function ffCancelGrace(){
  const run = FF.run;
  if (!run) return;
  FF.run = null; clearInterval(FF.tick); FF.tick = null;
  ffSchermoApplica();
  try{ localStorage.removeItem('fl_ff_session'); }catch(_){ }
  ffSoundStop();
  /* annullare la prima sessione di un ciclo annulla il ciclo: niente pausa, niente sessione dopo */
  if (run.ciclo && typeof ffcStop === 'function') await ffcStop();
  await ffEndSession(run);
  ffPaint();
  /* Niente messaggio: annullare entro dieci secondi non e' successo niente, e dirlo a voce
     alta fa sembrare che invece qualcosa sia successo. */
}
/* La pausa ferma il conto alla rovescia ma NON disarma il blocco: mettere in pausa per aprire
   Instagram sarebbe un'uscita di servizio, e le uscite di servizio le conosce solo chi le
   costruisce. */
function ffPauseToggle(){
  const run = FF.run;
  if (!run || ffInGrace()) return;
  if (run.pausedAt){ ffPausaRiprendi(); return; }
  if (!ffPausaPermessa()) return;
  run.pausedAt = Date.now();
  run.pausaFine = run.pausedAt + ffPausaMin() * 60000;
  /* il telefono chiude la sessione all'orario che sa: in pausa quell'orario si sposta di quanto dura la pausa,
     altrimenti la sveglia di fine la chiuderebbe (e farebbe partire la pausa del ciclo) */
  ffTellEngine(ffFineVera(run), run);
  ffWrite('fl_ff_session', run);
  ffPaint();
  ffPausaVelo();
}
/* 0.9.315, Andrea (ritratto di Forest): la pausa e' una schermata a tutto schermo, sfocata, con il conto alla rovescia:
   alla fine la sessione riparte da sola. Si puo' togliere, e se ne sceglie la durata, nelle Impostazioni del Full Focus. */
const FF_PAUSA_MIN = 5;
function ffPausaPermessa(){ return ffPref().pausaNo !== true; }
function ffPausaMin(){ return +ffPref().pausaMin || FF_PAUSA_MIN; }
function ffPausaPrefToggle(){ const p = ffPref(); p.pausaNo = !p.pausaNo; ffSavePref(); ffImpostazioniApri(); }
function ffPausaMinSet(v){ ffPref().pausaMin = v; ffSavePref(); ffImpostazioniApri(); }
function ffFineVera(run){ return run.pausedAt ? run.endAt + Math.max(0, (run.pausaFine || run.pausedAt) - run.pausedAt) : run.endAt; }
function ffPausaRiprendi(){
  const run = FF.run; if (!run || !run.pausedAt) return;
  const fino = run.pausaFine ? Math.min(Date.now(), run.pausaFine) : Date.now();
  const durata = Math.max(0, fino - run.pausedAt);
  run.endAt += durata; run.pausaTot = (run.pausaTot || 0) + durata;
  run.pausedAt = 0; run.pausaFine = 0;
  ffTellEngine(run.endAt, run);
  ffWrite('fl_ff_session', run);
  ffPausaVeloVia();
  ffPaint();
}
function ffPausaVeloHtml(testo, resta, azione, etichetta){
  return '<div class="ffp-c"><p class="ffp-t">' + testo + '</p><div class="ffp-n" id="ffpN">' + ffFmt(resta) + '</div>'
    + '<button type="button" class="ffp-play" onclick="' + azione + '" aria-label="' + etichetta + '"><svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor" aria-hidden="true"><path d="M8 5.200v13.600a1 1 0 001.500.860l11-6.800a1 1 0 000-1.720l-11-6.800A1 1 0 008 5.200z"/></svg></button></div>';
}
function ffPausaVeloDom(){
  let w = document.getElementById('ffPausaV');
  if (!w){ w = document.createElement('div'); w.id = 'ffPausaV'; w.className = 'ffp'; w.setAttribute('role', 'dialog'); w.setAttribute('aria-modal', 'true'); (document.getElementById('phone') || document.body).appendChild(w); }
  return w;
}
function ffPausaVelo(){
  const run = FF.run; if (!run || !run.pausedAt) return;
  const w = ffPausaVeloDom(), resta = Math.max(0, (run.pausaFine || 0) - Date.now());
  if (!document.getElementById('ffpN')){
    w.innerHTML = ffPausaVeloHtml('Concentrazione in pausa. Riprendi tra...', resta, 'ffPausaRiprendi()', 'Riprendi adesso');
    /* 0.9.350, Andrea: in pausa si appunta la distrazione (ff-distrazioni.js), e stasera la si taglia in Taglia */
    try{ if (typeof ffdAppuntoMonta === 'function') ffdAppuntoMonta(w); }catch(_){ }
  }
  else document.getElementById('ffpN').textContent = ffFmt(resta);
}
function ffPausaVeloVia(){
  /* la pausa finita da sola non butta l'appunto scritto a meta' */
  try{ if (typeof ffdAppuntoBozza === 'function') ffdAppuntoBozza(); }catch(_){ }
  const w = document.getElementById('ffPausaV'); if (w) w.remove();
}
/* "Prenditi una pausa" dalla schermata finale: la sessione e' chiusa, il telefono e' libero; a tempo scaduto si torna al timer */
function ffPausaLiberaApri(){
  FF.libera = Date.now() + ffPausaMin() * 60000;
  ffPausaVeloDom().innerHTML = ffPausaVeloHtml('Goditi la pausa. Riprendi tra...', FF.libera - Date.now(), 'ffPausaLiberaFine()', 'Riprendi adesso');
  clearInterval(FF.liberaT);
  FF.liberaT = setInterval(function(){
    const n = document.getElementById('ffpN'), r = (FF.libera || 0) - Date.now();
    if (!n || r <= 0){ ffPausaLiberaFine(r <= 0); return; }
    n.textContent = ffFmt(r);
  }, 1000);
}
function ffPausaLiberaFine(scaduta){
  clearInterval(FF.liberaT); FF.liberaT = 0; FF.libera = 0;
  ffPausaVeloVia();
  if (scaduta === true){ try{ flVibra([30, 60, 30]); }catch(_){ } }
  ffDoneClose();
}

/* ---- the tag, the intention ---- */
/* Il foglio sale dal basso e scende quando si chiude. Prima appariva e basta: un pannello che
   compare senza venire da nessuna parte sembra un errore di disegno, non una scelta. */
function ffSheetOpen(html){
  const w = document.getElementById('ffSheetWrap'), s = document.getElementById('ffSheet');
  if (!w || !s) return;
  s.innerHTML = html;
  w.classList.remove('closing');
  w.classList.add('open');
  requestAnimationFrame(function(){ w.classList.add('in'); });
  if (typeof flRangeAll === 'function') flRangeAll(s);
}
function ffSheetClose(){
  const w = document.getElementById('ffSheetWrap');
  if (!w || !w.classList.contains('open')) return;
  w.classList.remove('in');
  w.classList.add('closing');
  setTimeout(function(){ w.classList.remove('open', 'closing'); }, 280);
  /* e quando il foglio se ne va, la schermata dietro e' ridisegnata con quello che c'e' dentro */
  if (!FF.run){ try{ ffPaint(); }catch(_){ } }
}
function ffTagsOpen(){
  const p = ffPref();
  ffSheetOpen('<div class="ff-sh-title">Tag</div><div class="ff-tags">' + ffTags().map(t =>
    '<button type="button" class="ff-tagbtn' + (t.id === p.tag ? ' on' : '') + '" onclick="ffTagSet(\'' + t.id + '\')"><i style="background:' + t.col + '"></i>' + esc(t.name) + '</button>').join('')
    + '</div><div class="ff-newtag"><input class="fin" id="ffNewTag" placeholder="Nuovo tag" maxlength="24" autocomplete="off"><button type="button" class="ff-tag-add" onclick="ffTagAdd()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg><span>Aggiungi</span></button></div>');
}
function ffTagSet(id){ ffPref().tag = id; ffSavePref(); ffSheetClose(); ffPaint(); }
function ffTagAdd(){
  const inp = document.getElementById('ffNewTag'); const name = inp ? inp.value.trim() : '';
  if (!name){ toast('Scrivi il nome del tag'); return; }
  const tags = ffTags(); const cols = ['#F5A623', '#5B8DEF', '#E58FB5', '#E5515F', '#4CD39A', '#3FC7C9', '#005BB0'];
  const id = 't' + Date.now();
  tags.push({ id: id, name: name, col: cols[tags.length % cols.length] });
  ffWrite('fl_ff_tags', tags); ffPref().tag = id; ffSavePref(); ffSheetClose(); ffPaint();
}
function ffIntentOpen(){
  const p = ffPref();
  ffSheetOpen('<div class="ff-sh-title">Dedicherò questo tempo a…</div><textarea class="fin ff-ta" id="ffIntentIn" maxlength="250" rows="3" placeholder="es. finire il capitolo 3">' + esc(p.intent || '') + '</textarea>'
    + '<div class="ff-count"><span id="ffIntentN">' + (p.intent || '').length + '</span>/250</div>'
    + '<button type="button" class="cta" onclick="ffIntentSave()">Salva</button>');
  const ta = document.getElementById('ffIntentIn'); if (ta){ ta.addEventListener('input', () => { const n = document.getElementById('ffIntentN'); if (n) n.textContent = ta.value.length; }); setTimeout(() => ta.focus(), 120); }
}
function ffIntentSave(){
  const ta = document.getElementById('ffIntentIn');
  const v = ta ? ta.value.trim() : '';
  ffPref().intent = v;
  ffSavePref();
  /* L'intenzione della sessione e la prima riga del foglio della scheda START sono la stessa
     frase: scritta qui, si ritrova la'. */
  if (typeof stSyncFromFF === 'function') stSyncFromFF(v);
  ffSheetClose();
  ffPaint();
}

/* ---- the timer sheet: minutes, intensive, allowed apps, sound ---- */
/* Il righello.
   Lo slider aveva due difetti: la barra di riempimento restava indietro rispetto al pollice, e
   soprattutto non si capiva su che valore si fosse finiti finché non si leggeva il numero. Un
   righello a tacche dice dove sei mentre ti muovi: le tacche grosse sono i quarti d'ora, la
   tacca nera è il valore scelto. È più preciso perché ogni tacca è un valore, non un pixel. */
/* I preset: le durate che si scelgono davvero, piu' una voce per scrivere la tua. Cinque
   minuti non c'e' piu' — una sessione di cinque minuti resta possibile dal righello, ma come
   proposta era l'invito a non cominciare niente.

   TUTTE SU UNA RIGA SOLA, anche quando non ci stanno: la riga scorre di lato. Andando a capo
   la voce «Scegli tu» finiva sotto, da sola, e sembrava un'altra cosa invece dell'ultima di
   una fila.

   IL NUMERO CHE COMPARIVA DA SOLO. L'ultima pillola mostrava il minutaggio ogni volta che non
   coincideva con un preset — quindi anche quando quel numero era il valore di partenza, o
   quello lasciato li' dal righello. «Un numero che io non ho scritto»: esatto. Adesso il
   numero compare SOLO se la scelta e' stata fatta davvero (`pick`), e in tutti gli altri casi
   la pillola dice quello che e': Scegli tu. */
const FF_PRESETS = [15, 30, 60];

function ffPresChipsHtml(minutes, max){
  const chips = FF_PRESETS.filter(function(m){ return m <= max; }).map(function(m){
    return '<button type="button" class="ff-pre' + (minutes === m ? ' on' : '') + '" onclick="ffPreset(' + m + ')">'
      + (m >= 60 ? (m / 60) + 'h' : m + 'm') + '</button>';
  }).join('');
  const suo = ffPref().pick === 'custom' && FF_PRESETS.indexOf(minutes) < 0;
  return chips
    + '<button type="button" class="ff-pre ff-pre-x' + (suo ? ' on' : '') + '" onclick="ffCustomOpen()">'
    + (suo ? minutes + ' min' : 'Scegli tu') + '</button>';
}

/* Le pillole si ridisegnano da sole a ogni cambio di minuti — anche mentre il dito trascina il
   righello. Prima no: il numero grande diceva «5 min» e la pillola restava accesa su «50 min»,
   due verita' diverse nello stesso riquadro. */
function ffPresPaint(){
  const r = document.getElementById('ffPres');
  if (!r) return;
  const max = typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 90;
  r.innerHTML = ffPresChipsHtml(ffPref().minutes, max);
}

function ffPresetsHtml(minutes, max){
  return '<div class="ff-pres" id="ffPres">' + ffPresChipsHtml(minutes, max) + '</div>'
    + '<div class="ff-custom" id="ffCustom" hidden>'
    +   '<input id="ffCustomIn" type="number" min="1" max="' + max + '" inputmode="numeric" placeholder="minuti"'
    +     ' onkeydown="if(event.key===\'Enter\'){event.preventDefault();ffCustomSet();}">'
    +   '<button type="button" class="ghostmini" onclick="ffCustomSet()">Imposta</button>'
    + '</div>';
}

/* Toccare un preset non rifa' il foglio: cambia il numero, le pillole e la tacca. Rifarlo
   chiudeva la tendina dei suoni e riportava in cima chi stava guardando altro. */
function ffPreset(m){
  ffMinChange(m, 'preset');
  const b = document.getElementById('ffCustom');
  if (b) b.hidden = true;
}
function ffCustomOpen(){
  const b = document.getElementById('ffCustom');
  if (!b) return;
  b.hidden = !b.hidden;
  if (!b.hidden){
    const i = document.getElementById('ffCustomIn');
    /* Il campo si apre VUOTO, a meno che il numero dentro non sia gia' tuo: riempirlo con il
       valore di partenza e' lo stesso difetto della pillola, in piccolo. */
    if (i){ i.value = ffPref().pick === 'custom' ? ffPref().minutes : ''; i.focus(); }
  }
}
function ffCustomSet(){
  const i = document.getElementById('ffCustomIn');
  const max = typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 90;
  const v = Math.round(+(i ? i.value : 0) || 0);
  if (v < 1){ toast('Scrivi quanti minuti'); return; }
  if (v > max){ toast('Al tuo livello arrivi a ' + max + ' minuti'); return; }
  ffMinChange(v, 'custom');
  const b = document.getElementById('ffCustom');
  if (b) b.hidden = true;
}

function ffRulerHtml(minutes, max){
  const step = 5;
  const items = [];
  for (let m = 5; m <= max; m += step){
    const big = m % 15 === 0;
    items.push('<i class="ff-tick' + (big ? ' big' : '') + (m === minutes ? ' on' : '') + '" data-m="' + m + '"></i>');
  }
  return '<div class="ff-ruler" id="ffRuler" data-max="' + max + '">' + items.join('') + '</div>';
}
/* Il foglio del timer, rifatto per lo spazio.
   Prima aveva quattro gruppi diversi impilati a 10px l'uno dall'altro: il numero, il righello,
   l'interruttore e i suoni finivano nella stessa banda visiva e l'occhio non sapeva dove
   guardare per primo. Adesso ogni gruppo e' separato dal successivo di 32px, il pannello
   dell'intensiva ha 18px di aria dentro, e i suoni sono in una tendina chiusa, in fondo,
   lontani dall'interruttore: sono una preferenza, non una decisione. */
function ffTimerOpen(){
  /* 0.9.315, Andrea: a sessione partita il foglio del timer non si riapre */
  if (FF.run) return;
  const p = ffPref();
  const max = typeof lvMaxMinutes === 'function' ? lvMaxMinutes() : 90;
  if (p.minutes > max) p.minutes = max;
  const n = (p.allow || []).length + (p.allowSites || []).length;
  /* a sinistra l'ingranaggio (cicli con pausa, partenza automatica), a destra «da solo o in
     gruppo» com'era: due angoli, due cose (0.9.202, come l'ha chiesto Andrea) */
  ffSheetOpen('<div class="ff-sh-head"><button type="button" class="ff-who ff-gear" onclick="ffImpostazioniApri()" aria-label="Impostazioni del Full Focus">⚙️'
    +   ((typeof ffcCicli === 'function' && ffcCicli().on) ? '<i class="ff-who-dot"></i>' : '') + '</button>'
    + '<div class="ff-sh-title">Timer</div>'
    + '<button type="button" class="ff-who" onclick="ffCompanyOpen()" aria-label="Da solo o in gruppo">'
    +   '<svg viewBox="0 0 20 20" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M10 10a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 1.5c-3.6 0-6.5 1.9-6.5 4.2V18h13v-2.3c0-2.3-2.9-4.2-6.5-4.2Z"/></svg>'
    +   (p.company === 'group' ? '<i class="ff-who-dot"></i>' : '') + '</button></div>'
    + '<div class="ff-minbox">'
    +   '<div class="ff-min" id="ffMinLbl">' + p.minutes + ' min</div>'
    +   ffPresetsHtml(p.minutes, max)
    +   ffRulerHtml(p.minutes, max)
    +   '<div class="ff-hint">Fino a ' + max + ' minuti al tuo livello' + (max < 180 ? ' · i livelli successivi sbloccano sessioni più lunghe' : '') + '</div>'
    +   ((typeof ffcCicli === 'function' && ffcCicli().on) ? '<button type="button" class="ff-hint ff-hint-cicli" onclick="ffImpostazioniApri()">🍅 ' + ffcCicli().sessioni + ' sessioni di fila, pausa ' + ffcCicli().pausa + ' min ›</button>' : '')
    + '</div>'
    + '<div class="ff-opt"><div><b>Concentrazione intensiva</b><small id="ffIntTxt">' + ffIntCopy(p) + '</small>'
    + (p.intensive ? '<button type="button" class="ff-link" onclick="ffAllowOpen()">Lista delle app consentite' + (n ? ' (' + n + ')' : '') + '</button>' : '') + '</div>'
    + '<button type="button" class="switch' + (p.intensive ? ' on' : '') + '" id="ffIntSw" onclick="ffIntToggle()"></button></div>'
    + '<button type="button" class="cta ff-go" onclick="ffSheetClose();ffStart()">Inizia la concentrazione</button>');
  ffRulerBind();
}

/* La tendina del suono: chiusa quando il foglio si apre, perche' il suono e' l'ultima cosa che
   si decide e la prima che distrae se sta aperta sotto al naso. Stessa forma della tendina in
   fondo alla scheda START: testa con icona, sottotitolo che dice cosa sta suonando, freccia. */
function ffSoundBoxHtml(p){
  const cur = FF_SOUNDS.filter(function(x){ return x.id === p.sound; })[0];
  return '<div class="ff-sndbox" id="ffSndBox">'
    + '<button type="button" class="ff-sndhead" onclick="ffSoundToggle()">'
    +   '<span class="ico">🎵</span>'
    +   '<div><b>Suono di sottofondo</b><small id="ffSndSub">' + esc(cur && cur.id !== 'none' ? cur.name : 'Nessuno') + '</small></div>'
    +   '<svg class="fl-arrdown" viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" d="M6 9l6 6 6-6"/></svg>'
    + '</button>'
    + '<div class="ff-sndbody"><div class="ff-sounds">' + FF_SOUNDS.map(function(x){
        const ok = !x.grant || (typeof lvHas === 'function' && lvHas(x.grant));
        const lv = x.grant && typeof lvLevelFor === 'function' ? lvLevelFor(x.grant) : 1;
        return '<button type="button" class="ff-snd' + (p.sound === x.id ? ' on' : '') + (ok ? '' : ' locked') + '" onclick="'
          + (ok ? 'ffSoundSet(\'' + x.id + '\')' : 'toast(\'Si sblocca al livello ' + lv + '\')') + '">' + (ok ? '' : '🔒 ') + esc(x.name) + '</button>';
      }).join('') + '</div></div></div>';
}
function ffSoundToggle(){ const b = document.getElementById('ffSndBox'); if (b) b.classList.toggle('open'); }
/* Mentre il dito è giù cambia SOLO l'etichetta: ffPaint() riscrive tutto il pannello, e
   riscriverlo a metà trascinamento significa distruggere l'elemento che si sta trascinando.
   Il ridisegno arriva a dito staccato, con onchange. */
function ffMinChange(v, come){
  const p = ffPref();
  p.minutes = +v;
  /* Da dove viene questo numero: da un preset, o scelto da te (righello o campo). E' l'unica
     cosa che distingue «30 minuti perche' li hai scelti» da «30 minuti perche' qualcuno doveva
     pur scrivere qualcosa». */
  if (come) p.pick = come;
  ffSavePref();
  const l = document.getElementById('ffMinLbl');
  if (l) l.textContent = v + ' min';
  /* IL NUMERO GRANDE DIETRO AL FOGLIO. Cambiava solo la riga dentro al foglio: chiuso il
     foglio si vedeva ancora il tempo di prima, fino a «Inizia la concentrazione». */
  if (!FF.run){ const big = document.getElementById('ffTime'); if (big) big.textContent = ffFmt(+v * 60000); }
  ffPresPaint();
  const r = document.getElementById('ffRuler');
  if (r) r.querySelectorAll('.ff-tick').forEach(function(t){ t.classList.toggle('on', +t.dataset.m === +v); });
}

/* La frase sotto all'interruttore cambia con la modalità: dire "la pianta appassisce" quando
   il punto è un altro non aiuta nessuno a capire cosa sta accendendo. */
function ffIntCopy(p){
  return 'Durante la concentrazione puoi usare solo le app nella tua lista consentita.';
}

/* Il trascinamento sul righello: la tacca sotto al dito diventa il valore. */
function ffRulerBind(){
  const r = document.getElementById('ffRuler');
  if (!r || r._bound) return;
  r._bound = 1;
  const pick = x => {
    const ticks = r.querySelectorAll('.ff-tick');
    if (!ticks.length) return;
    let best = ticks[0], bd = 1e9;
    ticks.forEach(t => {
      const b = t.getBoundingClientRect();
      const d = Math.abs(b.left + b.width / 2 - x);
      if (d < bd){ bd = d; best = t; }
    });
    const m = +best.dataset.m;
    if (m === ffPref().minutes) return;
    ticks.forEach(t => t.classList.toggle('on', t === best));
    /* 0.9.308, Andrea: "come in Opal e Forest, il righello vibra sotto al dito". Un colpetto a ogni
       tacca, piu' deciso sulle mezz'ore cosi' si sentono senza guardare. */
    try{ if (typeof flTacca === 'function') flTacca(m % 30 === 0); }catch(_){ }
    ffMinChange(m, 'custom');
  };
  let down = false;
  r.addEventListener('touchstart', e => { down = true; pick(e.touches[0].clientX); }, { passive: true });
  r.addEventListener('touchmove', e => { if (down) pick(e.touches[0].clientX); }, { passive: true });
  r.addEventListener('touchend', () => { down = false; ffPaint(); });
  r.addEventListener('mousedown', e => { down = true; pick(e.clientX); });
  document.addEventListener('mousemove', e => { if (down) pick(e.clientX); });
  document.addEventListener('mouseup', () => { if (down){ down = false; ffPaint(); } });
}

/* ---- da solo o in gruppo ---- */
function ffCompanyOpen(){
  const p = ffPref();
  const row = (id, ico, t, s) => '<button type="button" class="ff-comp' + (p.company === id ? ' on' : '') + '" onclick="ffCompanySet(\'' + id + '\')">'
    + '<span class="ico">' + ico + '</span><div><b>' + t + '</b><small>' + s + '</small></div><i class="dot"></i></button>';
  ffSheetOpen('<div class="ff-sh-head"><button type="button" class="ff-back" onclick="ffTimerOpen()" aria-label="Indietro">'
    + '<svg viewBox="0 0 8 12" width="9" height="13" aria-hidden="true"><path fill="none" d="M7 1L2 6L7 11" stroke="currentColor" stroke-width="1.6"/></svg></button>'
    + '<div class="ff-sh-title">Con chi</div><span></span></div>'
    + row('solo', '👤', 'Da solo', 'Se ti arrendi, si spegne solo la tua stella')
    + row('group', '👥', 'In gruppo', 'Se uno solo si arrende, si spengono le stelle di tutti')
    + '<p class="ff-hint" style="margin-top:12px">In gruppo la sessione vale di più perché il costo di mollare non è più soltanto tuo. Chi partecipa lo inviti dalla pagina Amici.</p>');
}
function ffCompanySet(id){
  const p = ffPref();
  p.company = id;
  ffSavePref();
  if (id === 'group' && typeof toast === 'function') toast('In gruppo: invita chi vuoi dalla pagina Amici');
  ffTimerOpen();
}
function ffIntToggle(){ const p = ffPref(); p.intensive = !p.intensive; ffSavePref(); ffTimerOpen(); }
/* Le due scelte "resto nell'app" / "solo le app consentite" non ci sono piu': erano la stessa
   promessa detta due volte. Adesso e' la lista a decidere. Se contiene qualcosa, il motore arma
   l'elenco consentito; se e' vuota, la sessione e' quella morbida — esci e la pianta appassisce. */
/* Intensiva vuol dire che BLOCCA, non che ti sgrida quando esci.
   Prima, con l'elenco consentito vuoto, la sessione ripiegava su 'stay': il motore non armava
   niente e l'unica conseguenza dell'uscire era la pianta appassita al rientro. Cioe' esattamente
   il difetto: "esco, rientro, mi dice che e' appassita e nel frattempo non aveva bloccato
   niente". Adesso l'intensiva arma sempre l'elenco consentito — vuoto significa "solo
   FocusLock", e la casa e la tastiera restano raggiungibili perche' il servizio le esclude
   sempre. Chi esce trova la schermata di blocco, con il pulsante che lo riporta dentro. */
function ffModeFor(p){ return 'allow'; }
function ffModeSet(m){ const p = ffPref(); p.mode = m; ffSavePref(); ffTimerOpen(); }
function ffSoundSet(id){
  const p = ffPref(); p.sound = id; ffSavePref();
  document.querySelectorAll('.ff-snd').forEach(b => b.classList.remove('on'));
  if (event && event.currentTarget) event.currentTarget.classList.add('on');
  const sub = document.getElementById('ffSndSub');
  const cur = FF_SOUNDS.filter(function(x){ return x.id === id; })[0];
  if (sub) sub.textContent = cur && cur.id !== 'none' ? cur.name : 'Nessuno';
  ffSoundPreview(id);
}
let FF_PREVIEW = null;
function ffSoundPreview(id){ if (FF.run) return; ffSoundStop(); if (id === 'none' || String(id).indexOf('cat:') === 0) return; ffSoundStart(id); clearTimeout(FF_PREVIEW); FF_PREVIEW = setTimeout(() => { if (!FF.run) ffSoundStop(); }, 4000); }

/* Le app e i siti consentiti, nella forma di Opal: due schede in cima, l'icona vera dell'app
   accanto al nome, la lente nella barra di ricerca (la stessa del tema del sito). L'icona non e'
   decorazione: le app che rubano tempo si riconoscono dall'icona molto prima che dal nome. */
const FF_ICO_SEARCH = '<svg viewBox="0 0 18 18" width="17" height="17" aria-hidden="true"><path d="M12.336 12.336c2.634-2.635 2.682-6.859.106-9.435-2.576-2.576-6.8-2.528-9.435.106C.373 5.642.325 9.866 2.901 12.442c2.576 2.576 6.8 2.528 9.435-.106zm0 0L17 17" fill="none" stroke="currentColor" stroke-width="1.5"/></svg>';
let FF_APPS = null;

/* Il precarico: una volta sola, in silenzio, e se fallisce non lo sa nessuno. */
function ffPreloadApps(){
  if (FF_APPS || FF.appsLoading) return;
  if (!NATIVE || !NATIVE.getInstalledApps) return;
  FF.appsLoading = true;
  flApps().then(function(r){
    FF_APPS = (r && r.apps) || [];
    FF_APPS.sort(function(a, b){ return (a.label || '').localeCompare(b.label || '', 'it'); });
  }).catch(function(){ }).then(function(){ FF.appsLoading = false; });
}

/**
 * Il foglio delle cose sempre consentite.
 *
 * <p>Lo apre anche la scheda START, dal foglio di una card: e' lo stesso foglio, con le stesse
 * quattro linguette, perche' scriverne una copia vorrebbe dire avere due fogli che fanno la
 * stessa cosa e che da domani divergono. L'unica differenza e' dove si torna quando si chiude,
 * ed e' quello che dice `FF.allowDaPreset`.</p>
 */
async function ffAllowOpen(tab){
  FF.allowTab = tab || FF.allowTab || 'apps';
  if ((FF.allowTab === 'apps' || FF.allowTab === 'back') && !FF_APPS){
    try{ const r = await flApps(); FF_APPS = (r && r.apps) || []; }catch(_){ FF_APPS = []; }
    FF_APPS.sort((a, b) => (a.label || '').localeCompare(b.label || '', 'it'));
  }
  ffAllowPaint();
}
function ffAllowPaint(){
  const p = ffPref();
  const tab = FF.allowTab || 'apps';
  const check = '<svg viewBox="0 0 14 14" width="13" height="13" aria-hidden="true"><path d="M2 7.5L5.5 11L12 3.5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  /* Aperto dalla card si torna ALLA CARD, non al timer di una sessione che non e' partita. */
  const via = FF.allowDaPreset ? 'ffAllowChiudi()' : 'ffTimerOpen()';
  /* la testa (freccia, titolo, schede) resta ferma: scorre solo l'elenco (0.9.201) */
  const head = '<div class="ff-sh-fix"><div class="ff-sh-head"><button type="button" class="ff-back" onclick="' + via + '" aria-label="Indietro">'
    + '<svg viewBox="0 0 8 12" width="9" height="13" aria-hidden="true"><path fill="none" d="M7 1L2 6L7 11" stroke="currentColor" stroke-width="1.6"/></svg></button>'
    + '<div class="ff-sh-title">Sempre consentiti</div><span></span></div>'
    + '<div class="ff-seg"><button type="button" class="' + (tab === 'apps' ? 'on' : '') + '" onclick="ffAllowOpen(\'apps\')">' + (tab === 'apps' ? check : '') + 'App</button>'
    + '<button type="button" class="' + (tab === 'sites' ? 'on' : '') + '" onclick="ffAllowOpen(\'sites\')">' + (tab === 'sites' ? check : '') + 'Siti</button>'
    + '<button type="button" class="' + (tab === 'words' ? 'on' : '') + '" onclick="ffAllowOpen(\'words\')">' + (tab === 'words' ? check : '') + 'Parole</button>'
    + '<button type="button" class="' + (tab === 'back' ? 'on' : '') + '" onclick="ffAllowOpen(\'back\')">' + (tab === 'back' ? check : '') + 'Ritorno</button></div></div>';

  let body;
  if (tab === 'apps'){
    if (!FF_APPS || !FF_APPS.length){
      body = '<p class="ff-empty">Non riesco a leggere le app installate. Succede quando l\'app gira fuori dal telefono.</p>';
    } else {
      /* Il gruppo salvato, in un tocco: chi ha gia' scritto una volta cosa gli serve per
         lavorare non deve rispuntarlo prima di ogni sessione. */
      const conGruppo = (typeof flGroupCount === 'function' && flGroupCount('always'))
        ? '<button type="button" class="ghostmini grp-use" onclick="flGroupIntoAllow()">Aggiungi i miei Sempre consentiti ('
          + flGroupCount('always') + ')</button>'
        : '';
      body = conGruppo + '<div class="fl-search">' + FF_ICO_SEARCH + '<input id="ffAllowQ" placeholder="Cerca un\'app…" oninput="ffAllowFilter()" autocomplete="off"></div>'
        + '<div class="ff-picklist" id="ffAllowList">' + FF_APPS.map(function(a){
            const on = (p.allow || []).indexOf(a.packageName) >= 0;
            const letter = esc((a.label || '?').charAt(0).toUpperCase());
            return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + letter
              + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
              + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>'
              + '<input type="checkbox" value="' + esc(a.packageName) + '"' + (on ? ' checked' : '') + ' onchange="ffAllowToggle(this)"></label>';
          }).join('') + '</div>';
    }
  } else if (tab === 'words'){
    /* LE PAROLE CHIAVE, UNA ALLA VOLTA.
       I gruppi salvati servono quando sai gia' cosa ti frega. Ma una sessione nasce spesso da
       una cosa sola — "oggi devo stare su fatturazione" — e per quella non ha senso creare un
       gruppo: si scrive la parola qui, vale per questa sessione, e domani non c'e' piu'. */
    const list = (p.allowWords || []);
    body = '<div class="fl-search"><span class="fl-plus">＋</span><input id="ffWordIn" placeholder="Una parola che deve passare (es. fattura)" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();ffWordAdd();}"></div>'
      + '<button type="button" class="ghostmini ff-addsite" onclick="ffWordAdd()">Aggiungi</button>'
      + (list.length
          ? '<div class="ff-picklist">' + list.map(function(d){
              return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">🔤</span><span class="ff-pickname">' + esc(d) + '</span>'
                + '<button type="button" class="ff-rm" onclick="ffWordDel(\'' + esc(d) + '\')" aria-label="Togli">✕</button></div>';
            }).join('') + '</div>'
          : '<p class="ff-empty">Nessuna parola. Durante la sessione passa solo quello che hai consentito: una parola qui apre ogni indirizzo che la contiene.</p>');

  } else if (tab === 'back'){
    /* DOVE TI RIPORTA IL PULSANTE DELLA SCHERMATA DI BLOCCO.
       Su un telefono chiudere il blocco ti lascia sulla schermata iniziale, che e' dove volevi
       essere. Su un computer ti lascia davanti al desktop, cioe' lontano dal lavoro tanto
       quanto la distrazione da cui ti ha tolto. Qui scegli il posto giusto. */
    const cur = p.returnTo || '';
    const righe = (FF_APPS || []).map(function(a){
      const on = cur === a.packageName;
      const letter = esc((a.label || '?').charAt(0).toUpperCase());
      return '<div class="ff-pickrow' + (on ? ' on' : '') + '" onclick="ffReturnSet(\'' + esc(a.packageName) + '\')">'
        + '<span class="ub-appico ub-appico-fb">' + letter + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
        + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>'
        + (on ? '<span class="ff-rm" style="color:var(--blue)">✓</span>' : '') + '</div>';
    }).join('');

    body = '<p class="ff-empty" style="text-align:left;padding-bottom:6px">Quando un blocco ti ferma, la schermata ha un pulsante. Questo è il posto dove ti riporta.</p>'
      + '<div class="fl-search"><span class="fl-plus">🔗</span><input id="ffBackIn" value="' + esc(cur.indexOf('http') === 0 ? cur : '') + '" placeholder="Un indirizzo (es. https://mail.google.com)" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();ffReturnUrl();}"></div>'
      + '<button type="button" class="ghostmini ff-addsite" onclick="ffReturnUrl()">Usa questo indirizzo</button>'
      + '<div class="ff-pickrow' + (cur ? '' : ' on') + '" onclick="ffReturnSet(\'\')"><span class="ub-appico ub-appico-fb">↩</span>'
      + '<span class="ff-pickname">Dove ero prima <small style="display:block;opacity:.6">Sceglie da sé l\'ultima finestra che stavi usando</small></span>'
      + (cur ? '' : '<span class="ff-rm" style="color:var(--blue)">✓</span>') + '</div>'
      + (righe ? '<div class="ff-picklist" id="ffBackList">' + righe + '</div>' : '');

  } else {
    const list = (p.allowSites || []);
    body = '<div class="fl-search"><span class="fl-plus">＋</span><input id="ffSiteIn" placeholder="Aggiungi manualmente (es. gmail.com)" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();ffSiteAdd();}"></div>'
      + '<button type="button" class="ghostmini ff-addsite" onclick="ffSiteAdd()">Aggiungi</button>'
      + (list.length
          ? '<div class="ff-picklist">' + list.map(function(d){
              return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">🌐</span><span class="ff-pickname">' + esc(d) + '</span>'
                + '<button type="button" class="ff-rm" onclick="ffSiteDel(\'' + esc(d) + '\')" aria-label="Togli">✕</button></div>';
            }).join('') + '</div>'
          : '<p class="ff-empty">Nessun sito consentito. Durante la sessione il browser resta chiuso, a meno che tu non lo apra su uno di questi indirizzi.</p>');
  }

  ffSheetOpen(head + body + '<button type="button" class="cta ff-go" onclick="' + via + '">Fatto</button>');
  /* LO STRATO. Il foglio sta a z-index 75; quello di una card a 9994. Aperto da li' finirebbe
     dietro, cioe' invisibile: la classe lo porta sopra e se ne va quando si chiude. */
  const wrap = document.getElementById('ffSheetWrap');
  if (wrap) wrap.classList.toggle('ff-sopra', !!FF.allowDaPreset);
  if (typeof ubFillIcons === 'function'){
    const box = document.getElementById('ffAllowList') || document.getElementById('ffBackList');
    if (box) ubFillIcons(box);
  }
}
function ffAllowFilter(){
  const q = (document.getElementById('ffAllowQ').value || '').toLowerCase();
  document.querySelectorAll('#ffAllowList .ff-pickrow').forEach(function(r){ r.style.display = r.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none'; });
}
function ffAllowToggle(cb){ const p = ffPref(); p.allow = p.allow || []; const i = p.allow.indexOf(cb.value); if (cb.checked && i < 0) p.allow.push(cb.value); if (!cb.checked && i >= 0) p.allow.splice(i, 1); ffSavePref(); }
/* Un indirizzo scritto a mano arriva in tutte le forme: con https, con www, con una barra in
   fondo. Quello che serve al motore e' il solo nome di dominio. */
function ffSiteNorm(v){
  let d = String(v || '').trim().toLowerCase();
  d = d.replace(/^[a-z]+:\/\//, '').replace(/^www\./, '');
  d = d.split('/')[0].split('?')[0].split('#')[0].replace(/\.$/, '');
  return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(d) ? d : '';
}
function ffSiteAdd(){
  const inp = document.getElementById('ffSiteIn');
  const d = ffSiteNorm(inp ? inp.value : '');
  if (!d){ toast('Scrivi un indirizzo, per esempio gmail.com'); return; }
  const p = ffPref(); p.allowSites = p.allowSites || [];
  if (p.allowSites.indexOf(d) < 0) p.allowSites.push(d);
  ffSavePref(); ffAllowPaint();
}
function ffSiteDel(d){ const p = ffPref(); p.allowSites = (p.allowSites || []).filter(function(x){ return x !== d; }); ffSavePref(); ffAllowPaint(); }

function ffWordAdd(){
  const inp = document.getElementById('ffWordIn');
  const w = String(inp ? inp.value : '').trim().toLowerCase();
  if (w.length < 2){ toast('Scrivi una parola di almeno due lettere'); return; }
  const p = ffPref(); p.allowWords = p.allowWords || [];
  if (p.allowWords.indexOf(w) < 0) p.allowWords.push(w);
  ffSavePref(); ffAllowPaint();
}
function ffWordDel(w){ const p = ffPref(); p.allowWords = (p.allowWords || []).filter(function(x){ return x !== w; }); ffSavePref(); ffAllowPaint(); }

/** Chiude il foglio e riporta alla card da cui e' stato aperto. */
function ffAllowChiudi(){
  FF.allowDaPreset = false;
  const wrap = document.getElementById('ffSheetWrap');
  if (wrap) wrap.classList.remove('ff-sopra');
  ffSheetClose();
  /* La card deve rileggere quante cose sono consentite: e' il numero che mostra su quella riga. */
  if (typeof PR_SEL !== 'undefined' && PR_SEL && typeof prApri === 'function') prApri(PR_SEL.id);
}

function ffReturnSet(v){ const p = ffPref(); p.returnTo = v || ''; ffSavePref(); ffAllowPaint(); }
function ffReturnUrl(){
  const inp = document.getElementById('ffBackIn');
  let u = String(inp ? inp.value : '').trim();
  if (!u){ toast('Scrivi un indirizzo'); return; }
  if (!/^https?:\/\//i.test(u)) u = 'https://' + u;
  ffReturnSet(u);
  toast('Il pulsante ti riporterà lì');
}

/* ---------------------------------------------------------------------------------------
   The session
   --------------------------------------------------------------------------------------- */
async function ffStart(){
  const p = ffPref();
  const medita = p.tag === 'meditazione';
  /* la meditazione tiene il telefono chiuso sempre, anche senza la levetta «intensiva» */
  const wanted = (p.intensive || medita) ? ffModeFor(p) : 'free';
  if (wanted === 'allow' && (typeof NATIVE === 'undefined' || !NATIVE)){ toast('Disponibile solo nell\'app installata'); return; }
  ffSheetClose();
  /* Dieci secondi per ripensarci, come nell'app della foresta: il pulsante diventa "Annulla"
     e per quei dieci secondi non c'e' nessuna conseguenza. Chi fa partire un timer per sbaglio
     non deve pagare una pianta. */
  const run = { startAt: Date.now(), endAt: Date.now() + p.minutes * 60000, graceUntil: Date.now() + FF_GRACE_MS, minutes: p.minutes, tag: p.tag, intent: p.intent, intensive: p.intensive, meditazione: medita, mode: wanted, sound: p.sound, prev: null };
  /* sessione n di un ciclo (ff-cicli.js): la catena la porta avanti il telefono */
  run.ciclo = (typeof ffcRunCiclo === 'function') ? ffcRunCiclo(p) : null;
  /* la lettera dell'Io Futuro si chiede adesso, cosi' e' pronta quando si apre lo scrigno */
  try{ if (typeof ifPrimaSessione === 'function') ifPrimaSessione(run); }catch(_){ }
  if (run.mode === 'allow'){
    try{
      const cur = await blkNative('getRulesFull', {}, true);
      run.prev = { listMode: (cur && cur.listMode) || 'blocklist', allowApps: (cur && cur.allowApps) || [], allow: (cur && cur.allow) || [], enabled: !!(cur && cur.enabled !== false) };
      /* ATTENZIONE A COSA SI CHIAMA "PRIMA".

         Se una sessione precedente era rimasta armata — app chiusa a forza, aggiornamento a
         meta' strada — le regole di adesso NON sono le regole dell'utente: sono l'elenco
         consentito di quella sessione. Salvarle come "prima" vorrebbe dire che alla fine si
         rimette un blocco totale, per sempre, e ogni sessione successiva lo conferma. In quel
         caso vale il "prima" gia' salvato, che e' l'ultimo stato vero. */
      try{
        if (run.prev.listMode === 'allowlist' && typeof SETTINGS !== 'undefined' && SETTINGS.ffPrev){
          const old = JSON.parse(SETTINGS.ffPrev);
          if (old && old.listMode) run.prev = old;
        }
      }catch(_){ }
      const allow = (p.allow || []).slice(); if (allow.indexOf('com.dreambrothers.focuslock') < 0) allow.push('com.dreambrothers.focuslock');
      /* I siti consentiti viaggiano in "allow": in modalita' elenco consentito il motore li
         legge al rovescio, cioe' come gli unici indirizzi che passano. */
      /* DAL TELEFONO, non da setRulesFull. Con la Modalita' severa accesa setRulesFull rifiuta
         l'elenco consentito come «indebolimento», e la sessione intensiva non partiva mai su un
         telefono in severa. beginFocusSession e' il gemello di endFocusSession: arma senza
         passare dal cancello, perche' «solo queste app, per questo tempo» e' piu' stretto di
         qualunque lista nera. */
      const liste = medita
        ? { allowApps: ['com.dreambrothers.focuslock'], allow: [], allowWords: [] }
        : { allowApps: allow, allow: (p.allowSites || []).slice(), allowWords: (p.allowWords || []).slice() };
      let ok = null;
      if (blkHasNative('beginFocusSession')){
        const r = await blkNative('beginFocusSession', liste, true);
        ok = (r && r.ok) ? r : null;
      } else {
        ok = await blkNative('setRulesFull', Object.assign({ listMode: 'allowlist' }, liste));
      }
      if (ok === null) throw new Error('arm');
      await blkNative('setQuickBlock', { enabled: true, apps: (typeof QUICK !== 'undefined' ? QUICK.apps : []) || [], sites: (typeof QUICK !== 'undefined' ? QUICK.sites : []) || [], keywords: (typeof QUICK !== 'undefined' ? QUICK.keywords : []) || [] }, true);
    }catch(e){ toast('Non riesco ad armare l\'elenco consentito: controlla il servizio di blocco'); return; }
  }
  FF.run = run;
  ffWrite('fl_ff_session', run);
  ffTellEngine(run.endAt, run);
  /* 0.9.317, Andrea: "il suono parte gia' nei dieci secondi per ripensarci, deve partire dopo": lo fa partire ffTickFn, a grazia finita */
  ffSoundStop();
  /* Niente scritte sotto alla sfera: col timer acceso ogni riga di testo e' una cosa da
     leggere invece di una cosa da fare. */
  const st = document.getElementById('ffStatus'); if (st){ st.hidden = true; st.textContent = ''; }
  const plant = document.getElementById('ffPlant'); if (plant) delete plant.dataset.hold;
  clearInterval(FF.tick); FF.tick = setInterval(ffTickFn, 1000);
  ffSchermoApplica();
  ffPaint();
}
/* il suono della sessione, a grazia finita: quello scelto, o il programma "Dentro DreamMap" del Full Focus */
function ffSuonoParte(run){
  if (!run || run.suonoPartito || ffInGrace()) return;
  run.suonoPartito = true;
  /* 0.9.326, Andrea: "di default parte senza audio: e' una scelta manuale, o un programma creato dalla pagina dei suoni" */
  let id = ffPref().suonoAuto ? run.sound : '';
  try{ if (typeof sndDentro === 'function'){ const d = sndDentro('fullfocus'); if (d) id = d; } }catch(_){ }
  if (id && id !== 'none'){ run.sound = id; run.suonoOn = true; ffSoundStart(id); setTimeout(ffSndLabel, 150); }
}
/* lo schermo resta acceso finche' la sessione corre, se l'impostazione e' accesa (di serie si') */
function ffSchermoApplica(){ try{ if (typeof flSchermoAcceso === 'function') flSchermoAcceso('fullfocus', !!FF.run && !ffPref().schermoNo); }catch(_){ } }
function ffSuonoAutoToggle(){ const p = ffPref(); p.suonoAuto = !p.suonoAuto; ffSavePref(); ffImpostazioniApri(); }

/* USCIRE DALL'APP (0.9.326, Andrea: "se esce dall'app per un'altra il tempo dovrebbe fermarsi, e riprendere quando rientra").
   Lo schermo spento non e' un'uscita, e nemmeno le app consentite per la sessione, dove si sta lavorando: al ritorno si chiede al
   telefono quanto tempo e' passato sulle altre app, e solo quello (fino al tetto scelto) torna indietro. */
function ffFuoriMin(){ return +ffPref().fuoriMin || 5; }
function ffFuoriToggle(){ const p = ffPref(); p.fuori = p.fuori === 'continua' ? 'pausa' : 'continua'; ffSavePref(); ffImpostazioniApri(); }
function ffFuoriMinSet(v){ ffPref().fuoriMin = v; ffSavePref(); ffImpostazioniApri(); }
async function ffFuoriRientro(){
  const run = FF.run; if (!run || !run.viaDa) return;
  const da = run.viaDa, ora = Date.now();
  run.viaDa = 0; FF.fuoriCalc = true;
  let fuori = 0;
  /* il telefono scrive l'ultimo passaggio fra un'app e l'altra con un attimo di ritardo: appena rientrati la risposta e' ancora zero */
  /* e l'altra app si apre un attimo prima che questa pagina se ne accorga: si guarda da qualche secondo prima, se no quell'apertura resta fuori e il conto fa zero */
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getTopApps){
      const ok = (ffPref().allow || []).concat(['com.dreambrothers.focuslock']);
      for (let i = 0; i < 2 && !fuori; i++){
        await new Promise(function(r){ setTimeout(r, 2200); });
        const r = await NATIVE.getTopApps({ from: da - 5000, to: Date.now(), limit: 60, by: 'ms', icons: 0, minMs: 1000 });
        ((r && r.apps) || []).forEach(function(x){ if (x && !x.self && ok.indexOf(x.packageName) < 0) fuori += x.ms || 0; });
      }
    }
  }catch(_){ fuori = 0; }
  FF.fuoriCalc = false;
  if (FF.run !== run) return;
  const credito = Math.min(fuori, Math.max(0, ora - da), ffFuoriMin() * 60000);
  if (credito >= 5000){
    const scaduta = run.endAt <= ora;
    run.endAt += credito; run.pausaTot = (run.pausaTot || 0) + credito;
    ffTellEngine(run.endAt, run);
    if (scaduta && run.mode === 'allow'){ try{ ffRearm(run); }catch(_){ } }
    const m = Math.max(1, Math.round(credito / 60000));
    try{ toast('Eri su un’altra app: il tempo si è fermato per ' + (m === 1 ? '1 minuto' : m + ' minuti')); }catch(_){ }
  }
  ffWrite('fl_ff_session', run);
  ffPaint();
}
document.addEventListener('visibilitychange', function(){
  const run = FF.run; if (!run) return;
  if (document.hidden){
    if (!run.pausedAt && !run.meditazione && !ffInGrace() && ffPref().fuori !== 'continua'){ run.viaDa = Date.now(); ffWrite('fl_ff_session', run); }
    return;
  }
  ffFuoriRientro();
});
function ffTickFn(){
  try{ if (FF.run && !FF.run.suonoPartito) ffSuonoParte(FF.run); }catch(_){ }
  if (!FF.run) return;
  /* la pausa finita riparte da sola, anche se l'app si e' addormentata in mezzo */
  if (FF.run.pausedAt){
    if (!FF.run.pausaFine) FF.run.pausaFine = FF.run.pausedAt + ffPausaMin() * 60000;
    if (Date.now() >= FF.run.pausaFine){ ffPausaRiprendi(); try{ flVibra([30, 60, 30]); }catch(_){ } }
    else ffPausaVelo();
  }
  /* fuori dall'app, o appena rientrati, il conto vero si fa prima (ffFuoriRientro) */
  if (FF.fuoriCalc || FF.run.viaDa) return;
  if (!FF.run.pausedAt && Date.now() >= FF.run.endAt){ ffFinish(true); return; }
  ffPaint();
}
/* La schermata di blocco deve sapere che c'e' una sessione aperta: e' quello che le fa
   cambiare faccia e offrire "Torna in FocusLock" invece del solito muro. */
function ffTellEngine(until, run){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.setSettings) return;
  try{
    /* Tre cose, e nessuna e' di troppo: quando finisce (la schermata di blocco ci legge il
       tempo che manca), quando e' cominciata (la pianta cresce in proporzione) e com'erano le
       regole prima — perche' a rimetterle a posto dev'essere il telefono, non questa pagina,
       che alla fine della sessione quasi sempre non e' nemmeno aperta. */
    /* Due cose in piu', e servono tutte e due alla schermata di blocco del computer: dove
       riportare l'utente quando preme il pulsante, e l'unica cosa che si era scritto — perche'
       una parete che ti ricorda cosa stavi facendo vale il doppio di una che dice solo no. */
    let compito = '';
    try{
      const one = (typeof stOne === 'function') ? stOne() : null;
      if (one && one.task) compito = String(one.task.text || one.task.t || one.task || '').slice(0, 120);
    }catch(_){ }

    const patch = { ffUntil: until || 0, ffFrom: (until && run && run.startAt) || 0,
                    ffPrev: (until && run && run.prev) ? JSON.stringify(run.prev) : '',
                    ffReturnTo: until ? (ffPref().returnTo || '') : '',
                    ffTask: until ? compito : '',
                    /* 0.9.310: fino a qui sono i dieci secondi per ripensarci (il telefono non sorveglia ancora), e
                       questa sessione ha la pianta nella sfera (la schermata del richiamo la mostra solo per lei) */
                    ffGrazia: (until && run && run.graceUntil) || 0,
                    ffAlberoDi: (until && run && run.startAt) || 0 };
    /* la catena dei cicli: si scrive all'avvio; alla fine la gestisce il telefono */
    if (until && run && run.ciclo && typeof ffcEngineCiclo === 'function') patch.ffCiclo = ffcEngineCiclo(run);
    if (typeof SETTINGS !== 'undefined') Object.assign(SETTINGS, patch);
    /* Solo la patch: l'oggetto intero riportava al motore i valori di fabbrica di tutto
       quello che questa pagina non aveva ancora letto (vedi pnPush in start.js). */
    NATIVE.setSettings(patch);
  }catch(_){ }
}

/* LA FINE DI UNA SESSIONE, IN ORDINE.

   Prima si rimettono le regole, POI si spegne la rete di sicurezza del telefono. L'ordine
   inverso e' costato caro: si azzerava ffUntil e ffPrev (cioe' si diceva al telefono "non c'e'
   nessuna sessione, dimentica le regole di prima") e solo dopo si provava a ripristinare — e
   se quel ripristino falliva, come faceva sempre con la modalita' severa accesa, non restava
   nessuno a rimediare. Tutte le app bloccate per sempre.

   Il ripristino lo fa il telefono, che non ha controlli da superare. La vecchia strada resta
   come riserva per quando quel metodo non c'e' (versione vecchia del motore, anteprima nel
   browser). */
async function ffEndSession(run){
  let ok = false;
  /* UN'ALTRA SESSIONE E' VIVA. Con i cicli e i programmi il telefono puo' aver chiuso questa
     sessione e gia' aperto la successiva mentre l'app era chiusa: se adesso si chiudesse «la
     sessione» si chiuderebbe quella nuova. L'orario d'inizio dice di chi e' il blocco armato. */
  try{
    if (typeof settingsLoad === 'function') await settingsLoad();
    const from = +(SETTINGS && SETTINGS.ffFrom) || 0, until = +(SETTINGS && SETTINGS.ffUntil) || 0;
    if (run && run.startAt && until > Date.now() && from && Math.abs(from - run.startAt) > 5000) return true;
  }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.endFocusSession){
    try{ const r = await NATIVE.endFocusSession(); ok = !!(r && r.ok); }catch(_){ }
  }
  if (!ok){
    await ffRestoreRules(run);
    /* Controllo vero: se il motore e' ancora in elenco consentito, il telefono e' murato e
       bisogna dirlo, non fare finta di niente. */
    try{
      const cur = await blkNative('getRulesFull', {}, true);
      if (cur && cur.listMode === 'allowlist'){
        toast('Non riesco a togliere il blocco: apri le impostazioni di accessibilit\u00e0 e spegni DreamMap');
      } else ok = true;
    }catch(_){ }
  }
  ffTellEngine(0);
  /* Le regole VERE tornano al computer: durante la sessione non e' partita nessuna
     spedizione (l'elenco consentito e' della sessione, non del telefono), e senza questa
     riga il computer resterebbe con l'ultima foto buona, o peggio con nessuna. */
  try{ if (typeof rsPubblica === 'function') rsPubblica(); }catch(_){ }
  return ok;
}

async function ffRestoreRules(run){
  if (!run || run.mode !== 'allow' || !run.prev) return;
  try{
    await blkNative('setRulesFull', { listMode: run.prev.listMode, allowApps: run.prev.allowApps, allow: run.prev.allow || [] });
    await blkNative('setQuickBlock', { enabled: run.prev.enabled, apps: (typeof QUICK !== 'undefined' ? QUICK.apps : []) || [], sites: (typeof QUICK !== 'undefined' ? QUICK.sites : []) || [], keywords: (typeof QUICK !== 'undefined' ? QUICK.keywords : []) || [] });
  }catch(_){ }
}
async function ffFinish(ok, why, opz){
  const run = FF.run; if (!run) return;
  /* "Ho finito prima" (0.9.350): una sessione riuscita, chiusa prima del tempo. Conta come le altre, con i minuti veri */
  const prima = !!(ok && opz && opz.prima);
  FF.run = null; clearInterval(FF.tick); FF.tick = null;
  ffSchermoApplica();
  try{ localStorage.removeItem('fl_ff_session'); }catch(_){ }
  ffSoundStop();
  /* una sessione mollata ferma il ciclo: niente pausa e niente sessione dopo */
  if (!ok && run.ciclo && typeof ffcStop === 'function') await ffcStop();
  if (!ok){ try{ if (typeof ifSessioneMollata === 'function') ifSessioneMollata(); }catch(_){ } }
  await ffEndSession(run);
  if (ok && run.ciclo && typeof ffcDopo === 'function') ffcDopo();
  /* Focus insieme: l'esito va all'amico (insieme.js) */
  try{ if (run.insieme && typeof inDopoSessione === 'function') inDopoSessione(run, ok, ffSpeso(run)); }catch(_){ }
  let coins = 0;
  /* chi finisce prima prende le monete dei minuti fatti, non di quelli programmati */
  const minPremio = prima ? ffSpeso(run) / 60000 : run.minutes;
  if (ok){ coins = Math.round(minPremio * (run.intensive ? 1.25 : 1)); ffAddCoins(coins); }
  /* L'intenzione e il tipo di sessione restano nella storia: sono la prova che l'arbitro
     della scheda START cerca prima di assegnare un punto a una riga spuntata. */
  /* QUANTO E' CRESCIUTO PRIMA DI SECCARE.
     `min` sono i minuti PROGRAMMATI: in una scheda alla Forest direbbero «albero appassito, 60
     minuti» anche per una sessione mollata dopo tre. I minuti veri e lo stadio della pianta li
     calcolava gia' la schermata del verdetto (ffDoneOpen) e li buttava via un istante dopo.
     `start` serve a mettere la scheda all'ora GIUSTA: `at` e' quando la pagina se ne accorge, e
     se il timer scade ad app chiusa quell'ora arriva anche il mattino dopo. */
  const spentMs = ffSpeso(run);
  const stage = ok ? 4 : Math.max(0, Math.min(4, Math.floor((spentMs / Math.max(1, run.minutes * 60000)) * 5)));
  const fineAt = Date.now();
  const voce = { at: fineAt, start: run.startAt || 0, spentMs: spentMs, stage: stage, min: run.minutes, tag: run.tag, ok: ok, coins: coins, intent: run.intent || '', intensive: !!run.intensive, meditazione: !!run.meditazione };
  /* finita prima: `min` dice i minuti fatti (le classifiche degli amici sommano questo campo), `minPrevisti` quelli scelti */
  if (prima){ voce.min = Math.round(spentMs / 60000); voce.minPrevisti = run.minutes; voce.prima = true; }
  const hist = ffHist(); hist.push(voce); ffWrite('fl_ff_hist', hist.slice(-500));
  /* Una pianta appassita e' un punto al vecchio te: la promessa era di restare, e non e'
     stata mantenuta. Il punto non lo si da' per punire, lo si da' perche' e' successo. */
  if (!ok){ try{ if (typeof mgOldPoint === 'function') mgOldPoint('sessione mollata'); }catch(_){ } }
  /* «Ogni sessione portata a termine» e' una regola di alcuni modelli (modelli.js): l'arbitro
     la conta solo se il modello scelto la prevede; altrimenti vale zero, come prima. */
  else if (!run.meditazione){ try{ if (typeof mdMolt === 'function' && mdMolt('neo', 'sessione').n > 0 && typeof mgFocusPoint === 'function') mgFocusPoint('sessione portata a termine: ' + (run.intent || run.tag || ''), true); }catch(_){ } }
  /* LA COMBO (0.9.214): una sessione finita la fa salire, una mollata la azzera */
  try{ if (!ok && typeof fcComboZero === 'function') fcComboZero(); else if (ok && !run.meditazione && typeof fcComboPiu === 'function') fcComboPiu(); }catch(_){ }
  /* il sentiero di oggi: la riga del foglio (e la missione, se era l'intento) */
  try{ if (ok && typeof snTick === 'function') setTimeout(snTick, 600); }catch(_){ }
  try{ if (ok && typeof wgAggiorna === 'function') setTimeout(wgAggiorna, 700); }catch(_){ }
  try{ if (ok && typeof sdAggiorna === 'function') setTimeout(function(){ sdControllaMissioneFocus(); sdAggiorna(true); }, 900); }catch(_){ }
  const plant = document.getElementById('ffPlant');
  if (plant){ plant.dataset.hold = '1'; plant.innerHTML = ok ? ffPlantSvg(4, typeof lvHas === 'function' && lvHas('plant:rare')) : ffPlantWithered(); }
  /* Il verdetto ha la sua pagina: la schermata del timer torna a essere quella del timer. */
  ffPausaVeloVia();
  ffDoneOpen(ok, run, coins, fineAt);
  /* Lo scrigno: dopo il verdetto, sulla stessa pagina. Una sessione mollata lo rompe. */
  FF.dopoScr = [ok, run, coins, spentMs];
  const st = document.getElementById('ffStatus');
  if (st){ st.hidden = true; st.textContent = ''; }
  ffPaint();
  /* LA PRIORITA' DEL GIORNO NON SI SPUNTA PIU' DA SOLA. Finire il tempo non vuol dire aver
     finito la cosa: lo dice chi l'ha fatta, con una domanda che arriva DOPO il verdetto e lo
     scrigno (ffDoneClose). La sessione intensiva e' quella legata alla priorita'. */
  FF.chiedi = null;
  /* 0.9.333, Andrea: "non viene mai chiesto se ha finito la task". LA CAUSA: si chiedeva solo con la priorita' del giorno scelta E una sessione intensiva. Adesso basta sapere su cosa si lavorava */
  if (ok && !run.meditazione){
    let task = '', daOne = false;
    try{
      const one = (typeof stOne === 'function') ? stOne() : null;
      if (one && !one.done && !(one.forDay && typeof mtKey === 'function' && one.forDay > mtKey(Date.now()))){ task = String((one.task && (one.task.text || one.task)) || ''); daOne = !!task; }
    }catch(_){ }
    if (!task) task = String(run.intent || '').trim();
    if (task) FF.chiedi = { at: fineAt, min: Math.round(spentMs / 60000), task: task, daOne: daOne, stima: run.minutes, prima: prima };
  }
  try{ if (typeof dpCalcola === 'function') dpCalcola(true); }catch(_){ }
  if (typeof lvBump === 'function') lvBump();
  setTimeout(() => { const pl = document.getElementById('ffPlant'); if (pl) delete pl.dataset.hold; }, 20000);
}
/* La rinuncia passa dalla stessa schermata dell'interruzione di un blocco: la conseguenza
   scritta prima, non dopo. Se la conseguenza si scopre a cose fatte, rinunciare non costa
   niente nel momento in cui conta — cioe' un attimo prima. */
function ffGiveUp(){
  if (!FF.run) return;
  /* 0.9.353, Andrea: "dopo 1-2 minuti nessuno ha finito prima". Dallo stop la scelta "Ho finito prima" arriva solo dopo un
     tempo credibile (ffPrimaSogliaMs); prima di allora lo stop e' la resa di sempre */
  if (!FF.run.meditazione && !ffInGrace() && ffLavoratoMs(FF.run) >= ffPrimaSogliaMs(FF.run)){ ffFinitoPrimaApri({ resa: true }); return; }
  ffResa();
}
function ffResa(){
  if (!FF.run) return;
  if (typeof itOpen !== 'function'){ ffFinish(false, 'Hai rinunciato: la stella si è spenta'); return; }
  const left = Math.max(0, Math.round(ffLeft() / 60000));
  itOpen({
    title: 'Arrenderti adesso?',
    count: ffWithered(),
    countLabel: ffWithered() === 1 ? 'Stella spenta' : 'Stelle spente',
    cost: 'Mancavano ' + left + (left === 1 ? ' minuto' : ' minuti') + '. Questa stella si spegne e resta nel tuo cielo.',
    note: ffGiveUpNote(),
    yes: 'Tieni premuto per arrenderti',
    no: 'Resto ancora un minuto',
    onYes: function(){ ffFinish(false, 'Hai rinunciato: la stella si è spenta'); }
  });
}
/* "HO FINITO PRIMA" (0.9.350, Andrea, ritratto di Clarify): il compito e' fatto e il tempo non e' finito. Prima si poteva
   solo arrendersi, cioe' spegnere la stella per una cosa riuscita. Adesso il segno di spunta chiede conferma con una riga e
   chiude la sessione come RIUSCITA: stessa strada del tempo scaduto (ffFinish), con i minuti veri e le monete di quei minuti. */
/* 0.9.353, Andrea: "Ho finito prima" non sta piu' sotto al timer. Si apre in due modi:
   1. toccando il tempo che resta (ffTempoTocca): e' un gesto voluto, quindi c'e' sempre, anche per un compito da cinque minuti
      (non nella meditazione, che non ha un compito);
   2. dallo stop (ffGiveUp), ma solo dopo un tempo credibile: allora la seconda risposta e' "No, mi arrendo", che porta alla resa
      di sempre (ffResa). La X e il tocco fuori lasciano andare avanti la sessione. */
function ffFinitoPrimaApri(opz){
  const run = FF.run; if (!run || ffInGrace()) return;
  const resa = !!(opz && opz.resa);
  try{ flVibra(10); }catch(_){ }
  ffFinitoPrimaChiudi();
  const fatti = Math.max(0, Math.round(ffLavoratoMs(run) / 60000));
  const box = document.createElement('div');
  box.id = 'ffPrima'; box.className = 'ff-ask';
  box.addEventListener('click', function(e){ if (e.target === box) ffFinitoPrimaChiudi(); });
  box.innerHTML = '<div class="ff-ask-card ffpr-card" role="dialog" aria-modal="true" aria-labelledby="ffPrimaT">'
    + '<button type="button" class="ff-nota-x ffpr-x" onclick="ffFinitoPrimaChiudi()" aria-label="Chiudi"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"/></svg></button>'
    + '<div class="ff-ask-ico ffpr-ico"><svg viewBox="0 0 48 48" width="52" height="52" aria-hidden="true"><circle cx="24" cy="24" r="22" fill="#0075E3"/><path d="M14 24.5l7 7L34.5 17" fill="none" stroke="#fff" stroke-width="4.4" stroke-linecap="round" stroke-linejoin="round"/></svg></div>'
    + '<b class="ff-ask-t" id="ffPrimaT">Hai finito il compito?</b>'
    + '<div class="ffpr-txt">'
    +   (run.intent ? '<p class="ff-ask-task ffpr-int">' + esc(run.intent) + '</p>' : '')
    +   '<p class="ff-ask-task">' + (fatti === 0 ? 'Conta meno di 1 minuto di concentrazione.' : fatti === 1 ? 'Conta 1 minuto di concentrazione.' : 'Contano ' + fatti + ' minuti di concentrazione.') + '</p>'
    + '</div>'
    + '<button type="button" class="cta" onclick="ffFinitoPrimaSi()">Sì, l’ho finito</button>'
    + (resa
      ? '<button type="button" class="ff-ask-no" onclick="ffFinitoPrimaChiudi();ffResa()">No, mi arrendo</button>'
      : '<button type="button" class="ff-ask-no" onclick="ffFinitoPrimaChiudi()">No, continuo</button>')
    + '</div>';
  (document.getElementById('phone') || document.body).appendChild(box);
}
/* Il tempo grande della sessione: prima di partire apre il timer, a sessione partita chiede se il compito e' finito.
   La meditazione non ha un compito da finire: li' il tempo non apre niente */
function ffTempoTocca(){
  if (!FF.run){ ffTimerOpen(); return; }
  if (FF.run.meditazione) return;
  ffFinitoPrimaApri();
}
/* I minuti di lavoro veri: senza le pause chiuse (ffSpeso) e senza quella in corso */
function ffLavoratoMs(run){
  if (!run) return 0;
  return Math.max(0, ffSpeso(run) - (run.pausedAt ? Math.max(0, Date.now() - run.pausedAt) : 0));
}
/* 0.9.353, Andrea: "dopo il tempo stimato dal Genio per quella tappa, o comunque dopo una buona parte della sessione".
   La soglia: i due terzi della sessione, ma mai oltre 20 minuti (in una sessione da 90 minuti, un compito finito dopo
   25 minuti e' credibile). Se il Genio aveva stimato quel compito, e la stima e' piu' corta, basta la stima. Mai sotto i
   3 minuti, salvo sessioni cortissime, dove valgono i due terzi. Esempi: 25 min -> 16 min 40 s; 60 o 90 min -> 20 min;
   10 min -> 6 min 40 s; 5 min -> 3 min 20 s. Contano solo i minuti di lavoro, la pausa no. */
function ffPrimaSogliaMs(run){
  const tot = Math.max(1, +run.minutes || 1) * 60000;
  let soglia = Math.min(20 * 60000, tot * 2 / 3);
  const stima = ffStimaGenio(run.intent);
  if (stima > 0) soglia = Math.min(soglia, stima * 60000);
  return Math.max(Math.min(3 * 60000, tot * 2 / 3), soglia);
}
/* La stima del Genio per il compito della sessione (stMeta di start.js, la riga di oggi), in minuti; 0 se non c'e' */
function ffStimaGenio(intent){
  const t = String(intent || '').trim();
  if (!t || typeof stMeta !== 'function') return 0;
  try{ return +((stMeta(t) || {}).stima || (stMeta('☐ ' + t) || {}).stima) || 0; }catch(_){ return 0; }
}
function ffFinitoPrimaChiudi(){ const b = document.getElementById('ffPrima'); if (b) b.remove(); }
function ffFinitoPrimaSi(){
  ffFinitoPrimaChiudi();
  const run = FF.run; if (!run) return;
  /* in pausa: prima si chiude la pausa, cosi' i minuti della pausa non contano come lavoro */
  if (run.pausedAt) ffPausaRiprendi();
  ffFinish(true, '', { prima: true });
}
/* Quante ne sono appassite finora: il numero che la schermata mostra grande. */
function ffWithered(){ return ffHist().filter(function(x){ return x && !x.ok; }).length; }
/* La frase che compare a macchina da scrivere. La scrive l'utente in Personalizza: c'e' chi
   ha bisogno di essere ripreso e chi si e' gia' ripreso abbastanza da solo. */
function ffGiveUpNote(){
  try{
    if (typeof SETTINGS !== 'undefined' && SETTINGS.quitNote && String(SETTINGS.quitNote).trim()) return String(SETTINGS.quitNote).trim();
  }catch(_){ }
  try{ if (typeof whyMantra === 'function'){ const m = whyMantra(); if (m && m.trim()) return m.trim(); } }catch(_){ }
  return 'Mancava poco. Chiudere adesso è la parte facile.';
}

/* The app was closed or the phone restarted mid-session: pick it up or close it. */
function ffResume(){
  if (FF.run) return;
  const run = ffRead('fl_ff_session', null);
  if (!run) return;
  /* Dentro ai dieci secondi di ripensamento non appassisce niente, nemmeno uscendo. */
  if (run.intensive && run.mode === 'stay' && !run.pausedAt && !(run.graceUntil && Date.now() < run.graceUntil)){
    FF.run = run; ffFinish(false, 'Hai lasciato l\'app: la stella si è spenta'); return;
  }
  /* la pausa che e' finita ad app chiusa: la sessione e' ripartita da sola a quell'ora */
  if (run.pausedAt && (!run.pausaFine || Date.now() >= run.pausaFine)){
    const durata = Math.max(0, (run.pausaFine || run.pausedAt) - run.pausedAt);
    run.endAt += durata; run.pausaTot = (run.pausaTot || 0) + durata; run.pausedAt = 0; run.pausaFine = 0;
    ffWrite('fl_ff_session', run);
  }
  if (!run.pausedAt && Date.now() >= run.endAt){ FF.run = run; ffFinish(true); return; }
  FF.run = run;
  if (run.pausedAt) ffPausaVelo();
  clearInterval(FF.tick); FF.tick = setInterval(ffTickFn, 1000);
  if (ffInGrace()) run.suonoPartito = false;
  else { run.suonoPartito = true; if (run.suonoOn && run.sound && run.sound !== 'none') ffSoundStart(run.sound); }
  /* Il motore puo' essere stato riavviato dal sistema mentre l'app non c'era: l'elenco
     consentito si riarma, altrimenti la sessione continua a contare i minuti senza bloccare
     niente — che e' peggio di non averla. */
  if (run.mode === 'allow') ffRearm(run);
  ffTellEngine(ffFineVera(run), run);
  ffSchermoApplica();
  ffPaint();
  if (run.viaDa) ffFuoriRientro();
}

/* Rimette l'elenco consentito se il motore nel frattempo l'ha perso. */
async function ffRearm(run){
  try{
    const cur = await blkNative('getRulesFull', {}, true);
    if (cur && cur.listMode === 'allowlist') return;
    const p = ffPref();
    const allow = (p.allow || []).slice();
    if (allow.indexOf('com.dreambrothers.focuslock') < 0) allow.push('com.dreambrothers.focuslock');
    await blkNative('setRulesFull', { listMode: 'allowlist', allowApps: allow,
      allow: (p.allowSites || []).slice(), allowWords: (p.allowWords || []).slice() });
  }catch(_){ }
}
document.addEventListener('visibilitychange', function(){
  if (!FF.run) return;
  if (ffInGrace()) return;
  if (document.hidden && FF.run.intensive && FF.run.mode === 'stay' && !FF.run.pausedAt) ffFinish(false, 'Hai lasciato l\'app: la stella si è spenta');
});
/* ALL'AVVIO: la sessione si RIPRENDE, non si butta.

   Qui c'era la riga che ha rotto la modalita' intensiva. Diceva: se al riavvio trovi una
   sessione che non e' ne' scaduta ne' da far appassire, allora rimetti a posto le regole del
   motore e cancella la sessione. Cioe': esci da FocusLock per aprire un'altra app — che e'
   esattamente quello che la modalita' intensiva deve impedire — l'app riparte da capo, il
   blocco si disarma da solo e il timer torna a 25:00. Il difetto si vedeva come "non blocca
   niente e il timer si e' resettato", e la causa era una sola riga scritta per un caso
   diverso: l'app UCCISA a meta' sessione.

   Adesso l'unica cosa che si fa a freddo e' riprendere: ffResume() sa gia' distinguere una
   sessione scaduta, una abbandonata e una ancora viva. */
setTimeout(function(){ if (!FF.run) ffResume(); }, 1200);

/* ---------------------------------------------------------------------------------------
   Sounds, synthesised
   --------------------------------------------------------------------------------------- */
function ffCtx(){ if (!FF.audio){ try{ FF.audio = new (window.AudioContext || window.webkitAudioContext)(); }catch(_){ FF.audio = null; } } return FF.audio; }
function ffNoise(ctx, kind){
  const len = ctx.sampleRate * 2, buf = ctx.createBuffer(1, len, ctx.sampleRate), d = buf.getChannelData(0);
  let last = 0, b0 = 0, b1 = 0, b2 = 0;
  for (let i = 0; i < len; i++){
    const w = Math.random() * 2 - 1;
    if (kind === 'brown'){ last = (last + 0.02 * w) / 1.02; d[i] = last * 3.5; }
    else if (kind === 'pink'){ b0 = 0.99765 * b0 + w * 0.0990460; b1 = 0.96300 * b1 + w * 0.2965164; b2 = 0.57000 * b2 + w * 1.0526913; d[i] = (b0 + b1 + b2 + w * 0.1848) * 0.12; }
    else d[i] = w * 0.35;
  }
  const src = ctx.createBufferSource(); src.buffer = buf; src.loop = true; return src;
}
/* I suoni li fa sounds.js, che è dove vivono adesso: stesso motore della tendina nella
   scheda Sveglia, stessi livelli. Quelli di prima partivano a 0.7 di volume con i filtri
   spalancati sull'acuto, ed erano assordanti. */
function ffSoundStart(id){
  /* 0.9.326, Andrea: le categorie della scheda dei suoni per concentrarsi: suonano in fila, e cambiano traccia da sole */
  if (String(id || '').indexOf('cat:') === 0){ FF.cat = String(id).slice(4); try{ suoAvvia('focus', FF.cat, null, true); }catch(_){ } return; }
  if (typeof sndPlay === 'function' && id && id !== 'none'){ if (SND.id !== id) sndPlay(id); }
}
function ffCatNome(k){ try{ const a = (SUO_ATT.focus || []).filter(function(x){ return x.k === k; })[0]; return a ? a.n : ''; }catch(_){ return ''; } }
function ffCatFerma(){
  if (!FF.cat) return;
  FF.cat = '';
  try{ if (typeof suoFermaAudio === 'function') suoFermaAudio(); SUO.sess = null; if (typeof suoMiniPaint === 'function') suoMiniPaint(); }catch(_){ }
}

/* ---------- IL SUONO, DURANTE IL TIMER ----------
   Un tocco: silenzio / riprendi. Tenuto premuto: la lista dei suoni — la stessa della tendina
   «Suoni per concentrarsi» della scheda START, non una seconda lista che dice le stesse cose
   con altri nomi. */
let FF_HOLD_T = 0, FF_HOLD_OK = false;
function ffSndDown(e){
  if (e && e.preventDefault) e.preventDefault();
  FF_HOLD_OK = false; clearTimeout(FF_HOLD_T);
  FF_HOLD_T = setTimeout(function(){ FF_HOLD_OK = true; ffSoundSheet(); }, 480);
}
function ffSndCancel(){ clearTimeout(FF_HOLD_T); FF_HOLD_OK = false; }
function ffSndUp(e){
  if (e && e.preventDefault) e.preventDefault();
  clearTimeout(FF_HOLD_T);
  if (FF_HOLD_OK){ FF_HOLD_OK = false; return; }
  /* UN TOCCO = PLAY / STOP, sempre. A silenzio riparte il suono scelto per la sessione (o
     l'ultimo usato); a suono acceso lo ferma. La lista si apre SOLO tenendo premuto: un
     tocco che apre un foglio e' una porta, e col timer acceso le porte stanno chiuse. */
  if (!FF.cat && (typeof SND === 'undefined' || SND.id === 'none' || SND.playing === false)){
    let id = (FF.run && FF.run.sound) || '';
    if (!id || id === 'none'){ ffSoundSheet(); return; }
    if (FF.run){ FF.run.sound = id; FF.run.suonoOn = true; ffWrite('fl_ff_session', FF.run); }
    if (typeof SND !== 'undefined' && SND.id === id && SND.playing === false && typeof sndPlay === 'function') sndPlay(id);
    else ffSoundStart(id);
  } else {
    ffSoundStop();
    if (FF.run){ FF.run.suonoOn = false; ffWrite('fl_ff_session', FF.run); }
  }
  setTimeout(ffSndLabel, 150);
}
function ffSndLabel(){
  const l = document.getElementById('ffSndLbl'), b = document.getElementById('ffSndTop');
  if (!l || !b) return;
  const on = !!FF.run && !ffInGrace();
  l.hidden = !on; b.hidden = !on;
  if (!on) return;
  const id = (typeof SND !== 'undefined') ? SND.id : 'none';
  const suona = !!FF.cat || (id !== 'none' && typeof SND !== 'undefined' && SND.playing !== false);
  const nome = FF.cat ? ffCatNome(FF.cat) : ((suona && typeof sndName === 'function') ? sndName(id) : '');
  /* La riga compare solo se un suono sta suonando: a silenzio c'e' solo l'icona, e chi la
     tocca scopre da se' cosa fa. Una scritta che dice «nessun suono» e' rumore. */
  /* 0.9.353, Andrea: "Tocca per scegliere un suono distrae, via". A silenzio resta solo l'icona: chi vuole un suono la tocca
     (senza un suono scelto si apre la lista) o la tiene premuta */
  l.hidden = !nome;
  l.innerHTML = nome ? '<b>' + esc(nome) + '</b><small>Tieni premuto per cambiare suono</small>' : '';
  b.textContent = suona ? '\ud83d\udd0a' : '\ud83d\udd07';
}
async function ffSoundSheet(){
  try{ if (typeof sndCredits === 'function') await sndCredits(); }catch(_){ }
  const tutti = (typeof SOUNDS !== 'undefined' ? SOUNDS : []).reduce(function(a, g){ return a.concat(g.items); }, [])
    /* 0.9.326, Andrea: "nessuno entra in Full Focus per dormire" */
    .filter(function(x){ return x.id !== 'sonno' && (typeof sndAvailable !== 'function' || sndAvailable(x.id)); });
  const grant = function(id){ return (FF_SOUNDS.filter(function(x){ return x.id === id; })[0] || {}).grant; };
  const libero = function(id){ const g = grant(id); return !g || typeof lvHas !== 'function' || lvHas(g); };
  const cur = FF.cat ? 'cat:' + FF.cat : ((typeof SND !== 'undefined') ? SND.id : 'none');
  const cat = function(k, n, d, ico){ return '<button type="button" class="ff-sndrow' + (cur === 'cat:' + k ? ' on' : '') + '" onclick="ffSoundPick(\'cat:' + k + '\')"><span class="ico">' + ico + '</span><div><b>' + esc(n) + '</b><small>' + esc(d) + '</small></div></button>'; };
  ffSheetOpen('<div class="ff-sh-head"><span></span><div class="ff-sh-title">Suono di sottofondo</div><span></span></div>'
    + '<div class="ff-sndlist">'
    + '<button type="button" class="ff-sndrow' + (cur === 'none' ? ' on' : '') + '" onclick="ffSoundPick(\'none\')"><span class="ico">\ud83d\udd07</span><div><b>Silenzio</b></div></button>'
    + cat('deepwork', 'Il meglio del lavoro profondo', 'Una playlist che cambia traccia da sola', '🎧')
    + cat('motivation', ffCatNome('motivation') || 'Motivazione', 'Musica che sale, per tenere il ritmo', '⚡')
    + cat('creativity', ffCatNome('creativity') || 'Creatività', 'Per far nascere idee nuove', '💡')
    + cat('learning', ffCatNome('learning') || 'Studio', 'Per leggere, studiare e ricordare', '📖')
    + cat('lightwork', ffCatNome('lightwork') || 'Lavoro leggero', 'Per le cose semplici, senza sforzo', '🪶')
    + tutti.map(function(x){
        const ok = libero(x.id);
        return '<button type="button" class="ff-sndrow' + (cur === x.id ? ' on' : '') + (ok ? '' : ' lock') + '"'
          + ' ontouchstart="if(typeof sndWarm===\'function\')sndWarm(\'' + x.id + '\')"'
          + ' onclick="' + (ok ? 'ffSoundPick(\'' + x.id + '\')' : 'toast(\'Si sblocca salendo di livello\')') + '">'
          + '<span class="ico">' + x.ico + '</span><div><b>' + esc(x.n) + '</b><small>' + esc(x.d) + '</small></div>'
          + (ok ? '' : '<i>\ud83d\udd12</i>') + '</button>';
      }).join('')
    + '</div>');
}
function ffSoundPick(id){
  const p = ffPref(); p.sound = id; ffSavePref();
  if (FF.run){ FF.run.sound = id; FF.run.suonoOn = id !== 'none'; ffWrite('fl_ff_session', FF.run); }
  ffSheetClose();
  if (FF.run){ ffSoundStop(); if (id !== 'none') ffSoundStart(id); }
  else ffSoundPreview(id);
  setTimeout(ffSndLabel, 150);
}
function ffSoundStop(){
  ffCatFerma();
  if (typeof sndStop === 'function'){ sndStop(); SND.id = 'none'; }
  const ctx = FF.audio; if (!ctx || !FF.nodes.length) return;
  FF.nodes.forEach(n => { try{ if (n.stop) n.stop(); }catch(_){ } try{ n.disconnect(); }catch(_){ } });
  FF.nodes = [];
}

/* ---------------------------------------------------------------------------------------
   The real forest
   --------------------------------------------------------------------------------------- */
function ffDevice(){
  let id = ''; try{ id = localStorage.getItem('fl_device_id') || ''; }catch(_){ }
  if (!id){ id = 'fl-' + Math.random().toString(36).slice(2, 10) + Date.now().toString(36); try{ localStorage.setItem('fl_device_id', id); }catch(_){ } }
  return id;
}
/* 0.9.326, Andrea: entrando si rivive il cielo, dal giorno in cui e' cominciato a oggi: le stelle si accendono una per una */
function ffCieloViaggio(poi){
  const hist = ffHist().filter(function(h){ return h && h.ok && !h.meditazione; });
  let meno = false; try{ meno = window.matchMedia('(prefers-reduced-motion: reduce)').matches; }catch(_){ }
  if (!hist.length || meno || document.getElementById('ffoTl')){ poi(); return; }
  const w = document.createElement('div'); w.id = 'ffoTl';
  w.innerHTML = '<svg viewBox="0 0 400 300" aria-hidden="true"></svg><p class="ffoTl-t">Il tuo cielo</p><p class="ffoTl-d"></p>';
  (document.getElementById('phone') || document.body).appendChild(w);
  const svg = w.querySelector('svg'), dat = w.querySelector('.ffoTl-d'), n = Math.min(90, hist.length);
  const da = hist[0].at || Date.now(), a = Date.now(), dur = 1900, t0 = performance.now();
  let fatte = 0, finito = false;
  const fine = function(){ if (finito) return; finito = true; try{ poi(); }catch(_){ } w.classList.add('via'); setTimeout(function(){ w.remove(); }, 350); };
  w.addEventListener('click', fine);
  const giro = function(t){
    if (finito) return;
    const u = Math.min(1, (t - t0) / dur);
    dat.textContent = new Date(da + (a - da) * u).toLocaleDateString('it-IT', { day: 'numeric', month: 'long', year: 'numeric' });
    while (fatte < Math.round(n * u)){
      const i = fatte++, ang = i * 2.39996, r = 18 + Math.sqrt(i + 1) * 20;
      const x = 200 + Math.cos(ang) * r * 1.4, y = 150 + Math.sin(ang) * r * .95;
      svg.insertAdjacentHTML('beforeend', '<path class="ffoTl-s" transform="translate(' + x.toFixed(1) + ' ' + y.toFixed(1) + ')" d="M0-10C.7-2.800 2.800-.7 10 0 2.800.7.7 2.800 0 10-.7 2.800-2.800.7-10 0-2.800-.7-.7-2.800 0-10Z" fill="#fff"/>');
    }
    if (u < 1) requestAnimationFrame(giro); else setTimeout(fine, 450);
  };
  requestAnimationFrame(giro);
}
async function ffForestOpen(){
  /* 0.9.331, Andrea: "ogni volta sorbirsi quell'animazione e' fastidioso": parte dal pulsante nel cielo */
  goId('s-ff-forest'); ffForestPaint(); ffoAuto();
  try{
    if (NATIVE && NATIVE.publicApi){
      const r = await NATIVE.publicApi({ method: 'GET', path: '/api/focuslock/trees?device=' + encodeURIComponent(ffDevice()) });
      if (r && typeof r.total === 'number'){ FF.trees = r; if (Array.isArray(r.mine) && r.mine.length) ffWrite('fl_trees', r.mine); ffForestPaint(); }
    }
  }catch(_){ }
}
/* 0.9.315, Andrea: "mi fa schifo, va rifatta". Il bosco e' fatto delle tue sessioni: ogni sessione finita e' un albero azzurro,
   ogni sessione mollata un albero secco, gli alberi veri piantati sono verdi e stanno davanti. Sotto, una cosa sola: quanto
   manca al prossimo albero vero. */
function ffBoscoSvg(hist, mine){
  /* ogni sessione finita e' una stella accesa, ogni sessione mollata una stella spenta, un albero vero una stella dorata */
  const voci = mine.map(function(){ return 'vero'; }).concat(hist.slice().reverse().filter(function(h){ return h && !h.meditazione; }).map(function(h){ return h.ok ? 'ok' : 'secco'; })).slice(0, 90);
  const pos = function(i){ const a = i * 2.39996, r = 16 + Math.sqrt(i + 1) * 17; return { x: 200 + Math.cos(a) * r * 1.5, y: 110 + Math.sin(a) * r * .78 }; };
  const stella = function(x, y, s, col, op){ return '<path transform="translate(' + x.toFixed(1) + ' ' + y.toFixed(1) + ') scale(' + s + ')" d="M0-10C.7-2.800 2.800-.7 10 0 2.800.7.7 2.800 0 10-.7 2.800-2.800.7-10 0-2.800-.7-.7-2.800 0-10Z" fill="' + col + '" opacity="' + op + '"/>'; };
  const fondo = [[28, 22], [70, 48], [118, 16], [166, 30], [232, 20], [274, 46], [352, 30], [388, 62], [46, 88], [320, 84], [20, 150], [110, 190], [300, 196], [380, 150]].map(function(p){ return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="1.100" fill="#BCE0FF" opacity=".5"/>'; }).join('');
  return '<svg class="ffo-bosco" viewBox="0 0 400 214" role="img" aria-label="Il tuo cielo">' + fondo
    + (voci.length ? voci.map(function(k, i){ const p = pos(i); return k === 'vero' ? stella(p.x, p.y, 1.2, '#FFC94D', 1) : k === 'ok' ? stella(p.x, p.y, .9, '#FFFFFF', 1) : stella(p.x, p.y, .6, '#5B6F8C', .8); }).join('')
        : stella(200, 107, 1.1, '#8CC6FF', .9))
    + '</svg>';
}
/* il bosco fatto delle tue sessioni: un albero azzurro per ogni sessione finita, verde per ogni albero vero, secco per ogni sessione mollata */
function ffForestaSvg(hist, mine){
  const righe = [[122, 8, .5], [138, 8, .62], [156, 7, .76], [176, 6, .92], [198, 5, 1.1]];
  const posti = [];
  righe.forEach(function(r, ir){ for (let i = 0; i < r[1]; i++){ const x = 400 * (i + .5 + (ir % 2 ? .18 : -.18)) / r[1]; posti.push({ x: Math.round(x), y: r[0] + ((i * 7) % 5), s: r[2], d: Math.abs(x - 200) + (righe.length - ir) * 200 }); } });
  posti.sort(function(a, b){ return a.d - b.d; });
  const voci = mine.map(function(){ return 'vero'; }).concat(hist.slice().reverse().filter(function(h){ return h && !h.meditazione; }).map(function(h){ return h.ok ? 'ok' : 'secco'; })).slice(0, posti.length);
  const scelti = voci.map(function(k, i){ return { k: k, p: posti[i] }; }).sort(function(a, b){ return a.p.y - b.p.y; });
  const conifera = function(a, b){ return '<rect x="-2.500" y="-13" width="5" height="13" rx="1.500" fill="#0B2A5C"/><path d="M0-58 13-36H7L18-20H9L22-6H-22L-9-20H-18L-7-36H-13Z" fill="' + a + '"/><path d="M0-58 13-36H7L18-20H9L22-6H0Z" fill="' + b + '"/>'; };
  return '<svg class="ffo-bosco" viewBox="0 0 400 214" role="img" aria-label="La tua foresta"><defs>'
    + '<radialGradient id="ffoLuna"><stop offset="0" stop-color="#E3F1FF"/><stop offset=".45" stop-color="#BCE0FF" stop-opacity=".5"/><stop offset="1" stop-color="#BCE0FF" stop-opacity="0"/></radialGradient>'
    + '<g id="ffoOk">' + conifera('#8CC6FF', '#3F9FF4') + '</g>'
    + '<g id="ffoVero"><circle cy="-30" r="40" fill="#4CD39A" opacity=".16"/>' + conifera('#6FE3B4', '#1B9E6A') + '</g>'
    + '<g id="ffoSecco" fill="none" stroke="#7E93B8" stroke-width="3" stroke-linecap="round"><path d="M0 0V-38"/><path d="M0-14-11-26M0-22 10-34M0-30-7-40"/></g>'
    + '<g id="ffoVuoto" fill="none" stroke="#BCE0FF" stroke-width="1.800" stroke-dasharray="4 4" stroke-linejoin="round"><path d="M0-58 13-36H7L18-20H9L22-6H-22L-9-20H-18L-7-36H-13Z"/></g>'
    + '</defs><circle cx="330" cy="46" r="42" fill="url(#ffoLuna)"/><circle cx="330" cy="46" r="13" fill="#E3F1FF"/>'
    + '<path d="M0 118C60 92 130 104 200 112S340 98 400 116V214H0Z" fill="#0F3A7E"/><path d="M0 150C80 128 150 146 220 148S340 132 400 150V214H0Z" fill="#0B2C64"/><path d="M0 182C90 164 170 182 250 180S360 170 400 184V214H0Z" fill="#072150"/>'
    + (scelti.length ? scelti.map(function(x){ return '<use href="#' + (x.k === 'vero' ? 'ffoVero' : (x.k === 'ok' ? 'ffoOk' : 'ffoSecco')) + '" transform="translate(' + x.p.x + ' ' + x.p.y + ') scale(' + x.p.s + ')"/>'; }).join('')
        : '<use href="#ffoVuoto" transform="translate(200 196) scale(1.100)"/>')
    + '</svg>';
}
/* le due slide cambiano da sole, finche' non le tocchi */
const FFO = { t: 0 };
function ffoDot(c){
  const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth));
  const d = document.getElementById('ffoDots'); if (d) Array.prototype.forEach.call(d.children, function(x, k){ x.classList.toggle('on', k === i); });
  const t = document.getElementById('ffoTitolo'); if (t) t.textContent = i ? 'Il tuo cielo' : 'La tua foresta';
}
function ffoFerma(){ clearInterval(FFO.t); FFO.t = 0; }
function ffoAuto(){
  ffoFerma();
  FFO.t = setInterval(function(){
    const c = document.getElementById('ffoCar');
    if (!c || !c.offsetParent){ ffoFerma(); return; }
    const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth));
    c.scrollTo({ left: i ? 0 : c.clientWidth, behavior: 'smooth' });
  }, 7000);
}
function ffForestPaint(){
  const box = document.getElementById('ffForestBody'); if (!box) return;
  const mine = ffRead('fl_trees', []), coins = ffCoins(), hist = ffHist();
  const fatte = hist.filter(function(h){ return h && h.ok; });
  const mins = fatte.reduce(function(a, h){ return a + (h.spentMs ? Math.round(h.spentMs / 60000) : (h.min || 0)); }, 0);
  const secche = hist.filter(function(h){ return h && !h.ok; }).length;
  const total = FF.trees && typeof FF.trees.total === 'number' ? FF.trees.total : mine.length;
  const pieno = mine.length >= FF_TREE_CAP, can = !pieno && coins >= FF_TREE_COST;
  const num = function(n){ return Number(n).toLocaleString('it-IT'); };
  const pct = Math.min(100, Math.round(coins / FF_TREE_COST * 100));
  const cta = pieno ? '<button type="button" class="ffo-cta" disabled>Hai piantato tutti i tuoi alberi</button>'
    : (can ? '<button type="button" class="ffo-cta ff-plantbtn" onclick="ffPlantTree()">Pianta un albero vero</button>'
           : '<button type="button" class="ffo-cta" onclick="goId(\'s-fullfocus\');ffPaint()">Inizia una sessione</button>');
  const sx = document.getElementById('ffoCar') ? document.getElementById('ffoCar').scrollLeft : 0;
  box.innerHTML = '<div class="ffo-car" id="ffoCar" onscroll="ffoDot(this)" ontouchstart="ffoFerma()">'
    /* prima la Terra, poi il cielo */
    + '<div class="ffo-sl">' + ffForestaSvg(hist, mine) + '<div class="ffo-corpo">'
    + '<p class="ffo-lead">Con le monete che guadagni pianti <b>alberi veri</b> sulla Terra.</p>'
    + '<div class="ffo-card"><h3>' + (pieno ? 'Hai piantato tutti i tuoi alberi' : 'Il tuo prossimo albero vero') + '</h3>'
    +   (pieno ? '' : '<div class="ffo-bar"><i style="width:' + pct + '%"></i></div><div class="ffo-num"><span><b>' + num(coins) + '</b> di ' + num(FF_TREE_COST) + ' monete</span><span>' + (can ? 'Puoi piantarlo' : 'Ne mancano ' + num(FF_TREE_COST - coins)) + '</span></div>')
    +   cta + '</div>'
    + '<div class="ffo-stat due"><div><b>' + mine.length + '<span style="font-size:15px;font-weight:700;opacity:.7">/' + FF_TREE_CAP + '</span></b><small>alberi veri</small></div><div><b>' + fatte.length + '</b><small>alberi azzurri, uno per ogni sessione finita</small></div></div>'
    + (mine.length ? '<h3 class="ffo-h">I tuoi alberi veri</h3>' + mine.map(function(t, i){ return '<div class="ffo-albero"><span>🌳</span><div><b>Albero ' + (i + 1) + '</b><small>' + new Date(t.at).toLocaleDateString('it-IT') + (t.status === 'queued' ? ' · sarà piantato a breve' : '') + '</small></div>'
        + (t.url ? '<button type="button" onclick="ufOpenUrl(\'' + esc(t.url) + '\')">Certificato</button>' : '') + '</div>'; }).join('') : '')
    + '<p class="ffo-nota">Gli alberi li pianta Tree-Nation, massimo cinque a persona.</p>'
    + '</div></div>'
    + '<div class="ffo-sl">' + ffBoscoSvg(hist, mine) + '<div class="ffo-corpo">'
    + '<p class="ffo-lead">Ogni sessione finita accende una stella e dà energia al tuo sogno.</p>'
    + '<p class="ffo-lead ffo-l2">Più il cielo si riempie, più il Genio prevede bene il tuo arrivo. E quando ti concentri, accendi anche i sogni degli altri.</p>'
    + '<div class="ffo-stat due"><div><b>' + fatte.length + '</b><small>stelle accese</small></div><div><b>' + num(mins) + '</b><small>minuti di energia</small></div></div>'
    + (fatte.length ? '<button type="button" class="ffo-cta ffo-rivedi" onclick="ffoFerma();ffCieloViaggio(function(){ })"><svg viewBox="0 0 24 24" width="26" height="26" aria-hidden="true"><defs><mask id="ffoPlay"><rect width="24" height="24" fill="#fff"/><path d="M9.1 7.6v8.8a.8.8 0 0 0 1.2.7l6.9-4.4a.8.8 0 0 0 0-1.4l-6.9-4.4a.8.8 0 0 0-1.2.7z" fill="#000"/></mask></defs><circle cx="12" cy="12" r="12" fill="currentColor" mask="url(#ffoPlay)"/></svg><span>Rivedi il tuo cielo dall’inizio</span></button>' : '')
    + (secche ? '<p class="ffo-nota">Le stelle spente sono le ' + secche + ' sessioni mollate.</p>' : '')
    + '</div></div>'
    + '</div><div class="ffo-dots" id="ffoDots"><i class="on"></i><i></i></div>';
  const cc = document.getElementById('ffoCar'); if (cc && sx) cc.scrollLeft = sx;
}
async function ffPlantTree(){
  const mine = ffRead('fl_trees', []);
  if (mine.length >= FF_TREE_CAP){ toast('Hai già piantato ' + FF_TREE_CAP + ' alberi: grazie'); return; }
  if (ffCoins() < FF_TREE_COST){ toast('Servono ' + FF_TREE_COST + ' monete'); return; }
  if (!NATIVE || !NATIVE.publicApi){ toast('Disponibile solo nell\'app installata'); return; }
  const btn = document.querySelector('.ff-plantbtn'); if (btn){ btn.disabled = true; btn.textContent = 'Pianto…'; }
  try{
    const r = await NATIVE.publicApi({ method: 'POST', path: '/api/focuslock/plant', body: JSON.stringify({ device: ffDevice(), planted: mine.length }) });
    if (!r || r.error) throw new Error((r && r.error) || 'risposta vuota');
    ffAddCoins(-FF_TREE_COST);
    mine.push({ at: Date.now(), id: r.id || null, url: r.collectUrl || r.certificateUrl || '', status: r.queued ? 'queued' : 'planted' });
    ffWrite('fl_trees', mine);
    toast(r.queued ? 'Richiesta registrata: l\'albero sarà piantato a breve' : 'Albero piantato: grazie da parte della Terra 🌍');
    if (typeof lvBump === 'function') lvBump();
  }catch(e){ toast('Non sono riuscito a piantare: ' + (e && e.message ? e.message : 'riprova')); }
  ffForestPaint();
}

/* ---------------------------------------------------------------------------------------
   Styles
   --------------------------------------------------------------------------------------- */
(function ffStyle(){
  const css = [
    /* NON PIU' VERDE FORESTA. La pagina e' la notte del brand (la stessa della Rotta e del
       prototipo): blu profondo che scende verso il nero, il colore che nell'app vuol dire
       «qui si guarda lontano». E al centro non un vaso: la sfera di cristallo del Genio,
       con la pianta dentro, che si illumina man mano che la sessione avanza. */
    '#s-fullfocus{background:radial-gradient(120% 60% at 50% 34%,#123A7A 0%,#04173A 52%,#00060F 100%);color:#fff}',
    '#s-fullfocus::before{content:"";position:absolute;inset:0;pointer-events:none;opacity:.8;background-image:radial-gradient(1.2px 1.2px at 12% 18%,#fff,transparent),radial-gradient(1px 1px at 28% 74%,#BCE0FF,transparent),radial-gradient(1.4px 1.4px at 44% 12%,#fff,transparent),radial-gradient(1px 1px at 66% 28%,#BCE0FF,transparent),radial-gradient(1.2px 1.2px at 84% 16%,#fff,transparent),radial-gradient(1px 1px at 92% 58%,#BCE0FF,transparent),radial-gradient(1.2px 1.2px at 8% 52%,#fff,transparent),radial-gradient(1px 1px at 74% 82%,#fff,transparent),radial-gradient(1.2px 1.2px at 22% 92%,#BCE0FF,transparent),radial-gradient(1px 1px at 52% 94%,#fff,transparent)}',
    '#s-fullfocus > *{position:relative}',
    '.ff-altra{fill:#BCE0FF;opacity:.16}.ff-altra.on{opacity:.9;animation:ffBrilla 3s ease-in-out var(--d,0s) infinite}@keyframes ffBrilla{50%{opacity:.35}}',
    '#s-fullfocus.running .ff-st-p{animation:ffPulsa 3.6s ease-in-out infinite;transform-origin:center}@keyframes ffPulsa{50%{opacity:.82}}',
    '.ff-top{display:flex;align-items:center;gap:10px;margin-bottom:8px;min-height:44px}',
    /* col timer acceso: via le porte, resta il suono */
    '#s-fullfocus.running .ff-back,#s-fullfocus.running .ff-coins,#s-fullfocus.running .ff-forestbtn{display:none}',
    /* il pulsante sta a destra anche quando la riga del suono non c'e': la spinta verso
       destra e' sua, non della riga */
    '.ff-sndlbl{margin-left:auto;text-align:right;line-height:1.25}',
    '.ff-sndtop{margin-left:auto}',
    '.ff-sndlbl:not([hidden]) + .ff-sndtop{margin-left:0}',
    '.ff-sndlbl b{display:block;font:600 13px var(--font-body);color:#fff}',
    '.ff-sndlbl small{display:block;font:500 11px var(--font-body);color:rgba(255,255,255,.62)}',
    '.ff-sndtop{width:40px;height:40px;border-radius:50%;border:0;background:rgba(255,255,255,.2);font-size:19px;cursor:pointer;',
      'touch-action:none;-webkit-user-select:none;user-select:none;flex:none}',
    '.ff-sndlist{display:flex;flex-direction:column;gap:8px;margin-top:8px}',
    '.ff-sndrow{display:flex;align-items:center;gap:12px;border:1.5px solid var(--line);background:#fff;color:var(--navy);',
      'border-radius:14px;padding:11px 14px;text-align:left;cursor:pointer;font:inherit}',
    'body.dark .ff-sndrow{background:#12203A;border-color:#22345A;color:#fff}',
    '.ff-sndrow.on{border-color:var(--blue,#0075E3);background:rgba(0,117,227,.08)}',
    '.ff-sndrow.lock{opacity:.55}',
    '.ff-sndrow .ico{font-size:22px;flex:none}',
    '.ff-sndrow b{display:block;font:700 14px var(--font-body)}',
    '.ff-sndrow small{display:block;font:500 11.5px var(--font-body);color:var(--muted)}',
    '.ff-sndrow i{margin-left:auto;font-style:normal}',
    '.ff-top .iconbtn{background:rgba(255,255,255,.18);color:#fff}',
    '.ff-coins{margin-left:auto;border:0;background:rgba(255,255,255,.2);color:#fff;border-radius:99px;padding:8px 14px;font:700 14px var(--font-body);cursor:pointer}',
    '.ff-forestbtn{width:40px;height:40px;border-radius:50%;border:0;background:rgba(255,255,255,.2);font-size:20px;cursor:pointer}',
    '.ff-tagrow{display:flex;align-items:center;gap:8px;font:600 20px var(--font-body);cursor:pointer}',
    '.ff-tagrow i{width:9px;height:9px;border-radius:50%;background:#F5A623}',
    '.ff-chev{width:8px;height:8px;border-right:2px solid rgba(255,255,255,.8);border-top:2px solid rgba(255,255,255,.8);transform:rotate(45deg);margin-left:2px}',
    '.ff-intent{margin:6px 0 0 17px;font:500 15px var(--font-body);color:rgba(255,255,255,.7);border-bottom:1px solid rgba(255,255,255,.35);display:inline-block;padding-bottom:3px;cursor:pointer}',
    '.ff-intent .set{color:#fff}',
    /* 0.9.332, Andrea: come Pomodoro Terrarium, una luce che esce dalla sfera e illumina il buio attorno. Cresce con la sessione */
    '.ff-sfera{position:relative;width:270px;margin:30px auto 14px}.ff-sfera::before{content:"";position:absolute;left:50%;top:135px;width:470px;height:470px;margin:-235px 0 0 -235px;border-radius:50%;background:radial-gradient(circle,rgba(63,159,244,.62) 42%,rgba(63,159,244,.2) 58%,rgba(63,159,244,0) 70%);opacity:calc(.7 + .3 * var(--ffglow,0));pointer-events:none}',
    '.ff-ball{position:relative;z-index:1;width:270px;height:270px;border-radius:50%;display:flex;align-items:center;justify-content:center;overflow:hidden;',
    '  background:radial-gradient(circle at 50% 42%,rgba(18,58,122,.75) 0%,rgba(2,10,28,.92) 78%);',
    '  border:1.5px solid rgba(200,230,255,.42);',
    '  box-shadow:inset 0 -34px 60px rgba(0,60,140,.4),inset 0 12px 30px rgba(255,255,255,.16),',
    '    0 0 calc(22px + 70px * var(--ffglow,0)) rgba(63,159,244,calc(.22 + .6 * var(--ffglow,0))),0 30px 60px rgba(0,0,0,.35);',
    '  transition:box-shadow 1s ease}',
    /* il riflesso in alto a sinistra: e' quello che fa leggere il tondo come vetro */
    '.ff-ball::after{content:none}',
    '.ff-stand{display:none}',
    '#s-fullfocus.running .ff-ball{animation:ffRespira 4s ease-in-out infinite}',
    '@keyframes ffRespira{0%,100%{transform:scale(1)}50%{transform:scale(1.015)}}',
    '.ff-plant{width:230px;height:207px}.ff-plant svg{width:100%;height:100%;display:block}',
    '.ff-status{text-align:center;font:600 13px var(--font-body);color:rgba(255,255,255,.85);margin-top:10px;min-height:18px}',
    '.ff-time{display:block;width:100%;border:0;background:transparent;color:inherit;text-align:center;font:500 68px/1 var(--font-body);letter-spacing:.02em;margin:22px 0 26px;cursor:pointer}',
    '.ff-time::after{content:"tocca per cambiare";display:block;margin-top:10px;font:600 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;opacity:.55}',
    /* a sessione partita il timer non si cambia piu': la scritta sarebbe un invito a un
       pulsante che non fa niente */
    '.ff-time.running::after{content:"";margin:0}',
    '.ff-cta{display:block;width:100%;max-width:330px;margin:0 auto;border:0;border-radius:99px;background:#0075E3;color:#fff;padding:18px;font:600 16px var(--font-body);cursor:pointer;box-shadow:0 10px 26px rgba(0,117,227,.35)}',
    '.ff-cta[disabled]{opacity:.7}',
    '.ff-quit{display:block;margin:12px auto 0;border:0;background:none;color:rgba(255,255,255,.85);font:600 14px var(--font-body);text-decoration:underline;cursor:pointer}',
    '.ff-quit[hidden]{display:none}',
    /* i due tondi della sessione in corso, come nell'app della foresta */
    /* 0.9.353: solo lo stop e la pausa (o lo stop da solo), il segno di spunta in mezzo non c'e' piu' */
    '.ff-run{display:flex;justify-content:center;align-items:center;gap:44px}',
    '.ff-time.running:active{opacity:.7}',
    /* il foglio "Hai finito il compito?": titolo a 26px dal testo, pulsante a 32px dal testo, la seconda risposta 8px sotto */
    '.ffpr-card{position:relative;padding:30px 22px 16px}.ffpr-ico{margin:4px 0 14px;line-height:0}.ffpr-x{top:12px;right:12px}',
    '.ffpr-card .ff-ask-t{margin:0 30px 26px}.ffpr-txt{display:flex;flex-direction:column;gap:10px}.ffpr-card .ff-ask-task{margin:0}',
    '.ffpr-int{font-weight:700!important;color:var(--navy)!important}body.dark .ffpr-int{color:#fff!important}',
    '.ff-ask .ffpr-card .cta{margin-top:32px}.ff-ask .ffpr-card .ff-ask-no{margin-top:8px}',
    '.ff-run[hidden]{display:none}',
    '.ff-rb{width:62px;height:62px;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}',
    '.ff-rb.on{background:#fff;color:#001E44}',
    '.ff-cta.ff-cancel{background:rgba(255,255,255,.14);color:#fff;box-shadow:none;border:1px solid rgba(255,255,255,.2)}',
    /* la pagina del risultato */
    '#s-ff-done{background:linear-gradient(180deg,#0B3F7A,#001E44 60%,#000D1F)}',
    /* la schermata finale (0.9.315): la card con la pianta, poi i due pulsanti */
    '.ffd{min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:calc(20px + env(safe-area-inset-top)) 22px calc(26px + env(safe-area-inset-bottom));color:#fff;box-sizing:border-box}',
    '.ffd-card{width:100%;max-width:370px;box-sizing:border-box;padding:18px 20px 22px;border-radius:30px;border:1.5px solid rgba(188,224,255,.3);background:linear-gradient(180deg,rgba(63,159,244,.2),rgba(0,30,68,.24));text-align:center}',
    '.ffd-plant{width:190px;max-width:60%;margin:0 auto}',
    '.ffd-plant svg{width:100%;height:auto;display:block}',
    '.ffd-plant.spento{filter:saturate(.5) brightness(.85)}',
    '.ffz{position:fixed;inset:0;z-index:30;display:flex;flex-direction:column;align-items:center;padding:calc(26px + env(safe-area-inset-top)) 24px calc(30px + env(safe-area-inset-bottom));box-sizing:border-box;color:#fff;text-align:center;overflow:hidden;background:linear-gradient(180deg,#0B4C9C 0%,#072F6B 46%,#00132B 100%)}',
    '.ffz.no{background:linear-gradient(180deg,#0A3A7C 0%,#062655 46%,#000F24 100%)}',
    '.ffz::before{content:"";position:absolute;inset:-20% -40%;background:linear-gradient(115deg,transparent 42%,rgba(188,224,255,.13) 50%,transparent 58%),linear-gradient(100deg,transparent 56%,rgba(188,224,255,.08) 62%,transparent 68%);pointer-events:none}',
    '.ffz-testa{position:relative;min-height:44px}.ffz-testa b{display:block;font:700 15px var(--font-body);color:#fff}.ffz-testa small{display:block;margin-top:4px;font:500 14px var(--font-body);color:rgba(255,255,255,.75)}',
    '.ffz-c{position:relative;flex:1;width:100%;max-width:370px;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:0}',
    '.ffz-luce{width:280px;height:70px;margin:0 0 -56px;order:2;border-radius:50%;background:radial-gradient(closest-side,rgba(188,224,255,.55),rgba(188,224,255,0));pointer-events:none}',
    '.ffz-st{position:relative;order:1;width:210px;animation:ffzEntra .7s cubic-bezier(.2,1.3,.4,1) both}.ffz-st svg{display:block;width:100%;height:auto}.ffz-st.spoglia{filter:saturate(.55) brightness(.82)}',
    '@keyframes ffzEntra{0%{opacity:0;transform:scale(.6)}100%{opacity:1;transform:none}}',
    '.ffz-s{position:absolute;width:12px;height:12px;background:#D6E8FF;transform:rotate(45deg);border-radius:2px;animation:ffzSale 3.2s ease-in-out infinite}.ffz-s.a{left:10%;top:62%}.ffz-s.b{left:84%;top:40%;width:9px;height:9px;animation-delay:.8s}.ffz-s.c{left:62%;top:6%;width:7px;height:7px;animation-delay:1.5s}.ffz-s.d{left:24%;top:18%;width:8px;height:8px;animation-delay:2.2s}',
    '@keyframes ffzSale{0%,100%{opacity:0;transform:translateY(10px) rotate(45deg)}40%,70%{opacity:.95}100%{transform:translateY(-14px) rotate(45deg)}}',
    '.ffz-t{order:3;margin:64px 0 0;font:600 20px/1.35 var(--font-body);color:#fff}',
    '.ffz-tempo{order:4;display:flex;align-items:center;justify-content:center;gap:8px;margin:18px 0 0;font:700 19px var(--font-body);color:#D6E8FF}',
    '.ffz-mon{order:4;display:flex;align-items:center;gap:12px;width:100%;box-sizing:border-box;margin-top:26px;padding:18px 22px;border-radius:40px;background:rgba(188,224,255,.16);text-align:left}.ffz-mon-i{font-size:26px;line-height:1}.ffz-mon b{flex:1;font:600 17px var(--font-body);color:#fff}.ffz-mon-n{font:800 19px var(--font-body);color:#fff}',
    '.ffz-cta.ffz-pot{margin-top:12px;overflow:hidden;background:rgba(188,224,255,.2);color:#fff}.ffz-pot i{position:absolute;width:8px;height:8px;background:#fff;transform:rotate(45deg);border-radius:1px;animation:ffzSale 2.6s ease-in-out infinite}.ffz-pot i:nth-of-type(1){left:9%;top:44%}.ffz-pot i:nth-of-type(2){right:12%;top:30%;animation-delay:.7s}.ffz-pot i:nth-of-type(3){right:24%;top:66%;width:6px;height:6px;animation-delay:1.4s}',
    '#ffzBoost{position:fixed;inset:0;z-index:40;display:flex;align-items:flex-end;background:radial-gradient(circle at 50% 30%,#12305E,#001E44 65%);animation:ngfIn .2s ease both}.ffzb-c{width:100%;box-sizing:border-box;padding:0 24px calc(40px + env(safe-area-inset-bottom));display:flex;flex-direction:column;gap:16px}.ffzb-b{display:flex;align-items:center;gap:14px;min-height:78px;padding:14px 18px;border-radius:32px;border:0;text-align:left;cursor:pointer}.ffzb-b b{flex:1;font:700 17px/1.25 var(--font-body);color:#001E44}.ffzb-b.plus{background:linear-gradient(100deg,#F0FBFF,#8CC6FF);box-shadow:0 0 0 2.5px #8CC6FF}.ffzb-b.ann{background:rgba(255,255,255,.2)}.ffzb-b.ann b{color:#fff}.ffzb-m{flex:none;width:52px;height:52px;display:flex;align-items:center;justify-content:center;border-radius:50%;border:4px solid #fff;font:800 17px var(--font-display);color:#fff}.ffzb-m.v{background:#0075E3}.ffzb-m.o{background:#E63946}.ffzb-no{padding:14px;border:0;background:none;color:#fff;font:700 16px var(--font-body);cursor:pointer}',
    '.ffzb-c{height:100%;justify-content:flex-end}.ffzb-premio{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#fff}.ffzb-moneta{display:flex;align-items:center;justify-content:center;width:112px;height:112px;margin-bottom:22px;border-radius:50%;background:radial-gradient(circle,rgba(63,159,244,.45),rgba(63,159,244,0) 70%);font-size:72px;line-height:1;animation:ffzbSu .5s cubic-bezier(.2,.9,.3,1.3) both}.ffzb-premio small{font:700 13px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8CC6FF}.ffzb-premio b{margin-top:8px;font:900 40px/1.1 var(--font-display);color:#fff}.ffzb-premio p{margin:16px 0 0;font:600 16px var(--font-body);color:#C8EFFD}@keyframes ffzbSu{from{opacity:0;transform:scale(.5)}to{opacity:1;transform:none}}',
    '.ffzb-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.ffzb-t b{flex:none!important}.ffzb-t small{font:600 13px var(--font-body);color:#0B3E86}.ffzb-b.ann .ffzb-t small{color:#C8EFFD}',
    '.ff-manca{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin:14px 0 6px}.ff-manca button{padding:14px 4px;border:1.5px solid var(--line);border-radius:99px;background:var(--card,#fff);color:var(--navy);font:700 14.5px var(--font-body);cursor:pointer}body.dark .ff-manca button{color:#fff}',
    '.ffz-cta{position:relative;flex:none;width:100%;max-width:370px;min-height:60px;margin-top:20px;border:0;border-radius:99px;background:#fff;color:#001E44;font:800 17px var(--font-body);cursor:pointer}',
    '.ffd-riga{display:flex;justify-content:center;gap:8px;margin-top:14px}',
    '.ffd-pill{padding:6px 14px;border-radius:99px;background:rgba(0,13,31,.5);font:700 14px var(--font-body);color:#fff}',
    '.ffd-tag{display:block;margin-top:12px;font:800 20px var(--font-display);color:#fff}',
    '.ffd-int{margin:6px 0 0;font:500 14px/1.45 var(--font-body);color:rgba(255,255,255,.82)}',
    '.ffd-sub{margin:8px 0 0;font:500 14px/1.45 var(--font-body);color:rgba(255,255,255,.78)}',
    '.ffd-nota{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;min-height:54px;margin-top:18px;padding:12px 18px;box-sizing:border-box;border:0;border-radius:99px;background:rgba(188,224,255,.16);color:#BCE0FF;font:700 15px/1.3 var(--font-body);cursor:pointer}',
    '.ffd-nota svg{flex:none}.ffd-nota span{min-width:0;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}',
    '.ffd-nota.scritta{color:#fff}',
    '.ffd-go{width:100%;max-width:370px;margin-top:22px;background:#fff;color:#001E44}',
    '.ffd-pausa{margin-top:10px;padding:14px 20px;border:0;background:none;color:#fff;font:700 15.5px var(--font-body);cursor:pointer}',
    '.ff-nota-x{position:absolute;top:14px;right:14px;width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,30,68,.08);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .ff-nota-x{background:rgba(255,255,255,.14);color:#fff}',
    '.ff-nota-t{margin:6px 46px 6px;text-align:center}',
    '.ff-nota-p{margin:0 0 14px;text-align:center;font:500 14px/1.45 var(--font-body);color:var(--muted)}',
    /* la pausa a tutto schermo (0.9.315), blu e sfocata */
    '.ffp{position:fixed;inset:0;z-index:9800;display:flex;align-items:center;justify-content:center;background:linear-gradient(180deg,rgba(0,91,176,.78),rgba(0,30,68,.9) 55%,rgba(0,13,31,.96));-webkit-backdrop-filter:blur(22px);backdrop-filter:blur(22px);color:#fff;text-align:center}',
    '.ffp-c{padding:0 26px}',
    '.ffp-t{margin:0;font:500 16px/1.4 var(--font-body);color:rgba(255,255,255,.86)}',
    '.ffp-n{margin:16px 0 26px;font:600 76px/1 var(--font-display);font-variant-numeric:tabular-nums;letter-spacing:.02em;color:#fff;text-shadow:0 0 28px rgba(140,198,255,.75)}',
    '.ffp-play{width:64px;height:64px;border-radius:50%;border:1.5px solid rgba(255,255,255,.4);background:rgba(255,255,255,.14);color:#fff;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}',
    '.ff-ask{position:fixed;inset:0;z-index:9000;display:flex;align-items:center;justify-content:center;padding:24px;background:rgba(0,14,34,.62)}',
    '.ff-ask-card{width:100%;max-width:340px;background:#fff;border-radius:22px;padding:28px 20px 18px;text-align:center;box-shadow:0 24px 60px rgba(0,0,0,.35)}',
    'body.dark .ff-ask-card{background:#12203A}',
    '.ff-ask-ico{font-size:44px;margin-bottom:12px}',
    '.ff-ask-t{display:block;font:800 19px/1.3 var(--font-display);color:var(--navy);margin-bottom:12px}',
    'body.dark .ff-ask-t{color:#fff}',
    '.ff-ask-task{margin:0 0 12px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.ff-ask-task b{color:#1B9E6A}',
    '.ff-ask .cta{width:100%;margin-top:12px}',
    '.ff-ask-no{width:100%;margin-top:8px;padding:12px;border:0;background:none;font:700 14px var(--font-body);color:var(--muted);cursor:pointer}',
    '.ff-cta[hidden]{display:none}',
    '#ffSheetWrap{position:fixed;inset:0;z-index:75;display:none}#ffSheetWrap.open{display:block}',
    '#ffSheetWrap.ff-sopra{z-index:9996}',
    '#ffSheetWrap .ff-scrim{opacity:0;transition:opacity .26s ease}',
    '#ffSheetWrap.in .ff-scrim{opacity:1}',
    '#ffSheetWrap .ff-sheet{transform:translateY(100%);transition:transform .3s cubic-bezier(.2,.8,.3,1)}',
    '#ffSheetWrap.in .ff-sheet{transform:none}',
    '.ff-sh-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:24px}',
    '.ff-sh-head .ff-sh-title{margin:0;flex:1}',
    '.ff-sh-head > span{width:34px}',
    '.ff-who,.ff-back{position:relative;width:34px;height:34px;border-radius:50%;border:0;background:#EEF2F7;color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .ff-who,body.dark .ff-back{background:#16233A;color:#fff}',
    '.ff-gear{font-size:17px}',
    '.ff-sh-fix{position:sticky;top:-22px;z-index:3;margin:-22px -20px 0;padding:22px 20px 2px;background:#fff}body.dark .ff-sh-fix{background:#12203A}',
    '.ff-hint-cicli{display:block;margin:6px auto 0;border:0;background:transparent;color:var(--blue,#006FCF);font-weight:700;cursor:pointer}',
    '.ff-who-dot{position:absolute;top:2px;right:2px;width:8px;height:8px;border-radius:50%;background:#E5515F}',
    /* il righello: tacche fitte, quelle dei quarti d'ora piu' alte */
    '.ff-minbox{text-align:center}',
    /* nowrap + scorrimento laterale: le pillole stanno su una riga sola a qualsiasi larghezza.
       "safe center" le tiene centrate finche' ci stanno e smette di centrarle quando non ci
       stanno piu' — senza, la prima finirebbe tagliata fuori dal bordo e irraggiungibile. */
    '.ff-pres{display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;overflow-y:hidden;margin-top:18px;'
      + 'padding:2px 2px 4px;justify-content:center;justify-content:safe center;scrollbar-width:none;-webkit-overflow-scrolling:touch}',
    '.ff-pres::-webkit-scrollbar{display:none}',
    '.ff-pre{flex:0 0 auto;white-space:nowrap;border:1px solid var(--line);background:#fff;border-radius:99px;padding:9px 16px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}',
    '.ff-pre.on{background:var(--navy);border-color:var(--navy);color:#fff}',
    'body.dark .ff-pre{background:#12203A;border-color:#22345A;color:#fff}',
    'body.dark .ff-pre.on{background:#fff;color:#0E1B33}',
    '.ff-custom{display:flex;gap:8px;align-items:center;justify-content:center;margin-top:12px}',
    '.ff-custom input{width:110px;border:1px solid var(--line);border-radius:14px;padding:11px 14px;font:600 15px var(--font-body);color:var(--navy);background:#fff;text-align:center}',
    'body.dark .ff-custom input{background:#12203A;border-color:#22345A;color:#fff}',
    '.ff-custom .ghostmini{width:auto;margin:0}',
    '.ff-ruler{display:flex;align-items:flex-end;justify-content:space-between;height:46px;margin:20px 4px 0;touch-action:none;cursor:pointer;position:relative}',
    '.ff-tick{flex:1;max-width:2px;height:12px;border-radius:1px;background:#C4D2E4;transition:height .14s,background .14s}',
    '.ff-tick.big{height:20px;background:#A9BCD4}',
    '.ff-tick.on{height:46px;max-width:3px;background:var(--navy);border-radius:2px}',
    'body.dark .ff-tick{background:#2A3C5E}body.dark .ff-tick.on{background:#fff}',
    '.ff-link{display:inline-block;margin-top:8px;border:0;background:transparent;padding:0;color:var(--blue,#006FCF);font:700 13px var(--font-body);cursor:pointer;text-decoration:underline}',
    '.ff-comp{display:flex;align-items:center;gap:14px;width:100%;text-align:left;border:1px solid var(--line);background:#fff;border-radius:18px;padding:16px;margin-top:10px;cursor:pointer}',
    '.ff-comp.on{border-color:var(--blue,#006FCF);background:#F2F8FF}',
    'body.dark .ff-comp{background:#12203A;border-color:#22345A}body.dark .ff-comp.on{background:#16233A}',
    '.ff-comp .ico{font-size:26px;flex:none}',
    '.ff-comp > div{flex:1;min-width:0}',
    '.ff-comp b{display:block;font:700 16px var(--font-body);color:var(--navy)}',
    'body.dark .ff-comp b{color:#fff}',
    '.ff-comp small{display:block;margin-top:3px;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    '.ff-comp .dot{width:20px;height:20px;border-radius:50%;border:2px solid var(--line);flex:none}',
    '.ff-comp.on .dot{border-color:var(--blue,#006FCF);background:var(--blue,#006FCF);box-shadow:inset 0 0 0 3px #fff}',
    '.ff-scrim{position:absolute;inset:0;background:rgba(0,0,0,.35)}',
    '.ff-sheet{position:absolute;left:0;right:0;bottom:0;max-height:90%;overflow-y:auto;background:#fff;border-radius:26px 26px 0 0;padding:22px 20px calc(24px + env(safe-area-inset-bottom));color:var(--navy)}',
    /* 0.9.342, Andrea: "nel foglio Dedichero' questo tempo a, il campo e' troppo attaccato al titolo" */
    '.ff-sh-title{text-align:center;font:700 17px var(--font-body);margin-bottom:0}.ff-sh-title + .ff-ta{margin-top:18px}',
    '.ff-sh-sub{font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted);margin:32px 0 12px;text-align:center}',
    '.ff-tags{display:flex;flex-direction:column;gap:8px}',
    '.ff-tagbtn{display:flex;align-items:center;gap:12px;border:1px solid var(--line);background:#fff;border-radius:99px;padding:13px 16px;font:600 15px var(--font-body);color:var(--navy);cursor:pointer;text-align:left}',
    '.ff-tagbtn i{width:12px;height:12px;border-radius:50%}',
    '.ff-tagbtn.on{border-color:var(--navy);box-shadow:0 0 0 1px var(--navy)}',
    '.ff-newtag{display:flex;gap:8px;align-items:center;margin-top:12px}.ff-newtag .fin{flex:1;margin:0}.ff-newtag .ghostmini{margin:0}',
    /* 0.9.343, Andrea: "il + sulla stessa riga di Aggiungi, e quel pulsante non si vede": pieno, blu del brand, mai a capo */
    '.ff-newtag > :first-child{flex:1;min-width:0}.ff-tag-add{flex:none;display:inline-flex;align-items:center;gap:6px;height:48px;padding:0 18px;border:0;border-radius:14px;background:#0075E3;color:#fff;font:800 14.5px var(--font-body);white-space:nowrap;box-shadow:0 6px 16px rgba(0,117,227,.32);cursor:pointer}.ff-tag-add:active{transform:scale(.97)}',
    '.ff-ta{width:100%;resize:none;font:500 16px var(--font-body)}',
    '.ff-count{text-align:right;font:500 12px var(--font-body);color:var(--muted);margin:4px 0 10px}',
    '.ff-min{text-align:center;font:700 44px/1 var(--font-body);color:var(--navy)}',
    '.ff-range{width:100%;margin:6px 0 0;--rc:var(--navy);--rt:#DCE6F5}',
    'body.dark .ff-range{--rt:#22345A}',
    '.ff-hint{font:500 12.5px/1.55 var(--font-body);color:var(--muted);margin-top:14px}',
    /* Il pannello dell'intensiva: 32px di vuoto sopra perche' e' un gruppo diverso da quello
       del numero, 18px di aria dentro perche' contiene tre cose (titolo, frase, collegamento)
       e un bordo che sfiora il testo si legge come un errore, non come compattezza. */
    '.ff-opt{display:flex;align-items:center;gap:16px;background:#F3F5F8;border-radius:18px;padding:18px;margin-top:32px}',
    '.ff-opt > div{flex:1}.ff-opt b{display:block;font:700 15px var(--font-body);color:var(--navy)}.ff-opt small{display:block;font:500 12.5px/1.55 var(--font-body);color:var(--muted);margin-top:6px}',
    /* La tendina del suono sta lontana dall'interruttore: 40px e una linea. Sono due decisioni
       di peso diverso e non devono stare nella stessa banda visiva. */
    '.ff-sndbox{margin-top:40px;border-top:1px solid var(--line);padding-top:20px}',
    'body.dark .ff-sndbox{border-top-color:#22345A}',
    '.ff-sndhead{display:flex;align-items:center;gap:14px;width:100%;border:0;background:transparent;color:var(--navy);padding:4px 0;cursor:pointer;text-align:left}',
    'body.dark .ff-sndhead{color:#fff}',
    '.ff-sndhead .ico{font-size:22px;flex:none}',
    '.ff-sndhead > div{flex:1;min-width:0}',
    '.ff-sndhead b{display:block;font:700 15px var(--font-body)}',
    '.ff-sndhead small{display:block;margin-top:4px;font:500 12.5px var(--font-body);color:var(--muted)}',
    '.ff-sndhead .fl-arrdown{flex:none;width:18px;height:18px;color:var(--muted);transition:transform .25s}',
    '.ff-sndbox.open .ff-sndhead .fl-arrdown{transform:rotate(180deg)}',
    '.ff-sndbody{display:none;padding-top:18px}',
    '.ff-sndbox.open .ff-sndbody{display:block}',
    '.ff-sounds{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}',
    '.ff-snd{border:1px solid var(--line);background:#fff;border-radius:99px;padding:11px 16px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}',
    '.ff-snd.on{background:var(--navy);border-color:var(--navy);color:#fff}.ff-snd.locked{opacity:.55}',
    '.ff-go{margin-top:32px}',
    /* Le due schede App / Siti web, nella forma del selettore di Opal. */
    '.ff-seg{display:flex;gap:6px;background:#EEF2F7;border-radius:99px;padding:5px;margin-bottom:24px}',
    'body.dark .ff-seg{background:#0E1B33}',
    '.ff-seg button{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;border:0;border-radius:99px;background:transparent;color:var(--muted);padding:12px 8px;font:700 14px var(--font-body);cursor:pointer}',
    '.ff-seg button.on{background:#fff;color:var(--navy);box-shadow:0 2px 8px rgba(0,0,0,.08)}',
    'body.dark .ff-seg button.on{background:#1B2B47;color:#fff}',
    /* La barra di ricerca con la lente del tema del sito. */
    '.fl-search{display:flex;align-items:center;gap:12px;border:1px solid var(--line);border-radius:16px;padding:0 16px;background:#fff}',
    'body.dark .fl-search{background:#12203A;border-color:#22345A}',
    '.fl-search > svg,.fl-search .fl-plus{flex:none;color:var(--muted)}',
    '.fl-search .fl-plus{font:600 20px/1 var(--font-body)}',
    '.fl-search input{flex:1;min-width:0;border:0;outline:0;background:transparent;color:var(--navy);padding:15px 0;font:500 15px var(--font-body)}',
    'body.dark .fl-search input{color:#fff}',
    '.ff-picklist{max-height:42vh;overflow-y:auto;margin-top:20px}',
    '.ff-pickrow{display:flex;align-items:center;gap:14px;padding:12px 2px;border-bottom:1px solid var(--line);cursor:pointer}',
    '.ff-pickrow:last-child{border-bottom:0}',
    'body.dark .ff-pickrow{border-bottom-color:#22345A}',
    '.ff-pickrow .ub-appico{width:40px;height:40px;border-radius:11px;flex:none}',
    '.ff-pickname{flex:1;min-width:0;font:600 14.5px var(--font-body);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    'body.dark .ff-pickname{color:#fff}',
    '.ff-pickrow input{width:22px;height:22px;accent-color:var(--blue,#006FCF);flex:none}',
    '.ff-rm{border:0;background:transparent;color:var(--muted);font:600 17px var(--font-body);cursor:pointer;padding:4px 6px}',
    '.ff-addsite{width:100%;margin-top:12px}',
    '.ff-empty{margin:28px 8px;text-align:center;font:500 13px/1.6 var(--font-body);color:var(--muted)}',
    /* la Foresta reale (0.9.315): notte del brand in entrambi i temi, il bosco disegnato dalle tue sessioni */
    '#s-ff-forest{background:linear-gradient(180deg,#07306A 0%,#001E44 42%,#000D1F 100%);color:#fff;padding-left:0;padding-right:0}',
    '.ffo-top{display:grid!important;grid-template-columns:44px 1fr 44px;align-items:center;padding-left:16px;padding-right:16px;margin-bottom:0;background:none!important}',
    '.ffo-top .iconbtn{background:rgba(255,255,255,.14)!important;color:#fff!important}',
    '.ffo-top .blk-title{text-align:center;color:#fff!important;font-style:normal}',
    '.ffo-bosco{display:block;width:100%;height:auto;margin-top:-6px}',
    '.ffo-car{display:flex;overflow-x:auto;scroll-snap-type:x mandatory;scrollbar-width:none;align-items:flex-start}.ffo-car::-webkit-scrollbar{display:none}.ffo-sl{flex:0 0 100%;min-width:0;scroll-snap-align:center}',
    '.ffo-dots{position:fixed;left:0;right:0;bottom:calc(14px + env(safe-area-inset-bottom));display:flex;justify-content:center;gap:8px;pointer-events:none}.ffo-dots i{width:8px;height:8px;border-radius:50%;background:rgba(255,255,255,.3)}.ffo-dots i.on{background:#fff}',
    '.ffo-rivedi svg{flex:none;display:block}.ffo-rivedi span{line-height:1.2}',
    '.ffo-cta.ffo-rivedi{display:flex;align-items:center;justify-content:center;gap:12px}',
    '.ffo-rivedi{display:flex;align-items:center;justify-content:center;gap:12px;background:rgba(188,224,255,.16);color:#fff}.ffi-chips button{white-space:nowrap}.ffo-l2{margin-top:-8px!important;font-size:14.5px!important;color:rgba(255,255,255,.72)!important}.ffo-stat.due{grid-template-columns:repeat(2,1fr)}',
    '#ffoTl{position:fixed;inset:0;z-index:9995;display:flex;flex-direction:column;align-items:center;justify-content:center;background:linear-gradient(180deg,#07306A 0%,#001E44 42%,#000D1F 100%);color:#fff;transition:opacity .35s}#ffoTl.via{opacity:0}#ffoTl svg{width:100%;height:auto}.ffoTl-s{animation:ffoTlS .4s ease-out both;transform-box:fill-box;transform-origin:center}@keyframes ffoTlS{0%{opacity:0}100%{opacity:1}}.ffoTl-t{margin:18px 0 0;font:800 24px var(--font-display);color:#fff}.ffoTl-d{margin:8px 0 0;min-height:22px;font:600 15px var(--font-body);color:#BCE0FF}',
    '.ffo-corpo{position:relative;padding:0 18px calc(34px + env(safe-area-inset-bottom));margin-top:-2px}',
    '.ffo-lead{margin:18px 6px 20px;text-align:center;font:500 15.5px/1.5 var(--font-body);color:rgba(255,255,255,.88)}',
    '.ffo-lead b{color:#fff;font-weight:800}',
    '.ffo-card{padding:20px;border-radius:24px;background:rgba(188,224,255,.1);box-shadow:inset 0 0 0 1px rgba(188,224,255,.16)}',
    '.ffo-card h3{margin:0;text-align:center;font:800 19px var(--font-display);color:#fff}',
    '.ffo-bar{height:12px;margin:16px 0 10px;border-radius:99px;background:rgba(255,255,255,.14);overflow:hidden}',
    '.ffo-bar i{display:block;height:100%;min-width:12px;border-radius:99px;background:linear-gradient(90deg,#0075E3,#8CC6FF)}',
    '.ffo-num{display:flex;justify-content:space-between;gap:12px;font:600 14px var(--font-body);color:rgba(255,255,255,.82)}',
    '.ffo-num b{color:#fff;font-weight:800}',
    '.ffo-cta{display:block;width:100%;min-height:56px;margin-top:18px;padding:14px 18px;border:0;border-radius:99px;background:#fff;color:#001E44;font:800 16px var(--font-body);cursor:pointer}',
    '.ffo-cta[disabled]{opacity:.55;cursor:default}',
    '.ffo-stat{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:14px}',
    '.ffo-stat > div{padding:16px 6px;border-radius:18px;background:rgba(188,224,255,.08);text-align:center}',
    '.ffo-stat b{display:block;font:800 26px var(--font-display);color:#fff}',
    '.ffo-stat small{display:block;margin-top:4px;font:600 12.5px/1.25 var(--font-body);color:rgba(255,255,255,.72)}',
    '.ffo-h{margin:28px 0 12px;text-align:center;font:800 19px var(--font-display);color:#fff}',
    '.ffo-albero{display:flex;align-items:center;gap:12px;padding:12px 14px;margin-bottom:10px;border-radius:18px;background:rgba(188,224,255,.08)}',
    '.ffo-albero > span{font-size:26px;line-height:1}.ffo-albero > div{flex:1;min-width:0}',
    '.ffo-albero b{display:block;font:700 15px var(--font-body);color:#fff}.ffo-albero small{display:block;margin-top:2px;font:500 13px var(--font-body);color:rgba(255,255,255,.72)}',
    '.ffo-albero button{flex:none;padding:9px 14px;border:0;border-radius:99px;background:rgba(255,255,255,.16);color:#fff;font:700 13px var(--font-body);cursor:pointer}',
    '.ffo-nota{margin:22px 8px 0;text-align:center;font:500 13.5px/1.5 var(--font-body);color:rgba(255,255,255,.66)}',
    /* 0.9.304, Andrea: in scuro il foglio del timer era blu notte sopra a un velo blu notte, e non si vedeva dove
       finiva. Ora il foglio e' piu' chiaro del velo (e il velo piu' scuro), con un filo di luce sul bordo; le card
       dentro restano un gradino sotto, cosi' si leggono come pezzi del foglio. */
    'body.dark #ffSheetWrap .ff-scrim{background:rgba(0,8,24,.62)}',
    'body.dark .ff-sheet{background:#22376B!important;box-shadow:0 -1px 0 rgba(188,224,255,.35),0 -14px 40px rgba(0,0,0,.45);color:#fff}',
    'body.dark .ff-tagbtn,body.dark .ff-snd,body.dark .ff-mode{background:#12203A;border-color:#22345A;color:#fff}',
    'body.dark .ff-opt{background:#0E1B33}body.dark .ff-opt b,body.dark .ff-min{color:#fff}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
