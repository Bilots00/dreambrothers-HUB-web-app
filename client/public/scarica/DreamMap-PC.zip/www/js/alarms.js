/* alarms.js - la scheda Sveglia.

   Una sveglia vera, non un promemoria: la lista delle sveglie, l'editor con le ruote dell'ora,
   ripeti / volume / vibrazione, e la pagina dell'audio dove si scelgono le tracce (con
   "Shuffle ogni giorno": una diversa a ogni sveglia). Il salvataggio vero sta nel telefono
   (Alarms.java, AlarmManager); qui c'è una copia per disegnare subito.

   Le voci sono DUE, e le mette l'utente. L'app non porta audio pronti: le voci dei motivatori
   che girano su YouTube appartengono a chi le ha registrate, e infilarle dentro un'app è il
   genere di cosa per cui l'app viene tolta dallo store. Chi vuole quella voce mette il suo
   file, una volta, e resta lì. Con gli slot vuoti suona la suoneria di sveglia del telefono:
   una sveglia impostata deve suonare sempre, anche prima che l'utente abbia scelto. */

const AL = { list: [], slots: {}, edit: null, isNew: false, caps: { exact: true, fullScreen: true, notifications: true }, previewing: null, previewT: null };
const AL_KEY = 'fl_alarms';
const AL_SLOTS_KEY = 'fl_alarm_slots';

/* I due slot. I nomi dicono il tono, non la persona: intitolarli a qualcuno che esiste sarebbe
   un problema in sé, e comunque la voce la sceglie chi usa l'app. */
const AL_SLOTS = [
  { id: 'dura',   ico: '🔥', name: 'Voce dura',       hint: 'Quella che non ti fa sconti alle cinque del mattino.' },
  { id: 'ispira', ico: '⛰️', name: 'Voce che ispira', hint: 'Quella che ti ricorda perché vale la pena alzarsi.' }
];

/* 12 ore con AM/PM dove il telefono le usa, 24 ore altrove: le ruote seguono il sistema. */
const AL_H12 = (function(){
  try{
    const o = new Intl.DateTimeFormat(navigator.language, { hour: 'numeric' }).resolvedOptions();
    return o.hour12 === true || /^h1[12]$/.test(o.hourCycle || '');
  }catch(_){ return false; }
})();

function alFmt(h, m){
  const mm = String(m).padStart(2, '0');
  if (!AL_H12) return { t: String(h).padStart(2, '0') + ':' + mm, ap: '' };
  const ap = h >= 12 ? 'PM' : 'AM';
  let hh = h % 12; if (hh === 0) hh = 12;
  return { t: String(hh).padStart(2, '0') + ':' + mm, ap: ap };
}

/* ---------- i dati ---------- */
function alLocal(){
  try{ const l = JSON.parse(localStorage.getItem(AL_KEY) || '[]'); return Array.isArray(l) ? l : []; }catch(_){ return []; }
}
function alSlotsLocal(){
  try{ return JSON.parse(localStorage.getItem(AL_SLOTS_KEY) || '{}') || {}; }catch(_){ return {}; }
}
async function alLoad(){
  AL.list = alLocal();
  AL.slots = alSlotsLocal();
  alPaint();
  if (NATIVE && NATIVE.getAlarms){
    try{
      const r = await NATIVE.getAlarms();
      if (r && Array.isArray(r.list)) AL.list = r.list;
      if (r && r.slots) AL.slots = r.slots;
      AL.caps = { exact: r.exact !== false, fullScreen: r.fullScreen !== false, notifications: r.notifications !== false };
      try{ localStorage.setItem(AL_KEY, JSON.stringify(AL.list)); localStorage.setItem(AL_SLOTS_KEY, JSON.stringify(AL.slots)); }catch(_){ }
      alPaint();
    }catch(_){ }
  }
}
async function alSave(){
  try{ localStorage.setItem(AL_KEY, JSON.stringify(AL.list)); localStorage.setItem(AL_SLOTS_KEY, JSON.stringify(AL.slots)); }catch(_){ }
  alPaint();
  if (NATIVE && NATIVE.saveAlarms){
    try{
      const r = await NATIVE.saveAlarms({ list: AL.list, slots: AL.slots });
      if (r) AL.caps = { exact: r.exact !== false, fullScreen: r.fullScreen !== false, notifications: r.notifications !== false };
      alPaint();
    }catch(e){ toast('Sveglia non salvata nel telefono'); }
  }
}
function alSlotDef(id){ return AL_SLOTS.filter(x => x.id === id)[0] || null; }
function alSlotFilled(id){ const v = AL.slots[id]; return !!(v && v.uri); }
function alTrackTitle(id){
  if (!id) return 'Suoneria del telefono';
  const v = AL.slots[id];
  if (v && v.name) return v.name;
  const d = alSlotDef(id);
  return d ? d.name : 'Suoneria del telefono';
}
function alAudioLabel(a){
  const t = (a.tracks || []).filter(alSlotFilled);
  if (!t.length) return 'Suoneria del telefono';
  if (a.shuffle && t.length > 1) return 'Shuffle (' + t.length + ')';
  return alTrackTitle(t[0]) + (t.length > 1 ? ' +' + (t.length - 1) : '');
}

/* ---------- la lista ---------- */
function alPaint(){
  const host = document.getElementById('alPage');
  if (!host) return;
  const caps = [];
  if (!AL.caps.notifications) caps.push(['Le notifiche sono spente: la sveglia non può farsi vedere.', 'notifications', 'Attiva']);
  if (!AL.caps.exact) caps.push(['Per suonare al minuto esatto serve «Sveglie e promemoria».', 'exact', 'Concedi']);
  if (!AL.caps.fullScreen) caps.push(['Per aprirsi sul telefono bloccato serve un permesso in più.', 'fullscreen', 'Concedi']);
  let h = '<div class="al-head"><h2>Tutte le sveglie</h2><button type="button" class="al-plus" onclick="alOpen(null)" aria-label="Nuova sveglia">+</button></div>';
  h += caps.map(c => '<div class="al-cap"><span>' + esc(c[0]) + '</span><button type="button" onclick="alAccess(\'' + c[1] + '\')">' + c[2] + '</button></div>').join('');
  if (!AL.list.length){
    h += '<div class="al-empty"><div class="ico">⏰</div><b>Nessuna sveglia</b><p>Tocca + per crearne una: scegli l\'ora, e la voce che ti tira giù dal letto.</p></div>';
  } else {
    const sorted = AL.list.slice().sort((a, b) => (a.hour * 60 + a.minute) - (b.hour * 60 + b.minute));
    h += sorted.map(a => {
      const f = alFmt(a.hour, a.minute);
      return '<div class="al-row" onclick="alOpen(' + a.id + ')">'
        + '<div class="al-l"><b class="al-time">' + f.t + (f.ap ? '<small>' + f.ap + '</small>' : '') + '</b>'
        + '<span class="al-sub"><svg class="al-note" viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path fill="currentColor" d="M9 3v10.6A3.5 3.5 0 1 0 11 17V7h5V3z"/></svg><span>' + esc(alAudioLabel(a)) + '</span></span></div>'
        + '<span class="al-rep">' + (a.repeat ? 'Ogni giorno' : 'Una volta') + '</span>'
        + '<label class="al-tog" onclick="event.stopPropagation()"><input type="checkbox"' + (a.on ? ' checked' : '') + ' onchange="alToggle(' + a.id + ', this.checked)"><i></i></label>'
        + '</div>';
    }).join('');
  }
  host.innerHTML = h;
}
function alToggle(id, on){
  const a = AL.list.find(x => x.id === id);
  if (!a) return;
  a.on = !!on;
  alSave();
  if (on){ const f = alFmt(a.hour, a.minute); toast('Sveglia alle ' + f.t + (f.ap ? ' ' + f.ap : '')); }
}
async function alAccess(what){
  if (!NATIVE || !NATIVE.requestAlarmAccess) return;
  try{ await NATIVE.requestAlarmAccess({ what: what }); }catch(_){ }
  /* L'avviso deve sparire appena il permesso c'è.
     Concederlo porta fuori dall'app, e al ritorno nessuno ricontrollava: l'avviso rosso
     restava lì a dire una cosa non più vera. Si richiede lo stato al rientro, e per sicurezza
     un paio di volte dopo, perché il sistema a volte ci mette un attimo a registrarlo. */
  const again = () => { if (NATIVE.getAlarms) alLoad(); };
  const onBack = () => { if (!document.hidden){ again(); setTimeout(again, 900); setTimeout(again, 2500); document.removeEventListener('visibilitychange', onBack); } };
  document.addEventListener('visibilitychange', onBack);
  setTimeout(again, 1500);
}

/* ---------- l'editor ---------- */
function alNewId(){ let m = 0; AL.list.forEach(a => { if (a.id > m) m = a.id; }); return m + 1; }
function alOpen(id){
  if (id === null || id === undefined){
    const now = new Date();
    let hour = now.getHours() + 1, minute = 0;
    if (hour > 23) hour = 7;
    AL.edit = { id: alNewId(), hour: hour, minute: minute, on: true, repeat: false, volume: 70, vibrate: true,
                shuffle: true, tracks: AL_SLOTS.map(x => x.id) };
    AL.isNew = true;
  } else {
    const a = AL.list.find(x => x.id === id);
    if (!a) return;
    AL.edit = JSON.parse(JSON.stringify(a));
    AL.isNew = false;
  }
  alEditPaint();
  goId('s-alarm-edit');
}
function alWheel(id, values, sel, labels){
  return '<div class="al-wheel" id="' + id + '"><div class="al-pad"></div>'
    + values.map((v, i) => '<div class="al-wi' + (i === sel ? ' on' : '') + '" data-v="' + v + '">' + (labels ? labels[i] : v) + '</div>').join('')
    + '<div class="al-pad"></div></div>';
}
function alEditPaint(){
  const e = AL.edit;
  const hours = AL_H12 ? [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11] : Array.from({ length: 24 }, (_, i) => i);
  const hLabels = hours.map(v => String(v).padStart(2, '0'));
  const hSel = AL_H12 ? (e.hour % 12) : e.hour;
  const mins = Array.from({ length: 60 }, (_, i) => i);
  const mLabels = mins.map(v => String(v).padStart(2, '0'));
  const el = document.getElementById('alEditBody');
  if (!el) return;
  el.innerHTML = '<div class="al-picker">'
    + alWheel('alWh', hours, hSel, hLabels)
    + alWheel('alWm', mins, e.minute, mLabels)
    + (AL_H12 ? alWheel('alWa', ['AM', 'PM'], e.hour >= 12 ? 1 : 0) : '')
    + '</div>'
    + '<div class="al-opt"><span>Ripeti ogni giorno</span><label class="al-tog"><input type="checkbox" id="alRepeat"' + (e.repeat ? ' checked' : '') + '><i></i></label></div>'
    + '<div class="al-opt col"><span>Volume della sveglia</span><input type="range" class="al-range" id="alVolume" min="10" max="100" value="' + (e.volume || 70) + '" oninput="AL.edit.volume=+this.value"></div>'
    + '<div class="al-opt"><span>Vibrazione</span><label class="al-tog"><input type="checkbox" id="alVibrate"' + (e.vibrate ? ' checked' : '') + '><i></i></label></div>'
    + '<div class="al-opt link" onclick="alAudioOpen()"><span>Audio</span><em>' + esc(alAudioLabel(e)) + '</em><svg class="chev" viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path fill="none" stroke="#9A9AA3" stroke-width="2.5" stroke-linecap="round" d="M9 5l7 7-7 7"/></svg></div>'
    + '<button type="button" class="al-save" onclick="alEditSave()">Salva</button>'
    + (AL.isNew ? '' : '<button type="button" class="al-del" onclick="alDelete()">Elimina sveglia</button>');
  flRangeAll(el);
  ['alWh', 'alWm', 'alWa'].forEach(id => {
    const w = document.getElementById(id);
    if (!w) return;
    const items = w.querySelectorAll('.al-wi');
    let sel = 0; items.forEach((it, i) => { if (it.classList.contains('on')) sel = i; });
    requestAnimationFrame(() => { w.scrollTop = sel * 44; });
    w.addEventListener('scroll', () => {
      clearTimeout(w._t);
      w._t = setTimeout(() => {
        const i = Math.max(0, Math.min(items.length - 1, Math.round(w.scrollTop / 44)));
        items.forEach((it, k) => it.classList.toggle('on', k === i));
      }, 60);
    });
  });
}
function alWheelValue(id){
  const w = document.getElementById(id);
  if (!w) return null;
  const items = w.querySelectorAll('.al-wi');
  const i = Math.max(0, Math.min(items.length - 1, Math.round(w.scrollTop / 44)));
  return items[i].dataset.v;
}
function alEditSave(){
  const e = AL.edit;
  if (!e) return;
  let h = parseInt(alWheelValue('alWh'), 10);
  const m = parseInt(alWheelValue('alWm'), 10);
  if (AL_H12){
    const pm = alWheelValue('alWa') === 'PM';
    h = h % 12 + (pm ? 12 : 0);
  }
  e.hour = isNaN(h) ? e.hour : h;
  e.minute = isNaN(m) ? e.minute : m;
  e.repeat = !!(document.getElementById('alRepeat') || {}).checked;
  e.vibrate = !!(document.getElementById('alVibrate') || {}).checked;
  e.volume = +((document.getElementById('alVolume') || {}).value || 70);
  e.on = true;
  e.tracks = (e.tracks || []).filter(alSlotFilled);
  const i = AL.list.findIndex(x => x.id === e.id);
  if (i >= 0) AL.list[i] = e; else AL.list.push(e);
  alSave();
  const f = alFmt(e.hour, e.minute);
  toast('Sveglia alle ' + f.t + (f.ap ? ' ' + f.ap : '') + (e.repeat ? ', ogni giorno' : ''));
  goId('s-home'); switchTab('sveglia');
}
function alDelete(){
  if (!AL.edit) return;
  AL.list = AL.list.filter(x => x.id !== AL.edit.id);
  alSave();
  goId('s-home'); switchTab('sveglia');
}

/* ---------- la pagina dell'audio: due voci, le tue ---------- */
function alAudioOpen(){
  alAudioPaint();
  goId('s-alarm-audio');
}
function alAudioPaint(){
  const e = AL.edit; if (!e) return;
  const el = document.getElementById('alAudioBody');
  if (!el) return;
  const filled = AL_SLOTS.filter(x => alSlotFilled(x.id)).length;
  el.innerHTML = (filled > 1
      ? '<div class="al-opt"><span>Shuffle ogni giorno</span><label class="al-tog"><input type="checkbox"' + (e.shuffle ? ' checked' : '') + ' onchange="AL.edit.shuffle=this.checked"><i></i></label></div>'
        + '<p class="al-hint">Con tutte e due scelte, ogni mattina parte quella che non hai sentito ieri.</p>'
      : '')
    + '<div class="al-sect"><b>Le tue due voci</b></div>'
    + '<p class="al-hint">L\'audio lo scegli tu dal telefono: un file che hai già, una registrazione tua, quello che ti sveglia davvero. Finché sono vuote suona la suoneria di sveglia del telefono.</p>'
    + AL_SLOTS.map(alSlotRow).join('')
    + '<div class="al-savewrap"><button type="button" class="al-save" onclick="alAudioSave()">Salva modifiche</button></div>';
}
function alSlotRow(d){
  const e = AL.edit;
  const v = AL.slots[d.id];
  const has = !!(v && v.uri);
  const on = has && e.tracks.indexOf(d.id) >= 0;
  const sub = has ? esc(v.name || 'Audio dal telefono') : d.hint;
  return '<div class="al-track' + (on ? ' on' : '') + (has ? '' : ' empty') + '">'
    + '<div class="al-artwrap" onclick="' + (has ? 'alPreview(\'' + d.id + '\')' : 'alPickSlot(\'' + d.id + '\')') + '">'
    +   '<div class="al-art slot">' + d.ico + (has ? '<span class="al-play">' + (AL.previewing === d.id ? '❚❚' : '▶') + '</span>' : '') + '</div></div>'
    + '<div class="al-tl" onclick="' + (has ? 'alTrackToggle(\'' + d.id + '\')' : 'alPickSlot(\'' + d.id + '\')') + '">'
    +   '<b>' + esc(d.name) + '</b><small>' + sub + '</small>'
    +   (has ? '<button type="button" class="al-change" onclick="event.stopPropagation();alPickSlot(\'' + d.id + '\')">Cambia audio</button>' : '')
    + '</div>'
    + (has
        ? '<span class="al-check" onclick="alTrackToggle(\'' + d.id + '\')">' + (on ? '✓' : '') + '</span>'
        : '<span class="al-add" onclick="alPickSlot(\'' + d.id + '\')">+</span>')
    + '</div>';
}
function alTrackToggle(id){
  const e = AL.edit; if (!e) return;
  if (!alSlotFilled(id)){ alPickSlot(id); return; }
  const i = e.tracks.indexOf(id);
  if (i >= 0) e.tracks.splice(i, 1); else e.tracks.push(id);
  alAudioPaint();
}
async function alPickSlot(id){
  if (!NATIVE || !NATIVE.pickMedia){ toast('Disponibile solo sul telefono'); return; }
  try{
    const r = await NATIVE.pickMedia({ kind: 'audio' });
    const uri = r && (r.uri || r.value);
    if (!uri) return;
    const name = String((r && r.name) || 'Audio dal telefono').replace(/^.*[\/:]/, '').replace(/\.[a-z0-9]{2,4}$/i, '');
    AL.slots[id] = { uri: uri, name: name };
    if (AL.edit && AL.edit.tracks.indexOf(id) < 0) AL.edit.tracks.push(id);
    try{ localStorage.setItem(AL_SLOTS_KEY, JSON.stringify(AL.slots)); }catch(_){ }
    if (NATIVE.saveAlarms){ try{ await NATIVE.saveAlarms({ list: AL.list, slots: AL.slots }); }catch(_){ } }
    alAudioPaint();
  }catch(_){ }
}
function alAudioSave(){
  alPreviewStop();
  alEditPaint();
  goId('s-alarm-edit');
}

/* L'anteprima è esattamente quello che suonerà: la fa il telefono (AlarmPlayer). */
async function alPreview(id){
  if (AL.previewing === id){ alPreviewStop(); return; }
  alPreviewStop();
  AL.previewing = id;
  alAudioPaint();
  if (NATIVE && NATIVE.previewAlarm){
    try{ await NATIVE.previewAlarm({ id: id, volume: (AL.edit && AL.edit.volume) || 70 }); }
    catch(_){ toast('Anteprima non disponibile'); }
  }
  AL.previewT = setTimeout(alPreviewStop, 45000);
}
function alPreviewStop(){
  clearTimeout(AL.previewT);
  if (!AL.previewing) return;
  AL.previewing = null;
  if (NATIVE && NATIVE.stopAlarmPreview){ try{ NATIVE.stopAlarmPreview(); }catch(_){ } }
  alAudioPaint();
}
document.addEventListener('fl:screen', function(e){ if (e.detail !== 's-alarm-audio') alPreviewStop(); });
document.addEventListener('visibilitychange', function(){ if (document.hidden) alPreviewStop(); });

/* ---------- la pagina informativa, una volta ---------- */
function alInfoMaybe(){
  try{ if (localStorage.getItem('fl_alarm_info') === '1') return; }catch(_){ }
  const el = document.getElementById('alInfo');
  if (el) el.hidden = false;
}
function alInfoClose(){
  const el = document.getElementById('alInfo');
  const cb = document.getElementById('alInfoCb');
  if (cb && cb.checked){ try{ localStorage.setItem('fl_alarm_info', '1'); }catch(_){ } }
  if (el) el.hidden = true;
}

/* ---------- gli schermi ---------- */
/* LA PAGINA DELLE SVEGLIE.

   Stava in fondo alla scheda START, sotto alla pianificazione: l'unico blocco che non parlava
   di oggi, in mezzo a cose che parlano solo di oggi. Adesso e' una pagina sua, e ci si arriva
   dal carosello della pianificazione — che e' il momento in cui uno pensa a domani, cioe'
   l'unico momento in cui ha senso mettere una sveglia. */
registerScreen('s-alarms',
  '<div class="al-screen"><div class="al-top"><button type="button" class="al-back" onclick="alPageClose()" aria-label="Indietro">←</button><span></span></div>'
  + '<div class="al-page" id="alPage"></div></div>', { back: 's-home' });

function alPageOpen(){
  goId('s-alarms');
  alLoad();
  setTimeout(alInfoMaybe, 600);
}
function alPageClose(){
  goId('s-home');
  if (typeof switchTab === 'function') switchTab('sveglia');
}

registerScreen('s-alarm-edit',
  '<div class="al-screen"><div class="al-top"><span></span><button type="button" class="al-x" onclick="goId(\'s-alarms\')" aria-label="Chiudi">✕</button></div>'
  + '<div id="alEditBody"></div></div>', { back: 's-alarms' });
registerScreen('s-alarm-audio',
  '<div class="al-screen"><div class="al-top"><button type="button" class="al-back" onclick="alAudioSave()" aria-label="Indietro">←</button><span></span></div>'
  + '<div id="alAudioBody"></div></div>', { back: 's-alarm-edit' });
registerOverlay('alInfo',
  '<div class="al-info"><div class="al-info-i">i</div><h3>Le tue sveglie devono suonare</h3>'
  + '<h4>Notifiche attive</h4><p>La sveglia si mostra come una notifica a schermo intero: se le notifiche di DreamMap sono spente, non può farsi vedere.</p>'
  + '<h4>Batteria senza limiti</h4><p>Alcuni telefoni «addormentano» le app per risparmiare batteria e la sveglia non parte. Nelle impostazioni della batteria metti DreamMap fra le app senza limiti.</p>'
  + '<h4>Dopo un aggiornamento</h4><p>Le sveglie si riarmano da sole dopo un riavvio o un aggiornamento. Aprire l\'app una volta non fa mai male.</p>'
  + '<label class="al-cb"><input type="checkbox" id="alInfoCb"><span></span>Non mostrare più questo messaggio.</label>'
  + '<button type="button" class="al-save" onclick="alInfoClose()">Ho capito</button></div>');
(function(){ const el = document.getElementById('alInfo'); if (el) el.hidden = true; })();

document.addEventListener('fl:tab', function(e){
  // la barra in alto è chiara: sopra la pagina nera della sveglia diventa trasparente
  document.body.classList.toggle('al-on', e.detail === 'sveglia');
  if (e.detail !== 'sveglia') return;
  /* Le sveglie si caricano lo stesso: il portale nel carosello dice quante sono e a che ora
     suona la prossima, e per dirlo deve averle lette. */
  alLoad();
});

/* ---------- lo stile: nero, come una sveglia di notte ---------- */
(function(){
  const css = [
    '#tab-sveglia{background:var(--bg);color:var(--navy)}',
    'body.dark #tab-sveglia{color:#fff}',
    /* 0.9.306, Andrea: in START i contatori in alto galleggiavano sulle card ("Fai tua la mappa" ci passava sotto).
       La causa: questa regola, nata quando START era la sveglia nera, teneva l'intestazione trasparente SEMPRE.
       Adesso e' trasparente solo sopra al cielo in cima (.glass, blkhero.js); scorrendo prende lo sfondo come Dream e Mappa. */
    'body.al-on .home-head.glass{background:transparent !important;box-shadow:none !important;border-color:transparent !important;backdrop-filter:none !important;-webkit-backdrop-filter:none !important}',
    'body.al-on .home-head.glass .iconbtn{background:rgba(2,9,38,.42);color:#fff}',
    '.al-page{padding:26px 18px 130px}',
    '#s-alarms{background:var(--bg)}',
    '#s-alarms .al-page{padding-top:6px}',
    '#tab-sveglia .al-page:first-of-type{padding-top:8px}',
    /* Sotto alle sveglie adesso c'e' dell'altro: i 130px di coda servivano quando la
       pagina finiva li' e sotto c'era solo la barra. */
    '#alPage{padding-bottom:8px}',
    /* dietro all'header c'è lo sfondo dello schermo, chiaro: sulla sveglia diventa nero */
    'body.al-on #s-home{background:var(--bg) !important}',
    '.al-head{display:flex;align-items:center;justify-content:space-between;padding-bottom:14px;border-bottom:1px solid var(--line)}',
    '.al-head h2{margin:0;font:800 26px var(--font-display);color:var(--navy)}',
    'body.dark .al-head h2{color:#fff}',
    '.al-plus{width:40px;height:40px;border:0;background:transparent;color:#2F8BFF;font:300 34px/1 var(--font-body);cursor:pointer}',
    /* rosso, non giallo: nel marchio il giallo non c'è */
    '.al-cap{display:flex;align-items:center;gap:12px;margin:12px 0 0;padding:12px 14px;border-radius:14px;background:#FFF1F3;border:1px solid #F3C4CC;font:500 12.5px/1.45 var(--font-body);color:#B3253A}',
    'body.dark .al-cap{background:#1E0B0F;border-color:#5A1B27;color:#FF8A9B}',
    '.al-cap button{flex:none;border:0;border-radius:99px;background:#E5515F;color:#fff;padding:8px 12px;font:800 12px var(--font-body)}',
    '.al-row{display:flex;align-items:center;gap:12px;padding:20px 0;border-bottom:1px solid var(--line);cursor:pointer}',
    '.al-l{flex:1;min-width:0}',
    '.al-time{display:block;font:700 40px/1 var(--font-body);color:var(--navy);letter-spacing:-.5px}',
    'body.dark .al-time{color:#fff}',
    '.al-time small{font-size:22px;font-weight:600;margin-left:6px;color:inherit}',
    '.al-sub{display:flex;align-items:center;gap:5px;margin-top:8px;font:500 13px var(--font-body);color:var(--muted)}',
    '.al-note{flex:none;color:var(--muted)}',
    '.al-sub > span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.al-rep{font:500 15px var(--font-body);color:var(--navy);flex:none}',
    'body.dark .al-rep{color:#fff}',
    '.al-empty{text-align:center;padding:70px 20px}',
    '.al-empty .ico{font-size:54px}',
    '.al-empty b{display:block;margin-top:14px;font:800 20px var(--font-display)}',
    '.al-empty b{color:var(--navy)}',
    'body.dark .al-empty b{color:#fff}',
    '.al-empty p{margin:8px 0 0;font:500 13.5px/1.55 var(--font-body);color:var(--muted)}',
    '.al-tog{position:relative;width:52px;height:30px;flex:none;display:inline-block}',
    '.al-tog input{opacity:0;width:0;height:0;position:absolute}',
    '.al-tog i{position:absolute;inset:0;border-radius:99px;background:#D3DCEA;transition:.2s}',
    'body.dark .al-tog i{background:#3A3A40}',
    '.al-tog i::after{content:"";position:absolute;top:3px;left:3px;width:24px;height:24px;border-radius:50%;background:#fff;transition:.2s}',
    '.al-tog input:checked+i{background:#2F8BFF}',
    '.al-tog input:checked+i::after{transform:translateX(22px)}',
    /* gli schermi dell'editor e dell'audio */
    '#s-alarm-edit,#s-alarm-audio{background:#0A0A0C;color:#fff}',
    '.al-screen{padding:14px 18px 120px;color:#fff;min-height:100%}',
    '.al-top{display:flex;align-items:center;justify-content:space-between;height:48px}',
    '.al-x,.al-back{border:0;background:transparent;color:#2F8BFF;font:600 26px/1 var(--font-body);cursor:pointer;padding:6px}',
    '.al-picker{position:relative;display:flex;gap:6px;margin:16px 0 8px}',
    '.al-picker::before{content:"";position:absolute;left:6px;right:6px;top:88px;height:44px;border-radius:12px;background:#1F1F24}',
    '.al-wheel{position:relative;height:220px;overflow-y:auto;scroll-snap-type:y mandatory;-webkit-overflow-scrolling:touch;flex:1;text-align:center;scrollbar-width:none;',
    '  -webkit-mask-image:linear-gradient(transparent,#000 25%,#000 75%,transparent);mask-image:linear-gradient(transparent,#000 25%,#000 75%,transparent)}',
    '.al-wheel::-webkit-scrollbar{display:none}',
    '.al-pad{height:88px}',
    '.al-wi{height:44px;line-height:44px;font:600 28px var(--font-body);color:#6F6F78;scroll-snap-align:center}',
    '.al-wi.on{color:#fff}',
    '.al-opt{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:20px 0;border-bottom:1px solid #232328;font:500 18px var(--font-body);color:#fff}',
    '.al-opt.col{flex-direction:column;align-items:stretch;gap:14px}',
    '.al-opt.link{cursor:pointer}',
    '.al-opt em{font-style:normal;font-size:14px;color:#9A9AA3;margin-left:auto}',
    '.chev{flex:none}',
    '.al-range{width:100%;--rc:#2F8BFF;--rt:#2E2E36}',
    '.al-save{display:block;width:100%;margin-top:26px;border:0;border-radius:99px;padding:17px;background:linear-gradient(90deg,#2F8BFF,#006FCF);color:#fff;font:800 16px var(--font-body);cursor:pointer}',
    '.al-del{display:block;width:100%;margin-top:12px;border:0;background:transparent;color:#FF6B6B;padding:12px;font:700 14px var(--font-body);cursor:pointer}',
    '.al-hint{margin:6px 0 4px;font:500 13px/1.5 var(--font-body);color:#8A8A93}',
    '.al-sect{display:flex;align-items:baseline;gap:14px;margin:26px 0 0}',
    '.al-sect b{font:800 15px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#2F8BFF}',
    '.al-sect button{border:0;background:transparent;color:var(--muted);font:700 13px var(--font-body);letter-spacing:.06em;text-transform:uppercase;cursor:pointer;padding:0}',
    '.al-track{display:flex;align-items:center;gap:14px;padding:14px 0;border-bottom:1px solid var(--line)}',
    '.al-artwrap{flex:none;cursor:pointer}',
    '.al-art{position:relative;width:78px;height:78px;border-radius:12px;overflow:hidden;background:#1F1F24}',
    '.al-art img{width:100%;height:100%;object-fit:cover;display:block}',
    '.al-art.slot{display:flex;align-items:center;justify-content:center;font-size:34px;background:#16161B;position:relative}',
    '.al-track.empty .al-art.slot{border:1px dashed #3A3A40;background:transparent;opacity:.75}',
    '.al-add{flex:none;width:28px;height:28px;border-radius:50%;background:#2F8BFF;color:#fff;display:flex;align-items:center;justify-content:center;font:300 22px/1 var(--font-body);cursor:pointer}',
    '.al-change{margin-top:6px;border:0;background:transparent;color:#2F8BFF;padding:0;font:700 12px var(--font-body);cursor:pointer}',
    '.al-track{align-items:flex-start}',
    '.al-tl small{display:block;margin-top:4px;font:500 12.5px/1.45 var(--font-body);color:#8A8A93}',
    '.al-play{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:22px;color:#fff;background:rgba(0,0,0,.28);text-shadow:0 2px 8px rgba(0,0,0,.6)}',
    '.al-tl{flex:1;min-width:0;cursor:pointer}',
    '.al-tl b{display:block;font:600 17px var(--font-body);color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.al-tl span{display:block;margin-top:4px;font:500 13px var(--font-body);color:#9A9AA3}',
    '.al-tl small{display:block;margin-top:3px;font:500 12px/1.4 var(--font-body);color:#6F6F78}',
    '.al-check{flex:none;width:28px;height:28px;border-radius:50%;border:2px solid #4A4A52;display:flex;align-items:center;justify-content:center;font:800 15px var(--font-body);color:#fff;cursor:pointer}',
    '.al-track.on .al-check{background:#2F8BFF;border-color:#2F8BFF}',
    '.al-savewrap{position:sticky;bottom:14px;padding-top:14px;background:linear-gradient(transparent,#0A0A0C 30%)}',
    /* la pagina informativa */
    '#alInfo[hidden]{display:none}',
    '#alInfo{position:absolute;inset:0;z-index:60;background:radial-gradient(120% 60% at 50% 0%,#2A1A08,#0A0A0C 55%);color:#fff;overflow:auto}',
    '.al-info{padding:80px 26px 40px;max-width:520px;margin:0 auto}',
    '.al-info-i{width:110px;height:110px;margin:0 auto;border-radius:50%;background:linear-gradient(135deg,#FFB13B,#FF6A00);display:flex;align-items:center;justify-content:center;font:800 64px Georgia,serif;color:#000}',
    '.al-info h3{margin:34px 0 26px;text-align:center;font:800 24px var(--font-display)}',
    '.al-info h4{margin:22px 0 8px;font:700 19px var(--font-body)}',
    '.al-info p{margin:0;font:500 16px/1.55 var(--font-body);color:#D6D6DC}',
    '.al-cb{display:flex;align-items:center;gap:12px;margin-top:38px;font:500 16px var(--font-body);cursor:pointer}',
    '.al-cb input{position:absolute;opacity:0;width:0;height:0}',
    '.al-cb span{width:26px;height:26px;border-radius:6px;border:2px solid #FF8A1F;flex:none;display:flex;align-items:center;justify-content:center;color:#fff;font-weight:800}',
    '.al-cb input:checked+span{background:#FF8A1F}',
    '.al-cb input:checked+span::after{content:"✓"}',
    '.al-info .al-save{background:linear-gradient(90deg,#FFB13B,#FF6A00);color:#111}'
  ];
  const st = document.createElement('style');
  st.textContent = css.join('\n');
  document.head.appendChild(st);
})();
