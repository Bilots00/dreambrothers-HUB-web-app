/* ===========================================================================================
   LA LETTURA A EPISODI — sette giorni di domande, un tassello al giorno (0.9.173)

   Il primo avvio dice una cosa sola, oggettiva: le ore al telefono. Tutto il resto, chi rischi
   di diventare, la data d'arrivo, la probabilita', l'ostacolo che ti tiene fermo, si guadagna
   in sette episodi da sei domande, uno al giorno. Ogni episodio finisce con un tassello dentro
   alla sfera: non si sa prima cosa contiene, e non e' mai lo stesso genere di cosa.

   PERCHE' UN GIORNO ALLA VOLTA. Akinator fa venti domande in una partita perche' deve indovinare
   un personaggio; qui le domande servono a far parlare, piu' avanti, un Io futuro che abbia la
   voce dell'utente. Quaranta domande in fila si rispondono a caso; sei al giorno, con qualcosa
   in cambio alla fine, si rispondono davvero.

   GLI OSTACOLI si contano in silenzio. Ogni risposta sposta dieci pesi; nessuno sparisce, una
   risposta successiva puo' riaccenderlo. Si vede solo l'esito, al settimo giorno. Le etichette
   sopra alla domanda distraevano: via.

   La scena e' quella del primo avvio (genio-intro.js): stesso Genio, stessa nuvoletta con la
   macchina da scrivere, stessi pulsanti gialli. Le carte in due colonne e lo slider sono gli
   stessi del primo avvio. Niente e' nuovo da imparare.
   =========================================================================================== */

const DQ_KEY = 'fl_domande';
const DQ = { ep: 0, i: 0, q: null, tass: false, ripasso: false };

const DQ_OSTACOLI = [
  { k: 'direzione',  t: 'Direzione confusa',   f: 'Non sai qual è il passo dopo, e finché non lo sai fai tutto tranne quello.' },
  { k: 'partenza',   t: 'Partenza tardiva',    f: 'Le tue giornate cominciano tardi, e il telefono si prende la parte migliore.' },
  { k: 'energia',    t: 'Poca energia',        f: 'Dormi poco o male, e con poca energia il telefono vince sempre.' },
  { k: 'attenzione', t: 'Attenzione spezzata', f: 'Prendi il telefono senza sapere perché: la giornata si rompe in cento pezzi.' },
  { k: 'paura',      t: 'Paura di sbagliare',  f: 'Se non può venire perfetta, non la fai. È così che non parte niente.' },
  { k: 'troppo',     t: 'Troppo sul piatto',   f: 'Vuoi fare tutto insieme, e tutto insieme non si muove.' },
  { k: 'ambiente',   t: 'Ambiente contrario',  f: 'Intorno a te nessuno spinge, e da soli si molla prima.' },
  { k: 'imparare',   t: 'Cose da imparare',    f: 'Ti manca ancora qualcosa da saper fare, e senza si gira a vuoto.' },
  { k: 'invisibili', t: 'Risultati invisibili', f: 'Non vedi i progressi, e quello che non si vede si abbandona.' },
  { k: 'identita',   t: 'Non mi ci vedo',      f: 'Non ti vedi ancora come la persona che ci arriva. Prima si diventa, poi si arriva.' }
];

/* i cinque pulsanti di Akinator: il peso si moltiplica per +1, +½, 0, −½, −1 */
const DQ_CINQUE = [['Sì', 1], ['Probabilmente sì', .5], ['Non lo so', 0], ['Probabilmente no', -.5], ['No', -1]];

/* ---------------------------------------------------------------------------------------
   LE DOMANDE. tipo: cinque | scelta | due | scala | parole.
   o: pesi degli ostacoli per ogni risposta (scelta/due) o per il «Sì» (cinque: il No li inverte).
   mmm: la reazione del Genio a quella risposta (scelta/due: per indice; cinque: per lato).
   --------------------------------------------------------------------------------------- */
const DQ_EPISODI = [
  { n: 1, titolo: 'Il sogno, da vicino', tema: 'della tua giornata', domande: [
    { id: 'e1q1', tipo: 'scelta', t: 'Quando avrai realizzato il tuo sogno, qual è la *prima cosa* che cambia nelle tue giornate?',
      opz: [['🌅', 'A che ora mi sveglio', { partenza: .5 }], ['👥', 'Con chi passo il tempo', { ambiente: .5 }], ['🏡', 'Dove vivo', {}], ['🌙', 'Come mi sento la sera', { energia: .5 }]] },
    { id: 'e1q2', tipo: 'cinque', t: 'Sapresti dirmi qual è *il passo di domani*?', o: { direzione: -1.5 },
      mmm: { no: 'Mmm… *non lo sai.* Va bene così: è la prima cosa che sistemiamo insieme.' } },
    { id: 'e1q3', tipo: 'due', t: 'Cosa ti pesa di più?',
      opz: [['🚪', 'Non averci mai provato', { paura: 1, identita: .5 }], ['🩹', 'Averci provato e aver fallito', { invisibili: .5, paura: .5 }]] },
    { id: 'e1q4', tipo: 'cinque', t: 'Qualcuno, oltre a te, *sa di questo sogno*?', o: { ambiente: -1 } },
    { id: 'e1q5', tipo: 'scala', t: 'Quanto ci credi, *oggi*?', min: 1, max: 10, o: { identita: -.25 } },
    { id: 'e1q6', tipo: 'scelta', t: 'Finisci la frase: *lo voglio perché…*',
      opz: [['🕊️', 'Voglio essere libero di scegliere', {}], ['💪', 'Voglio dimostrare che ce la faccio', {}], ['❤️', 'Voglio dare di più a chi amo', {}], ['🏆', 'Voglio essere fiero di me', {}]],
      mmm: ['Mmm… *questa la tengo.* Un giorno te la rileggerò, e vedrai che effetto fa.', 'Mmm… *questa la tengo.* Un giorno te la rileggerò, e vedrai che effetto fa.', 'Mmm… *questa la tengo.* Un giorno te la rileggerò, e vedrai che effetto fa.', 'Mmm… *questa la tengo.* Un giorno te la rileggerò, e vedrai che effetto fa.'] }
  ], chiusura: 'Ho un\'idea di chi rischi di diventare. *Tocca la sfera.*' },

  { n: 2, titolo: 'La tua giornata', tema: 'del vecchio te', domande: [
    { id: 'e2q1', tipo: 'scelta', t: 'In quale momento hai *la testa più lucida*?',
      opz: [['🌄', 'Mattina presto', {}], ['☕', 'Tarda mattina', {}], ['🌤️', 'Pomeriggio', {}], ['🌙', 'Sera tardi', { energia: .5 }]],
      variante: { se: function(r){ return dqNeg(r.e1q2); }, q: { id: 'e2q1b', tipo: 'scelta', t: 'Da quanto tempo *non sai qual è il passo dopo*?',
        opz: [['📅', 'Da qualche giorno', { direzione: .5 }], ['🗓️', 'Da settimane', { direzione: 1 }], ['📆', 'Da mesi', { direzione: 1.5 }], ['♾️', 'Da sempre', { direzione: 2, identita: .5 }]],
        mmm: [null, null, 'Mmm… *da mesi.* Allora non è un passo che manca: è la rotta. Ci penso io.', 'Mmm… *da sempre.* Va bene, cominciamo da zero: è il posto migliore da cui partire.'] } } },
    { id: 'e2q2', tipo: 'cinque', t: 'Nelle ore in cui hai la testa più lucida, di solito stai *lavorando al tuo sogno*?', o: { partenza: -1, attenzione: -.5 } },
    { id: 'e2q3', tipo: 'scelta', t: 'Qual è la prima cosa che tocchi *appena sveglio*?',
      opz: [['📱', 'Il telefono', { attenzione: 1, partenza: .5 }], ['⏰', 'Solo la sveglia', {}], ['☕', 'Il caffè', {}], ['📓', 'Un libro o un quaderno', { attenzione: -.5 }]],
      mmm: ['Mmm… *il telefono.* Come quasi tutti. È la prima abitudine che vale la pena spezzare.', null, null, 'Mmm… *un quaderno.* Sei più avanti di quanto pensi.'] },
    { id: 'e2q4', tipo: 'cinque', t: 'Ti capita di prendere il telefono *senza sapere perché* l\'hai preso?', o: { attenzione: 1.5 } },
    { id: 'e2q5', tipo: 'scelta', t: 'Quante ore dormi, in una *notte normale*?',
      opz: [['😵', 'Meno di 5', { energia: 2 }], ['😴', '5 o 6', { energia: 1 }], ['😌', '7 o 8', {}], ['🛌', 'Più di 8', {}]],
      mmm: ['Mmm… *meno di cinque.* Prima di ogni regola, viene il sonno. Me lo segno in cima.', null, null, null] },
    { id: 'e2q6', tipo: 'scelta', t: 'Ieri sera, *dalle 21 in poi*, cosa ti ha preso più tempo?',
      opz: [['📱', 'Il telefono', {}], ['📺', 'Una serie o dei video', {}], ['👥', 'Gli amici o la famiglia', {}], ['🎯', 'Il mio sogno', {}]],
      mmm: ['Mmm… *le tue sere.* Sono quasi sempre lì che si decide la giornata dopo.', 'Mmm… *le tue sere.* Sono quasi sempre lì che si decide la giornata dopo.', 'Mmm… *le tue sere.* Sono quasi sempre lì che si decide la giornata dopo.', 'Mmm… *le tue sere.* Sono quasi sempre lì che si decide la giornata dopo.'] }
  ], chiusura: 'Nei tuoi giorni c\'è un\'ora che decide le altre. *L\'ho trovata.*' },

  { n: 3, titolo: 'Il vecchio te', tema: 'delle prove passate', domande: [
    { id: 'e3q1', tipo: 'scelta', t: 'Quando rimandi, *cosa ti dici*?',
      opz: [['🕰️', 'Lo faccio dopo, con più calma', { partenza: 1 }], ['🪫', 'Oggi non sono in forma', { energia: 1 }], ['🧹', 'Prima sistemo un\'altra cosa', { troppo: 1 }], ['🌫️', 'Tanto non cambia niente', { invisibili: 1.5, identita: .5 }]],
      mmm: [null, null, null, 'Mmm… *tanto non cambia niente.* Questa frase me la segno. Ci torniamo, e ti farò cambiare idea con i numeri.'] },
    { id: 'e3q2', tipo: 'cinque', t: 'Ti è mai capitato di *preparare tutto* per cominciare, e poi non cominciare?', o: { paura: 1, partenza: .5 } },
    { id: 'e3q3', tipo: 'due', t: 'Quando molli?',
      opz: [['🚦', 'All\'inizio, prima di partire', { paura: 1, partenza: .5 }], ['⛰️', 'A metà, quando si fa dura', { invisibili: 1, energia: .5 }]] },
    { id: 'e3q4', tipo: 'cinque', t: 'Se una cosa *non può venire perfetta*, preferisci non farla?', o: { paura: 1.5 },
      mmm: { si: 'Mmm… *il perfezionista.* È il travestimento preferito della paura. Lo conosco bene.' } },
    { id: 'e3q5', tipo: 'scelta', t: 'Dopo una giornata buttata, *cosa fai*?',
      opz: [['😤', 'Mi arrabbio con me', { identita: .5 }], ['🙈', 'Faccio finta di niente', { invisibili: .5 }], ['🤞', 'Prometto che domani cambio', { partenza: .5 }], ['🌃', 'Recupero di notte', { energia: 1 }]] },
    { id: 'e3q6', tipo: 'scelta', t: 'Che *soprannome* daresti al vecchio te?',
      opz: [['🐌', 'Il Rimandatore', {}], ['📱', 'Lo Scrollatore', {}], ['🛋️', 'Il Domani-lo-faccio', {}], ['🎭', 'Il Perfezionista', {}]],
      mmm: ['Mmm… *adesso ha un nome.* E una cosa con un nome si può battere.', 'Mmm… *adesso ha un nome.* E una cosa con un nome si può battere.', 'Mmm… *adesso ha un nome.* E una cosa con un nome si può battere.', 'Mmm… *adesso ha un nome.* E una cosa con un nome si può battere.'] }
  ], chiusura: 'Adesso il tuo avversario ha un nome. *E so come gioca.*' },

  { n: 4, titolo: 'Le prove passate', tema: 'di quello che hai, e di quello che ti manca', domande: [
    { id: 'e4q1', tipo: 'cinque', t: 'Hai già provato a cambiare, *almeno una volta*?', o: {} },
    { id: 'e4q2', tipo: 'scelta', t: 'La volta che è andata meglio, *quanto è durata*?',
      opz: [['🌱', 'Pochi giorni', { invisibili: .5 }], ['🌿', 'Un paio di settimane', {}], ['🌳', 'Qualche mese', { invisibili: -.5 }], ['🏔️', 'Più di sei mesi', { invisibili: -1 }]],
      variante: { se: function(r){ return dqNeg(r.e4q1); }, q: { id: 'e4q2b', tipo: 'scelta', t: 'Cosa ti ha fermato *prima ancora di provare*?',
        opz: [['🧭', 'Non sapevo da dove partire', { direzione: 1.5 }], ['😰', 'La paura di fare una figuraccia', { paura: 1.5 }], ['⏳', 'Non c\'era mai il momento', { troppo: 1, partenza: .5 }], ['🪞', 'Non mi sembrava roba per me', { identita: 2 }]] } } },
    { id: 'e4q3', tipo: 'scelta', t: '*Cosa l\'ha fatta finire*?',
      opz: [['🌪️', 'Un imprevisto', {}], ['🥱', 'La noia', { invisibili: .5, energia: .5 }], ['🔍', 'Non vedevo nessun risultato', { invisibili: 1.5 }], ['🗣️', 'Qualcuno mi ha scoraggiato', { ambiente: 1.5 }]],
      variante: { se: function(r){ return dqNeg(r.e4q1); }, q: { id: 'e4q3b', tipo: 'scelta', t: 'Chi ti ha detto, o fatto capire, che *non faceva per te*?',
        opz: [['👪', 'Qualcuno in famiglia', {}], ['🤝', 'Un amico', {}], ['🧑‍🏫', 'Un insegnante o un capo', {}], ['🪞', 'Nessuno: me lo sono detto da solo', {}]],
        mmm: ['Mmm… *me lo ricorderò.* Quando arriverai, sarà la prima cosa a cui penserai.', 'Mmm… *me lo ricorderò.* Quando arriverai, sarà la prima cosa a cui penserai.', 'Mmm… *me lo ricorderò.* Quando arriverai, sarà la prima cosa a cui penserai.', 'Mmm… *me lo ricorderò.* Quando arriverai, sarà la prima cosa a cui penserai.'] } } },
    { id: 'e4q4', tipo: 'cinque', t: 'In quel periodo *tenevi il conto* dei progressi?', o: { invisibili: -1 } },
    { id: 'e4q5', tipo: 'due', t: 'Cosa reggi meglio?',
      opz: [['🧱', 'Una regola dura e chiara', {}], ['🌊', 'Una regola morbida, che posso adattare', {}]] },
    { id: 'e4q6', tipo: 'scelta', t: 'Cosa faresti *in modo diverso*, questa volta?',
      opz: [['🪜', 'Comincerei più in piccolo', {}], ['📊', 'Terrei il conto dei progressi', {}], ['📣', 'Lo direi a qualcuno', {}], ['📵', 'Toglierei le distrazioni prima di partire', {}]],
      mmm: ['Mmm… *lo sai già.* Quasi sempre è così: la risposta c\'è, manca chi la tiene in piedi.', 'Mmm… *lo sai già.* Quasi sempre è così: la risposta c\'è, manca chi la tiene in piedi.', 'Mmm… *lo sai già.* Quasi sempre è così: la risposta c\'è, manca chi la tiene in piedi.', 'Mmm… *lo sai già.* Quasi sempre è così: la risposta c\'è, manca chi la tiene in piedi.'] }
  ], chiusura: 'Oggi niente numeri. *Ti ho lasciato una cosa da usare.*' },

  { n: 5, titolo: 'Quello che hai, quello che ti manca', tema: 'della tua voce', domande: [
    { id: 'e5q1', tipo: 'scelta', t: 'Quanto *tempo vero* puoi dare al sogno, in un giorno feriale?',
      opz: [['⏱️', 'Meno di 30 minuti', { troppo: 1 }], ['⏲️', 'Da 30 minuti a un\'ora', {}], ['⏰', 'Da una a due ore', { troppo: -.5 }], ['🕰️', 'Più di due ore', { troppo: -1 }]],
      mmm: ['Mmm… *poco.* Ma trenta minuti veri battono tre ore distratte. Li useremo bene.', null, null, null] },
    { id: 'e5q2', tipo: 'cinque', t: 'Sai già fare *quello che serve* per arrivarci?', o: { imparare: -1.5 } },
    { id: 'e5q3', tipo: 'cinque', t: 'Conosci qualcuno che ha *già realizzato* un sogno come il tuo?', o: { ambiente: -1, identita: -.5 } },
    { id: 'e5q4', tipo: 'scelta', t: 'Chi hai intorno, *come reagisce* al tuo sogno?',
      opz: [['🚀', 'Mi spinge', { ambiente: -1.5 }], ['🤷', 'Mi lascia fare', {}], ['😏', 'Mi prende in giro', { ambiente: 1.5 }], ['🤫', 'Non lo sa nessuno', { ambiente: 1 }]],
      mmm: [null, null, 'Mmm… *ti prendono in giro.* Succede a chi prova. Nessuno prende in giro chi sta fermo.', null] },
    { id: 'e5q5', tipo: 'cinque', t: 'Hai un posto dove puoi lavorare *senza essere interrotto*?', o: { attenzione: -1, ambiente: -.5 } },
    { id: 'e5q6', tipo: 'scelta', t: 'Qual è la cosa che *ti manca di più*, adesso?',
      opz: [['⏳', 'Il tempo', {}], ['🔁', 'La costanza', {}], ['🧭', 'Una guida', {}], ['💫', 'La fiducia in me', {}]],
      mmm: ['Mmm… *quello che ti manca è più chiaro di quanto pensi.* E di solito costa meno di quanto sembri.', 'Mmm… *quello che ti manca è più chiaro di quanto pensi.* E di solito costa meno di quanto sembri.', 'Mmm… *quello che ti manca è più chiaro di quanto pensi.* E di solito costa meno di quanto sembri.', 'Mmm… *quello che ti manca è più chiaro di quanto pensi.* E di solito costa meno di quanto sembri.'] }
  ], chiusura: 'Ho abbastanza per un numero. *È il tuo, e può cambiare.*' },

  { n: 6, titolo: 'La tua voce', tema: 'del patto', domande: [
    { id: 'e6q1', tipo: 'due', t: 'Quando sbagli, come vuoi che *te lo si dica*?',
      opz: [['🪓', 'La verità secca', {}], ['🕊️', 'La verità con garbo', {}]] },
    { id: 'e6q2', tipo: 'scelta', t: 'Cosa *ti fa muovere* di più?',
      opz: [['⏳', 'Una scadenza', {}], ['⚔️', 'Una sfida con qualcuno', {}], ['📈', 'Vedere i progressi', { invisibili: .5 }], ['🧊', 'La paura di restare fermo', {}]] },
    { id: 'e6q3', tipo: 'due', t: 'Nei messaggi, *come scrivi*?',
      opz: [['✂️', 'Due parole e via', {}], ['📜', 'Spiego tutto per bene', {}]] },
    { id: 'e6q4', tipo: 'cinque', t: 'Con gli amici, dici le cose *senza girarci intorno*?', o: {} },
    { id: 'e6q5', tipo: 'scelta', t: 'Quale frase *ti diresti* per ripartire?',
      opz: [['🏃', 'Muoviti', {}], ['🪜', 'Un passo alla volta', {}], ['🔁', 'L\'hai già fatto, rifallo', {}], ['👀', 'Pensa a chi ti guarda', {}]] },
    { id: 'e6q6', tipo: 'scelta', t: 'Fra un anno, *cosa vuoi che ti dica* il tuo Io Futuro?',
      opz: [['🎉', 'Ce l\'abbiamo fatta', {}], ['🙏', 'Grazie per non aver mollato', {}], ['✅', 'Avevi ragione a cominciare', {}], ['🌅', 'Ne è valsa la pena', {}]],
      mmm: ['Mmm… *il tuo messaggio è partito* verso il te di fra un anno. Lo leggerà lui, e ti risponderà.', 'Mmm… *il tuo messaggio è partito* verso il te di fra un anno. Lo leggerà lui, e ti risponderà.', 'Mmm… *il tuo messaggio è partito* verso il te di fra un anno. Lo leggerà lui, e ti risponderà.', 'Mmm… *il tuo messaggio è partito* verso il te di fra un anno. Lo leggerà lui, e ti risponderà.'] }
  ], chiusura: 'Il tuo messaggio è arrivato al te di fra un anno. *E lui ti ha risposto: ecco la sua lettera.*' },

  { n: 7, titolo: 'Il patto', tema: '', domande: [
    { id: 'e7q1', tipo: 'scelta', t: 'A cosa sei disposto a rinunciare, *per tre mesi*?',
      /* 0.9.210: la risposta di chi vede tutto in bianco e nero, e per il sogno lascia andare
         quello che serve. Sta in cima, larga: e' la piu' radicale delle cinque. */
      opz: [['🔥', 'A tutto quello che mi rallenta', { identita: -.3 }], ['📺', 'Alle serie la sera', {}], ['📱', 'Ai social la mattina', {}], ['🍻', 'A un\'uscita a settimana', {}], ['➕', 'A niente: voglio aggiungere, non togliere', { troppo: .5 }]],
      mmm: ['Mmm… *a tutto quello che ti rallenta.* Allora il patto lo scriviamo largo: ogni giorno lasci andare la cosa che ti frena quel giorno.', 'Mmm… *le serie la sera.* Sono due ore al giorno che tornano tue.', 'Mmm… *i social la mattina.* La prima ora della giornata torna a decidere tu.', 'Mmm… *un’uscita a settimana.* Quattro sere al mese per il tuo sogno.', 'Mmm… *aggiungere senza togliere.* Va bene: allora il tempo lo troviamo dentro alle giornate che hai già.'] },
    { id: 'e7q2', tipo: 'cinque', t: 'Se fra un anno sei *nello stesso punto*, ti va bene?', o: { identita: 1 },
      mmm: { si: 'Mmm… *ti andrebbe bene.* Allora mi hai appena detto la cosa più utile di tutte. Ci torniamo.', no: 'Mmm… *no.* Bene. Da quel no partono tutte le rotte che valgono.' } },
    { id: 'e7q3', tipo: 'scala', t: 'Quanto sei pronto a *cominciare domani*?', min: 1, max: 10, o: { partenza: -.25 } },
    { id: 'e7q4', tipo: 'scelta', t: 'Se salti un giorno, *cosa deve succedere*?',
      opz: [['🔄', 'Niente, riparto', {}], ['⏭️', 'Recupero il giorno dopo', {}], ['💸', 'Pago un pegno', {}], ['📣', 'Lo dico a qualcuno', { ambiente: -.5 }]] },
    { id: 'e7q5', tipo: 'cinque', t: 'Vuoi che qualcuno *veda il tuo punteggio*?', o: { ambiente: -.5 } },
    { id: 'e7q6', tipo: 'scelta', t: 'Finisci la frase: *fra un anno voglio poter dire che…*',
      opz: [['🏁', '…ce l\'ho fatta', {}], ['🧗', '…non ho mollato', {}], ['🔄', '…ho cambiato le mie giornate', {}], ['🌟', '…sono fiero di me', {}]],
      mmm: ['Mmm… *segnato.* Adesso guardiamo insieme dove porta.', 'Mmm… *segnato.* Adesso guardiamo insieme dove porta.', 'Mmm… *segnato.* Adesso guardiamo insieme dove porta.', 'Mmm… *segnato.* Adesso guardiamo insieme dove porta.'] }
  ], chiusura: 'La sfera è accesa. *Guardiamo insieme.*' }
];

/* ---------------------------------------------------------------------------------------
   LO STATO
   --------------------------------------------------------------------------------------- */
function dqStato(){
  let s = null; try{ s = JSON.parse(localStorage.getItem(DQ_KEY) || 'null'); }catch(_){ }
  if (!s) s = { risposte: {}, fatti: {}, pesi: {}, aperti: {} };
  s.risposte = s.risposte || {}; s.fatti = s.fatti || {}; s.pesi = s.pesi || {}; s.aperti = s.aperti || {};
  return s;
}
function dqSalva(s){ try{ localStorage.setItem(DQ_KEY, JSON.stringify(s)); }catch(_){ } }
function dqOggiK(){ const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function dqNeg(r){ return !!r && (r.v === 'No' || r.v === 'Probabilmente no'); }
function dqRisp(id){ return dqStato().risposte[id] || null; }
function dqVal(id){ const r = dqRisp(id); return r ? r.v : ''; }
/** L'episodio che tocca adesso: il primo non fatto. null se e' finita. */
function dqProssimo(){
  const s = dqStato();
  for (let i = 0; i < DQ_EPISODI.length; i++){
    const ep = DQ_EPISODI[i];
    if (s.fatti[ep.n]) continue;
    /* la stagione 2 comincia solo dopo il finale della prima */
    if (ep.stagione === 2 && !s.finale) return null;
    return ep;
  }
  return null;
}
/** Vero se oggi un episodio e' gia' stato chiuso: il prossimo aspetta domani. */
function dqFattoOggi(){
  const s = dqStato(), k = dqOggiK();
  return Object.keys(s.fatti).some(function(n){ return s.fatti[n] && s.fatti[n].giorno === k; });
}
function dqContaRisposte(){ return Object.keys(dqStato().risposte).filter(function(id){ return /^e[1-7]q/.test(id); }).length; }
/** Quanto il Genio ti conosce: il primo avvio vale 12, le 42 domande il resto. */
function dqConoscenza(){
  let base = 0; try{ base = (typeof gnDati === 'function' && gnDati().at) ? 12 : 0; }catch(_){ }
  /* 0.9.300: la serie del Genio chiede le domande dentro agli episodi: il conto si fa su quelle */
  try{
    if (typeof EPI !== 'undefined' && EPI.cfg){
      const ids = {}; ((EPI.cfg.stagioni || [])[0] || { episodi: [] }).episodi.forEach(function(e){ (e.passi || []).forEach(function(p){ if (typeof p.d === 'string') ids[p.d] = 1; }); });
      const tot = Object.keys(ids).length;
      if (tot){ const r = dqStato().risposte; const n = Object.keys(ids).filter(function(id){ return r[id] && r[id].v !== '' && r[id].v != null; }).length; return Math.min(100, Math.round(base + 88 * n / tot)); }
    }
  }catch(_){ }
  return Math.min(100, Math.round(base + 88 * dqContaRisposte() / 42));
}
function dqDomanda(ep, i){
  const q = ep.domande[i]; if (!q) return null;
  if (q.variante && q.variante.se){ try{ if (q.variante.se(dqStato().risposte)) return q.variante.q; }catch(_){ } }
  return q;
}
function dqPesa(o, m){
  if (!o || DQ.ripasso) return;
  const s = dqStato();
  Object.keys(o).forEach(function(k){ s.pesi[k] = (s.pesi[k] || 0) + o[k] * (m == null ? 1 : m); });
  dqSalva(s);
}
function dqOstacoli(){
  const p = dqStato().pesi;
  return DQ_OSTACOLI.map(function(x){ return Object.assign({ w: p[x.k] || 0 }, x); }).sort(function(a, b){ return b.w - a.w; });
}

/* ---------------------------------------------------------------------------------------
   LA SCENA: la stessa del primo avvio, con la barra in cima
   --------------------------------------------------------------------------------------- */
function dqApri(){
  const ep = dqProssimo();
  if (!ep){ dqFinaleApri(); return; }
  if (dqFattoOggi()){ toast('Il prossimo episodio è domani. Il Genio ha bisogno di una notte.'); return; }
  if (typeof GN === 'undefined') return;
  GN.on = true; GN.modo = 'dq'; DQ.ep = ep; DQ.i = 0; DQ.tass = false; DQ.cron = []; DQ.t0 = Date.now(); DQ.ripasso = false;
  GN.audio = true;
  goId('s-genio');
  dqBarra();
  gnVai('dq');
}
/* Rifare un episodio gia' fatto (0.9.202): le risposte si aggiornano, i pesi degli ostacoli no
   (si sommerebbero due volte), e la fine passa dalla mappa (sdRipetiFine). */
/* 0.9.322: un livello lasciato a meta' si riprende da dove eri: le risposte date sono gia' salve, manca solo il segno */
const DQ_RIP_K = 'fl_dq_ripresa';
function dqRipLeggi(n){ try{ const o = JSON.parse(localStorage.getItem(DQ_RIP_K) || 'null'); return (o && o.n === n && o.i > 0) ? o : null; }catch(_){ return null; } }
function dqRipSalva(){ try{ if (DQ.ep && !DQ.ripasso && !DQ.tass) localStorage.setItem(DQ_RIP_K, JSON.stringify({ n: DQ.ep.n, i: DQ.i, cron: DQ.cron || [], sec: DQ.t0 ? Math.round((Date.now() - DQ.t0) / 1000) : 0 })); }catch(_){ } }
function dqRipVia(){ try{ localStorage.removeItem(DQ_RIP_K); }catch(_){ } }
function dqApriEp(n, ripasso, scelta){
  const ep = DQ_EPISODI.filter(function(e){ return e.n === n; })[0]; if (!ep) return false;
  if (typeof GN === 'undefined') return false;
  const rip = ripasso ? null : dqRipLeggi(n);
  if (rip && !scelta && typeof inSheet === 'function'){
    inSheet('<div class="am-sheet center drs-ri"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><span class="drs-ri-ico" aria-hidden="true">🧭</span>'
      + '<b class="am-sh-title">Hai già iniziato questo livello</b><p class="am-sh-p">Vuoi riprendere da dove avevi lasciato o ricominciarlo da capo?</p>'
      + '<button type="button" class="nvs-cta" onclick="inSheetChiudi();dqApriEp(' + n + ',false,\'riprendi\')">Riprendi da dove avevi lasciato</button>'
      + '<button type="button" class="nvs-cta sec" onclick="inSheetChiudi();dqRipVia();dqApriEp(' + n + ',false,\'capo\')">Ricomincia da capo</button></div>');
    return true;
  }
  GN.on = true; GN.modo = 'dq'; DQ.ep = ep; DQ.i = 0; DQ.tass = false; DQ.cron = []; DQ.t0 = Date.now(); DQ.ripasso = !!ripasso;
  if (rip && scelta === 'riprendi'){ DQ.i = rip.i; DQ.cron = rip.cron || []; DQ.t0 = Date.now() - (rip.sec || 0) * 1000; }
  GN.audio = true;
  goId('s-genio');
  dqBarra();
  gnVai('dq');
  return true;
}
function dqChiudi(){
  dqRipSalva();
  try{ gnAu.musicaOff(); }catch(_){ }
  GN.on = false; GN.modo = ''; DQ.ripasso = false;
  const t = document.getElementById('gnTop'); if (t) t.hidden = true;
  goId('s-home');
  try{ if (typeof switchTab === 'function') switchTab('rotta'); }catch(_){ }
  try{ if (typeof snTick === 'function') snTick(); }catch(_){ }
  try{ if (typeof sdAggiorna === 'function') setTimeout(function(){ sdAggiorna(true); sdPaint(); }, 250); }catch(_){ }
  try{ if (typeof nvPaint === 'function') nvPaint(); }catch(_){ }
  try{ if (typeof scLifePaint === 'function') scLifePaint(); }catch(_){ }
}
function dqBarra(){
  const t = document.getElementById('gnTop'); if (!t) return;
  t.hidden = false;
  const bar = document.getElementById('gnProgBar'), txt = document.getElementById('gnProgTxt');
  const pct = dqConoscenza();
  const nq = DQ.ep ? DQ.ep.domande.length : 6;
  /* 0.9.214: la barra e' la strada fatta in QUESTO episodio, come su Duolingo (prima era quanto
     il Genio ti conosce in tutto: alla prima domanda sembrava gia' piena) */
  if (bar) bar.style.width = (DQ.ep ? (DQ.tass ? 100 : Math.round(Math.min(nq, DQ.i) / nq * 100)) : pct) + '%';
  if (txt) txt.textContent = DQ.ep ? ((DQ.ep.check ? '' : (DQ.ep.stagione === 2 ? 'Stagione 2 · Episodio ' : 'Episodio ') + DQ.ep.n + ' · ') + DQ.ep.titolo + (DQ.tass ? '' : ' · ' + Math.min(nq, DQ.i + 1) + '/' + nq)) : ('Il Genio ti conosce al ' + pct + '%');
}

/* il passo unico: ogni volta che entra, disegna la domanda corrente (o la chiusura) */
if (typeof GN_PASSI !== 'undefined'){
  GN_PASSI.dq = { entra: function(){ dqDisegna(); } };
  GN_PASSI.dqmmm = { entra: function(){
    gnPosa('pensa');
    /* 0.9.200: la freccia anche qui, perche' e' proprio dopo aver risposto che viene voglia di cambiare */
    const r0 = document.getElementById('gnRisp'); if (r0) r0.innerHTML = dqFrecciaHtml();
    gnScrivi('Mmm…', function(){ setTimeout(function(){ if (GN.step !== 'dqmmm') return; gnScrivi(GN.mmmFrase || '', function(){ const tap = document.getElementById('gnTap'); if (tap) tap.hidden = false; const r = document.getElementById('gnRisp'); if (r && !r.querySelector('.ak-indietro')) r.innerHTML = dqFrecciaHtml(); }); }, 420); });
  }, tocco: function(){ dqAvanti(); } };
  GN_PASSI.dqchiusura = { entra: function(){
    gnPosa('rivela');
    gnScrivi(DQ.ep.chiusura, function(){
      const r = document.getElementById('gnRisp');
      if (r) r.innerHTML = '<div class="dq-sfera" onclick="event.stopPropagation();dqTassello()"><div class="dq-sfera-ball"><span>?</span></div><small>Tocca la sfera</small></div>';
    });
  } };
}

function dqDisegna(){
  const ep = DQ.ep; if (!ep) return;
  if (DQ.i >= ep.domande.length){ dqChiudiEpisodio(); return; }
  const q = dqDomanda(ep, DQ.i); DQ.q = q;
  dqBarra();
  const sc = document.getElementById('gnScena');
  if (sc){ sc.classList.toggle('molte', q.tipo !== 'cinque'); sc.classList.toggle('carte', q.tipo === 'scelta' || q.tipo === 'due'); }
  let html = '';
  /* 0.9.300, Andrea: "Cosa l'ha fatta finire?" con quattro opzioni e niente "Lo scrivo io". Ogni domanda a opzioni
     ha anche la risposta scritta dall'utente, senza limiti di lunghezza (dqScrivoApri). */
  const ui = function(k, fb){ try{ return (typeof epiUi === 'function' && epiUi(k)) || fb; }catch(_){ return fb; } };
  if (q.tipo === 'cinque'){
    /* SEMPRE NEGLI STESSI POSTI, come nella lettura del Genio (oracle.js): in alto
       «Probabilmente sì» a sinistra e «Probabilmente no» a destra; sotto Sì, Non lo so, No */
    html = '<div class="or-grid">' + [1, 3, 0, 2, 4].map(function(i){
      return '<button type="button" class="or-a" onclick="event.stopPropagation();dqCinque(' + i + ')">' + DQ_CINQUE[i][0] + '</button>';
    }).join('') + '</div>'
      + '<button type="button" class="gn-link epi-scrivo-link" onclick="event.stopPropagation();dqScrivoApri()">' + gnEsc(ui('scrivo_t', 'Lo scrivo io')) + '</button>';
  } else if (q.tipo === 'scelta' || q.tipo === 'due'){
    html = '<div class="gn-carta"><div class="gn-cards' + ((q.opz.length + 1) % 2 ? ' dispari-s' : '') + '">' + q.opz.map(function(o, i){
      return '<button type="button" class="gn-card" onclick="event.stopPropagation();dqScelta(' + i + ')"><span>' + o[0] + '</span><b>' + gnEsc(o[1]) + '</b></button>';
    }).join('') + '<button type="button" class="gn-card tratt" onclick="event.stopPropagation();dqScrivoApri()"><span>✍️</span><b>' + gnEsc(ui('scrivo_t', 'Lo scrivo io')) + '</b><small>' + gnEsc(ui('scrivo_s', 'Con parole mie')) + '</small></button></div></div>';
  } else if (q.tipo === 'scala'){
    html = '<div class="gn-carta gn-slider"><b id="dqScalaVal">5</b><input type="range" id="dqScalaRange" min="' + q.min + '" max="' + q.max + '" step="1" value="5" oninput="flRangeFill(this);document.getElementById(\'dqScalaVal\').textContent=this.value" onclick="event.stopPropagation()">'
      + '<div class="gn-ends"><span>' + q.min + ' · per niente</span><span>' + q.max + ' · del tutto</span></div></div>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();dqScala()">Confermo</button></div>';
  } else if (q.tipo === 'parole'){
    html = '<textarea class="gn-area" id="dqParole" rows="' + (q.lungo ? 4 : (q.corto ? 1 : 2)) + '" placeholder="' + gnEsc(q.ph || '') + '" onclick="event.stopPropagation()"></textarea>'
      + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();dqParole()">Confermo</button></div>'
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();dqParole(true)">Preferisco non dirlo</button>';
  }
  /* 0.9.198: la freccia per tornare alla domanda prima, la stessa del gioco del Genio */
  html = dqFrecciaHtml() + html;
  gnDomanda('pensa', q.t, html, function(){
    if (q.tipo === 'scala') flRangeFill(document.getElementById('dqScalaRange'));
  });
  if (q.tipo === 'parole') setTimeout(function(){ try{ const a = document.getElementById('dqParole'); if (a) a.focus(); }catch(_){ } }, 1200);
}
function dqSegna(v, extra){
  const s = dqStato();
  /* per tornare indietro: com'erano i pesi e la risposta PRIMA di questa, cosi' cambiare idea
     non somma due volte gli ostacoli */
  DQ.cron = DQ.cron || [];
  DQ.cron.push({ i: DQ.i, id: DQ.q.id, pesi: JSON.parse(JSON.stringify(s.pesi || {})), prima: s.risposte[DQ.q.id] || null });
  s.risposte[DQ.q.id] = Object.assign({ v: v, at: Date.now(), ep: DQ.ep.n }, extra || {});
  dqSalva(s);
  try{ gnAu.scelta(DQ.i); gnVibra(18); }catch(_){ }
}
function dqCinque(i){
  const c = DQ_CINQUE[i]; const q = DQ.q;
  dqSegna(c[0]); dqPesa(q.o, c[1]);
  const m = q.mmm && (c[1] > 0 ? q.mmm.si : (c[1] < 0 ? q.mmm.no : null));
  dqDopo(m);
}
function dqScelta(i){
  const q = DQ.q, o = q.opz[i];
  dqSegna(o[1], { i: i }); dqPesa(o[2]);
  dqDopo(Array.isArray(q.mmm) ? q.mmm[i] : null);
}
function dqScala(){
  const el = document.querySelector('#gnRisp input[type=range]'); const v = el ? +el.value : 5;
  dqSegna(v); dqPesa(DQ.q.o, v - 5);
  dqDopo(v <= 3 ? 'Mmm… *' + v + ' su 10.* Onesto. Si parte anche da qui, e si parte meglio di chi dice dieci.' : null);
}
function dqParole(salta){
  const a = document.getElementById('dqParole'); const v = salta ? '' : String(a ? a.value : '').trim();
  dqSegna(v, { testo: true });
  dqDopo(v ? DQ.q.mmm : null);
}
function dqScrivoApri(){
  const r = document.getElementById('gnRisp'); if (!r) return;
  const ui = function(k, fb){ try{ return (typeof epiUi === 'function' && epiUi(k)) || fb; }catch(_){ return fb; } };
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.remove('carte');
  r.innerHTML = dqFrecciaHtml() + '<textarea class="gn-area" id="dqScrivoArea" rows="3" placeholder="' + gnEsc(ui('scrivo_ph', 'Scrivi qui la tua risposta')) + '" onclick="event.stopPropagation()"></textarea>'
    + '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();dqScrivoOk()">' + gnEsc(ui('scrivo_ok', 'Confermo')) + '</button></div>';
  try{ if (typeof micAvvolgi === 'function') micAvvolgi(r); }catch(_){ }
  setTimeout(function(){ try{ const a = document.getElementById('dqScrivoArea'); if (a) a.focus(); }catch(_){ } }, 200);
}
function dqScrivoOk(){
  const a = document.getElementById('dqScrivoArea'); const v = String(a ? a.value : '').trim();
  if (!v){ try{ if (a) a.focus(); }catch(_){ } return; }
  dqSegna(v, { testo: true });
  let m = ''; try{ m = (typeof epiUi === 'function') ? epiUi('scrivo_mmm') : ''; }catch(_){ }
  dqDopo(m || null);
}
function dqDopo(mmm){
  if (mmm){ GN.mmmFrase = mmm; gnVai('dqmmm'); return; }
  dqAvanti();
}
function dqAvanti(){ DQ.i++; dqRipSalva(); gnVai('dq'); }
function dqFrecciaHtml(){
  if (!DQ.cron || !DQ.cron.length) return '';
  return '<button type="button" class="ak-indietro" onclick="event.stopPropagation();dqIndietro()" aria-label="Torna alla domanda prima">'
    + '<svg viewBox="0 0 17 14" width="17" height="14" aria-hidden="true"><path d="M17 7H2M8 1L2 7l6 6" stroke="currentColor" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
}
function dqIndietro(){
  if (!DQ.cron || !DQ.cron.length) return false;
  const c = DQ.cron.pop();
  const s = dqStato();
  s.pesi = c.pesi;
  if (c.prima) s.risposte[c.id] = c.prima; else delete s.risposte[c.id];
  dqSalva(s);
  DQ.i = c.i;
  try{ gnAu.scelta(0); }catch(_){ }
  gnVai('dq');
  return true;
}
function dqChiudiEpisodio(){
  if (DQ.ripasso){
    const sec = DQ.t0 ? Math.round((Date.now() - DQ.t0) / 1000) : 0;
    const id = 'ep:' + DQ.ep.n;
    dqChiudi();
    try{ if (typeof sdRipetiFine === 'function' && sdRipetiFine(id, { sec: sec })) return; }catch(_){ }
    return;
  }
  dqRipVia(); DQ.tass = true;
  const s = dqStato();
  if (!s.fatti[DQ.ep.n]) s.fatti[DQ.ep.n] = { at: Date.now(), giorno: dqOggiK(), sec: DQ.t0 ? Math.round((Date.now() - DQ.t0) / 1000) : 0 };
  dqSalva(s);
  DQ.tass = true; dqBarra();
  const sc = document.getElementById('gnScena'); if (sc){ sc.classList.remove('molte'); sc.classList.remove('carte'); }
  /* 0.9.201: l'episodio finisce qui. La sfera con il tassello arriva DOPO la schermata
     dell'XP e della serie (sdSerieAvanti → dqSferaApri), come il premio su Duolingo.
     Il check della settimana tiene la sua chiusura subito. */
  if (typeof DQ.ep.n === 'number' && DQ.ep.n < 8){ dqChiudi(); return; }
  /* 0.9.300: gli episodi della stagione 2 non sono piu' tappe della Mappa: la chiusura con la sfera arriva subito */
  gnVai('dqchiusura');
}
/* La sfera dell'episodio n, una volta sola: true se si e' aperta. */
function dqSferaApri(n){
  const ep = DQ_EPISODI.filter(function(e){ return e.n === n; })[0]; if (!ep) return false;
  const f = dqStato().fatti[n]; if (!f || f.tass) return false;
  if (typeof GN === 'undefined') return false;
  GN.on = true; GN.modo = 'dq'; DQ.ep = ep; DQ.i = ep.domande.length; DQ.tass = true; DQ.cron = [];
  GN.audio = true;
  goId('s-genio');
  dqBarra();
  const sc = document.getElementById('gnScena'); if (sc){ sc.classList.remove('molte'); sc.classList.remove('carte'); }
  gnVai('dqchiusura');
  return true;
}

/* ---------------------------------------------------------------------------------------
   IL TASSELLO DEL GIORNO — dentro alla sfera, mai lo stesso genere di cosa
   --------------------------------------------------------------------------------------- */
function dqTassello(){
  const n = DQ.ep.n;
  const r = document.getElementById('gnRisp'); if (!r) return;
  /* 0.9.207: gli XP doppi non escono piu' da ogni sfera: sono un premio raro della mystery box */
  try{ const s = dqStato(); if (s.fatti[n] && !s.fatti[n].tass){ s.fatti[n].tass = Date.now(); dqSalva(s); } }catch(_){ }
  try{ gnAu.punto(); gnVibra([20, 30, 40]); }catch(_){ }
  const b = r.querySelector('.dq-sfera-ball'); if (b) b.classList.add('apre');
  setTimeout(function(){
    if (n === 7){ dqFinaleApri(); return; }
    /* stagione 2 e check (sentiero.js): la mappa degli ostacoli, aggiornata */
    if ((typeof n === 'string' || n >= 8) && typeof snTasselloHtml === 'function'){
      r.innerHTML = snTasselloHtml(n);
      const sc2 = document.getElementById('gnScena'); if (sc2) sc2.classList.add('molte');
      gnPosa('rivela');
      const ep2 = (typeof n === 'number') ? DQ_EPISODI.filter(function(e){ return e.n === n + 1; })[0] : null;
      gnScrivi(ep2 ? 'Domani ti chiedo *' + ep2.tema + '*.' : 'Ci risentiamo *fra una settimana*, per il check.', null);
      return;
    }
    r.innerHTML = dqTasselloHtml(n);
    const sc = document.getElementById('gnScena'); if (sc) sc.classList.add('molte');
    gnPosa('rivela');
    const prox = DQ_EPISODI[n] ? DQ_EPISODI[n].tema : '';
    gnScrivi(prox ? 'Domani ti chiedo *' + prox + '*. Il resto lo scopri lì.' : 'Domani chiudiamo il cerchio.', null);
  }, 900);
}
function dqProfilo(){
  try{ const L = gnLettura(); if (L && L.prof) return L.prof; }catch(_){ }
  try{ const o = orLast(); if (o && typeof orProfile === 'function') return orProfile(o.profile); }catch(_){ }
  return { ico: '🔮', name: 'L\'Equilibrista', desc: 'Ci prova davvero. Oscilla: settimane buone e settimane no. Non cade mai, ma non sale.' };
}
const DQ_ANTIDOTI = {
  proc: 'La cosa che lo cambia è una: cominciare prima di sentirsi pronto. Dieci minuti, oggi, contano più di un piano perfetto per domani.',
  inc: 'La cosa che lo cambia è finire una cosa piccola alla volta. Non un progetto: una riga spuntata al giorno, per venti giorni.',
  sogn: 'La cosa che lo cambia è sapere cosa fare domani alle sette. Il sogno resta grande; il passo diventa piccolo.',
  reat: 'La cosa che lo cambia è un\'ora al giorno che decidi tu, con il telefono da un\'altra parte. Una sola. Poi si allarga.',
  nott: 'La cosa che lo cambia comincia la sera prima: schermo spento un\'ora prima di dormire. Il giorno dopo si sistema da solo.',
  equi: 'La cosa che lo cambia è il giorno storto: chi tiene la regola anche lì, sale. Tutto il resto lo fai già.',
  disc: 'La cosa che lo cambia è quasi niente: la costanza nei giorni in cui non hai voglia. È lì che si stacca il gruppo.'
};
function dqTasselloHtml(n){
  const nome = (typeof gnNome === 'function') ? gnNome() : '';
  /* il premio della sfera (0.9.202): XP doppi per un quarto d'ora, e il pulsante porta alla
     tappa dopo, da fare ADESSO */
  const boost = (typeof sdBoostResta === 'function' && sdBoostResta())
    ? '<div class="dq-boost"><span>⚡</span><div><b>XP doppi per 15 minuti</b><small>Ogni tappa che fai adesso vale il doppio.</small></div></div>' : '';
  const card = function(kicker, inner, btn){
    return boost + '<div class="dq-tass"><small>Giorno ' + n + ' · ' + kicker + '</small>' + inner + (btn || '') + '</div>'
      + (boost ? '<button type="button" class="or-a dq-prossima" onclick="event.stopPropagation();dqChiudi();setTimeout(function(){ try{ switchTab(\'mappa\'); const nd = sdProssimaOggi(); if (nd) sdTapVia(nd.id); }catch(_){ } }, 350)">Fai la prossima tappa ×2</button>' : '')
      + '<button type="button" class="gn-link" onclick="event.stopPropagation();dqChiudi()">Torna alla pagina</button>';
  };
  if (n === 1){
    const p = dqProfilo();
    return card('Rivelazione', '<div class="dq-ico">' + p.ico + '</div><b class="dq-t">Se continui così, rischi di diventare</b><div class="dq-big">' + gnEsc(p.name) + '</div><p class="dq-p">' + gnEsc(p.desc) + '</p><p class="dq-p dq-anti" id="dqAnti" hidden>' + gnEsc(DQ_ANTIDOTI[p.id] || DQ_ANTIDOTI.equi) + '</p>',
      '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();const a=document.getElementById(\'dqAnti\');a.hidden=false;this.parentElement.remove()">Scopri cosa lo cambia</button></div>');
  }
  if (n === 2){
    const h = dqOraFragile();
    const hh = String(h).padStart(2, '0') + ':00';
    return card('Scoperta dai dati', '<div class="dq-ico">🕰️</div><b class="dq-t">La tua ora fragile</b><div class="dq-big">' + hh + '</div><p class="dq-p">È l\'ora in cui prendi in mano il telefono più spesso. Una fascia protetta lì cambia la sera, e la sera cambia il giorno dopo.</p>',
      '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();dqProteggi(' + h + ')">Proteggi quest\'ora</button></div>');
  }
  if (n === 3){
    const sop = dqVal('e3q6') || 'Il vecchio ' + (nome || 'te');
    const mosse = [dqVal('e3q1'), dqVal('e3q3'), dqVal('e3q5')].filter(Boolean);
    return card('Il tuo avversario', '<div class="dq-ico">😈</div><b class="dq-t">Si chiama</b><div class="dq-big">' + gnEsc(sop) + '</div><p class="dq-p">Le sue tre mosse preferite:</p><ul class="dq-mosse">' + mosse.map(function(m){ return '<li>' + gnEsc(m) + '</li>'; }).join('') + '</ul><p class="dq-p">Adesso che le conosci, scegli con quali regole giocare contro di lui.</p>',
      '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();dqChiudi();setTimeout(function(){ if(typeof mdApri===\'function\') mdApri(); },300)">Scegli come giocare</button></div>');
  }
  if (n === 4){
    try{ if (typeof lvGrantExtra === 'function') lvGrantExtra('sound:fire'); }catch(_){ }
    return card('Uno strumento', '<div class="dq-ico">🔥</div><b class="dq-t">Un suono nuovo per il Full Focus</b><div class="dq-big">Camino</div><p class="dq-p">È tuo da adesso. E una sfida lampo: dieci minuti di Full Focus entro stasera, con il camino acceso.</p>',
      '<div class="or-grid one"><button type="button" class="or-a" onclick="event.stopPropagation();dqSfidaLampo()">Provalo adesso</button></div>');
  }
  if (n === 5){
    /* 0.9.200, su richiesta di Andrea: prima SOLO la probabilita' di oggi, poi quella nuova,
       poi da cosa dipende. Tutto insieme («46% → 84%» con una frase per due numeri) non si
       capiva quale fosse quale. */
    let pct = 40, rotta = 78, sogno = ''; try{ const L = gnLettura(); pct = L.pct; rotta = L.pctRotta; sogno = L.sogno; }catch(_){ }
    DQ.p5 = { passo: 1, pct: pct, rotta: rotta, sogno: (sogno && sogno !== 'quel sogno') ? sogno : 'il tuo sogno', top: dqOstacoli().slice(0, 2) };
    return card('Rivelazione', '<div id="dq5">' + dq5Html() + '</div>',
      '<div class="or-grid one" id="dq5Btn"><button type="button" class="or-a" onclick="event.stopPropagation();dq5Avanti()">Scopri come alzarla</button></div>');
  }
  if (n === 6){
    return card('Un incontro', '<div class="dq-ico">✉️</div><b class="dq-t">Una lettera dal futuro</b><div class="dq-lettera">' + dqLettera().replace(/\n/g, '<br>') + '</div>', '');
  }
  return card('Il finale', '', '');
}
/* «al 75%» ma «all'84%», «all'8%», «all'11%», «all'1%»: si legge il numero, non la cifra */
function dqAlPerc(n){ n = Math.round(+n || 0); const t = String(n); return (t.charAt(0) === '8' || n === 11 || n === 1) ? 'all\'' + n : 'al ' + n; }
function dq5Html(){
  const p = DQ.p5; if (!p) return '';
  if (p.passo === 1) return '<div class="dq-ico">🎯</div><b class="dq-t">La tua probabilità di farcela, oggi</b>'
    + '<div class="dq-big"><span class="rosso">' + p.pct + '%</span></div>'
    + '<p class="dq-p">È la probabilità di realizzare ' + gnEsc(p.sogno) + ' se le tue giornate restano come sono adesso.</p>';
  if (p.passo === 2) return '<div class="dq-ico">📈</div><b class="dq-t">Se le ore che oggi finiscono sul telefono tornano a te</b>'
    + '<div class="dq-big"><span class="verde" id="dq5Num">' + p.pct + '%</span></div>'
    + '<p class="dq-p">La tua probabilità sale ' + dqAlPerc(p.rotta) + '%. Questo numero si aggiorna ogni giorno con quello che fai.</p>';
  return '<div class="dq-ico">🧭</div><b class="dq-t">Da cosa dipende, nel tuo caso</b>'
    + p.top.map(function(o){ return '<p class="dq-p dq-anti">' + gnEsc(o.t) + '. ' + gnEsc(o.f) + '</p>'; }).join('');
}
function dq5Avanti(){
  const p = DQ.p5; if (!p) return;
  p.passo++;
  const el = document.getElementById('dq5'); if (el) el.innerHTML = dq5Html();
  try{ gnAu.scelta(p.passo); }catch(_){ }
  const b = document.getElementById('dq5Btn');
  if (p.passo === 2){
    /* il numero sale davanti ai suoi occhi: da quello di oggi a quello possibile */
    const num = document.getElementById('dq5Num'), t0 = Date.now(), dur = 1100;
    const giro = setInterval(function(){
      const k = Math.min(1, (Date.now() - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      if (num) num.textContent = Math.round(p.pct + (p.rotta - p.pct) * e) + '%';
      if (k >= 1) clearInterval(giro);
    }, 30);
    if (b) b.innerHTML = '<button type="button" class="or-a" onclick="event.stopPropagation();dq5Avanti()">Scopri da cosa dipende</button>';
  } else if (b) b.remove();
}
function dqOraFragile(){
  try{
    /* la lettura di ieri e' completa; quella di oggi no */
    if (typeof TL_RIASSUNTO_CACHE !== 'undefined'){ /* nessuna cache: si usa il valore salvato */ }
    const v = +localStorage.getItem('fl_dq_ora') || -1;
    if (v >= 0) return v;
  }catch(_){ }
  return 22;
}
/* l'ora fragile si calcola con calma quando si apre la scheda, cosi' il tassello la trova pronta */
async function dqOraFragileCalcola(){
  try{
    if (typeof tlRiassuntoDi !== 'function') return;
    const t = await tlRiassuntoDi(1);
    if (t && t.oraRotta >= 0) localStorage.setItem('fl_dq_ora', String(t.oraRotta));
  }catch(_){ }
}
function dqProteggi(h){
  dqChiudi();
  setTimeout(function(){ try{ if (typeof wkProgramma === 'function') wkProgramma(h); else toast('Apri la pagina Blocco per creare il programma'); }catch(_){ } }, 400);
}
function dqSfidaLampo(){
  try{ const p = ffPref(); p.minutes = 10; p.sound = 'fire'; ffSavePref(); }catch(_){ }
  dqChiudi();
  setTimeout(function(){ try{ ffOpen(); }catch(_){ } }, 300);
}
/* LA LETTERA. Scritta con le risposte dell'utente: cosa vuole sentirsi dire fra un anno (e6q6), il
   suo perche' (e1q6), il suo sogno. Lo stile lo decide lui: «due parole e via» o «spiego tutto». */
function dqLettera(){
  const nome = (typeof gnNome === 'function') ? gnNome() : '';
  const asciutto = dqVal('e6q3') === 'Due parole e via';
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  const perche = dqVal('e1q6'), msg = dqVal('e6q6'), manca = dqVal('e5q6');
  const anno = new Date().getFullYear() + 1;
  const firma = (nome || 'Tu') + ', ' + anno;
  if (asciutto){
    return 'Ehi' + (nome ? ' ' + nome : '') + '.\n' + (msg ? msg + '.\n' : '') + (sogno ? sogno + ': fatto.\n' : 'Ci sono arrivato.\n')
      + (manca ? 'Quello che ti manca adesso, ' + manca.toLowerCase() + ', l\'ho trovato per strada. Non prima.\n' : '') + 'Una cosa sola: comincia. Il resto viene.\n' + firma;
  }
  /* 0.9.206: il sogno e il perche' entrano nella lettera solo se sono CORTI. Un testo lungo scritto
     nell'onboarding (e magari troncato dal limite) incollato in mezzo a una frase non suona come
     una lettera: suona come un modulo. Allora si parla del sogno senza citarlo. */
  const sognoCorto = sogno && sogno.length <= 36 && !/[.!?]\s/.test(sogno) ? sogno.replace(/[.…]+$/, '') : '';
  const pCorto = perche ? perche.replace(/^lo voglio perché\s*/i, '').replace(/[.…]+$/, '').trim() : '';
  const percheCorto = pCorto && pCorto.length <= 70 && !/[.!?]\s/.test(pCorto) ? pCorto.replace(/^./, function(c){ return c.toLowerCase(); }) : '';
  return 'Ehi' + (nome ? ' ' + nome : '') + ', sono io. Da qui, un anno dopo.\n'
    + (msg ? msg + '. Te lo dovevo.\n' : '')
    + (sognoCorto ? 'Ti scrivo dal giorno in cui ' + sognoCorto.charAt(0).toLowerCase() + sognoCorto.slice(1) + ' è diventato vero. Sì, ci siamo arrivati. ' : 'Ti scrivo dal giorno in cui il sogno che hai raccontato al Genio è diventato vero. Sì, ci siamo arrivati. ')
    + (percheCorto ? 'Il motivo era quello che hai scelto tu: ' + percheCorto + '. Non è cambiato.\n' : 'Il motivo lo sai: te lo sei scritto il primo giorno, e non è cambiato.\n')
    + (manca ? 'Quello che ti mancava, ' + manca.toLowerCase() + ', è arrivato per strada, non prima di partire. Come sempre.\n' : '')
    + 'Non ti dico che è stato facile. Ti dico che è stato più semplice di come lo pensavi la sera, col telefono in mano.\n' + firma;
}

/* ---------------------------------------------------------------------------------------
   IL FINALE — la traiettoria, la data, l'ostacolo, la pagina bianca
   --------------------------------------------------------------------------------------- */
function dqFinaleApri(){
  if (typeof GN === 'undefined') return;
  GN.on = true; GN.modo = 'dq'; DQ.ep = null; DQ.tass = true;
  goId('s-genio');
  const t = document.getElementById('gnTop'); if (t){ t.hidden = false; const txt = document.getElementById('gnProgTxt'); if (txt) txt.textContent = 'Il finale'; const bar = document.getElementById('gnProgBar'); if (bar) bar.style.width = '100%'; }
  const sc = document.getElementById('gnScena'); if (sc){ sc.classList.remove('molte'); sc.classList.remove('carte'); }
  let sogno = ''; try{ sogno = (typeof nvSogno === 'function') ? nvSogno() : ''; }catch(_){ }
  gnTraiettoria(['Le tue 42 risposte', 'I tuoi sette giorni al telefono', 'Le sere e le mattine', 'La strada fino a ' + (sogno || 'quel sogno').toLowerCase()], function(){ dqFinaleMostra(); });
}
function dqFinaleMostra(){
  const r = document.getElementById('gnRisp'); if (!r) return;
  const sc = document.getElementById('gnScena'); if (sc) sc.classList.add('molte');
  let data = '', pct = 0, rotta = 0;
  try{ const a = etaArrivo(); if (a && isFinite(a.at)){ const d = new Date(a.at); data = d.getDate() + ' ' + NV_MESI[d.getMonth()] + ' ' + d.getFullYear(); } }catch(_){ }
  try{ const L = gnLettura(); pct = L.pct; rotta = L.pctRotta; if (!data) data = L.arrivo; }catch(_){ }
  const o = dqOstacoli()[0];
  gnPosa('rivela');
  gnScrivi('Ecco cosa vedo, *adesso che ti conosco*.', function(){
    r.innerHTML = '<div class="dq-tass dq-fin">'
      + '<small>Arrivo previsto</small><div class="dq-big">' + gnEsc(data || '—') + '</div>'
      + '<p class="dq-p">Probabilità di arrivarci: <b class="rosso">' + pct + '%</b> così, <b class="verde">' + rotta + '%</b> se quelle ore tornano tue.</p>'
      + '<b class="dq-t">Il tuo ostacolo è uno</b><div class="dq-ost">' + gnEsc(o.t) + '</div><p class="dq-p">' + gnEsc(o.f) + '</p>'
      + '</div>'
      + '<div class="or-grid one"><button type="button" class="or-a main" onclick="event.stopPropagation();dqPaginaBianca()">Ho capito</button></div>';
  });
}
function dqPaginaBianca(){
  const r = document.getElementById('gnRisp'); if (!r) return;
  gnPosa('pensa');
  gnScrivi('Una domanda sola. *Qual è il passo di domani?*', function(){
    r.innerHTML = '<textarea class="gn-area" id="dqPasso" rows="2" placeholder="Domani…" onclick="event.stopPropagation()"></textarea>'
      + '<div class="dq-due"><button type="button" class="or-a" onclick="event.stopPropagation();dqScrivoIo()">Lo scrivo io</button>'
      + '<button type="button" class="or-a" onclick="event.stopPropagation();dqChiedoIo()">Lo chiedo al mio Io futuro</button></div>';
  });
}
function dqScrivoIo(){
  const a = document.getElementById('dqPasso'); const v = String(a ? a.value : '').trim();
  try{
    if (v && typeof stNotesSave === 'function'){
      const cur = (typeof stNotes === 'function') ? (stNotes('tomorrow') || '') : '';
      stNotesSave((cur ? cur + '\n' : '') + '☐ ' + v, 'tomorrow');
    }
  }catch(_){ }
  const s = dqStato(); s.finale = Date.now(); dqSalva(s);
  dqChiudi();
  setTimeout(function(){ try{ switchTab('sveglia'); if (typeof stTabSet === 'function') stTabSet('domani'); }catch(_){ } }, 300);
}
function dqChiedoIo(){
  const a = document.getElementById('dqPasso'); const v = String(a ? a.value : '').trim();
  const s = dqStato(); s.finale = Date.now(); dqSalva(s);
  dqChiudi();
  setTimeout(function(){
    try{ if (typeof agApri === 'function') agApri(); }catch(_){ }
    setTimeout(function(){ const t = document.getElementById('agTesto'); if (t){ t.value = 'Qual è il passo di domani?' + (v ? ' Pensavo: ' + v : ''); t.focus(); } }, 500);
  }, 300);
}

/* ---------------------------------------------------------------------------------------
   LA CARD NELLA ROTTA: la sfera, quanto ti conosce, l'episodio di oggi
   --------------------------------------------------------------------------------------- */
function dqCardHtml(){
  const pct = dqConoscenza();
  const ep = dqProssimo();
  const oggi = dqFattoOggi();
  let riga, btn;
  if (!ep){
    riga = 'La lettura è completa. La previsione è tua.';
    btn = '<button type="button" class="am-cta" onclick="dqFinaleApri()">Rileggi la previsione</button>';
  } else if (oggi){
    riga = 'Torna domani: <b>Episodio ' + ep.n + ' · ' + gnEsc(ep.titolo) + '</b>.';
    btn = '<button type="button" class="am-cta dq-off" disabled>Domani</button>';
  } else {
    riga = '<b>Episodio ' + ep.n + ' · ' + gnEsc(ep.titolo) + '</b> · sei domande, due minuti.';
    btn = '<button type="button" class="am-cta" onclick="dqApri()">' + (ep.n === 1 ? 'Comincia a leggermi' : 'Rispondi alle domande di oggi') + '</button>';
  }
  return '<div class="dq-card"><div class="dq-card-top"><span class="dq-card-ball' + (ep ? '' : ' on') + '">🔮</span><div><small>La lettura del Genio</small><b>Il Genio ti conosce al ' + pct + '%</b></div></div>'
    + '<div class="dq-bar"><i style="width:' + pct + '%"></i></div>'
    + '<p>' + riga + '</p>' + btn + '</div>';
}
setTimeout(dqOraFragileCalcola, 6000);

(function(){
  const css = [
    '.dq-card-ball.rientro{background:radial-gradient(circle at 32% 28%,#FFB3B9,#E63946 60%,#8E1520) !important}.dq-rientro{border-color:rgba(230,57,70,.55) !important}.dq-nonora{display:block;margin:8px auto 0}',
    '.gn-top{position:absolute;left:0;right:0;top:0;z-index:6;display:flex;align-items:center;gap:10px;padding:calc(10px + env(safe-area-inset-top,0px)) 14px 8px}',
    '.gn-top[hidden]{display:none}',
    '.gn-x{width:34px;height:34px;flex:none;border-radius:50%;border:0;background:rgba(255,255,255,.16);color:#fff;font:700 15px var(--font-body);cursor:pointer}',
    '.gn-prog{flex:1;min-width:0}.gn-prog > div{height:14px;border-radius:99px;background:rgba(255,255,255,.18);overflow:hidden}.gn-prog i{display:block;height:100%;border-radius:3px;background:linear-gradient(90deg,#3F9FF4,#8CC6FF);transition:width .6s}',
    '.gn-prog small{display:block;margin-top:5px;font:700 10.5px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#BFE0FF;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.gn.con-top .gn-sopra{padding-top:52px}',
    '.dq-sfera{display:flex;flex-direction:column;align-items:center;gap:10px;padding:10px 0;cursor:pointer}',
    '.dq-sfera-ball{position:relative;width:150px;height:150px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at 32% 26%,rgba(255,255,255,.55),rgba(140,198,255,.35) 30%,rgba(0,117,227,.35) 60%,rgba(0,30,68,.7));box-shadow:0 0 40px rgba(63,159,244,.55),inset 0 -20px 40px rgba(0,60,140,.4);animation:dqPulse 2s ease-in-out infinite}',
    '.dq-sfera-ball span{font:900 64px var(--font-display);color:#fff;text-shadow:0 4px 18px rgba(0,0,0,.4)}',
    '.dq-sfera-ball.apre{animation:dqApre .9s ease-in forwards}',
    '@keyframes dqPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.05)}}',
    '@keyframes dqApre{0%{transform:scale(1)}60%{transform:scale(1.25);box-shadow:0 0 90px rgba(140,198,255,1)}100%{transform:scale(0);opacity:0}}',
    '.dq-sfera small{font:700 11px var(--font-body);letter-spacing:.2em;text-transform:uppercase;color:#BFE0FF}',
    '#gnRisp > .ak-indietro + .gn-carta,#gnRisp > .ak-indietro + .gn-area{margin-top:12px}',
    '.dq-boost{display:flex;align-items:center;gap:12px;margin:0 0 12px;padding:12px 14px;border-radius:16px;background:#E6F2FF;color:#001E44;text-align:left;animation:gnIn .4s ease-out both}.dq-boost span{font-size:26px}.dq-boost b{display:block;font:900 15px var(--font-body)}.dq-boost small{display:block;font:600 12.5px var(--font-body);margin-top:2px}',
    '.dq-prossima{display:block;width:100%;margin-top:12px;background:#E63946 !important;color:#fff !important}.dq-tass .or-a{background:#0075E3 !important;color:#fff !important;border-color:#0075E3 !important}',
    '.dq-tass{background:#fff;border:2px solid #0E2350;border-radius:22px;padding:22px 18px;text-align:center;color:#0E2350;animation:gnIn .4s ease-out both}',
    'body.dark .dq-tass{background:#141C2C;border-color:#4FA8FF;color:#EEF4FF}',
    '.dq-tass > small{display:block;font:700 10.5px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#0075E3}',
    '.dq-ico{font-size:44px;line-height:1;margin:12px 0 6px}',
    '.dq-t{display:block;font:600 14px var(--font-body);color:#6A7B99}',
    '.dq-big{font:900 30px/1.15 var(--font-display);margin:6px 0 8px}.dq-big i{font-style:normal;color:#8B99AC;margin:0 6px}.dq-big .rosso{color:#E5515F}.dq-big .verde{color:#1B9E6A}',
    '.dq-p{margin:8px 0 0;font:500 14px/1.55 var(--font-body)}.dq-p b.rosso{color:#E5515F}.dq-p b.verde{color:#1B9E6A}',
    '.dq-anti{margin-top:12px;padding:12px;border-radius:14px;background:#E3F1FF;color:#0E2350;text-align:left}body.dark .dq-anti{background:rgba(63,159,244,.15);color:#EEF4FF}',
    '.dq-mosse{list-style:none;margin:8px 0 0;padding:0}.dq-mosse li{padding:9px 12px;margin-top:6px;border-radius:12px;background:#F4F8FF;font:600 13.5px var(--font-body);text-align:left}body.dark .dq-mosse li{background:rgba(255,255,255,.06)}',
    '.dq-lettera{margin-top:12px;padding:16px;border-radius:14px;background:#FFF8E6;color:#2A1E00;font:500 14.5px/1.6 "Caveat",var(--font-body);font-size:18px;text-align:left}',
    '.dq-ost{display:inline-block;margin:6px 0;padding:8px 16px;border-radius:99px;background:#0E2350;color:#fff;font:800 15px var(--font-display)}',
    '.dq-tass .or-grid{margin-top:14px}',
    '.dq-due{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}.dq-due .or-a{padding:15px 8px;font-size:13.5px}',
    /* la card nella Rotta */
    '.dq-card{background:var(--card,#fff);border:1px solid var(--line);border-radius:24px;padding:18px 20px 20px;display:flex;flex-direction:column;gap:10px}body.dark .dq-card{background:#12203A;border-color:#22345A}',
    '.dq-card-top{display:flex;align-items:center;gap:12px}',
    '.dq-card-ball{width:46px;height:46px;flex:none;border-radius:23px;display:flex;align-items:center;justify-content:center;font-size:24px;background:radial-gradient(circle at 35% 30%,#E3F1FF,#8CC6FF 60%,#3F9FF4);box-shadow:0 0 18px rgba(63,159,244,.5)}',
    '.dq-card-top small{display:block;font:600 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.dq-card-top b{display:block;font:800 16px var(--font-display);color:var(--navy)}body.dark .dq-card-top b{color:#fff}',
    '.dq-bar{height:8px;border-radius:4px;background:var(--blue-soft,#E3F1FF);overflow:hidden}.dq-bar i{display:block;height:100%;border-radius:4px;background:linear-gradient(90deg,#3F9FF4,#0075E3);transition:width .6s}body.dark .dq-bar{background:rgba(255,255,255,.1)}',
    '.dq-card p{margin:0;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}.dq-card p b{color:var(--navy)}body.dark .dq-card p b{color:#fff}',
    /* su una riga sola (0.9.216): «Rispondi alle domande di oggi» andava a capo */
    '.dq-card .am-cta{margin-top:4px;white-space:nowrap;padding-left:10px;padding-right:10px;font-size:clamp(13.5px,4vw,16px)}.dq-off{opacity:.45}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
