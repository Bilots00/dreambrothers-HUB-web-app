/* ===========================================================================================
   IL CARBURANTE VERO E LA COMBO (0.9.214)

   IL CARBURANTE. Il foglio «Quanto ci vuole?» promette «+5 / +15 / +30 carburante», ma dava XP:
   il carburante dell'intestazione (la riserva di dopamina) non si muoveva. Adesso la promessa e'
   mantenuta: una task chiusa entro il tempo scelto, dal foglio o dentro al Full Focus, aggiunge
   alla riserva il carburante che il foglio diceva. Lo calcola il motore della dopamina (un
   check-in «tempo»), e l'intestazione si ridisegna subito.

   LA COMBO, come su Duolingo («La tua combo continua · 37 risposte esatte di fila»). Ogni livello
   della Roadmap e ogni sessione di Full Focus portata a termine, uno dopo l'altro, la fanno
   salire; una sessione mollata o un livello lasciato a meta' la azzerano, e a mezzanotte riparte.
   Dalla seconda in fila, alla fine compare la frase che mette benzina sul fuoco, e la combo
   stessa vale carburante in piu'.
   =========================================================================================== */
const FC_COMBO_KEY = 'fl_combo';
function fcGiorno(){ const d = new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); }
/** Il carburante promesso per una task di N minuti: lo stesso numero del foglio del tempo. */
/* IL CARBURANTE E' PROPORZIONALE AL TEMPO (0.9.216): mezzo punto a minuto. Due minuti valgono 1,
   dieci ne valgono 5, un'ora 30, l'ora e mezza (il massimo che si puo' scegliere) 45. Prima erano
   tre gradini fissi: cinque minuti valevano 5 come dieci, e un'ora valeva quanto mezz'ora. */
const FC_MAX_MIN = 90;
function fcPremio(min){ min = Math.max(1, Math.min(FC_MAX_MIN, +min || 25)); return Math.max(1, Math.round(min / 2)); }
/** Aggiunge carburante alla riserva (un check-in del motore della dopamina) e ridisegna. */
function fcAggiungi(delta, l, nota){
  delta = Math.max(0, Math.min(45, Math.round(+delta || 0))); if (!delta) return 0;
  if (!/^Combo/.test(l || '')){ FC_ULTIMA.premio = delta; FC_ULTIMA.premioAt = Date.now(); }
  try{
    const l0 = JSON.parse(localStorage.getItem('fl_dopa_checkin') || '[]') || [];
    const ck = { t: Date.now(), tipo: 'tempo', delta: delta, l: l || 'Task chiusa nel tempo', nota: nota || '' };
    /* 0.9.306: sul computer il check-in porta il segno del dispositivo, viaggia verso il telefono con i granelli del
       computer (dpPubblicaComputer) e lo specchio non lo cancella (swCheckinUniti, specchio-web.js) */
    let pc = false; try{ pc = typeof pcQui === 'function' && pcQui() === 'desktop'; }catch(_){ }
    if (pc){ ck.dev = 'computer'; try{ DP_PUB_PC_AT = 0; }catch(_){ } }
    l0.push(ck);
    localStorage.setItem('fl_dopa_checkin', JSON.stringify(l0.slice(-200)));
  }catch(_){ }
  /* 0.9.224: il numero sale SUBITO, nell'intestazione e nel tachimetro insieme. Prima l'intestazione
     aspettava il ricalcolo (nascosta mentre eri nel respiro) e per qualche secondo i due numeri
     erano diversi. Il ricalcolo poi conferma il valore vero. */
  try{ if (typeof DP !== 'undefined' && DP && typeof DP.L === 'number'){ FC_ULTIMA.da = DP.L; DP.L = Math.min(100, DP.L + delta); FC_ULTIMA.a = DP.L; FC_ULTIMA.at = Date.now(); if (typeof hdrMatchApply === 'function') hdrMatchApply(); } }catch(_){ }
  fcRidisegna();
  return delta;
}
/* l'ultima salita del carburante: da quanto a quanto, per la schermata con la lancetta */
var FC_ULTIMA = FC_ULTIMA || { da: null, a: null, at: 0 };

/* ---------------------------------------------------------------------------------------------
   LA LANCETTA CHE SALE (0.9.224). Andrea: dopo il respiro o la concentrazione il carburante deve
   salire DAVANTI agli occhi, come le barre delle missioni che si riempiono a fine livello. Il
   tachimetro e' lo stesso della pagina del carburante (dpGaugeSvg): la lancetta parte dal valore
   di prima, gira fino a quello nuovo, e il numero sale con lei.
   --------------------------------------------------------------------------------------------- */
/** "Perché funziona" sotto al guadagno di carburante: si apre e si chiude */
function fcSalInfo(b){
  const p = b && b.nextElementSibling; if (!p) return;
  const apri = p.hidden; p.hidden = !apri;
  b.setAttribute('aria-expanded', apri ? 'true' : 'false');
}
function fcSalitaApri(da, a, titolo, sotto, poi){
  if (!(typeof da === 'number' && typeof a === 'number') || !(a - da >= 0.05) || typeof dpGaugeSvg !== 'function'){ if (poi) poi(); return; }
  let w = document.getElementById('fcSalita');
  if (w) w.remove();
  w = document.createElement('div'); w.id = 'fcSalita'; w.className = 'fc-salita';
  w.innerHTML = '<div class="fc-sal-in"><p class="fc-sal-eti">' + (titolo || 'Il carburante sale') + '</p>'
    + '<div class="fc-sal-g">' + dpGaugeSvg(da) + '</div>'
    + '<b class="fc-sal-n"><span id="fcSalN">' + dpNum(da) + '</span> <small id="fcSalB">' + dpBanda(da).t + '</small></b>'
    /* 0.9.306, Andrea: il guadagno nei colori del brand (il verde e' solo per "fatto"), staccato dal numero; il
       perche' scientifico dietro a "Perché funziona", che si apre: il focus e' il carburante recuperato */
    + '<p class="fc-sal-piu"><b>+' + dpNum(a - da) + '</b> di carburante nella tua riserva di dopamina</p>'
    + (sotto ? '<button type="button" class="fc-sal-info" aria-expanded="false" onclick="fcSalInfo(this)">'
        + '<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><circle cx="12" cy="12" r="9.5" fill="none" stroke="currentColor" stroke-width="1.8"/><path d="M12 10.5v6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="7.3" r="1.3" fill="currentColor"/></svg>'
        + '<span>Perché funziona</span></button><p class="fc-sal-sotto" hidden>' + sotto + '</p>' : '')
    + '<button type="button" class="fc-sal-ok" id="fcSalOk">Continua</button></div>';
  document.body.appendChild(w);
  const ago = w.querySelector('.dp-ago line'), num = document.getElementById('fcSalN'), band = document.getElementById('fcSalB');
  const T = 1800, t0 = performance.now() + 450;
  let ultimoTic = Math.floor(da);
  const passo = function(ora){
    const k = Math.max(0, Math.min(1, (ora - t0) / T));
    const e = 1 - Math.pow(1 - k, 3);
    const v = da + (a - da) * e;
    const ang = 180 - Math.max(0, Math.min(100, v)) * 1.8;
    const P = dpPunto(ang, 76);
    if (ago){ ago.setAttribute('x2', P[0]); ago.setAttribute('y2', P[1]); }
    if (num){ num.textContent = dpNum(v); num.style.color = dpFascia(v); }
    if (band) band.textContent = dpBanda(v).t;
    if (Math.floor(v) > ultimoTic){ ultimoTic = Math.floor(v); try{ flVibra(8); }catch(_){ } }
    if (k < 1) requestAnimationFrame(passo);
    else { w.classList.add('fatto'); try{ flVibra([20, 40, 30]); }catch(_){ } try{ if (typeof sndFx === 'function') sndFx('ok'); }catch(_){ } }
  };
  requestAnimationFrame(function(){ w.classList.add('in'); requestAnimationFrame(passo); });
  document.getElementById('fcSalOk').onclick = function(){ w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 250); if (poi) poi(); };
}
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.fc-salita{position:fixed;inset:0;z-index:10050;display:flex;align-items:center;justify-content:center;background:#0B1530;color:#fff;opacity:0;transition:opacity .25s;padding:24px}.fc-salita.in{opacity:1}',
    '.fc-sal-in{width:100%;max-width:380px;text-align:center}.fc-sal-eti{margin:0 0 18px;font:800 22px/1.3 var(--font-display);color:#fff}',
    '.fc-sal-g{color:#fff;width:100%;max-width:320px;margin:0 auto}.fc-sal-g .dp-svg{width:100%;height:auto;display:block;color:#fff !important}.fc-sal-g .dp-ago line,.fc-sal-g .dp-ago circle{stroke:#fff;fill:#fff}.fc-sal-g .dp-ax{fill:#fff}',
    '.fc-sal-n{display:block;margin-top:10px;font:900 52px var(--font-display);font-variant-numeric:tabular-nums}.fc-sal-n small{font:800 22px var(--font-body);color:rgba(255,255,255,.85)}',
    '.fc-sal-piu{margin:28px auto 0;max-width:30ch;padding:12px 16px;border-radius:16px;background:rgba(63,159,244,.16);border:1px solid rgba(140,198,255,.35);font:700 15px/1.45 var(--font-body);color:#BCE0FF;opacity:0;transform:translateY(8px);transition:opacity .4s,transform .4s}.fc-salita.fatto .fc-sal-piu{opacity:1;transform:none}',
    '.fc-sal-piu b{display:block;font:900 26px/1.15 var(--font-display);color:#8CC6FF}',
    '.fc-sal-info{display:flex;align-items:center;justify-content:center;gap:7px;margin:16px auto 0;padding:8px 14px;border:0;border-radius:99px;background:transparent;color:rgba(255,255,255,.75);font:700 13.5px var(--font-body);cursor:pointer}',
    '.fc-sal-sotto{margin:8px auto 0;max-width:32ch;padding:12px 14px;border-radius:14px;background:rgba(255,255,255,.06);font:500 14.5px/1.5 var(--font-body);color:rgba(255,255,255,.8)}.fc-sal-sotto[hidden]{display:none}',
    '.fc-sal-ok{margin-top:34px;width:100%;padding:16px;border:0;border-radius:16px;background:#0075E3;color:#fff;font:900 16px var(--font-body);letter-spacing:.08em;text-transform:uppercase;box-shadow:0 5px 0 #00509E;cursor:pointer}.fc-sal-ok:active{transform:translateY(3px);box-shadow:0 2px 0 #00509E}'
  ].join('\n');
  document.head.appendChild(st);
})();
/* LA CONCENTRAZIONE: a fine sessione di Full Focus il carburante si ricalcola (il bonus della
   sessione lo da' il motore della dopamina) e, se e' salito, la lancetta lo fa vedere prima di
   tornare alla Home. */
(function(){
  if (typeof ffDoneOpen === 'function'){
    const v = ffDoneOpen;
    window.ffDoneOpen = ffDoneOpen = function(ok){
      FC_ULTIMA.ff = null;
      try{
        const prima = (typeof DP !== 'undefined' && DP && typeof DP.L === 'number') ? DP.L : null;
        if (prima !== null && typeof dpCalcola === 'function') setTimeout(function(){ dpCalcola(true).then(function(d){ if (d && typeof d.riserva === 'number' && d.riserva - prima >= 0.1) FC_ULTIMA.ff = { da: prima, a: d.riserva }; try{ hdrMatchApply(); }catch(_){ } }).catch(function(){ }); }, 300);
      }catch(_){ }
      return v.apply(this, arguments);
    };
  }
  if (typeof ffDoneClose === 'function'){
    const v2 = ffDoneClose;
    window.ffDoneClose = ffDoneClose = function(){
      const s = FC_ULTIMA.ff; FC_ULTIMA.ff = null;
      const args = arguments, self = this;
      if (s) { fcSalitaApri(s.da, s.a, 'La concentrazione ha ricaricato il carburante', 'Ogni minuto di Full Focus riempie la riserva di dopamina che ti serve per il resto della giornata.', function(){ v2.apply(self, args); }); return; }
      return v2.apply(this, arguments);
    };
  }
})();
function fcRidisegna(){
  try{
    if (typeof dpCalcola !== 'function') return;
    const giro = function(){ dpCalcola(true).then(function(){ try{ if (typeof hdrMatchApply === 'function') hdrMatchApply(); }catch(_){ } try{ if (typeof dpRidipingi === 'function') dpRidipingi(); }catch(_){ } try{ const sd = document.getElementById('s-dopamina'); if (sd && sd.classList.contains('active') && typeof dpDettaglioPaint === 'function') dpDettaglioPaint(); }catch(_){ } }).catch(function(){ }); };
    /* se un calcolo e' gia' in corso, quello non vede il check-in nuovo: si rifa' dopo */
    if (typeof DP !== 'undefined' && DP.inCorso) DP.inCorso.then(function(){ setTimeout(giro, 50); }); else giro();
  }catch(_){ }
}
/** Una task chiusa: se e' dentro al tempo scelto, il carburante promesso. Torna il carburante dato. */
function fcTaskChiusa(task, minFatti){
  let stima = 0;
  try{ const day = stDayKey('today'); const m = stMeta(task, day); stima = +(m && m.stima) || 0; }catch(_){ }
  const scelto = stima || +minFatti || 25;
  if (stima && minFatti && minFatti > stima * 1.1) return 0;      // oltre il tempo scelto: niente bonus
  return fcAggiungi(fcPremio(scelto), 'Task chiusa nel tempo: ' + String(task || '').slice(0, 40), scelto + ' min');
}

/* ---- la combo ---- */
function fcCombo(){ try{ const v = JSON.parse(localStorage.getItem(FC_COMBO_KEY) || 'null'); return (v && v.g === fcGiorno()) ? v : { g: fcGiorno(), n: 0, at: 0 }; }catch(_){ return { g: fcGiorno(), n: 0, at: 0 }; } }
function fcComboPiu(){
  const v = fcCombo();
  if (Date.now() - (v.at || 0) < 90000) return v.n;       // la stessa cosa contata due volte (sessione + livello)
  v.n++; v.at = Date.now();
  /* 0.9.298: una cosa fatta azzera la combo di aperture della schermata fuori rotta */
  try{ localStorage.setItem('fl_rotta_reset', String(Date.now())); if (typeof ptPedaggiSync === 'function') setTimeout(function(){ ptPedaggiSync(true); }, 1500); }catch(_){ }
  try{ localStorage.setItem(FC_COMBO_KEY, JSON.stringify(v)); }catch(_){ }
  /* 0.9.298: la combo positiva e' un moltiplicatore dichiarato e con un tetto, come quella negativa: il premio
     dell'ultima cosa fatta vale x1,25, x1,5, x1,75, x2 (il tetto) se e' la seconda, terza, quarta, quinta di fila */
  if (v.n >= 2){
    const f = fcComboFattore(v.n);
    const base = (FC_ULTIMA.premio && Date.now() - FC_ULTIMA.premioAt < 120000) ? FC_ULTIMA.premio : 5;
    fcAggiungi(Math.max(1, Math.round(base * (f - 1))), 'Combo ×' + String(f).replace('.', ','), v.n + ' cose fatte di fila');
  }
  return v.n;
}
function fcComboFattore(n){ const f = [1, 1.25, 1.5, 1.75, 2]; return f[Math.max(0, Math.min(f.length - 1, (n || 1) - 1))]; }
function fcComboZero(){ try{ localStorage.setItem(FC_COMBO_KEY, JSON.stringify({ g: fcGiorno(), n: 0, at: 0 })); }catch(_){ } }
const FC_FRASI = [
  'Il tuo io futuro ti sta ringraziando.',
  'Il traguardo si avvicina: continua così.',
  'Sei sulla strada giusta, e si vede.',
  'Il vecchio te non ti sta più dietro.',
  'Così si costruisce un’abitudine: una dopo l’altra.',
  'Stai diventando una leggenda vivente.',
  'Il sogno impossibile sta diventando inevitabile.'
];
function fcComboTitolo(n){ return n >= 5 ? 'Sei inarrestabile' : 'La tua combo continua'; }
function fcComboFrase(n){ return n + ' cose fatte di fila. ' + FC_FRASI[(n - 2 + FC_FRASI.length) % FC_FRASI.length]; }

/* le uscite a meta' azzerano la combo */
(function(){
  if (typeof flEsciVia === 'function'){ const v = flEsciVia; window.flEsciVia = flEsciVia = function(){ fcComboZero(); return v.apply(this, arguments); }; }
  if (typeof esPerso === 'function'){ const v = esPerso; window.esPerso = esPerso = function(){ fcComboZero(); return v.apply(this, arguments); }; }
})();
