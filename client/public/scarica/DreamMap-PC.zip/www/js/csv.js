/* csv.js - importing and exporting the block lists as CSV (G16). Owned by area U-B together
   with blocklist.js; nothing here touches another module's file.

   Import is what AppBlock charges for and what was missing here. Export is ours: AppBlock has
   no way to get a list back out, so a user who has spent an hour building one is locked in.

   Two things shape the code below:
   - a CSV written by an Italian spreadsheet uses `;`, one written by an English one uses `,`,
     and the same person will bring both. The delimiter is detected per file, and both are
     accepted on the same import;
   - the WebView cannot save a file the way a browser can. `<a download>` is inert inside the
     app, so the export always ends in a selectable textarea with a Copy button, and only adds
     a real download when the page is being previewed in a desktop browser. If a Filesystem
     plugin is ever installed, the code picks it up on its own — see csvSaveToDisk(). */

let CSV_TARGET = 'web';      // which list the open dialog is working on: 'web' or 'kw'
let CSV_PENDING = null;      // the parsed, deduplicated import waiting for confirmation
let CSV_EXPORT_TEXT = '';    // the text currently shown in the export box

/* ---------------------------------------------------------------------------------------
   Parsing
   --------------------------------------------------------------------------------------- */

/* Names an exported file (ours or a spreadsheet's) is likely to put on the first row. If the
   first cell is one of these the row is a header and not a rule — importing it would create a
   block on the literal word "dominio". */
const CSV_HEADERS = ['sito','siti','site','sites','website','url','dominio','domain','host',
                     'parola','parole','parola chiave','parole chiave','keyword','keywords',
                     'termine','term','voce','valore','value'];

const CSV_MODE_ALIASES = {
  domain:['domain','dominio','dominio esatto','d','host','sito','site','nel dominio'],
  url:   ['url','indirizzo','u','ovunque','anywhere','ovunque nell\'url','link','full url'],
  content:['content','contenuto','c','pagina','testo','text','page','nel contenuto della pagina']
};
function csvMode(raw){
  const v = String(raw==null?'':raw).trim().toLowerCase();
  if(!v) return null;
  for(const m in CSV_MODE_ALIASES){ if(CSV_MODE_ALIASES[m].indexOf(v) >= 0) return m; }
  return null;
}

/* Splits one line into fields, honouring double quotes and the "" escape inside them. */
function csvSplitLine(line, delim){
  const out = [];
  let field = '', quoted = false;
  for(let i=0;i<line.length;i++){
    const c = line.charAt(i);
    if(quoted){
      if(c === '"'){
        if(line.charAt(i+1) === '"'){ field += '"'; i++; }
        else quoted = false;
      }else field += c;
    }else if(c === '"') quoted = true;
    else if(c === delim){ out.push(field); field=''; }
    else field += c;
  }
  out.push(field);
  return out;
}

/* The delimiter is whichever of ; and , appears more often outside quotes. A file with neither
   is a one-column list, which is the most common thing a user will paste together by hand. */
function csvDelimiter(text){
  let semi=0, comma=0, quoted=false;
  for(let i=0;i<text.length;i++){
    const c = text.charAt(i);
    if(c === '"') quoted = !quoted;
    else if(!quoted && c === ';') semi++;
    else if(!quoted && c === ',') comma++;
  }
  return semi >= comma && semi > 0 ? ';' : ',';
}

/* text -> [{t, m|null}], with the header row dropped and empty rows ignored. */
function csvParse(text){
  const delim = csvDelimiter(text);
  const lines = String(text||'').split(/\r\n|\r|\n/);
  const rows = [];
  lines.forEach(function(line, idx){
    if(!line.trim()) return;
    const f = csvSplitLine(line, delim);
    const term = String(f[0]||'').trim().toLowerCase();
    if(!term) return;
    if(idx === 0 && CSV_HEADERS.indexOf(term) >= 0) return;   // header row
    rows.push({t:term, m:csvMode(f[1])});
  });
  return rows;
}

/* ---------------------------------------------------------------------------------------
   Import
   --------------------------------------------------------------------------------------- */

/* 0.9.290, Andrea: "ripristina un backup deve comparire nell'importa". Importa apre la scelta: il file CSV di questo
   programma, o il backup di tutta l'app. */
function csvImportOpen(target){
  if(!DRAFT){ toast('Apri prima un programma'); return; }
  CSV_TARGET = target;
  const cosa = target==='web' ? 'I siti' : 'Le parole chiave';
  const body = '<div class="csv-scelte">'
    +   '<button type="button" class="csv-scelta on" onclick="csvCloseModal();csvImportPick(CSV_TARGET)"><b>Importa un file CSV</b><small>' + cosa + ' da un file salvato prima, o da un’altra app.</small></button>'
    +   '<button type="button" class="csv-scelta" onclick="csvCloseModal();if(typeof ufRestoreFile===\'function\')ufRestoreFile()"><b>Ripristina un backup</b><small>Scegli un file di backup: sostituisce i dati di tutta l’app.</small></button>'
    + '</div>';
  csvOpenModal('Importa', body, '');
}
function csvImportPick(target){
  if(!DRAFT){ toast('Apri prima un programma'); return; }
  CSV_TARGET = target;
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.csv,text/csv,text/plain';
  input.style.display = 'none';
  input.addEventListener('change', function(){
    const file = input.files && input.files[0];
    if(!file){ input.remove(); return; }
    const reader = new FileReader();
    reader.onerror = function(){ toast('Impossibile leggere il file'); input.remove(); };
    reader.onload = function(){
      try{ csvPreview(String(reader.result||''), file.name); }
      catch(e){ toast('File CSV non leggibile: '+(e && e.message ? e.message : 'formato non riconosciuto')); }
      input.remove();
    };
    reader.readAsText(file);
  });
  document.body.appendChild(input);
  input.click();
}

/* Builds the plan and shows it. Nothing is written to the DRAFT until the user confirms:
   an import that silently swallows 400 rows is impossible to undo on a phone. */
function csvPreview(text, filename){
  const rows = csvParse(text);
  const plan = {file:filename||'file.csv', target:CSV_TARGET, sites:[], keywords:[],
                total:rows.length, dup:0, bad:0, moved:0};

  const haveSites = {}, haveKw = {};
  (DRAFT.sites||[]).forEach(function(s){ haveSites[s]=1; });
  (DRAFT.keywords||[]).map(ubKw).forEach(function(k){ haveKw[k.m+' '+k.t]=1; });

  rows.forEach(function(r){
    if(CSV_TARGET === 'web' && (r.m === null || r.m === 'domain')){
      const v = ubSiteNorm(r.t);
      if(!v){ plan.bad++; return; }
      if(haveSites[v]){ plan.dup++; return; }
      haveSites[v] = 1;
      plan.sites.push(v);
      return;
    }
    // On the Web tab a row that explicitly asks for url/content is not a domain rule: it goes
    // to the keywords, where that mode actually exists. The preview says so out loud.
    if(CSV_TARGET === 'web') plan.moved++;
    const t = r.t;
    if(!t || /^\s*$/.test(t)){ plan.bad++; return; }
    // No mode column: guess the same way the entry field guesses while you type.
    const m = r.m || (ubLooksLikeDomain(t) ? 'domain' : 'url');
    const key = m+' '+t;
    if(haveKw[key]){ plan.dup++; return; }
    haveKw[key] = 1;
    plan.keywords.push({t:t, m:m});
  });

  CSV_PENDING = plan;
  const fresh = plan.sites.length + plan.keywords.length;

  let body = '<p class="ub-csv-line"><b>Trovate '+plan.total+' voci, '+fresh+' nuove</b> — Importa?</p>'
           + '<p class="ub-csv-sub">'+esc(plan.file)+'</p>';
  const notes = [];
  const n = function(k, one, many){ return k + ' ' + (k===1 ? one : many); };
  if(plan.dup) notes.push(n(plan.dup,'già in elenco','già in elenco'));
  if(plan.bad) notes.push(n(plan.bad,'scartata perché non valida','scartate perché non valide'));
  if(plan.moved) notes.push(n(plan.moved,'con corrispondenza URL o contenuto finirà tra le parole chiave',
                                         'con corrispondenza URL o contenuto finiranno tra le parole chiave'));
  if(notes.length) body += '<p class="ub-csv-sub">'+esc(notes.join(' · '))+'</p>';

  if(!fresh){
    body += '<div class="hintline" style="margin-top:12px">Non c\'è niente di nuovo da importare.</div>';
    csvOpenModal('Importa da CSV', body,
      '<button class="ghost" onclick="csvCloseModal()">Chiudi</button>');
    return;
  }

  const sample = plan.sites.map(function(s){ return '<span class="ub-chip">'+esc(s)+'</span>'; })
    .concat(plan.keywords.map(function(k){ return '<span class="ub-chip ub-m-'+k.m+'">'+esc(k.t)+'</span>'; }));
  body += '<div class="ub-chipbox" style="margin-top:12px">'
        + sample.slice(0,14).join('')
        + (sample.length>14 ? '<span class="ub-chip ub-more">+'+(sample.length-14)+'</span>' : '')
        + '</div>';

  csvOpenModal('Importa da CSV', body,
    '<button class="ghost" onclick="csvCloseModal()">Annulla</button>' +
    '<button class="cta" onclick="csvConfirmImport()">Importa '+fresh+'</button>');
}

function csvConfirmImport(){
  const plan = CSV_PENDING;
  if(!plan){ csvCloseModal(); return; }
  if(!DRAFT){ toast('Apri prima un programma'); csvCloseModal(); return; }
  ubNormalizeDraftKeywords();
  plan.sites.forEach(function(s){ if(DRAFT.sites.indexOf(s)<0) DRAFT.sites.push(s); });
  plan.keywords.forEach(function(k){
    if(!DRAFT.keywords.some(function(x){ return x.t===k.t && x.m===k.m; })) DRAFT.keywords.push(k);
  });
  const n = plan.sites.length + plan.keywords.length;
  CSV_PENDING = null;
  csvCloseModal();
  // The import can touch both lists, so both are redrawn whichever tab is open.
  ubAfterListChange('web');
  ubAfterListChange('kw');
  toast(n + (n===1 ? ' voce importata' : ' voci importate'));
}

/* ---------------------------------------------------------------------------------------
   Export
   --------------------------------------------------------------------------------------- */

function csvCell(v){
  const s = String(v==null?'':v);
  return /[";,\r\n]/.test(s) ? '"'+s.replace(/"/g,'""')+'"' : s;
}
function csvBuild(target){
  const rows = [];
  if(target === 'web'){
    rows.push(['sito','tipo']);
    (DRAFT.sites||[]).forEach(function(s){ rows.push([s,'dominio']); });
  }else{
    rows.push(['parola','tipo']);
    (DRAFT.keywords||[]).map(ubKw).forEach(function(k){
      rows.push([k.t, k.m==='domain'?'dominio':k.m==='content'?'contenuto':'url']);
    });
  }
  // `;` because that is what an Italian spreadsheet expects; the importer reads both anyway.
  return rows.map(function(r){ return r.map(csvCell).join(';'); }).join('\r\n');
}
function csvFilename(target){
  const d = new Date();
  const p = function(n){ return String(n).padStart(2,'0'); };
  return 'DreamMap-' + (target==='web'?'siti':'parole') + '-'
    + d.getFullYear() + p(d.getMonth()+1) + p(d.getDate()) + '.csv';
}

/* 0.9.289, Andrea: "esportare deve dare un FILE salvato in Download, pronto da mandarsi su Telegram, non un testo da
   copiare; e voglio poter scegliere: il file di questo programma, il testo, o il backup di tutta l'app". */
function csvExportOpen(target){
  if(!DRAFT){ toast('Apri prima un programma'); return; }
  CSV_TARGET = target;
  const count = target==='web' ? (DRAFT.sites||[]).length : (DRAFT.keywords||[]).length;
  if(!count){ toast('Non c\'è ancora niente da esportare'); return; }
  CSV_EXPORT_TEXT = csvBuild(target);
  if(NATIVE && NATIVE.salvaInDownload){
    const cosa = target==='web' ? 'i siti' : 'le parole chiave';
    const body = '<p class="ub-csv-line"><b>'+count+(count===1?' voce':' voci')+'</b> di questo programma.</p>'
      + '<div class="csv-scelte">'
      +   '<button type="button" class="csv-scelta on" onclick="csvSalvaFile()"><b>Salva il file CSV</b><small>Finisce nella cartella Download, pronto da condividere o da importare.</small></button>'
      +   '<button type="button" class="csv-scelta" onclick="csvMostraTesto()"><b>Copia come testo</b><small>Solo '+cosa+', da incollare dove vuoi.</small></button>'
      +   '<button type="button" class="csv-scelta" onclick="csvBackupApp()"><b>Backup di tutta l’app</b><small>Programmi, impostazioni, note e tutto il resto, in un file solo.</small></button>'
      + '</div>';
    /* 0.9.290, Andrea: "Ripristina un backup sta nell'importa, non nell'esporta" */
    csvOpenModal('Esporta', body, '');
    return;
  }

  const body = '<p class="ub-csv-line"><b>'+count+(count===1?' voce':' voci')+'</b> pronte da salvare.</p>'
    + '<p class="ub-csv-sub">Copia il testo e incollalo in un file .csv, oppure rimandalo qui con l\'importazione.</p>'
    + '<textarea class="ub-csv-area" id="ub-csv-area" readonly onclick="this.select()">'+esc(CSV_EXPORT_TEXT)+'</textarea>';

  // A download started by the page is inert inside the WebView, so that button only appears
  // where it actually works: the browser preview.
  const actions = '<button class="ghost" onclick="csvCloseModal()">Chiudi</button>'
    + (NATIVE ? '' : '<button class="ghost" onclick="csvDownloadExport()">Scarica .csv</button>')
    + '<button class="cta" onclick="csvCopyExport()">Copia</button>';

  csvOpenModal('Esporta in CSV', body, actions);
  csvSaveToDisk();   // only does something if a Filesystem plugin is installed
}

function csvMostraTesto(){
  const body = '<p class="ub-csv-sub">Copia il testo e incollalo dove vuoi, oppure rimandalo qui con l\'importazione.</p>'
    + '<textarea class="ub-csv-area" id="ub-csv-area" readonly data-no-mic onclick="this.select()">'+esc(CSV_EXPORT_TEXT)+'</textarea>';
  csvOpenModal('Copia come testo', body, '<button class="ghost" onclick="csvCloseModal()">Chiudi</button><button class="cta" onclick="csvCopyExport()">Copia</button>');
}
async function csvSalvaFile(){
  try{
    const r = await NATIVE.salvaInDownload({ nome: csvFilename(CSV_TARGET), testo: '\ufeff' + CSV_EXPORT_TEXT, mime: 'text/csv' });
    csvCloseModal();
    flFileSalvato('Salvato in Download', r.uri, 'text/csv');
  }catch(e){ toast((e && e.message) || 'File non salvato'); }
}
async function csvBackupApp(){
  csvCloseModal();
  if (typeof ufBackupFile === 'function') ufBackupFile();
}
/** La barra in fondo (come StayFocused): "Salvato in Download · Condividi". Resta qualche secondo. */
function flFileSalvato(testo, uri, mime){
  let b = document.getElementById('flFileBar');
  if (!b){ b = document.createElement('div'); b.id = 'flFileBar'; b.className = 'fl-filebar'; document.body.appendChild(b); }
  b.innerHTML = '<span>' + esc(testo) + '</span>' + (uri ? '<button type="button">Condividi</button>' : '');
  const bt = b.querySelector('button');
  if (bt) bt.onclick = function(){ try{ NATIVE.condividiFile({ uri: uri, mime: mime || '*/*', titolo: 'Condividi il file' }); }catch(_){ } b.classList.remove('on'); };
  b.classList.add('on');
  clearTimeout(b._t); b._t = setTimeout(function(){ b.classList.remove('on'); }, 7000);
}
(function(){
  const st = document.createElement('style');
  st.textContent = '.csv-scelte{display:grid;gap:10px;margin:12px 0 4px}.csv-scelta{display:block;width:100%;text-align:left;padding:14px 16px;border-radius:16px;border:1.5px solid var(--line,#DCE8F5);background:var(--card,#fff);cursor:pointer;font:inherit}'
    + '.csv-scelta b{display:block;font:800 15.5px var(--font-body);color:var(--navy)}.csv-scelta small{display:block;margin-top:3px;font:500 13px/1.4 var(--font-body);color:var(--muted)}.csv-scelta.on{border-color:#0075E3;background:#EEF6FF}'
    + 'body.dark .csv-scelta{background:#12203A;border-color:#22345A}body.dark .csv-scelta.on{background:#0E2B57;border-color:#3F9FF4}body.dark .csv-scelta b{color:#fff}'
    + '.fl-filebar{position:fixed;left:12px;right:12px;bottom:calc(env(safe-area-inset-bottom,0px) + 16px);z-index:99990;display:flex;align-items:center;gap:12px;padding:14px 16px;border-radius:14px;background:#14213D;color:#fff;box-shadow:0 10px 30px rgba(0,20,60,.35);transform:translateY(140%);transition:transform .3s cubic-bezier(.2,.8,.2,1)}'
    + '.fl-filebar.on{transform:none}.fl-filebar span{flex:1;font:600 14.5px var(--font-body)}.fl-filebar button{border:0;background:none;color:#7DBEFF;font:800 14.5px var(--font-body);cursor:pointer}';
  document.head.appendChild(st);
})();
function csvCopyExport(){
  const area = document.getElementById('ub-csv-area');
  const done = function(){ toast('Copiato negli appunti'); };
  const fail = function(){ toast('Copia non riuscita: seleziona il testo e copialo a mano'); };
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(CSV_EXPORT_TEXT).then(done, function(){ csvCopyLegacy(area, done, fail); });
  }else csvCopyLegacy(area, done, fail);
}
function csvCopyLegacy(area, done, fail){
  try{
    if(!area) return fail();
    area.removeAttribute('readonly');
    area.focus(); area.select(); area.setSelectionRange(0, CSV_EXPORT_TEXT.length);
    const ok = document.execCommand('copy');
    area.setAttribute('readonly','readonly');
    ok ? done() : fail();
  }catch(e){ fail(); }
}

/* Browser preview only: a Blob the browser saves like any other download. */
function csvDownloadExport(){
  try{
    const blob = new Blob(['﻿'+CSV_EXPORT_TEXT], {type:'text/csv;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = csvFilename(CSV_TARGET);
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 4000);
  }catch(e){ toast('Download non riuscito: usa Copia'); }
}

/* If a Capacitor Filesystem plugin is ever added to the project this writes a real file and
   offers the share sheet. It is absent today (only @capacitor/app is installed), so the guard
   makes the whole thing a no-op instead of a promise that never settles. */
async function csvSaveToDisk(){
  const P = window.Capacitor && window.Capacitor.Plugins;
  const FS = P && P.Filesystem;
  if(!FS || !FS.writeFile) return;
  const note = document.getElementById('ub-csv-note');
  try{
    const res = await FS.writeFile({
      path: csvFilename(CSV_TARGET),
      data: CSV_EXPORT_TEXT,
      directory: 'DOCUMENTS',
      encoding: 'utf8'
    });
    const where = res && res.uri ? res.uri : csvFilename(CSV_TARGET);
    if(note) note.textContent = 'Salvato in ' + where;
    if(P.Share && P.Share.share){
      try{ await P.Share.share({title:'Lista di blocco DreamMap', url:res && res.uri ? res.uri : undefined}); }
      catch(e){ /* the user dismissing the share sheet is not an error */ }
    }
  }catch(e){
    if(note) note.textContent = 'Salvataggio su file non riuscito: ' + (e && e.message ? e.message : 'permesso negato') + '. Usa Copia.';
  }
}

/* ---------------------------------------------------------------------------------------
   The shared dialog
   --------------------------------------------------------------------------------------- */

function csvOpenModal(title, body, actions){
  const root = document.getElementById('ub-csv-root');
  if(!root) return;
  document.getElementById('ub-csv-title').textContent = title;
  document.getElementById('ub-csv-body').innerHTML = body + '<p class="ub-csv-sub" id="ub-csv-note"></p>';
  const az = document.getElementById('ub-csv-actions'); az.innerHTML = actions || ''; az.hidden = !actions;
  root.classList.add('open');
}
function csvCloseModal(){
  const root = document.getElementById('ub-csv-root');
  if(root) root.classList.remove('open');
  CSV_PENDING = null;
}

(function csvUi(){
  const css = [
  '#ub-csv-root{position:absolute;inset:0;z-index:70;pointer-events:none;opacity:0;transition:opacity .2s}',
  '#ub-csv-root.open{pointer-events:auto;opacity:1}',
  /* 0.9.290, Andrea: "non e' un popover: non ha la X e dietro non si scurisce". Velo scuro vero (anche nel tema scuro),
     la X in alto, e un tocco fuori chiude. */
  '#ub-csv-root{position:fixed!important;z-index:9990!important}',
  '#ub-csv-root .ub-csv-scrim{position:absolute;inset:0;background:rgba(0,8,20,.62)}',
  '#ub-csv-root .ub-csv-x{position:absolute;top:12px;right:12px;width:36px;height:36px;border-radius:50%;border:0;background:rgba(0,30,68,.07);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark #ub-csv-root .ub-csv-x{background:rgba(255,255,255,.1);color:#fff}',
  '#ub-csv-root h3{padding-right:44px}#ub-csv-actions[hidden]{display:none!important}',
  '#ub-csv-root .ub-csv-card{position:absolute;left:14px;right:14px;bottom:calc(14px + env(safe-area-inset-bottom,0px));background:var(--card);',
  '  border-radius:18px;padding:18px;box-shadow:0 18px 44px rgba(0,0,0,.32);max-height:82%;',
  '  display:flex;flex-direction:column;transform:translateY(12px);transition:transform .2s}',
  '#ub-csv-root.open .ub-csv-card{transform:none}',
  '#ub-csv-root h3{font:800 17px var(--font-display);font-style:italic;color:var(--navy);margin-bottom:8px}',
  '#ub-csv-body{overflow:auto;flex:1}',
  '.ub-csv-line{font:600 14px/1.5 var(--font-body);color:var(--ink);margin:0}',
  '.ub-csv-line b{color:var(--navy)}',
  '.ub-csv-sub{font:500 11.5px/1.5 var(--font-body);color:var(--muted);margin:4px 0 0}',
  '.ub-csv-sub:empty{display:none}',
  '.ub-csv-area{width:100%;height:150px;margin-top:10px;border:1px solid var(--line);border-radius:12px;',
  '  padding:10px;font:500 11.5px/1.5 ui-monospace,Menlo,Consolas,monospace;color:var(--navy);background:#fff;resize:none}',
  // .ghost is width:100% in app.css; three of those in a row would run off a 360px card.
  '#ub-csv-actions{display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-top:14px;flex:none}',
  '#ub-csv-actions .ghost{flex:1 1 auto;width:auto;min-width:0;padding:12px 6px;white-space:nowrap}',
  '#ub-csv-actions .cta{flex:1 1 100%;margin:0;order:2}'
  ].join('\n');
  const s = document.createElement('style');
  s.id = 'ub-csv-style';
  s.textContent = css;
  document.head.appendChild(s);

  registerOverlay('ub-csv-root',
    '<div class="ub-csv-scrim" onclick="csvCloseModal()"></div>' +
    '<div class="ub-csv-card">' +
      '<button type="button" class="ub-csv-x" aria-label="Chiudi" onclick="csvCloseModal()"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
      '<h3 id="ub-csv-title"></h3>' +
      '<div id="ub-csv-body"></div>' +
      '<div id="ub-csv-actions"></div>' +
    '</div>');
})();
