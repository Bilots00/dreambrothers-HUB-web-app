/* ===========================================================================================
   IL PIANO A TUTTO SCHERMO DIVENTA UN NOTION (0.9.215)

   Andrea: «la nostra pagina a schermo intero e' troppo rigida, l'utente deve adattarsi a lei».
   Al suo posto c'e' la replica di Notion che gli ha fatto Lovable (repo Bilots00/
   notion-clone-studio), costruita come pagina a parte in www/notion/ e aperta qui dentro in un
   iframe a tutto schermo. Pagine libere, blocchi, preferiti, cestino: tutto suo.

   MA LE TASK RESTANO QUELLE DELL'APP. La prima pagina, «Il piano», ha il database del giorno:
   le sue righe sono le righe di `fl_notes_<giorno>`, le spunte passano da stSpunta (con la sua
   domanda «L'hai fatta davvero?» e l'arbitro), le sezioni sono quelle del foglio (la priorita'
   assoluta, importante, urgente, non urgente). START, la Mappa, Full Focus e la Roadmap
   continuano a leggere gli stessi dati: la pagina nuova e' un modo diverso di guardarli, non
   un secondo posto dove stanno.

   Il ponte e' `window.flPiano`: l'iframe e' sulla stessa origine e chiama queste funzioni
   direttamente. Quando qualcosa cambia di qua (una spunta confermata nel foglio dell'app),
   glielo diciamo con ntAvvisa(); quando cambia localStorage lo sente anche da solo.
   =========================================================================================== */

const NT = { aperto: false, pronto: false, giorno: 0 };

function ntIso(off){ return mtKey(Date.now() + (off || 0) * 86400000); }
function ntTitolo(off){
  if (off === 0) return 'Oggi';
  if (off === 1) return 'Domani';
  if (off === -1) return 'Ieri';
  const d = new Date(Date.now() + off * 86400000);
  const G = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
  const M = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  return G[d.getDay()] + ' ' + d.getDate() + ' ' + M[d.getMonth()];
}
function ntRighe(day){
  const righe = stRigheDi(day);
  let prio = '';
  try{ prio = stPriorita(day, righe) || ''; }catch(_){ }
  return righe.map(function(t){
    let sez = 'idee', stima = 0;
    try{ sez = stSezione(t, day, righe); }catch(_){ }
    try{ stima = stMeta(t, day).stima || 0; }catch(_){ }
    return { t: t, sez: sez, fatta: sez === 'fatte', prio: t === prio, stima: stima };
  });
}

window.flPiano = {
  versione: 1,
  sezioni: function(){ return ST_SEZIONI.map(function(s){ return { k: s[0], nome: s[1], sotto: s[2] }; }); },
  nome: function(){
    try{ if (typeof dvNome === 'function' && dvNome()) return dvNome().split(' ')[0]; }catch(_){ }
    try{ if (typeof gnNome === 'function' && gnNome()) return gnNome().split(' ')[0]; }catch(_){ }
    return '';
  },
  /** Il giorno a `off` giorni da oggi: le righe con la loro sezione, e se e' ancora chiuso. */
  giorno: function(off){
    off = Math.max(-60, Math.min(2, off | 0));
    NT.giorno = off;
    const iso = ntIso(off);
    const chiuso = off >= 1 && typeof pnDomaniAperto === 'function' && !pnDomaniAperto();
    let perche = '';
    if (chiuso){
      const c = [];
      try{ if (pnCond('prio') && !pnPrioFatta()) c.push('finisci la priorità assoluta di oggi'); }catch(_){ }
      try{ if (pnCond('fine') && !pnDopoFine()) c.push('aspetta la fine della giornata di lavoro (' + pnFineLavoro() + ')'); }catch(_){ }
      perche = c.join(' e ');
    }
    return { off: off, iso: iso, titolo: ntTitolo(off), oggi: off === 0, chiuso: chiuso, perche: perche, righe: chiuso ? [] : ntRighe(iso) };
  },
  /** La settimana (lunedi'-domenica) che contiene il giorno a `off`: per la vista Calendario. */
  settimana: function(off){
    const base = new Date(Date.now() + (off | 0) * 86400000);
    const lun = new Date(base.getFullYear(), base.getMonth(), base.getDate(), 12);
    lun.setDate(lun.getDate() - ((lun.getDay() + 6) % 7));
    const oggi = new Date(); const o0 = new Date(oggi.getFullYear(), oggi.getMonth(), oggi.getDate(), 12);
    const out = [];
    for (let i = 0; i < 7; i++){
      const d = new Date(lun); d.setDate(lun.getDate() + i);
      const o = Math.round((d - o0) / 86400000);
      const iso = mtKey(d.getTime());
      const chiuso = o >= 1 && typeof pnDomaniAperto === 'function' && !pnDomaniAperto();
      out.push({ off: o, iso: iso, titolo: ntTitolo(o), giorno: d.getDate(), chiuso: chiuso || o > 2, righe: (chiuso || o > 2) ? [] : ntRighe(iso) });
    }
    return out;
  },
  aggiungi: function(iso, testo){
    const t = String(testo || '').replace(/\s+/g, ' ').trim();
    if (!t) return false;
    const righe = stRigheDi(iso);
    if (righe.indexOf(t) >= 0) return false;
    righe.push(t);
    try{ localStorage.setItem('fl_notes_' + iso, righe.join('\n')); }catch(_){ }
    try{ if (typeof fsToccato === 'function') fsToccato(iso); }catch(_){ }
    if (iso === ntIso(0) || iso === ntIso(1)){
      const prima = STN.day;
      STN.day = iso === ntIso(1) ? 'tomorrow' : 'today';
      try{ stPlanned(); }catch(_){ }
      STN.day = prima;
    }
    return true;
  },
  rinomina: function(iso, vecchio, nuovo){
    const n = String(nuovo || '').replace(/\s+/g, ' ').trim();
    const righe = stRigheDi(iso), i = righe.indexOf(vecchio);
    if (i < 0 || !n || n === vecchio) return false;
    righe[i] = n;
    try{ localStorage.setItem('fl_notes_' + iso, righe.join('\n')); }catch(_){ }
    /* la sezione scelta a mano e la stima seguono la riga */
    try{ const m = stMeta(vecchio, iso); if (m && Object.keys(m).length) stMetaSave(n, iso, m); }catch(_){ }
    try{ if (typeof fsToccato === 'function') fsToccato(iso); }catch(_){ }
    return true;
  },
  togli: function(iso, testo){
    const righe = stRigheDi(iso), i = righe.indexOf(testo);
    if (i < 0) return false;
    righe.splice(i, 1);
    try{ localStorage.setItem('fl_notes_' + iso, righe.join('\n')); }catch(_){ }
    try{ if (typeof fsToccato === 'function') fsToccato(iso); }catch(_){ }
    return true;
  },
  sposta: function(iso, testo, sez){
    if (['one', 'imp', 'scad', 'idee'].indexOf(sez) < 0) return false;
    try{ stMetaSave(testo, iso, { sez: sez }); }catch(_){ return false; }
    return true;
  },
  /** La spunta passa dalla domanda dell'app: `fatto` gira quando l'utente ha risposto. */
  spunta: function(iso, testo, fatto){
    try{ stSpunta(testo, iso, function(){ try{ if (fatto) fatto(); }catch(_){ } }); }catch(_){ }
  },
  /** I dettagli della riga (passi, stima, dove sta): la pagina dell'app, che torna qui. */
  dettagli: function(iso, testo){ try{ stRigaOpen(testo, iso, 's-notion'); }catch(_){ } },
  /** Il ▶ di una riga di oggi: il foglio «Quanto ci vuole?» e poi Full Focus. */
  avvia: function(testo){
    try{
      STN.day = 'today';
      const i = stLines('today').indexOf(testo);
      if (i >= 0) stStimaSheet(i);
    }catch(_){ }
  },
  /** Il piano di prima (Trimestri, Mesi, Settimane, Giorni, Note), per chi lo vuole ancora. */
  classico: function(){ ntChiudi(true); setTimeout(function(){ stFullOpenClassico(); }, 30); },
  chiudi: function(){ ntChiudi(); },
  vibra: function(p){ try{ flVibra(p); }catch(_){ } },
  /** Un giorno qualsiasi (il Calendario del pannello). */
  giornoIso: function(iso){
    const o0 = new Date(ntIso(0) + 'T12:00:00'), d = new Date(iso + 'T12:00:00');
    const off = Math.round((d - o0) / 86400000);
    const chiuso = off === 1 && typeof pnDomaniAperto === 'function' && !pnDomaniAperto();
    return { off: off, iso: iso, titolo: ntTitolo(off), oggi: off === 0, chiuso: chiuso, perche: chiuso ? window.flPiano.giorno(1).perche : '', righe: chiuso ? [] : ntRighe(iso) };
  },
  /** I giorni del mese con qualcosa scritto: quante righe, quante fatte. */
  mese: function(anno, mese0){
    const c = (typeof mfConteggi === 'function') ? mfConteggi(anno, mese0) : {};
    return Object.keys(c).sort().map(function(iso){ return { iso: iso, n: c[iso].t, fatte: c[iso].f }; });
  },
  /** Il caveau delle idee: si scrive e basta, non si rilegge (e' il patto dell'ADHD Mode). */
  caveau: function(){
    try{ return { n: cvChiuse().length, quando: cvQuandoTxt(), apribile: cvApribile() }; }catch(_){ return { n: 0, quando: '', apribile: false }; }
  },
  caveauAggiungi: function(testo, urgente){ try{ const ok = cvAggiungi(testo, !!urgente); if (ok) flVibra([10, 30, 10]); return ok; }catch(_){ return false; } },
  /** Il diario sfogliabile del profilo (scheda Story): si apre sopra al Notion, e si chiude tornando qui. */
  // 0.9.227: l'AI del piano e' per chi ha Premium
  premium: function(){ try{ return typeof Premium !== 'undefined' && !!Premium.isPremium(); }catch(_){ return false; } },
  apriDiario: function(){ try{ dvApri(); }catch(_){ try{ toast('Il diario si apre dal profilo, scheda Story'); }catch(__){ } } },
  apriTaglia: function(){ ntChiudi(true); try{ cvTagliaApri(); }catch(_){ } },
  toast: function(m){ try{ toast(m); }catch(_){ } },
  /** Le pagine della vecchia scheda Note, da portare nel Notion una volta sola. */
  vecchieNote: function(){
    try{
      return (pnPagine() || []).map(function(p){
        const d = document.createElement('div');
        d.innerHTML = String(p.html || '').replace(/<\/(p|div|li|h\d)>|<br\s*\/?>/gi, '\n');
        const righe = (d.textContent || '').split('\n').map(function(r){ return r.trim(); }).filter(Boolean);
        return { id: String(p.id || ''), titolo: p.titolo || 'Senza titolo', righe: righe, at: p.at || 0 };
      });
    }catch(_){ return []; }
  }
};

/* ===========================================================================================
   GLI ORIZZONTI TEMPORALI NEL PIANO (0.9.306)

   Andrea: togli "Il piano di prima", ma porta nella replica quello che aveva di buono: trimestri,
   mesi, settimane e giorni COLLEGATI, ognuno con la sua percentuale e la sua barra, che salgono
   quando si spuntano le task sotto e si sommano fino al sogno. I dati sono gli stessi del piano di
   prima (niente migrazione, niente perso): obiettivo e milestone di ogni periodo in `fl_periodi`
   (chiavi Q2026-4, M2026-10, W2026-44), le task di ogni giorno in `fl_notes_<giorno>` con le spunte
   del registro (pnGiorniConti di piano.js), i passi della Roadmap per il mese e la settimana in corso
   (pnContenuto). La differenza col piano di prima: ogni periodo conta ANCHE le milestone dei periodi
   che contiene (il trimestre quelle dei suoi mesi e delle sue settimane), e il sogno conta tutto.
   =========================================================================================== */
const NTOZ_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
function ntOzPct(f, t){ return t ? Math.round(f / t * 100) : 0; }
/** Le milestone di un periodo (le sue e i passi della Roadmap se e' quello in corso). */
function ntOzMs(tipo, key){
  const c = pnContenuto(tipo, key);
  return { ob: c.ob || '', ms: c.ms.map(function(x){ return { t: x.t, f: !!x.f, dove: x.dove, i: x.i }; }) };
}
function ntOzMsConto(tipo, key){ const m = ntOzMs(tipo, key).ms; return { t: m.length, f: m.filter(function(x){ return x.f; }).length }; }
/** Le settimane (lunedi') che appartengono a un intervallo: una settimana sta dove cade il suo giovedi', come le settimane ISO. */
function ntOzSettimaneIn(da, a){
  const out = [];
  let lun = pnLunedi(pnData(da));
  const fine = pnData(a);
  while (lun <= fine){
    const gio = new Date(lun); gio.setDate(gio.getDate() + 3);
    const ig = pnIso(gio);
    if (ig >= da && ig <= a) out.push(new Date(lun));
    lun = new Date(lun); lun.setDate(lun.getDate() + 7);
  }
  return out;
}
function ntOzChiaveSett(lun){ const s = pnSettimana(lun); return 'W' + s.anno + '-' + pnPad(s.w); }
/** Un periodo: le task dei giorni dentro + le sue milestone + quelle dei periodi che contiene. */
function ntOzRiga(tipo, key, titolo, sotto, conti, da, a, ora){
  const base = pnSomma(conti, da, a);
  const mio = ntOzMs(tipo, key);
  let t = base.t + mio.ms.length, f = base.f + mio.ms.filter(function(x){ return x.f; }).length;
  let figli = { t: 0, f: 0 };
  if (tipo === 'trim'){
    const y = +da.slice(0, 4), m0 = +da.slice(5, 7) - 1;
    for (let m = m0; m < m0 + 3; m++){ const c = ntOzMsConto('mesi', 'M' + y + '-' + pnPad(m + 1)); figli.t += c.t; figli.f += c.f; }
  }
  if (tipo === 'trim' || tipo === 'mesi'){
    ntOzSettimaneIn(da, a).forEach(function(l){ const c = ntOzMsConto('sett', ntOzChiaveSett(l)); figli.t += c.t; figli.f += c.f; });
  }
  t += figli.t; f += figli.f;
  return { key: key, tipo: tipo, titolo: titolo, sotto: sotto, ob: mio.ob, ms: mio.ms, base: base, figli: figli, t: t, f: f, pct: ntOzPct(f, t), ora: !!ora };
}
/** Le task di un giorno contate come le conta il piano (le idee per il futuro non sono task). */
function ntOzGiornoRighe(iso){
  const fatte = {};
  try{ (stDone() || []).forEach(function(d){ if (d && d.day === iso) fatte[String(d.text || '').trim().toLowerCase()] = 1; }); }catch(_){ }
  let meta = {}; try{ meta = stMetaAll() || {}; }catch(_){ meta = {}; }
  const out = [];
  stRigheDi(iso).forEach(function(r){
    let mk = null; try{ mk = meta[stMetaKey(r, iso)]; }catch(_){ }
    if (mk && mk.sez === 'idee') return;
    out.push({ t: r, f: !!fatte[r.trim().toLowerCase()] });
  });
  return out;
}
/** Tutto quello che serve alla pagina degli orizzonti. `v`: { anno, mese: 'YYYY-MM', lun: 'YYYY-MM-DD' } (assenti = adesso). */
function ntOrizzonti(v){
  v = v || {};
  const oggi = new Date(), isoOggi = mtKey(Date.now());
  const conti = pnGiorniConti();
  const anno = +v.anno || oggi.getFullYear();
  const mm = /^(\d{4})-(\d{2})$/.exec(v.mese || '');
  const mese = mm ? new Date(+mm[1], +mm[2] - 1, 1, 12) : new Date(oggi.getFullYear(), oggi.getMonth(), 1, 12);
  const lun = pnLunedi(/^\d{4}-\d{2}-\d{2}$/.test(v.lun || '') ? pnData(v.lun) : oggi);
  const qOggi = Math.floor(oggi.getMonth() / 3) + 1;
  const nomiQ = ['da gennaio a marzo', 'da aprile a giugno', 'da luglio a settembre', 'da ottobre a dicembre'];
  const trim = [], mesi = [], sett = [], giorni = [];
  for (let q = 1; q <= 4; q++){
    const da = anno + '-' + pnPad(q * 3 - 2) + '-01', a = pnIso(new Date(anno, q * 3, 0, 12));
    trim.push(ntOzRiga('trim', 'Q' + anno + '-' + q, 'Q' + q + ' ' + anno, nomiQ[q - 1], conti, da, a, anno === oggi.getFullYear() && q === qOggi));
  }
  for (let m = 0; m < 12; m++){
    const da = anno + '-' + pnPad(m + 1) + '-01', a = pnIso(new Date(anno, m + 1, 0, 12));
    mesi.push(ntOzRiga('mesi', 'M' + anno + '-' + pnPad(m + 1), pnCap(NTOZ_MESI[m]) + ' ' + anno, '', conti, da, a, anno === oggi.getFullYear() && m === oggi.getMonth()));
  }
  const sOggi = ntOzChiaveSett(oggi);
  const daM = pnIso(mese), aM = pnIso(new Date(mese.getFullYear(), mese.getMonth() + 1, 0, 12));
  ntOzSettimaneIn(daM, aM).forEach(function(l){
    const dom = new Date(l); dom.setDate(dom.getDate() + 6);
    const s = pnSettimana(l);
    sett.push(ntOzRiga('sett', ntOzChiaveSett(l), 'Settimana ' + s.w, 'dal ' + l.getDate() + ' ' + NTOZ_MESI[l.getMonth()] + ' al ' + dom.getDate() + ' ' + NTOZ_MESI[dom.getMonth()], conti, pnIso(l), pnIso(dom), ntOzChiaveSett(l) === sOggi));
  });
  const GG = ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica'];
  for (let i = 0; i < 7; i++){
    const d = new Date(lun); d.setDate(lun.getDate() + i);
    const iso = pnIso(d), righe = ntOzGiornoRighe(iso);
    const f = righe.filter(function(r){ return r.f; }).length;
    giorni.push({ key: iso, tipo: 'giorni', titolo: pnCap(GG[i]) + ' ' + d.getDate() + ' ' + NTOZ_MESI[d.getMonth()], sotto: '', righe: righe, t: righe.length, f: f, pct: ntOzPct(f, righe.length), ora: iso === isoOggi });
  }
  /* il sogno: tutte le task di tutti i giorni + tutte le milestone di tutti i periodi + i passi della Roadmap in corso */
  let st = 0, sf = 0;
  Object.keys(conti).forEach(function(d){ st += conti[d].t; sf += conti[d].f; });
  const per = pnPeriodi();
  Object.keys(per).forEach(function(k){ (Array.isArray(per[k].ms) ? per[k].ms : []).forEach(function(x){ if (x && x.t){ st++; if (x.f) sf++; } }); });
  [['mesi', 'M' + oggi.getFullYear() + '-' + pnPad(oggi.getMonth() + 1)], ['sett', sOggi]].forEach(function(x){
    ntOzMs(x[0], x[1]).ms.forEach(function(m){ if (m.dove !== 'p'){ st++; if (m.f) sf++; } });
  });
  let testo = ''; try{ testo = (typeof nvSogno === 'function') ? (nvSogno() || '') : ''; }catch(_){ }
  let mappa = null; try{ mappa = (typeof flPercorso === 'function') ? Math.round(flPercorso() * 100) : null; }catch(_){ }
  /* la catena di adesso: il trimestre, il mese, la settimana e il giorno in corso, quelli di oggi anche se si sfoglia altro */
  const tq = ntOzRiga('trim', 'Q' + oggi.getFullYear() + '-' + qOggi, 'Q' + qOggi + ' ' + oggi.getFullYear(), nomiQ[qOggi - 1], conti, oggi.getFullYear() + '-' + pnPad(qOggi * 3 - 2) + '-01', pnIso(new Date(oggi.getFullYear(), qOggi * 3, 0, 12)), true);
  const tm = ntOzRiga('mesi', 'M' + oggi.getFullYear() + '-' + pnPad(oggi.getMonth() + 1), pnCap(NTOZ_MESI[oggi.getMonth()]), '', conti, oggi.getFullYear() + '-' + pnPad(oggi.getMonth() + 1) + '-01', pnIso(new Date(oggi.getFullYear(), oggi.getMonth() + 1, 0, 12)), true);
  const l0 = pnLunedi(oggi), d0 = new Date(l0); d0.setDate(d0.getDate() + 6);
  const tw = ntOzRiga('sett', sOggi, 'Settimana ' + pnSettimana(oggi).w, '', conti, pnIso(l0), pnIso(d0), true);
  const rg = ntOzGiornoRighe(isoOggi), fg = rg.filter(function(r){ return r.f; }).length;
  return {
    v: 1, at: Date.now(), anno: anno, mese: pnIso(mese).slice(0, 7), meseTit: pnCap(NTOZ_MESI[mese.getMonth()]) + ' ' + mese.getFullYear(),
    lun: pnIso(lun), settTit: 'Dal ' + lun.getDate() + ' ' + NTOZ_MESI[lun.getMonth()] + ' al ' + (function(){ const d = new Date(lun); d.setDate(d.getDate() + 6); return d.getDate() + ' ' + NTOZ_MESI[d.getMonth()]; })(),
    sogno: { testo: testo, t: st, f: sf, pct: ntOzPct(sf, st), mappa: mappa },
    catena: [
      { tipo: 'trim', key: tq.key, titolo: tq.titolo, t: tq.t, f: tq.f, pct: tq.pct },
      { tipo: 'mesi', key: tm.key, titolo: tm.titolo, t: tm.t, f: tm.f, pct: tm.pct },
      { tipo: 'sett', key: tw.key, titolo: tw.titolo, t: tw.t, f: tw.f, pct: tw.pct },
      { tipo: 'giorni', key: isoOggi, titolo: 'Oggi', t: rg.length, f: fg, pct: ntOzPct(fg, rg.length) }
    ],
    trim: trim, mesi: mesi, sett: sett, giorni: giorni
  };
}
Object.assign(window.flPiano, {
  /* 0.9.321: il pannello del piano e' lo specchio di quello della Mappa: stesse schede, stesso prossimo passo */
  schede: function(){
    try{
      const mia = typeof sdStradaMia === 'function' && sdStradaMia();
      const l = mia ? (typeof mfSchede === 'function' ? mfSchede() : null) : (typeof rmpSchede === 'function' ? rmpSchede() : null);
      return (l || []).map(function(t){ return [t[0] === 'cal' ? 'calendario' : t[0], t[1]]; });
    }catch(_){ return null; }
  },
  prossimaTappa: function(){
    try{
      if (typeof sdStradaMia === 'function' && sdStradaMia()) return null;
      const n = sdCorrente().nodo; return n ? { nome: sdNomeTappa(n) } : null;
    }catch(_){ return null; }
  },
  tappaVia: function(){ try{ if (typeof rmpTappaVia === 'function') rmpTappaVia(); }catch(_){ } },
  /* 0.9.322: un'icona sulla Home che apre proprio questa pagina */
  iconaPagina: function(id, titolo, emoji){ try{ if (typeof drsIconaHome === 'function') drsIconaHome('piano-' + id, titolo, 'piano:' + id, emoji); }catch(_){ } },
  /* il pannello "Dal sogno a oggi" dentro alla replica: lo stesso disegno della pagina degli orizzonti (orizzonti.js) */
  ozAggancia: function(el, scheda){ OZ.fuori = { el: el, scheda: scheda }; ozPaint(); },
  ozStacca: function(el){ if (OZ.fuori && OZ.fuori.el === el){ OZ.fuori = null; try{ ozPaint(); }catch(_){ } } },
  ozFunzioni: function(){ return { ozVai: ozVai, ozScriviTesto: ozScriviTesto, ozAnnulla: ozAnnulla, ozSalvaTesto: ozSalvaTesto, ozRimetti: ozRimetti, ozBozza: ozBozza, ozAgente: ozAgente, ozVaiRoadmap: ozVaiRoadmap, ozOltre: ozOltre, ozAperto: ozAperto }; },
  /* per il sito del computer: le due schede gia' disegnate, in sola lettura */
  ozPannelloStatico: function(){ const sc = {}; ['orizzonti', 'itinerario'].forEach(function(k){ try{ sc[k] = ozPannelloHtml(k, false); }catch(_){ sc[k] = ''; } }); return sc; },
  orizzonti: function(v){ try{ return ntOrizzonti(v); }catch(e){ try{ console.warn('[orizzonti]', e); }catch(_){ } return null; } },
  /** L'obiettivo di un periodo (Q2026-4, M2026-10, W2026-44), nello stesso posto del piano di prima. */
  periodoObiettivo: function(key, testo){
    if (!/^[QMW]\d{4}-\d{1,2}$/.test(String(key || ''))) return false;
    const p = pnPeriodi(); p[key] = Object.assign({ ob: '', ms: [] }, p[key] || {});
    p[key].ob = String(testo || '').replace(/\s+/g, ' ').trim();
    pnPeriodiSalva(p); return true;
  },
  periodoMilestone: function(key, testo){
    const t = String(testo || '').replace(/\s+/g, ' ').trim();
    if (!t || !/^[QMW]\d{4}-\d{1,2}$/.test(String(key || ''))) return false;
    const p = pnPeriodi(); p[key] = Object.assign({ ob: '', ms: [] }, p[key] || {});
    p[key].ms = (p[key].ms || []).concat([{ t: t, f: false }]); pnPeriodiSalva(p);
    try{ flVibra(8); }catch(_){ }
    return true;
  },
  periodoMilestoneVia: function(key, i){
    const p = pnPeriodi(); if (!p[key] || !Array.isArray(p[key].ms) || !p[key].ms[i]) return false;
    p[key].ms.splice(i, 1); pnPeriodiSalva(p); return true;
  },
  /** La spunta di una milestone: le sue (dove 'p') o un passo della Roadmap (dove 'mese' | 'settimana'). */
  periodoSpunta: function(key, dove, i){
    let ora = false;
    if (dove === 'p'){
      const p = pnPeriodi(); if (!p[key] || !p[key].ms || !p[key].ms[i]) return false;
      p[key].ms[i].f = !p[key].ms[i].f; ora = p[key].ms[i].f; pnPeriodiSalva(p);
    } else if (typeof ozAnello === 'function'){
      const a = ozAnello(dove); const x = a && a.passi && a.passi[i]; if (!x) return false;
      x.fatto = !x.fatto; x.il = x.fatto ? ozGiorno() : ''; ora = x.fatto;
      ozSalvaAnello(dove, a);
    } else return false;
    try{ flVibra(ora ? [10, 30, 10] : 8); }catch(_){ }
    return true;
  }
});

registerScreen('s-notion', '<iframe id="ntFrame" class="nt-frame" title="Il piano" src="about:blank"></iframe>', { back: 's-home' });
/* indietro: prima chiude quello che e' aperto dentro (un menu, la barra laterale), poi esce */
BACK_TO['s-notion'] = function(){ ntChiudi(true); return 's-home'; };

(function(){
  const st = document.createElement('style');
  st.textContent = '#s-notion{padding:0 !important;overflow:hidden !important}'
    + '.nt-frame{position:fixed;inset:0;width:100%;height:100%;border:0;background:#fff;z-index:5}';
  document.head.appendChild(st);
})();

function ntFrameWin(){ const f = document.getElementById('ntFrame'); return f && f.contentWindow; }
function ntApri(off){
  const f = document.getElementById('ntFrame');
  if (!f) return;
  /* indietro riporta dove eri (la Mappa, START...), non sempre a START */
  if (!NT.aperto){ try{ STF.ritorno = localStorage.getItem('fl_tab') || 'sveglia'; }catch(_){ } }
  NT.giorno = off | 0;
  if (!NT.pronto || !/notion\/index\.html/.test(f.getAttribute('src') || '')){
    f.setAttribute('src', 'notion/index.html?v=' + Date.now() + (NT.giorno ? '#giorno=' + NT.giorno : ''));
    NT.pronto = true;
  } else ntAvvisa(NT.giorno);
  NT.aperto = true;
  goId('s-notion');
}
/** «Nuova pagina» nella Mappa (0.9.231): il piano a schermo intero con una pagina nuova, che
    compare subito anche nel menu laterale. */
function ntNuovaPagina(){
  const f = document.getElementById('ntFrame');
  if (!f) return;
  const w = ntFrameWin();
  if (NT.pronto && /notion\/index\.html/.test(f.getAttribute('src') || '') && w && typeof w.flNotionNuova === 'function'){
    ntApri(0); try{ w.flNotionNuova(); }catch(_){ }
    return;
  }
  if (!NT.aperto){ try{ STF.ritorno = localStorage.getItem('fl_tab') || 'sveglia'; }catch(_){ } }
  NT.giorno = 0;
  f.setAttribute('src', 'notion/index.html?v=' + Date.now() + '#nuova=1');
  NT.pronto = true; NT.aperto = true;
  goId('s-notion');
}
/** Dice alla pagina di rileggere il giorno (dopo una spunta confermata, o tornando qui). */
function ntAvvisa(off){
  try{ const w = ntFrameWin(); if (w && w.flNotionAggiorna) w.flNotionAggiorna(typeof off === 'number' ? off : undefined); }catch(_){ }
}
/** Il tasto indietro di Android: se dentro c'e' un menu aperto chiude quello. */
function ntBack(){
  if (order[cur] !== 's-notion') return false;
  try{ const w = ntFrameWin(); if (w && w.flNotionIndietro && w.flNotionIndietro()) return true; }catch(_){ }
  ntChiudi();
  return true;
}
function ntChiudi(soloStato){
  NT.aperto = false;
  if (soloStato){ NT.schermo = ''; return; }
  /* 0.9.296: aperto da "Il tuo perche'" (i modelli), indietro torna li' */
  if (NT.schermo){ const sc = NT.schermo; NT.schermo = ''; goId(sc); return; }
  goId('s-home');
  switchTab(STF.ritorno || 'sveglia'); STF.ritorno = '';
  setTimeout(function(){ try{ stPaint(); stSyncToFF(); }catch(_){ } }, 160);
}

/* Il piano a tutto schermo apre il Notion. Il vecchio resta raggiungibile dai tre puntini. */
const stFullOpenClassico = stFullOpen;
stFullOpen = function(){ ntApri(0); };
/* «Domani» dalla scheda del lucchetto: il Notion sul giorno dopo */
if (typeof pnApriDomani === 'function') pnApriDomani = function(){ ntApri(1); };
/* tornando dal foglio di una riga, la pagina rilegge (la riga puo' essere cambiata) */
document.addEventListener('fl:spunta', function(){ ntAvvisa(); });
