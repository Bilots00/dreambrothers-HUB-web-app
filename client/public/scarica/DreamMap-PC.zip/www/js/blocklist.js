/* blocklist.js - the s-blocklist screen and its three tabs: installed apps (read from the
   engine and cached), websites and keywords. Edits the DRAFT owned by blocco.js.

   Area U-B owns this file and csv.js. Everything this module adds to the frozen markup of
   index.html is injected from here at load time: six agents share that file, so a screen that
   has to grow must grow from its own module. Every selector added here is prefixed `ub-`.

   What lives here beyond the original three tabs:
   - Bug F / G17: the keyword match type (domain / anywhere in the URL / page content). The
     engine stores keywords as {t, m} objects, so the DRAFT stores them the same way.
   - G18: a real catalogue of suggested sites with checkboxes on the Web tab.
   - G04: per-row counters and chips of the selected items under each row of the editor.
   - G16: the import/export icons; the CSV work itself is in csv.js. */

let APPS_CACHE = [];       // installed apps, fetched once per visit

/* ---- blocklist (App / Web / Parole chiave) ---- */
let BL_TAB='app';

/* The three match modes the engine understands (Rules.Keyword.Mode). `m` is what goes into
   {t, m}; anything the engine does not recognise it reads back as URL, which is why URL is our
   fallback for values written before this screen existed. CONTENT is ours: AppBlock has only
   the first two. */
const UB_MODES = {
  domain: {label:'Nel dominio',
           hint:'Blocca solo i siti il cui dominio è, o finisce con, quello che scrivi. “youtube.com” blocca anche “m.youtube.com”, non “notyoutube.com”.'},
  url:    {label:'Ovunque nell\'URL',
           hint:'Blocca qualsiasi indirizzo che contenga la parola, in qualunque punto: dominio, cartella o ricerca.'},
  content:{label:'Nel contenuto della pagina',
           hint:'Blocca la pagina se la parola compare nel testo, anche quando l\'indirizzo è pulito.'}
};

let UB_NEW_MODE = 'domain';   // mode for the keyword being typed — AppBlock opens on "Nel dominio"
let UB_MODE_TOUCHED = false;  // once the user picks a mode by hand we stop guessing for them
let UB_MODE_TARGET = null;    // null = the entry being typed; a number = that row of the list below
/* Which keyword list the picker is acting on. null = the program editor's draft; the Quick
   Block passes its own, so one picker serves both screens instead of the two drifting apart. */
let UB_MODE_SRC = null;
let UB_SUGG_OPEN = true;      // the Web suggestions start open, like AppBlock's pre-filled list
let UB_CTA_BACK = null;       // the frozen markup's own Salva handler, restored when the field empties

/* ---------------------------------------------------------------------------------------
   Normalisation
   --------------------------------------------------------------------------------------- */

/* Any stored keyword to the {t, m} shape the engine expects. Plain strings are what earlier
   builds (and blocco.js's templates) wrote: they become URL, because URL is exactly how the
   engine already interprets a bare string. Promoting them to DOMAIN would silently stop them
   from matching, and a rule that quietly stops blocking is the worst failure this app has. */
function ubKw(v){
  if(v && typeof v === 'object'){
    const t = String(v.t != null ? v.t : (v.term != null ? v.term : '')).trim().toLowerCase();
    const raw = v.m != null ? v.m : v.mode;
    return {t:t, m: UB_MODES[raw] ? raw : 'url'};
  }
  return {t:String(v==null?'':v).trim().toLowerCase(), m:'url'};
}
function ubNormalizeKeywordList(list){
  const seen = {}, out = [];
  (list||[]).map(ubKw).forEach(function(k){
    if(!k.t) return;
    const key = k.m+' '+k.t;
    if(seen[key]) return;
    seen[key] = 1; out.push(k);
  });
  return out;
}
function ubNormalizeDraftKeywords(){
  if(!DRAFT) return;
  DRAFT.keywords = ubNormalizeKeywordList(DRAFT.keywords);
}

/* ---- the list the picker is editing, and what to repaint after it changes ---- */
function ubModeList(){
  if(UB_MODE_SRC && typeof UB_MODE_SRC.list === 'function') return UB_MODE_SRC.list() || [];
  return (DRAFT && DRAFT.keywords) || [];
}
function ubModeNormalize(){
  if(UB_MODE_SRC && typeof UB_MODE_SRC.normalize === 'function'){ UB_MODE_SRC.normalize(); return; }
  ubNormalizeDraftKeywords();
}
function ubModeAfterChange(){
  if(UB_MODE_SRC && typeof UB_MODE_SRC.after === 'function'){ UB_MODE_SRC.after(); return; }
  renderSimpleList('kw');
  refreshEditorCounts();
}
/* Entry point for a screen that owns its own keyword list (the Quick Block). */
function ubOpenModeForList(i, src){
  UB_MODE_SRC = src || null;
  ubOpenModeFor(i);
}

/* A site is matched by host, so a pasted address has to lose everything that is not the host:
   scheme, credentials, port, path, query and a leading "www.". Left as typed it would be a
   domain rule that can never equal any host. */
function ubSiteNorm(raw){
  let s = String(raw==null?'':raw).trim().toLowerCase();
  if(!s) return '';
  s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//,'');   // scheme
  s = s.replace(/^[^/@]*@/,'');                  // credentials
  s = s.split('/')[0].split('?')[0].split('#')[0];
  s = s.replace(/:\d+$/,'');                     // port
  s = s.replace(/^www\./,'').replace(/^\.+|\.+$/g,'');
  return /\s/.test(s) ? '' : s;
}

/* Does this look like a domain the user typed? Used only to preselect the match type. */
function ubLooksLikeDomain(v){ return /^[a-z0-9][a-z0-9.-]*\.[a-z]{2,}$/.test(String(v||'').trim().toLowerCase()); }

/* ---------------------------------------------------------------------------------------
   Navigation into the screen
   --------------------------------------------------------------------------------------- */

function openBlocklist(which){ BL_TAB=which; goId('s-blocklist'); blTab(which); }
function blTab(which){
  BL_TAB=which;
  document.querySelectorAll('.bltab').forEach(b=>b.classList.toggle('on', b.dataset.bl===which));
  ['app','web','kw'].forEach(k=>{ document.getElementById('bl-'+k).hidden = (k!==which); });
  ubCloseModePanel();
  ubPaintModeBar();
  ubPaintCta();
  if(which==='app') loadApps();
  else if(which==='web'){ ubRenderSuggestions(); renderSimpleList('web'); }
  else renderSimpleList('kw');
}

/* ---------------------------------------------------------------------------------------
   Tab App
   --------------------------------------------------------------------------------------- */

async function loadApps(){
  const box = document.getElementById('appList');
  if(!NATIVE){ box.innerHTML='<div class="hintline" style="padding:14px">Elenco disponibile solo nell\'app installata.</div>'; return; }
  if(!APPS_CACHE.length){
    if(!(typeof FLA !== 'undefined' && FLA.list && FLA.list.length)) box.innerHTML='<div class="hintline" style="padding:14px">Leggo le app installate…</div>';
    try{ const r = await flApps(); APPS_CACHE = r.apps||[]; }
    catch(e){
      // A rejected plugin call has to say what happened: an empty list looks like "no apps".
      APPS_CACHE=[];
      box.innerHTML='<div class="hintline" style="padding:14px">Impossibile leggere le app installate: '
        + esc(e && e.message ? e.message : 'errore sconosciuto') + '</div>';
      return;
    }
  }
  renderAppList();
  ubFunzRileggi(renderAppList);
}
/* Icons arrive one at a time, only for rows on screen.

   They used to travel inside getInstalledApps: 150+ PNGs encoded to base64 in a single reply.
   An IntersectionObserver asks for each one as its row scrolls into view, and the answer is
   cached, so opening the picker is instant and a slow icon never holds up the list. */
const UB_ICON_CACHE = {};

function ubFillIcons(box){
  if(!NATIVE || !NATIVE.getAppIcon) return;
  const imgs = box.querySelectorAll('img.ub-appico[data-pkg]');
  if(!imgs.length) return;

  const load = function(img){
    const pkg = img.dataset.pkg;
    if(!pkg || img.dataset.done) return;
    img.dataset.done = '1';
    /* 0.9.307: la cache delle icone del Report (insights.js, anche in IndexedDB) vale per ogni elenco */
    if(typeof insIcona === 'function'){
      const subito = insIconaSubito(pkg);
      if(subito){ img.src = subito; return; }
      insIcona(pkg).then(function(uri){ if(uri) img.src = uri; }).catch(function(){ });
      return;
    }
    if(UB_ICON_CACHE[pkg]){ if(UB_ICON_CACHE[pkg] !== 'none') img.src = UB_ICON_CACHE[pkg]; return; }
    NATIVE.getAppIcon({ packageName: pkg }).then(function(r){
      const uri = r && r.icon ? r.icon : '';
      UB_ICON_CACHE[pkg] = uri || 'none';
      if(uri) img.src = uri;
    }).catch(function(){ UB_ICON_CACHE[pkg] = 'none'; });
  };

  if(typeof IntersectionObserver === 'undefined'){
    imgs.forEach(load);
    return;
  }
  const io = new IntersectionObserver(function(entries){
    entries.forEach(function(en){
      if(!en.isIntersecting) return;
      load(en.target);
      io.unobserve(en.target);
    });
  }, { root: box, rootMargin: '250px' });
  imgs.forEach(function(img){ io.observe(img); });
}

/* 0.9.313, Andrea: aprendo la lista di un programma, le app gia' bloccate stanno in cima. Stesso ordine di prima fra loro. */
function ubPrimaLeScelte(list, scelte){
  const s = scelte || [];
  return list.filter(function(a){ return s.indexOf(a.packageName) >= 0; }).concat(list.filter(function(a){ return s.indexOf(a.packageName) < 0; }));
}
function renderAppList(){
  const q = (document.getElementById('appSearch').value||'').toLowerCase();
  const conFunz = !!(DRAFT && !DRAFT.grey && !DRAFT.sound && !window.BLK_GREY && !window.BLK_SOUND);
  const list = APPS_CACHE.filter(a=>ubAppCercata(a, q, conFunz));
  const box = document.getElementById('appList');
  if(!list.length){ box.innerHTML='<div class="hintline" style="padding:14px">Nessuna app trovata.</div>'; return; }
  box.innerHTML = ubPrimaLeScelte(list, DRAFT ? DRAFT.apps : []).map(a=>ubRigaAppHtml(a, !!(DRAFT && DRAFT.apps.includes(a.packageName)), conFunz)).join('');
  ubFillIcons(box);
  box.querySelectorAll('input:not([data-funz])').forEach(i=>{
    i.addEventListener('change',()=>{
      if(!DRAFT) return;
      if(i.checked){ if(!DRAFT.apps.includes(i.value)) DRAFT.apps.push(i.value); }
      else DRAFT.apps = DRAFT.apps.filter(p=>p!==i.value);
      ubFunzSegui(box, i.value, i.checked);
      refreshEditorCounts();
    });
  });
  ubFunzCollega(box, function(){ refreshEditorCounts(); });
}

/* The icon carries the row. People recognise the apps that take their time by the icon,
   not by "com.instagram.android": a list of names and checkboxes gives the eye nothing to
   land on. When the icon is missing we draw the initial rather than leave a hole: the initial
   sits underneath as a placeholder and the icon paints over it when it arrives.
   Una sola riga per le due liste (programmi e Blocco rapido). */
function ubIconaAppHtml(a){
  const letter = esc(((a.label||'?').trim().charAt(0) || '?').toUpperCase());
  return `<span class="ub-appico ub-appico-fb">${letter}`
       + `<img class="ub-appico ub-appico-img" data-pkg="${esc(a.packageName)}" alt=""></span>`;
}
function ubRigaAppHtml(a, spuntata, conFunz){
  const funz = conFunz ? ubFunzDi(a.packageName) : [];
  const ico = ubIconaAppHtml(a);
  return `
    <label class="pickrow ub-approw${funz.length ? ' ub-con-figli' : ''}">
      ${ico}
      <span class="ub-appname"><span class="pl">${esc(a.label)}</span></span>
      <input type="checkbox" value="${esc(a.packageName)}" ${spuntata?'checked':''}>
    </label>` + funz.map(function(f, n){
      const su = spuntata || inappSetting(f.key).on;
      return `
    <label class="pickrow ub-approw ub-frow${spuntata ? ' ub-frow-spenta' : ''}${n === funz.length - 1 ? ' ub-frow-ult' : ''}">
      <span class="ub-freccia">${UB_FRECCIA}</span>
      ${ico}
      <span class="ub-appname ub-fname"><span class="pl">${esc(ubFunzNome(f.label))}</span><span class="ub-beta">BETA</span></span>
      <input type="checkbox" data-funz="${esc(f.key)}" data-di="${esc(a.packageName)}" aria-label="${esc(ubFunzNome(f.label) + ' di ' + a.label)}" ${su?'checked':''} ${spuntata?'disabled':''}>
    </label>`;
    }).join('');
}

/* ---------------------------------------------------------------------------------------
   Le funzioni delle app sotto all'app (0.9.311, come la lista di blocco del modello)

   UNA SOLA VERITA': lo stato e' quello della pagina Blocco Funzionalita' (settings.js). Stesso
   oggetto INAPP, stesso motore (getFeatureBlocks / setFeatureBlocks), nessuna copia nel
   programma: ogni volta che si apre la scheda App si rilegge il motore, ogni spunta si scrive
   subito (non aspetta "Salva"). Vale quindi a livello di telefono, non del singolo programma.

   App spuntata: blocca gia' tutto, le righe figlie si vedono spuntate e grigie, ma lo stato
   della funzione non si tocca: togliendo la spunta all'app si ritrova quello che c'era.
   --------------------------------------------------------------------------------------- */
const UB_FRECCIA = '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 4v9a3 3 0 0 0 3 3h10"/><path d="M15 12l4 4-4 4"/></svg>';
let UB_F_LETTE = false;     // il motore e' gia' stato letto almeno una volta
let UB_F_SALVO = null;      // il salvataggio in volo
let UB_F_ANCORA = false;    // una spunta arrivata mentre il salvataggio era in volo

function ubFunzPronte(){ return typeof INAPP !== 'undefined' && !!NATIVE && !!NATIVE.getFeatureBlocks; }
/* TikTok ha due pacchetti per la stessa funzione: si guarda f.pkgs, non solo il primo. */
function ubFunzDi(pkg){
  if(!ubFunzPronte()) return [];
  return (INAPP.catalog || []).filter(function(f){ return f.pkg === pkg || (f.pkgs || []).indexOf(pkg) >= 0; });
}
/* Il catalogo del motore parla da interruttore ("Blocca il feed"): qui serve il nome della cosa ("Feed"). */
function ubFunzNome(label){
  const s = String(label || '').replace(/^Blocca\s+/i, '').replace(/^(il|lo|la|i|gli|le)\s+/i, '');
  return s.charAt(0).toUpperCase() + s.slice(1);
}
/* Le funzioni spuntate, dette per esteso, per le etichette del programma e del Blocco rapido. */
function ubFunzScelte(){
  if(!ubFunzPronte()) return [];
  return (INAPP.catalog || []).filter(function(f){ return (INAPP.settings[f.key] || {}).on; }).map(function(f){
    const n = ubFunzNome(f.label);
    return n.toLowerCase().indexOf(String(f.app).toLowerCase()) >= 0 ? n : n + ' di ' + f.app;
  });
}
/* La ricerca trova l'app anche dal nome di una sua funzione: "reels" porta a Instagram. */
function ubAppCercata(a, q, conFunz){
  if(!q) return true;
  if(String(a.label || '').toLowerCase().indexOf(q) >= 0) return true;
  return !!conFunz && ubFunzDi(a.packageName).some(function(f){ return ubFunzNome(f.label).toLowerCase().indexOf(q) >= 0; });
}
/* Rilegge il motore; `poi` ridisegna solo se e' cambiato qualcosa, cosi' la lista non salta. */
function ubFunzRileggi(poi){
  if(!ubFunzPronte() || UB_F_SALVO) return Promise.resolve();
  const firma = function(){ return JSON.stringify([(INAPP.catalog || []).map(function(f){ return f.key; }), INAPP.settings]); };
  const prima = firma();
  UB_F_LETTE = true;
  return NATIVE.getFeatureBlocks().then(function(r){
    if(!r || UB_F_SALVO) return;
    INAPP.catalog = r.catalog || []; INAPP.settings = r.settings || {}; INAPP.recent = r.recent || [];
    if(firma() !== prima && typeof poi === 'function') poi();
  }).catch(function(){ UB_F_LETTE = false; });
}
/* Le spunte possono arrivare piu' veloci del motore: si manda sempre l'ultimo stato, e la risposta di
   un invio vecchio non riscrive mai una spunta piu' nuova. */
function ubFunzSalva(box){
  if(UB_F_SALVO){ UB_F_ANCORA = true; return UB_F_SALVO; }
  UB_F_SALVO = (async function(){
    let fallito = false;
    do {
      UB_F_ANCORA = false;
      try{
        const r = await NATIVE.setFeatureBlocks({ settings: JSON.parse(JSON.stringify(INAPP.settings)) });
        if(r && !UB_F_ANCORA){ INAPP.catalog = r.catalog || INAPP.catalog; INAPP.settings = r.settings || INAPP.settings; INAPP.recent = r.recent || INAPP.recent; }
      }catch(e){ fallito = true; toast(e && e.message ? e.message : 'Non salvato'); }
    } while(UB_F_ANCORA);
    UB_F_SALVO = null;
    /* non salvato: la casella torna a dire quello che il motore fa davvero */
    if(fallito){
      try{ const r = await NATIVE.getFeatureBlocks(); INAPP.settings = (r && r.settings) || INAPP.settings; }catch(_){ }
      ubFunzRidisegna(box);
    }
  })();
  return UB_F_SALVO;
}
function ubFunzCasella(i, appSu){
  i.disabled = !!appSu;
  i.checked = !!appSu || !!inappSetting(i.dataset.funz).on;
  /* niente closest(): la WebView minima non lo garantisce */
  let r = i.parentNode;
  while(r && !(r.classList && r.classList.contains('ub-frow'))) r = r.parentNode;
  if(r) r.classList.toggle('ub-frow-spenta', !!appSu);
}
/* L'app appena spuntata o tolta: le sue righe figlie la seguono subito. */
function ubFunzSegui(box, pkg, appSu){
  box.querySelectorAll('input[data-funz]').forEach(function(i){ if(i.dataset.di === pkg) ubFunzCasella(i, appSu); });
}
function ubFunzRidisegna(box){
  if(!box) return;
  box.querySelectorAll('input[data-funz]').forEach(function(i){
    let su = false;
    box.querySelectorAll('input:not([data-funz])').forEach(function(a){ if(a.value === i.dataset.di && a.checked) su = true; });
    ubFunzCasella(i, su);
  });
}
function ubFunzCollega(box, dopo){
  box.querySelectorAll('input[data-funz]').forEach(function(i){
    i.addEventListener('change', function(){
      const key = i.dataset.funz, s = inappSetting(key);
      /* Modalita' severa: stringere si', allentare no, come per i programmi */
      if(!i.checked && s.on && typeof blkEditLocked === 'function' && blkEditLocked()){
        i.checked = true;
        toast('Modalità severa attiva: i blocchi delle funzioni non si possono togliere');
        return;
      }
      s.on = i.checked; INAPP.settings[key] = s;
      try{ flVibra(8); }catch(_){ }
      /* la stessa funzione puo' stare sotto a due app (i due pacchetti di TikTok) */
      ubFunzRidisegna(box);
      ubFunzSalva(box);
      if(typeof dopo === 'function') dopo();
    });
  });
}

/* ---------------------------------------------------------------------------------------
   Tab Web e tab Parole chiave
   --------------------------------------------------------------------------------------- */

function listFor(which){ return which==='web' ? DRAFT.sites : DRAFT.keywords; }

function renderSimpleList(which){
  const box = document.getElementById(which==='web'?'webList':'kwList');
  if(!box) return;
  if(!DRAFT){
    box.innerHTML='<div class="hintline" style="padding:14px">Apri prima un programma: la lista di blocco appartiene al programma che stai creando.</div>';
    return;
  }
  if(which==='kw') ubNormalizeDraftKeywords();
  const arr = listFor(which);
  if(!arr.length){ box.innerHTML='<div class="hintline" style="padding:14px">Ancora niente in elenco.</div>'; return; }

  if(which==='web'){
    box.innerHTML = arr.map((v,i)=>`
      <div class="pickrow">${flFavHtml(v, 'big')}<span class="pl">${esc(v)}</span>
        <button class="del" onclick="removeItem('web',${i})">✕</button></div>`).join('');
    return;
  }
  // Every keyword shows its own match type and can change it: a rule whose behaviour is
  // invisible is a rule the user cannot trust.
  box.innerHTML = arr.map((k,i)=>`
    <div class="pickrow ub-kwrow"><span class="pl">${esc(k.t)}</span>
      <button class="ub-modetag ub-m-${k.m}" onclick="ubOpenModeFor(${i})">${esc(UB_MODES[k.m].label)}<i class="ub-caret"></i></button>
      <button class="del" onclick="removeItem('kw',${i})">✕</button></div>`).join('');
}

function addItem(which){
  if(!DRAFT){ toast('Apri prima un programma'); return; }
  const input = document.getElementById(which==='web'?'webIn':'kwIn');
  const raw = (input.value||'').trim().toLowerCase();
  if(!raw) return;

  if(which==='web'){
    const v = ubSiteNorm(raw);
    if(!v){ toast('Indirizzo non valido'); return; }
    if(DRAFT.sites.includes(v)) toast('“'+v+'” è già in elenco');
    else DRAFT.sites.push(v);
    input.value='';
    ubRenderSuggestions();
  }else{
    ubNormalizeDraftKeywords();
    const k = {t:raw, m:UB_NEW_MODE};
    if(DRAFT.keywords.some(x=>x.t===k.t && x.m===k.m)) toast('“'+k.t+'” è già in elenco come “'+UB_MODES[k.m].label+'”');
    else DRAFT.keywords.push(k);
    input.value='';
    UB_MODE_TOUCHED = false;   // the next keyword gets its own guess
  }
  renderSimpleList(which);
  refreshEditorCounts();
  ubPaintCta();
}
function removeItem(which,i){
  if(!DRAFT) return;
  listFor(which).splice(i,1);
  renderSimpleList(which);
  if(which==='web') ubRenderSuggestions();
  refreshEditorCounts();
}

/* Called by csv.js after an import, so the import path never has to know how a list is drawn. */
function ubAfterListChange(which){
  renderSimpleList(which);
  if(which==='web') ubRenderSuggestions();
  refreshEditorCounts();
}

/* ---------------------------------------------------------------------------------------
   Bug F / G17 — the match type picker
   --------------------------------------------------------------------------------------- */

/* Opens the picker for the entry being typed (no index) or for an existing row.

   It used to be a panel that unfolded inside the bar at the TOP of the screen: with a long
   keyword list, changing the type of row forty meant scrolling up to answer and back down to
   see the result, for every single row. It is a sheet now — it opens over whatever the user
   is looking at, and closes back onto the same place. */
function ubOpenModeFor(i){
  UB_MODE_TARGET = (typeof i === 'number') ? i : null;
  if(UB_MODE_TARGET !== null){
    ubModeNormalize();
    if(!ubModeList()[UB_MODE_TARGET]){ UB_MODE_TARGET = null; return; }
  }
  ubPaintModePanel();
  const sh = document.getElementById('ubModeSheet');
  if(sh) sh.classList.add('open');
  const b = document.getElementById('ub-modebar');
  if(b) b.classList.add('open');
}
function ubToggleModePanel(){
  const sh = document.getElementById('ubModeSheet');
  if(sh && sh.classList.contains('open')) ubCloseModePanel();
  else ubOpenModeFor(null);
}
function ubCloseModePanel(){
  const sh = document.getElementById('ubModeSheet');
  if(sh) sh.classList.remove('open');
  const b = document.getElementById('ub-modebar');
  if(b) b.classList.remove('open');
  UB_MODE_TARGET = null;
  UB_MODE_SRC = null;
}
function ubCurrentMode(){
  const row = UB_MODE_TARGET !== null ? ubModeList()[UB_MODE_TARGET] : null;
  return row ? ubKw(row).m : UB_NEW_MODE;
}
function ubPaintModePanel(){
  const cur = ubCurrentMode();
  const row = UB_MODE_TARGET !== null ? ubModeList()[UB_MODE_TARGET] : null;
  const word = row ? ubKw(row).t : '';
  const title = UB_MODE_TARGET === null ? 'Tipo di corrispondenza' : 'Tipo per “' + word + '”';
  const ttl = document.getElementById('ub-modetitle');
  if(ttl) ttl.textContent = 'Tipo di corrispondenza';
  const lbl = document.getElementById('ub-modelbl');
  if(lbl) lbl.textContent = UB_MODES[cur].label;
  const host = document.getElementById('ubModeSheetBody');
  if(host){
    host.innerHTML = '<div class="blk-sheet-title">' + esc(title) + '</div>'
      + ['domain','url','content'].map(function(m){
          return '<label class="ub-radio' + (m === cur ? ' on' : '') + '" data-mode="' + m + '"'
            + ' onclick="ubPickMode(\'' + m + '\')"><i></i><div><b>' + esc(UB_MODES[m].label) + '</b>'
            /* La spiegazione la puo' dare la pagina che ha aperto il foglio: le stesse tre
               modalita', in un posto dove non si blocca niente, vanno raccontate per quello
               che fanno li'. */
            + '<small>' + esc(((UB_MODE_SRC && UB_MODE_SRC.hints) || {})[m] || UB_MODES[m].hint) + '</small>'
            + (m === 'content' ? '<span class="tag">Solo DreamMap</span>' : '')
            + '</div></label>';
        }).join('');
  }
}
function ubPickMode(m){
  if(!UB_MODES[m]) return;
  if(UB_MODE_TARGET === null){
    UB_NEW_MODE = m;
    UB_MODE_TOUCHED = true;
    const after = UB_MODE_SRC && UB_MODE_SRC.after;
    ubCloseModePanel();
    if(typeof after === 'function') after();
  }else{
    ubModeNormalize();
    const list = ubModeList();
    const k = list[UB_MODE_TARGET];
    const at = UB_MODE_TARGET;
    if(k){
      // Changing a row's mode can collide with an identical rule that already exists.
      if(list.some((x,i)=>i!==at && x.t===k.t && x.m===m)) toast('“'+k.t+'” è già in elenco come “'+UB_MODES[m].label+'”');
      else k.m = m;
    }
    const after = UB_MODE_SRC && UB_MODE_SRC.after;
    ubCloseModePanel();
    if(typeof after === 'function') after();
    else { renderSimpleList('kw'); refreshEditorCounts(); }
  }
  ubPaintModeBar();
}
function ubPaintModeBar(){
  const lbl = document.getElementById('ub-modelbl');
  if(lbl) lbl.textContent = UB_MODES[UB_NEW_MODE].label;
  const h = document.getElementById('ub-modehint');
  if(h) h.textContent = UB_MODES[UB_NEW_MODE].hint;
}

/* While a keyword is being typed AppBlock turns the bottom button into "Inserisci"; we do the
   same, and we also guess the match type from the shape of what is being typed. A bare word as
   a DOMAIN rule can never match any host, so guessing badly here means an inert rule. */
function ubOnKwInput(){
  const v = ((document.getElementById('kwIn')||{}).value||'').trim().toLowerCase();
  if(!UB_MODE_TOUCHED) UB_NEW_MODE = ubLooksLikeDomain(v) ? 'domain' : 'url';
  ubPaintModeBar();
  if(UB_MODE_TARGET === null) ubPaintModePanel();
  // The match type is a question about a word. With no word there is no question, so the
  // control stays away instead of sitting there asking to be understood.
  ubShowModeBar(!!v);
  ubPaintCta();
}
function ubOnWebInput(){ ubPaintCta(); }

/* Shows or hides the match-type control, and with it the line that explains the chosen mode:
   an explanation of a control nobody can see is just noise above the list. */
function ubShowModeBar(on){
  const bar = document.getElementById('ub-modebar');
  const hint = document.getElementById('ub-modehint');
  if(bar) bar.hidden = !on;
  if(hint) hint.hidden = !on;
  // Only the sheet opened for the word being typed follows the bar away. One opened for a
  // row of the list belongs to that row, and must not close because the field emptied.
  if(!on && UB_MODE_TARGET === null) ubCloseModePanel();
}

/* Enter confirms. The "+" button next to the field duplicated a gesture every keyboard
   already offers, and was one more thing competing for attention on the row. */
function ubBindEnter(inputId, which){
  const el = document.getElementById(inputId);
  if(!el || el._ubEnter) return;
  el._ubEnter = true;
  el.addEventListener('keydown', function(ev){
    if(ev.key !== 'Enter') return;
    ev.preventDefault();
    if((el.value||'').trim()) addItem(which);
  });
}

/* ---------------------------------------------------------------------------------------
   The bottom CTA: "Salva" normally, "Inserisci" while something is being typed
   --------------------------------------------------------------------------------------- */

function ubPaintCta(){
  const cta = document.querySelector('#s-blocklist .cta');
  if(!cta) return;
  if(UB_CTA_BACK === null) UB_CTA_BACK = cta.onclick;   // the handler written in the frozen markup
  const id = BL_TAB==='web' ? 'webIn' : BL_TAB==='kw' ? 'kwIn' : null;
  const el = id ? document.getElementById(id) : null;
  const typed = el && (el.value||'').trim();
  if(typed){
    cta.textContent = 'Inserisci';
    cta.onclick = function(){ addItem(BL_TAB); };
  }else{
    cta.textContent = 'Salva';
    cta.onclick = UB_CTA_BACK;
  }
}

/* ---------------------------------------------------------------------------------------
   G18 — suggested sites with checkboxes
   --------------------------------------------------------------------------------------- */

const UB_SUGGESTIONS = [
  {name:'Social', icon:'💬', sites:['facebook.com','instagram.com','tiktok.com','x.com','twitter.com','snapchat.com','reddit.com','linkedin.com','pinterest.com','threads.net']},
  {name:'Video e streaming', icon:'▶️', sites:['youtube.com','netflix.com','twitch.tv','primevideo.com','disneyplus.com','dailymotion.com','vimeo.com']},
  {name:'Notizie', icon:'📰', sites:['repubblica.it','corriere.it','ansa.it','fanpage.it','ilfattoquotidiano.it','tgcom24.mediaset.it','news.google.com']},
  {name:'Shopping', icon:'🛒', sites:['amazon.it','ebay.it','aliexpress.com','temu.com','shein.com','zalando.it','subito.it','vinted.it']},
  {name:'Gaming', icon:'🎮', sites:['roblox.com','epicgames.com','steampowered.com','miniclip.com','poki.com','y8.com','ea.com']},
  {name:'Adulti (18+)', icon:'🔞', sites:['pornhub.com','xvideos.com','xnxx.com','onlyfans.com','redtube.com','youporn.com','chaturbate.com','stripchat.com']}
];

const UB_CHEV_GIU = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const UB_CHEV_SU = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 15l6-6 6 6"/></svg>';
function ubToggleSugg(){ UB_SUGG_OPEN = !UB_SUGG_OPEN; ubRenderSuggestions(); }

function ubRenderSuggestions(){
  const box = document.getElementById('ub-sugg');
  if(!box) return;
  const have = DRAFT ? (DRAFT.sites||[]) : [];
  /* 0.9.289, Andrea: "nei suggerimenti c'e' il carattere a V, non l'icona chevron": icone SVG */
  const head = '<div class="ub-sugghead" onclick="ubToggleSugg()"><b>Suggerimenti</b>'
    + '<small>i siti che distraggono di più</small><span class="ub-chev">' + (UB_SUGG_OPEN ? UB_CHEV_SU : UB_CHEV_GIU) + '</span></div>';
  if(!UB_SUGG_OPEN){ box.innerHTML = head; return; }
  /* 0.9.313: i siti gia' bloccati in cima. ci e si restano gli indici veri, li usa ubToggleSite */
  const quanti = cat => cat.sites.filter(s=>have.indexOf(s)>=0).length;
  const cats = UB_SUGGESTIONS.map((cat,ci)=>({cat,ci}));
  const body = cats.filter(x=>quanti(x.cat)>0).concat(cats.filter(x=>!quanti(x.cat))).map(({cat,ci})=>{
    const on = quanti(cat);
    const siti = cat.sites.map((s,si)=>({s,si}));
    return `<div class="ub-cat"><span>${cat.icon}</span><b>${esc(cat.name)}</b><small>${on}/${cat.sites.length}</small></div>
      <div class="picklist">${siti.filter(x=>have.indexOf(x.s)>=0).concat(siti.filter(x=>have.indexOf(x.s)<0)).map(({s,si})=>`
        <label class="pickrow">
          <input type="checkbox" ${have.indexOf(s)>=0?'checked':''} onchange="ubToggleSite(${ci},${si},this.checked)">
          ${flFavHtml(s)}<span class="pl">${esc(s)}</span>
        </label>`).join('')}</div>`;
  }).join('');
  box.innerHTML = head + body;
}
function ubToggleSite(ci,si,on){
  if(!DRAFT){ toast('Apri prima un programma'); ubRenderSuggestions(); return; }
  const s = UB_SUGGESTIONS[ci].sites[si];
  if(on){ if(DRAFT.sites.indexOf(s)<0) DRAFT.sites.push(s); }
  else DRAFT.sites = DRAFT.sites.filter(x=>x!==s);
  renderSimpleList('web');
  ubRenderSuggestions();
  refreshEditorCounts();
}

/* ---------------------------------------------------------------------------------------
   G04 — per-row counters and chips of what is selected, under each row of the editor
   --------------------------------------------------------------------------------------- */

/* The label when we know it, the package when we do not. Never the last dotted segment: it
   turns com.instagram.android into "android", which names the wrong thing entirely. */
function ubAppLabel(pkg){
  const a = APPS_CACHE.filter(x=>x.packageName===pkg)[0];
  return (a && a.label) ? a.label : String(pkg||'');
}
function ubChipsHtml(list, cls){
  if(!list.length) return '<span class="ub-nochip">Niente selezionato</span>';
  const shown = list.slice(0,8).map(t=>'<span class="ub-chip '+(cls||'')+'">'+esc(t)+'</span>').join('');
  return shown + (list.length>8 ? '<span class="ub-chip ub-more">+'+(list.length-8)+'</span>' : '');
}
function ubPaintEditorRows(){
  ubEnsureEditorRows();   // a row may have been added by another area after this file loaded
  const a = document.getElementById('ub-chips-app'),
        w = document.getElementById('ub-chips-web'),
        k = document.getElementById('ub-chips-kw');
  if(!a || !w || !k) return;
  if(!DRAFT){ a.innerHTML = w.innerHTML = k.innerHTML = ''; return; }
  ubNormalizeDraftKeywords();

  // AppBlock puts two counters on the Applications row: the apps picked, and the device the
  // selection applies to. We have exactly one device, and saying so is more honest than
  // pretending the number can vary.
  const ac = document.getElementById('edAppCount'),
        wc = document.getElementById('edWebCount'),
        kc = document.getElementById('edKwCount');
  if(ac) ac.innerHTML = '<span class="ub-cnt">▦ '+(DRAFT.apps||[]).length+'</span><span class="ub-cnt">📱 1</span>';
  if(wc) wc.innerHTML = '<span class="ub-cnt">🌐 '+(DRAFT.sites||[]).length+'</span>';
  if(kc) kc.innerHTML = '<span class="ub-cnt"># '+(DRAFT.keywords||[]).length+'</span>';

  /* le funzioni spuntate si leggono anche qui: senza, dopo aver spuntato Reels la riga direbbe "Niente selezionato" */
  const conFunz = !DRAFT.grey && !DRAFT.sound;
  if(conFunz && !UB_F_LETTE) ubFunzRileggi(ubPaintEditorRows);
  a.innerHTML = ubChipsHtml((DRAFT.apps||[]).map(ubAppLabel).concat(conFunz ? ubFunzScelte() : []));
  w.innerHTML = ubChipsHtml((DRAFT.sites||[]).slice());
  const kws = DRAFT.keywords||[];
  k.innerHTML = kws.length
    ? kws.slice(0,8).map(x=>'<span class="ub-chip ub-m-'+x.m+'">'+esc(x.t)+'</span>').join('')
      + (kws.length>8 ? '<span class="ub-chip ub-more">+'+(kws.length-8)+'</span>' : '')
    : '<span class="ub-nochip">Niente selezionato</span>';
}

/* ---------------------------------------------------------------------------------------
   Injection into the frozen markup
   --------------------------------------------------------------------------------------- */

(function ubStyle(){
  const css = [
  '.ub-iconbtn{border:1px solid var(--line);background:#fff;border-radius:12px;width:46px;flex:none;',
  '  font-size:17px;color:var(--blue);cursor:pointer;display:grid;place-items:center}',
  '.ub-iconbtn:active{transform:scale(.95)}',
  '.ub-modebar{border:1px solid var(--line);border-radius:12px;background:#fff;margin-top:10px;overflow:hidden}',
  '.ub-modebar.open{border-color:var(--blue)}',
  '.ub-modebtn{display:flex;align-items:center;gap:8px;width:100%;border:0;background:none;padding:12px 14px;',
  '  cursor:pointer;font:600 12px var(--font-body);color:var(--muted);text-align:left}',
  '.ub-modebtn b{margin-left:auto;font:700 13px var(--font-body);color:var(--navy)}',
  '.ub-modebtn .ub-chev{color:var(--faint);font-size:15px}', '.ub-caret{display:inline-block;width:0;height:0;margin-left:7px;vertical-align:middle;border-left:4.5px solid transparent;border-right:4.5px solid transparent;border-top:5.5px solid currentColor;opacity:.75}','.ub-modetag{display:inline-flex;align-items:center}',
  '#ubModeSheet{position:fixed;inset:0;z-index:72;display:none}',
  '#ubModeSheet.open{display:block}',
  '#ubModeSheet .blk-sheet{max-height:82%;overflow:auto}',
  '.ub-radio{display:flex;align-items:flex-start;gap:11px;padding:11px 10px;border-radius:10px;cursor:pointer}',
  '.ub-radio i{width:19px;height:19px;border-radius:50%;border:2px solid var(--line);flex:none;margin-top:1px;position:relative}',
  '.ub-radio.on i{border-color:var(--blue)}',
  '.ub-radio.on i::after{content:"";position:absolute;inset:3px;border-radius:50%;background:var(--blue)}',
  '.ub-radio.on{background:var(--blue-soft)}',
  '.ub-radio b{display:block;font:700 13px var(--font-body);color:var(--navy)}',
  '.ub-radio small{display:block;font:500 11px/1.5 var(--font-body);color:var(--muted);margin-top:2px}',
  '.ub-radio .tag{margin-top:6px;display:inline-block}',
  '.ub-modetag{margin-left:auto;border:1px solid var(--line);background:#F1F7FE;border-radius:99px;',
  '  padding:5px 10px;font:700 10px var(--font-body);color:var(--blue);cursor:pointer;flex:none;white-space:nowrap}',
  '.ub-modetag.ub-m-content{color:var(--red-deep);background:var(--red-soft);border-color:#F5C2C7}',
  '.ub-kwrow .del{margin-left:8px}',
  '.ub-glob{flex:none;font-size:15px}',
  '.ub-sugg{margin-top:14px}',
  '.ub-sugghead{display:flex;align-items:center;gap:8px;cursor:pointer;padding:6px 0}',
  '.ub-sugghead b{font:700 14px var(--font-display);color:var(--navy)}',
  '.ub-sugghead small{font:500 11px var(--font-body);color:var(--faint)}',
  '.ub-sugghead .ub-chev{margin-left:auto;color:var(--blue);font-size:15px}',
  '.ub-cat{display:flex;align-items:center;gap:8px;margin-top:14px}',
  '.ub-cat b{font:700 12px var(--font-body);color:var(--navy)}',
  '.ub-cat small{margin-left:auto;font:700 11px var(--font-body);color:var(--blue)}',
  '.ub-chipbox{display:flex;flex-wrap:wrap;gap:6px;margin:-2px 0 10px;padding:0 2px}',
  '.ub-chipbox:empty{display:none}',
  /* LA CARTA SEGUE IL TEMA. `#EDF4FC` fisso con l'inchiostro in `--navy` (che di notte diventa
     quasi bianco) e' il bianco su bianco che Andrea ha segnalato cinque volte: erano QUESTI i
     chip, non quelli del Blocco rapido. Un colore fisso per la carta e una variabile per
     l'inchiostro non possono stare nella stessa regola. */
  '.ub-chip{font:600 10.5px var(--font-body);color:var(--navy);background:#EDF4FC;border:1px solid var(--line);',
  '  border-radius:99px;padding:4px 10px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  '.ub-chip.ub-m-content{color:var(--red-deep);background:var(--red-soft);border-color:#F5C2C7}',
  '.ub-chip.ub-more{color:var(--blue);font-weight:700}',
  'body.dark .ub-chip{background:#141C2C;color:#E8F1FF;border-color:#25314A}',
  'body.dark .ub-chip.ub-more{background:#1B2540;color:#9FB6CF}',
  'body.dark .ub-nochip{color:#8698B4}',
  '.ub-nochip{font:500 11px var(--font-body);color:var(--faint)}',
  '.ub-cnt{font:600 12px var(--font-body);color:var(--muted)}',
  '#edAppCount,#edWebCount,#edKwCount{margin-left:auto;display:flex;gap:8px}',
  /* App row: icon first, name second, checkbox last. The eye lands on the icon, which is
     how people actually recognise the app they are looking for. */
  '.ub-approw{display:flex;align-items:center;gap:12px;padding:11px 12px}',
  '.ub-appico{width:38px;height:38px;border-radius:9px;flex:none;object-fit:cover}',
  '.ub-appico-fb{display:grid;place-items:center;background:var(--blue-soft);color:var(--blue);font:800 16px var(--font-display)}',
  '.ub-appico-fb{position:relative}',
  '.ub-appico-img{position:absolute;inset:0;width:100%;height:100%;opacity:0;transition:opacity .18s}',
  '.ub-appico-img[src]{opacity:1}',
  '.ub-appname{flex:1;min-width:0}',
  '.ub-appname .pl{display:block;font:700 14px var(--font-body);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
  '.ub-approw input[type=checkbox]{flex:none;width:21px;height:21px;accent-color:var(--blue)}',
  /* Le righe figlie: la freccia sta sotto all'icona dell'app, poi la stessa icona, il nome e la pillola. */
  '.ub-con-figli,.ub-frow{border-bottom:0}',
  '.ub-frow.ub-frow-ult{border-bottom:1px solid var(--line)}',
  '.ub-freccia{flex:none;width:38px;display:grid;place-items:center;color:var(--faint)}',
  '.ub-fname{display:flex;align-items:center;gap:8px}',
  '.ub-fname .pl{flex:0 1 auto;min-width:0;font-weight:600}',
  '.ub-beta{flex:none;background:#0075E3;color:#fff;border-radius:6px;padding:3px 7px;font:800 10.5px/1.2 var(--font-body);letter-spacing:.4px}',
  '.ub-frow-spenta{cursor:default}',
  '.ub-frow-spenta .pl{color:var(--faint)}',
  '.ub-frow-spenta input[type=checkbox]{accent-color:#8A97AB;cursor:default}',
  /* di notte la casella vuota e' un contorno sul fondo scuro, non un quadrato bianco acceso */
  'body.dark .ub-approw input[type=checkbox]{color-scheme:dark}',
  '.ub-csvfoot{display:flex;align-items:center;justify-content:center;gap:8px;margin:22px 0 4px}',
  '.ub-csvfoot button{background:none;border:0;padding:6px 2px;font:600 12px var(--font-body);color:var(--blue);cursor:pointer}',
  '.ub-csvfoot span{color:var(--faint)}',
  '#ub-modehint{padding:10px 2px 2px;line-height:1.6}'
  ].join('\n');
  const s = document.createElement('style');
  s.id = 'ub-style';
  s.textContent = css;
  document.head.appendChild(s);
})();

(function ubInject(){
  /* --- Web tab: import/export icons, then the suggestions block --- */
  const web = document.getElementById('bl-web');
  if(web){
    const row = web.querySelector('.addrow');
    const input = document.getElementById('webIn');
    if(input) input.addEventListener('input', ubOnWebInput);
    ubBindEnter('webIn', 'web');
    web.insertAdjacentHTML('beforeend', '<div class="ub-sugg" id="ub-sugg"></div>');
    // The list belongs under the suggestions, not above them.
    const list = document.getElementById('webList');
    if(list) web.appendChild(list);
  }

  /* The match-type sheet. Registered once, shared by the entry being typed and by every row. */
  if(typeof registerOverlay === 'function' && !document.getElementById('ubModeSheet')){
    registerOverlay('ubModeSheet',
      '<div class="blk-sheet-scrim" onclick="ubCloseModePanel()"></div>' +
      '<div class="blk-sheet"><div class="blk-grab"></div><div id="ubModeSheetBody"></div>' +
      '<button class="ghost blk-sheet-cancel" onclick="ubCloseModePanel()">Annulla</button></div>');
  }

  /* --- Keyword tab: import/export icons and the match-type dropdown (Bug F / G17) --- */
  const kw = document.getElementById('bl-kw');
  if(kw){
    const row = kw.querySelector('.addrow');
    const bar = document.createElement('div');
    bar.className = 'ub-modebar';
    bar.id = 'ub-modebar';
    // Nasce nascosta: scegliere il tipo di corrispondenza non ha senso finche' non
    // c'e' una parola da far corrispondere. Compare al primo carattere digitato.
    bar.hidden = true;
    bar.innerHTML =
      '<button class="ub-modebtn" onclick="ubToggleModePanel()"><span id="ub-modetitle">Tipo di corrispondenza</span>' +
        '<b id="ub-modelbl">' + UB_MODES[UB_NEW_MODE].label + '</b><i class="ub-caret"></i></button>' +
      '';
    if(row && row.nextSibling) kw.insertBefore(bar, row.nextSibling); else kw.appendChild(bar);

    // The frozen hint line describes only one of the three modes; make it follow the chosen one.
    const hint = kw.querySelector('.hintline');
    if(hint){ hint.id = 'ub-modehint'; hint.textContent = UB_MODES[UB_NEW_MODE].hint; }

    const input = document.getElementById('kwIn');
    if(input) input.addEventListener('input', ubOnKwInput);
    ubBindEnter('kwIn', 'kw');
    ubShowModeBar(false);
  }

  /* CSV out of the main flow. It is a power-user affordance used by a tiny minority, and
     next to the field it competed with the one control everybody needs. In words, at the
     bottom, where whoever is looking for it will look. */
  ['web','kw'].forEach(function(which){
    const host = document.getElementById(which === 'web' ? 'bl-web' : 'bl-kw');
    if(!host || document.getElementById('ub-csvfoot-' + which)) return;
    const foot = document.createElement('div');
    foot.className = 'ub-csvfoot';
    foot.id = 'ub-csvfoot-' + which;
    // Built with the DOM rather than an HTML string: the handler names travel as values,
    // so there are no nested quotes to get wrong.
    const mk = function(label, fn){
      const b = document.createElement('button');
      b.textContent = label;
      b.addEventListener('click', fn);
      return b;
    };
    const sep = document.createElement('span');
    sep.textContent = '·';
    foot.appendChild(mk('Importa', function(){ csvImportOpen(which); }));
    foot.appendChild(sep);
    foot.appendChild(mk('Esporta', function(){ csvExportOpen(which); }));
    host.appendChild(foot);
  });

  ubEnsureEditorRows();
})();

/* The App row opened the screen with goId() and never set the tab, so it landed on whichever
   tab had been used last. It has to say which list it is opening.

   The three rows are found through their own counters, never by position: other areas add
   rows to this editor from their own modules, and an index would silently attach the chips —
   and the fix above — to somebody else's row. Idempotent, and retried on the first paint in
   case a row is added after this file has run. */
function ubEnsureEditorRows(){
  const ids = {app:'edAppCount', web:'edWebCount', kw:'edKwCount'};
  Object.keys(ids).forEach(function(k){
    if(document.getElementById('ub-chips-'+k)) return;
    // Walked by hand rather than with closest(): the minimum WebView this app supports is not
    // guaranteed to have it, and a missing chip box would be a silent hole.
    let row = document.getElementById(ids[k]);
    while(row && !(row.classList && row.classList.contains('setrow'))) row = row.parentElement;
    if(!row || !row.parentNode) return;
    if(k==='app'){
      row.setAttribute('onclick', "openBlocklist('app')");
      row.onclick = function(){ openBlocklist('app'); };
    }
    const box = document.createElement('div');
    box.className = 'ub-chipbox';
    box.id = 'ub-chips-'+k;
    row.parentNode.insertBefore(box, row.nextSibling);
  });
}

/* blocco.js owns refreshEditorCounts and is being worked on in parallel, so we wrap it instead
   of redeclaring it: whatever it grows into keeps running, and the chips are painted after. A
   `function refreshEditorCounts` here would be hoisted over its own backup and recurse. */
(function ubWrapCounts(){
  const prev = window.refreshEditorCounts;
  window.refreshEditorCounts = function(){
    try{ if(typeof prev === 'function') prev.apply(this, arguments); }catch(e){}
    try{ ubPaintEditorRows(); }catch(e){}
  };
})();

/* Shared with the quick-block list, which renders the same tiles. */
window.ubLoadIcons = ubFillIcons;
