/* ===========================================================================================
   I BLOCCHI DELLA PAGINA REPORT (0.9.285, Andrea)

   "Rendi personalizzabili i blocchi della pagina Report, con il blocco tratteggiato «Personalizza
   la pagina Report» in fondo, solo per me". Il Report (insights.js) si ridisegna da capo a ogni cambio
   di vista (Giorno, Settimana, Tendenza): dentro all'HTML ci sono dei segnaposto (<i class="rp-mk">)
   che dicono dove comincia ogni blocco. Dopo ogni disegno, qui:
     1. i pezzi fra un segnaposto e l'altro diventano un blocco con il suo id (rpApp, rpAbitudini...);
     2. entra la partita delle idee (partita-idee.js, piCardReport);
     3. l'ordine e i blocchi spenti li decide Personalizza (start-costruisci.js, pagina "report");
     4. in fondo il piede tratteggiato, solo per chi ha creato l'app.
   Gli id dentro ai blocchi restano gli stessi: chi colora il grafico dopo li ritrova.
   =========================================================================================== */
function rpbAdmin(){ return typeof flAdmin === 'function' && flAdmin(); }
function rpbAvvolgi(body){
  if (!body || !body.querySelector('.rp-mk')) return false;
  const nodi = Array.prototype.slice.call(body.childNodes);
  let blocco = null;
  const nuovo = function(id){ const d = document.createElement('div'); d.id = id; d.className = 'rp-blk'; return d; };
  const prima = nuovo('rpRiepilogo');
  body.insertBefore(prima, body.firstChild);
  blocco = prima;
  nodi.forEach(function(n){
    if (n.nodeType === 1 && n.classList.contains('rp-mk')){
      const k = n.getAttribute('data-k');
      n.remove();
      if (k === 'fine'){ blocco = null; return; }
      const gia = document.getElementById(k);
      blocco = (gia && gia.parentElement === body) ? gia : nuovo(k);
      if (!blocco.parentElement) body.appendChild(blocco);
      return;
    }
    if (blocco) blocco.appendChild(n);
  });
  /* un blocco rimasto vuoto (una vista senza quella parte) non resta come buco */
  Array.prototype.slice.call(body.querySelectorAll(':scope > .rp-blk')).forEach(function(b){ if (!b.childNodes.length) b.remove(); });
  return true;
}
function rpbApplica(){
  const body = document.getElementById('insBody'); if (!body) return;
  try{ if (typeof piPaintUno === 'function') piPaintUno('piCardReport'); }catch(_){ }
  /* il piede tratteggiato: solo per chi ha creato l'app. Va messo prima di ordinare: Personalizza lo tiene in fondo */
  let p = body.querySelector(':scope > .hd-piede');
  if (rpbAdmin()){
    if (!p){
      p = document.createElement('button'); p.type = 'button'; p.className = 'hd-piede rp-piede';
      p.innerHTML = (typeof HD_TRATTO !== 'undefined' ? HD_TRATTO : '') + (typeof HD_PIU !== 'undefined' ? HD_PIU : '') + '<span>Personalizza la pagina Report</span>';
      p.setAttribute('onclick', "if(typeof scsApri==='function')scsApri('report')");
    }
    body.appendChild(p);
  } else if (p) p.remove();
  try{ if (typeof scsOrdinaBlocchi === 'function') scsOrdinaBlocchi('report'); }catch(_){ }
  const share = body.querySelector(':scope > #insShareText'); if (share && body.lastElementChild !== share) body.appendChild(share);
}
(function(){
  setTimeout(function(){
    try{
      if (typeof insDopoDisegno !== 'function' || insDopoDisegno.__rpb) return;
      const vero = insDopoDisegno;
      const g = function(body){ const r = vero.apply(this, arguments); try{ if (body && body.id === 'insBody' && rpbAvvolgi(body)) rpbApplica(); }catch(_){ } return r; };
      g.__rpb = true; window.insDopoDisegno = g; try{ insDopoDisegno = g; }catch(_){ }
    }catch(_){ }
  }, 300);
  /* tornando da Personalizza: l'ordine nuovo vale subito */
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights') setTimeout(rpbApplica, 300); });
  const css = [
    '#insBody > .rp-blk.scs-off{display:none}',
    '#insBody > .rp-piede{width:100%;margin:42px 0 24px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
