/* ===========================================================================================
   LA SERIE — i giorni in cui hai fatto, non i giorni in cui hai scritto

   COSA E' CAMBIATO, E PERCHE'. La serie contava i giorni chiusi con un piano scritto. Ma un
   piano scritto e non fatto non porta da nessuna parte: si puo' passare una settimana a
   riordinare l'elenco delle cose da fare e arrivare a domenica esattamente dove si era
   partiti, con la serie a sette. Una serie che premia l'intenzione misura l'intenzione, e
   l'intenzione e' gratis.

   Da qui in poi un giorno conta se dentro c'e' almeno UNA sessione di concentrazione totale
   portata a termine. E' l'unica cosa in quest'app che avvicina davvero alla destinazione, ed
   e' anche l'unica che non si puo' fingere.

   UNA SESSIONE BASTA. Chi gioca in difficile ne deve cinque per chiudere la giornata, ma
   farne una e non cinque non spezza niente: si e' mosso piu' piano, non si e' fermato. Il
   calendario lo dice con due colori diversi — pieno e mezzo — e la differenza la paga dove
   va pagata: nella data di arrivo, che si allontana se il passo e' meta' di quello che
   serve. Un cancello che azzera la serie a chi ha fatto quattro sessioni su cinque insegna
   una cosa sola: che tanto vale non cominciare.
   =========================================================================================== */

const SER_APERTA = 'fl_serie_aperta';
const SER_MESE = { off: 0 };          // 0 = questo mese, 1 = quello prima…

function serDayKey(t){
  const d = new Date(t);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
function serHist(){
  try{ return JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []; }catch(_){ return []; }
}
/** Quante sessioni di concentrazione totale sono state PORTATE A TERMINE in quel giorno. */
function serSessioniDi(day){
  const a = new Date(day + 'T00:00:00').getTime();
  if (isNaN(a)) return 0;
  const b = a + 86400000;
  return serHist().filter(function(x){ return x && x.ok && x.at >= a && x.at < b; }).length;
}
/** Il passo del giorno secondo la modalita': un passo, tre o cinque. */
function serMeta(){
  let m = 'normale';
  try{ m = (typeof fsModalita === 'function') ? fsModalita() : (localStorage.getItem('fl_modalita') || 'normale'); }catch(_){ }
  return { facile: 1, normale: 3, difficile: 5 }[m] || 3;
}
/** 'piena' (tutte), 'mezza' (almeno una), 'vuota' (nessuna). */
function serStato(day){
  const n = serSessioniDi(day);
  if (!n) return 'vuota';
  return n >= serMeta() ? 'piena' : 'mezza';
}
/** Da quanti giorni di fila c'e' almeno una sessione. Oggi conta solo se ne ha gia' una. */
function serStreak(){
  let n = 0;
  const base = new Date(); base.setHours(0, 0, 0, 0);
  for (let i = 0; i < 400; i++){
    const k = serDayKey(base.getTime() - i * 86400000);
    if (serSessioniDi(k) > 0){ n++; continue; }
    /* Oggi non e' finito: una giornata ancora aperta non spezza niente, altrimenti alle
       nove di mattina la serie direbbe zero a chi ne ha trenta. */
    if (i === 0) continue;
    /* un giorno in pausa per un imprevisto non conta e non spezza: il vento non e' colpa tua */
    if (typeof etaInPausa === 'function' && etaInPausa(k)) continue;
    break;
  }
  return n;
}
/** Il primo giorno di cui questa app puo' dire qualcosa. */
function serNascita(){
  let t = 0;
  try{ t = (typeof flPrimoAvvio === 'function') ? flPrimoAvvio() : 0; }catch(_){ }
  const h = serHist();
  if (h.length && h[0].at && (!t || h[0].at < t)) t = h[0].at;
  return t;
}

/* ---------------------------------------------------------------------------------------
   LA DATA DI ARRIVO VIVE NEL NAVIGATORE (eta-motore.js + eta.js).

   Qui c'era una formula: i mesi del Genio divisi per il rapporto fra il passo fatto e quello
   richiesto. Era una data che si allontanava da sola ogni giorno, e sotto aveva un contatore
   di ritardo cumulativo. Adesso l'arrivo e' una simulazione sulla strada che resta e sul
   passo vero, ricalcolata a ogni cosa chiusa, con il bollino «rispetto a ieri» come quello
   del tempo di schermo. serArrivo resta il nome che il resto dell'app conosce.
   --------------------------------------------------------------------------------------- */
const SER_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno',
                  'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];

/** Sessioni al giorno, media sui giorni osservati (non su una finestra inventata). */
function serPasso(finestra){
  const nato = serNascita();
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  let giorni = finestra || 14;
  if (nato){
    const vissuti = Math.floor((oggi.getTime() - nato) / 86400000) + 1;
    giorni = Math.max(1, Math.min(giorni, vissuti));
  }
  let tot = 0;
  for (let i = 0; i < giorni; i++) tot += serSessioniDi(serDayKey(oggi.getTime() - i * 86400000));
  return { alGiorno: tot / giorni, giorni: giorni, tot: tot };
}
/** L'arrivo: quello del navigatore. Null senza una lettura del Genio. */
function serArrivo(){
  if (typeof etaArrivo !== 'function') return null;
  try{ return etaArrivo(); }catch(_){ return null; }
}

/** Quando e' cominciato il viaggio: la lettura del Genio, o il primo giorno dell'app. */
function serInizioViaggio(){
  let t = 0;
  try{ const L = (typeof gnLettura === 'function') ? gnLettura() : null; if (L) t = L.at || L.quando || L.ts || 0; }catch(_){ }
  if (!t){ try{ const o = (typeof orLast === 'function') ? orLast() : null; if (o) t = o.at || o.when || 0; }catch(_){ } }
  if (!t) t = serNascita() || Date.now();
  return t;
}

/** Le opzioni di viaggio: pedaggi, budget, capitale. Restano qui: servono al Genio, non a noi. */
const SER_OPZ_KEY = 'fl_viaggio_opz';
function serOpzioni(){
  try{ return Object.assign({ pedaggi: false, budget: 0, capitale: 0, precisione: 'precisa' }, JSON.parse(localStorage.getItem(SER_OPZ_KEY) || '{}') || {}); }
  catch(_){ return { pedaggi: false, budget: 0, capitale: 0, precisione: 'precisa' }; }
}
function serOpzioniSalva(p){
  const o = Object.assign(serOpzioni(), p || {});
  try{ localStorage.setItem(SER_OPZ_KEY, JSON.stringify(o)); }catch(_){ }
  return o;
}

/**
 * Il conto alla rovescia, come sul navigatore, nei tre gradi delle opzioni di viaggio:
 * «semplice» anni e mesi, «precisa» anni, mesi e giorni, «dettagliata» fino al minuto.
 * Cambiare grado cambia solo le parole: la data sotto e' la stessa.
 */
function serContoRovescia(at, modo){
  if (modo === undefined || modo === null){
    try{ modo = (typeof etaPrecisione === 'function') ? etaPrecisione() : serOpzioni().precisione; }catch(_){ modo = 'precisa'; }
  }
  if (modo === true) modo = 'semplice';
  if (modo === false || modo === 'minuti') modo = 'dettagliata';
  let ms = Math.max(0, at - Date.now());
  const anni = Math.floor(ms / (365.25 * 86400000)); ms -= anni * 365.25 * 86400000;
  const mesi = Math.floor(ms / (30.4375 * 86400000)); ms -= mesi * 30.4375 * 86400000;
  const giorni = Math.floor(ms / 86400000); ms -= giorni * 86400000;
  const ore = Math.floor(ms / 3600000); ms -= ore * 3600000;
  const min = Math.floor(ms / 60000);
  const p = [];
  if (anni) p.push(anni + (anni === 1 ? ' anno' : ' anni'));
  if (mesi) p.push(mesi + (mesi === 1 ? ' mese' : ' mesi'));
  if (modo === 'semplice'){
    if (!p.length) p.push(giorni + (giorni === 1 ? ' giorno' : ' giorni'));
    return p.join(', ');
  }
  p.push(giorni + (giorni === 1 ? ' giorno' : ' giorni'));
  if (modo !== 'dettagliata') return p.join(', ');
  p.push(ore + (ore === 1 ? ' ora' : ' ore'));
  p.push(min + (min === 1 ? ' minuto' : ' minuti'));
  return p.join(', ');
}

/* ---------------------------------------------------------------------------------------
   IL CALENDARIO
   Un mese per volta, la settimana da lunedi, e la serie disegnata come una fascia continua
   sotto ai giorni che si tengono per mano: una fila di pallini staccati non fa vedere che
   sono di fila, che e' l'unica cosa che il calendario deve far vedere.
   --------------------------------------------------------------------------------------- */
const SER_DOW_LUN = ['L', 'M', 'M', 'G', 'V', 'S', 'D'];
function serWs(){ return (typeof flWeekStart === 'function') ? flWeekStart() : 1; }
/* le sigle dei giorni, ruotate sul primo giorno scelto */
function serDow(){ return serWs() === 0 ? ['D'].concat(SER_DOW_LUN.slice(0, 6)) : SER_DOW_LUN; }

function serMeseVai(d){
  SER_MESE.off = Math.max(0, Math.min(36, SER_MESE.off + d));
  serPaint();
}
function serToggle(){
  let on = false;
  try{ on = localStorage.getItem(SER_APERTA) === '1'; }catch(_){ }
  try{ localStorage.setItem(SER_APERTA, on ? '0' : '1'); }catch(_){ }
  serPaint();
}
function serAperta(){ try{ return localStorage.getItem(SER_APERTA) === '1'; }catch(_){ return false; } }

function serCalendarioHtml(){
  const base = new Date();
  base.setDate(1);
  base.setMonth(base.getMonth() - SER_MESE.off);
  base.setHours(0, 0, 0, 0);
  const anno = base.getFullYear(), mese = base.getMonth();
  const primo = new Date(anno, mese, 1);
  const giorniNel = new Date(anno, mese + 1, 0).getDate();
  const salto = (primo.getDay() - serWs() + 7) % 7;      // il primo giorno della settimana = colonna 0
  const oggiK = serDayKey(Date.now());
  const nato = serNascita();

  let celle = '';
  for (let i = 0; i < salto; i++) celle += '<i class="ser-vuota"></i>';
  for (let g = 1; g <= giorniNel; g++){
    const k = anno + '-' + String(mese + 1).padStart(2, '0') + '-' + String(g).padStart(2, '0');
    const t = new Date(anno, mese, g).getTime();
    const futuro = k > oggiK;
    const prima = nato && t < new Date(serDayKey(nato) + 'T00:00:00').getTime();
    const st = futuro || prima ? 'fuori' : serStato(k);
    /* Le estremita' della fascia: un giorno con i vicini accesi si attacca a loro. */
    const acceso = st === 'piena' || st === 'mezza';
    const pre = g > 1 && serSessioniDi(anno + '-' + String(mese + 1).padStart(2, '0') + '-' + String(g - 1).padStart(2, '0')) > 0;
    const post = g < giorniNel && serSessioniDi(anno + '-' + String(mese + 1).padStart(2, '0') + '-' + String(g + 1).padStart(2, '0')) > 0;
    const fascia = acceso ? ' f' + (pre ? 'l' : '') + (post ? 'r' : '') : '';
    /* 0.9.348, Andrea: "perche' compare quel pallino rosso sotto al 4?" (era il segno di "almeno una"): via. E i giorni salvati da una
       protezione si vedono con il ghiaccio, come nel calendario della serie */
    let coperto = false; try{ coperto = !futuro && typeof spUsedOn === 'function' && typeof mtRoll === 'function' && !!spUsedOn(mtRoll(), k); }catch(_){ }
    celle += '<i class="ser-g ' + (coperto ? 'coperto' : st) + fascia + (k === oggiK ? ' oggi' : '') + '">'
      + (coperto ? '<b class="ser-ghiaccio">🧊</b>' : '<b>' + g + '</b>')
      + '</i>';
  }

  const st = serStreak();
  const p = serPasso(14);
  const arr = serArrivo();
  const oggiN = serSessioniDi(oggiK), meta = serMeta();

  return '<div class="ser-cal">'
    /* 0.9.348: "deve essere chiaro che e' il calendario del Full Focus, non quello della serie di tappe dell'intestazione" */
    + '<p class="ser-cal-tit">Le tue sessioni di Full Focus</p>'
    + '<div class="ser-top">'
    +   '<button type="button" onclick="serMeseVai(1)" aria-label="Mese precedente">‹</button>'
    +   '<b>' + SER_MESI[mese].charAt(0).toUpperCase() + SER_MESI[mese].slice(1) + ', ' + anno + '</b>'
    +   '<button type="button" onclick="serMeseVai(-1)"' + (SER_MESE.off === 0 ? ' disabled' : '') + ' aria-label="Mese successivo">›</button>'
    + '</div>'
    + '<div class="ser-dow">' + serDow().map(function(d){ return '<span>' + d + '</span>'; }).join('') + '</div>'
    + '<div class="ser-grid">' + celle + '</div>'
    + '<div class="ser-leg">'
    +   '<span><i class="piena"></i>Tutte e ' + meta + '</span>'
    +   '<span><i class="mezza"></i>Almeno una</span>'
    + '</div>'
    + '<div class="ser-oggi">'
    +   '<b>' + (st ? st + (st === 1 ? ' giorno di fila' : ' giorni di fila') : 'La serie non è partita') + '</b>'
    +   '<small>' + (oggiN
          ? 'Oggi ' + oggiN + ' su ' + meta + (oggiN >= meta ? ': giornata piena.' : ': la serie tiene, il passo è più corto.')
          : 'Oggi ancora nessuna sessione. Ne basta una per tenere la serie.') + '</small>'
    + '</div>'
    /* la data del navigatore, e basta: niente contatori di ritardo, il perche' sta nella Timeline */
    + serArrivoHtml(arr, p, meta)
    + '</div>';
}

/* L'ARRIVO SOTTO AL CALENDARIO (0.9.304). Andrea: "un riquadro brutto: Di questo passo arrivi a 18 luglio 2028 · stima,
   e sotto una riga fitta". Adesso e' un pannello con la gerarchia: l'etichetta, la DATA grande, una riga piccola che dice
   da dove viene. La data e' quella di tutta l'app (etaArrivo, eta.js): la stessa della slideshow di Dream, della scheda
   Sogno, della cartina e della schermata di blocco. Finche' la data e' velata (eta.js, evVelata) qui non si vede, come
   altrove; senza una data finita si dice perche', con le stesse parole della cartina. */
function serArrivoHtml(arr, p, meta){
  if (!arr) return '<p class="ser-nodata">La data d’arrivo compare con la lettura del Genio.</p>';
  let velata = false; try{ velata = typeof evVelata === 'function' && evVelata(); }catch(_){ }
  let grande = '', testo = false;
  if (velata){ grande = (typeof evBreve === 'function') ? evBreve() : 'La data arriva fra pochi giorni'; testo = true; }
  else if (arr.senzaPiano || arr.oltre || !isFinite(arr.at)){
    const k = arr.senzaPiano ? 'card.senzaPiano' : 'card.oltre';
    let t = ''; try{ t = (typeof etaT === 'function') ? etaT(k) : ''; }catch(_){ }
    grande = (typeof t === 'string' && t) || 'Ancora nessuna data: serve una leva'; testo = true;
  } else grande = arr.semplice ? arr.txtSemplice : arr.txt;
  const n = +p.alGiorno || 0, gg = p.giorni + (p.giorni === 1 ? ' giorno' : ' giorni');
  const riga = n > 0
    ? 'Negli ultimi ' + gg + ' hai fatto in media ' + n.toFixed(1).replace('.', ',') + ' sessioni di Full Focus al giorno. Per arrivare entro la tua data ne servono ' + meta + '.'
    : 'Negli ultimi ' + gg + ' non hai fatto sessioni di Full Focus. Per arrivare entro la tua data ne servono ' + meta + ' al giorno.';
  return '<div class="ser-arr">'
    + '<small class="ser-arr-k">Arrivo previsto</small>'
    + '<b class="ser-arr-d' + (testo ? ' testo' : '') + '">' + esc(grande) + '</b>'
    + (velata ? '' : '<p class="ser-arr-p">' + esc(riga) + '</p>')
    + '</div>';
}

/** Ridisegna il pannello della serie, se c'è. Lo host lo prepara start.js (spPaint). */
/* 0.9.347, Andrea: "il calendario della Protezione serie fa schifo: il giorno di oggi cerchiato di nero, e diverso da quello della serie
   nell'intestazione". Stessa grafica del calendario dell'intestazione (intestazione.js, .hd-cal): una card, i giorni tenuti con l'anello
   rosso, oggi pieno di rosso, niente nero. E la card della protezione ha la sua pillola con il numero. */
(function(){ const st = document.createElement('style'); st.textContent = [
  '#serBody .ser-cal{margin:12px 0 0;padding:12px 10px 14px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark #serBody .ser-cal{background:#12203A;border-color:#22345A}',
  '#serBody .ser-top b{font:800 15px var(--font-body)}#serBody .ser-top button{background:transparent;font-size:22px}#serBody .ser-dow{border-bottom:0;padding-bottom:4px}#serBody .ser-dow span{font-weight:800;color:var(--muted)}',
  '#serBody .ser-g::before{width:36px;height:36px}#serBody .ser-g.f::after,#serBody .ser-g.fl::after,#serBody .ser-g.fr::after,#serBody .ser-g.flr::after{background:rgba(230,57,70,.10);height:36px}',
  '#serBody .ser-g.piena::before{background:#FFE3E6;box-shadow:inset 0 0 0 2px #E63946}#serBody .ser-g.piena b{color:#B91C2C;font-weight:800}body.dark #serBody .ser-g.piena::before{background:rgba(230,57,70,.22)}body.dark #serBody .ser-g.piena b{color:#FFB3BA}',
  '#serBody .ser-g.mezza::before{background:#F0FBFF;box-shadow:inset 0 0 0 2px #8CC6FF}#serBody .ser-g.mezza b{color:#0075E3}',
  '#serBody .ser-g.oggi::before{background:#E63946!important;box-shadow:none!important}#serBody .ser-g.oggi b{color:#fff!important;font-weight:800}body.dark #serBody .ser-g.oggi::before{box-shadow:none!important}',
  /* 0.9.348: il numero di oggi usciva scuro sul rosso. Il guardiano del contrasto (darkfix.js) vedeva la carta della pagina (chiara) e
     scuriva il testo: il cerchio rosso stava in un ::before che lui non vede. Ora il rosso e' lo sfondo del giorno stesso, a gradiente
     (il guardiano non giudica i gradienti) */
  '#serBody .ser-g.oggi{background:radial-gradient(circle at center,#E63946 0 18px,transparent 18.5px)!important}#serBody .ser-g.oggi b{color:#fff!important}',
  '#serBody .ser-g.coperto b{font-size:20px}.ser-cal-tit{margin:0 0 6px;text-align:center;font:800 12px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#0075E3}body.dark .ser-cal-tit{color:#8CC6FF}',
  '#serBody .ser-g u{background:#E63946}#serBody .ser-g.oggi u{background:#fff}',
  '#serBody .ser-leg i.piena{background:#FFE3E6;box-shadow:inset 0 0 0 2px #E63946}#serBody .ser-leg i.mezza{background:#F0FBFF;box-shadow:inset 0 0 0 2px #8CC6FF}',
  '.sp-n-pill{flex:none;display:flex;flex-direction:column;align-items:center;justify-content:center;min-width:64px;padding:6px 10px;border-radius:14px;background:#F0FBFF;border:1px solid #C8EFFD;margin-left:auto}',
  '.sp-n-pill b{font:900 20px/1 var(--font-display);color:#0075E3}.sp-n-pill small{font:700 10.5px var(--font-body);color:var(--muted);margin-top:2px}.sp-n-pill.zero b{color:var(--muted)}',
  'body.dark .sp-n-pill{background:#12203A;border-color:#22345A}',
  '.sp-card{gap:12px!important}.sp-card .sp-row{display:block}.sp-card .sp-row b{white-space:normal;font-size:16px;line-height:1.25}.sp-card .sp-q{width:28px;height:28px;flex:none;margin:0}.sp-card .sp-ico{font-size:30px}'
].join(''); document.head.appendChild(st); })();
function serPaint(){
  const box = document.getElementById('serBody');
  const wrap = document.getElementById('serWrap');
  if (wrap) wrap.classList.toggle('open', serAperta());
  if (!box) return;
  box.innerHTML = serAperta() ? serCalendarioHtml() : '';
}

(function serStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.ser-cal{padding:4px 2px 2px}',
    '.ser-top{display:flex;align-items:center;justify-content:space-between;margin:2px 0 14px}',
    '.ser-top b{font:800 15px var(--font-display);color:var(--navy)}',
    'body.dark .ser-top b{color:#fff}',
    '.ser-top button{width:32px;height:32px;border:0;border-radius:50%;background:rgba(0,30,68,.06);',
      'color:var(--navy);font:700 17px var(--font-body);cursor:pointer;padding:0}',
    'body.dark .ser-top button{background:rgba(255,255,255,.1);color:#fff}',
    '.ser-top button[disabled]{opacity:.28;cursor:default}',
    '.ser-dow{display:grid;grid-template-columns:repeat(7,1fr);gap:2px;padding-bottom:8px;',
      'border-bottom:1px solid var(--line);margin-bottom:8px}',
    '.ser-dow span{text-align:center;font:700 11px var(--font-body);color:var(--faint)}',
    '.ser-grid{display:grid;grid-template-columns:repeat(7,1fr);gap:4px 2px}',
    '.ser-vuota{display:block;height:38px}',
    /* Il giorno: il numero al centro, il tondo dietro. La fascia della serie è lo stesso
       tondo allargato ai lati, così i giorni di fila si leggono come una riga sola. */
    '.ser-g{position:relative;display:flex;align-items:center;justify-content:center;height:38px;font-style:normal}',
    '.ser-g b{position:relative;z-index:2;font:700 13.5px var(--font-body);color:var(--muted)}',
    '.ser-g.fuori b{opacity:.38}',
    '.ser-g::before{content:"";position:absolute;z-index:1;left:50%;top:50%;transform:translate(-50%,-50%);',
      'width:34px;height:34px;border-radius:50%}',
    '.ser-g.piena::before{background:#0075E3}',
    '.ser-g.piena b{color:#fff}',
    /* mezza giornata: lo stesso blu ma svuotato — si vede che è acceso e che non è pieno */
    '.ser-g.mezza::before{background:rgba(0,117,227,.20);box-shadow:inset 0 0 0 2px #0075E3}',
    '.ser-g.mezza b{color:#0075E3}',
    'body.dark .ser-g.mezza b{color:#7FC0FF}',
    'body.dark .ser-g.mezza::before{background:rgba(0,117,227,.26);box-shadow:inset 0 0 0 2px #4FA6F5}',
    /* la fascia: i lati si squadrano verso il vicino acceso */
    '.ser-g.f::after,.ser-g.fl::after,.ser-g.fr::after,.ser-g.flr::after{content:"";position:absolute;z-index:0;top:50%;',
      'transform:translateY(-50%);height:34px;background:rgba(0,117,227,.13)}',
    '.ser-g.fl::after{left:-2px;right:50%}',
    '.ser-g.fr::after{left:50%;right:-2px}',
    '.ser-g.flr::after{left:-2px;right:-2px}',
    '.ser-g.oggi::before{box-shadow:inset 0 0 0 2px var(--navy)}',
    'body.dark .ser-g.oggi::before{box-shadow:inset 0 0 0 2px #fff}',
    '.ser-g.oggi.piena::before{box-shadow:inset 0 0 0 2px #0075E3}',
    '.ser-g.oggi.mezza::before{box-shadow:inset 0 0 0 2px #0075E3}',
    '.ser-g u{position:absolute;z-index:2;bottom:1px;left:50%;transform:translateX(-50%);',
      'width:4px;height:4px;border-radius:50%;background:#0075E3}',
    '.ser-leg{display:flex;gap:16px;justify-content:center;margin-top:14px}',
    '.ser-leg span{display:flex;align-items:center;gap:6px;font:600 11px var(--font-body);color:var(--faint)}',
    '.ser-leg i{width:12px;height:12px;border-radius:50%}',
    '.ser-leg i.piena{background:#0075E3}',
    '.ser-leg i.mezza{background:rgba(0,117,227,.20);box-shadow:inset 0 0 0 2px #0075E3}',
    '.ser-oggi{margin-top:16px;padding-top:14px;border-top:1px solid var(--line);text-align:center}',
    '.ser-oggi b{display:block;font:800 15px var(--font-display);color:var(--navy)}',
    'body.dark .ser-oggi b{color:#fff}',
    '.ser-oggi small{display:block;margin-top:5px;font:500 12.5px/1.55 var(--font-body);color:var(--muted)}',
    '.ser-arr{margin-top:16px;padding:18px 16px 16px;border-radius:18px;background:#E3F1FF;border:1px solid #BCE0FF;text-align:center}',
    'body.dark .ser-arr{background:#1C2E5A;border-color:#2F4C86}',
    '.ser-arr-k{display:block;font:700 11px var(--font-body);letter-spacing:.14em;text-transform:uppercase;color:#005BB0}',
    'body.dark .ser-arr-k{color:#8CC6FF}',
    '.ser-arr-d{display:block;margin-top:8px;font:900 24px/1.15 var(--font-display);letter-spacing:-.01em;color:#001E44}',
    '.ser-arr-d.testo{font:800 17px/1.35 var(--font-display);letter-spacing:0}',
    'body.dark .ser-arr-d{color:#fff}',
    '.ser-arr-p{margin:10px auto 0;max-width:34ch;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    'body.dark .ser-arr-p{color:#BCD3F2}',
    '.ser-nodata{margin:14px 0 0;font:500 12px/1.55 var(--font-body);color:var(--faint);text-align:center}'
  ].join('');
  document.head.appendChild(st);
})();
