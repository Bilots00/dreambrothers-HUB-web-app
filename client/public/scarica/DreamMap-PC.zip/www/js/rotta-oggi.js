/* ===========================================================================================
   LA PRIMA SLIDE DELLA ROADMAP — la rotta di oggi

   Due numeri, uno per parte: a sinistra le DEVIAZIONI (le volte in cui hai aggiunto una cosa
   fuori rotta: le segna l'arbitro esterno, l'hook di Claude sul computer), a destra le
   SESSIONI DI FULL FOCUS fatte. Non le task chiuse: le sessioni. Sono le due cose che, ogni
   giorno, spostano l'arrivo: una lo allontana, l'altra lo avvicina.

   Il periodo si cambia toccando «Oggi», come nel pannello del tempo di schermo del Blocco.
   I tre puntini cambiano cosa si guarda:
     · Deviazioni e sessioni (di serie)
     · Tempo perso e tempo investito — distrazioni + deviazioni contro il tempo in Full Focus
     · Le serie — giorni di fila della modalita' severa e delle sessioni di Full Focus
     · Ore di focus e mantra — per ultima: la meno legata a quello che cambia i risultati

   Sotto ai due numeri non c'e' piu' nessuna frase: il dettaglio sta nella «i».

   DA DOVE ARRIVANO LE DEVIAZIONI. Da `fl_deviazioni` (le scrive arbitro-claude.js quando legge
   la riga `fl:arbitro`), con i minuti di ogni deviazione misurati dall'hook di Claude (dal
   messaggio alla fine della risposta). I punti «fuori rotta» del tabellone scritti prima che
   questo registro esistesse si recuperano dallo storico della partita.
   =========================================================================================== */

const RO_VISTA_K = 'fl_ro_vista', RO_RANGE_K = 'fl_ro_range';
const RO_VISTE = [
  ['conta', 'Deviazioni e sessioni'],
  ['tempo', 'Tempo perso e tempo investito'],
  ['serie', 'Le serie'],
  ['focus', 'Ore di focus e mantra']
];
const RO_RANGES = (typeof SC_RANGES !== 'undefined') ? SC_RANGES
  : [['today', 'Oggi'], ['yesterday', 'Ieri'], ['7d', 'Ultimi 7 giorni'], ['30d', 'Ultimo mese'], ['365d', 'Ultimo anno'], ['all', 'Da sempre']];

function roLeggi(k, d){ try{ const v = localStorage.getItem(k); return v === null ? d : v; }catch(_){ return d; } }
function roVista(){ const v = roLeggi(RO_VISTA_K, 'conta'); return RO_VISTE.some(function(x){ return x[0] === v; }) ? v : 'conta'; }
function roRange(){ const v = roLeggi(RO_RANGE_K, 'today'); return RO_RANGES.some(function(x){ return x[0] === v; }) ? v : 'today'; }
function roFinestra(r){
  if (typeof scRangeWindow === 'function') return scRangeWindow(r);
  const d = new Date(); d.setHours(0, 0, 0, 0);
  return { from: d.getTime(), to: Date.now() };
}
function roFmt(ms){ return (typeof scFmtShort === 'function') ? scFmtShort(ms) : Math.round(ms / 60000) + 'min'; }

/* ---------------------------------------------------------------------------------------
   I DATI
   --------------------------------------------------------------------------------------- */
function roJSON(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
/** Le deviazioni, con i minuti quando l'hook li ha misurati. */
function roDeviazioni(){
  const reg = roJSON('fl_deviazioni', []) || [];
  const out = reg.map(function(e){ return { at: +e.at || 0, motivo: e.motivo || '', minuti: +e.minuti || 0 }; });
  /* i punti «fuori rotta» scritti prima del registro: dallo storico della partita */
  (roJSON('fl_match_hist', []) || []).forEach(function(g){
    ((g && g.eventi) || []).forEach(function(e){
      if (!e || e.chi !== 'old' || !/^fuori rotta/i.test(String(e.motivo || ''))) return;
      if (out.some(function(x){ return Math.abs(x.at - e.at) < 5 * 60000; })) return;
      out.push({ at: +e.at || 0, motivo: String(e.motivo).replace(/^fuori rotta:\s*/i, ''), minuti: 0 });
    });
  });
  return out;
}
function roSessioni(from, to){
  return (roJSON('fl_ff_hist', []) || []).filter(function(x){ return x && x.ok && !x.meditazione && x.at >= from && x.at < to; });
}
/** Il tempo sulle app che distraggono nel periodo: telefono (lo misura Android) + computer. */
async function roDistrazioniMs(r, w){
  let ms = 0;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE){
      if ((r === 'today' || r === 'yesterday') && typeof scReport === 'function' && typeof scDistractions === 'function'){
        const rep = await scReport(r === 'today' ? 0 : 1);
        if (rep && rep.granted) ms += scDistractions(rep);
      } else if (NATIVE.getTopApps && typeof scIsDistracting === 'function'){
        const t = await NATIVE.getTopApps({ from: w.from, to: w.to, limit: 200, by: 'ms' });
        const ex = (typeof scExcluded === 'function') ? scExcluded() : [];
        ms += ((t && t.apps) || []).filter(function(a){ return ex.indexOf(a.packageName) < 0 && !a.launcher && scIsDistracting(a.packageName); })
          .reduce(function(s, a){ return s + (a.ms || 0); }, 0);
      }
    }
  }catch(_){ }
  /* il computer: i minuti «distrazione» dei giorni del periodo che il PC ha mandato */
  try{
    if (typeof pcGiorno === 'function'){
      const giorni = Math.min(400, Math.ceil((w.to - w.from) / 86400000));
      const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
      const primo = Math.round((oggi.getTime() - new Date(w.from).setHours(0, 0, 0, 0)) / 86400000);
      for (let off = Math.max(0, primo - giorni + 1); off <= primo; off++){
        const d = pcGiorno(off);
        if (d && d.distr > 0) ms += d.distr * 60000;
      }
    }
  }catch(_){ }
  return ms;
}
/** Giorni di fila con almeno una sessione di Full Focus. */
function roSerieFF(){ try{ return (typeof serStreak === 'function') ? serStreak() : 0; }catch(_){ return 0; } }
/* LA STESSA SERIE DEL PANNELLO CON LA FIAMMA. Qui si leggeva scStreak(), che conta i giorni con
   un blocco qualsiasi acceso (10), mentre il pannello sotto conta i giorni di modalita' severa
   (6): due numeri diversi con lo stesso nome. Adesso tutte e due leggono fl_sev_streak, in sola
   lettura (sevStreakDays(false) la cancellerebbe). */
function roSerieSevera(){
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (!st || !st.start) return 0;
    if (typeof sevState !== 'undefined' && sevState !== null && !(sevState && sevState.level)) return 0;
    const oggi = (typeof blkToday === 'function') ? blkToday() : mtKey(Date.now());
    return Math.max(1, ((typeof blkDaysBetween === 'function') ? blkDaysBetween(st.start, oggi) : 0) + 1);
  }catch(_){ return 0; }
}

/* ---------------------------------------------------------------------------------------
   IL DISEGNO
   --------------------------------------------------------------------------------------- */
function roStat(ico, glow, num, cls, label, tip, d){
  return '<div class="pf-stat sev-rise" style="--d:' + d + 's" onclick="scTipAt(this.querySelector(\'i.q\'), ' + esc(JSON.stringify(tip)) + ', \'\')">'
    + '<span class="ico ' + glow + '">' + ico + '</span><b class="num ' + cls + '">' + num + '</b><small>' + label + '<i class="q">i</i></small></div>';
}
function roTesta(){
  const v = roVista();
  const conRange = v === 'conta' || v === 'tempo';
  const cur = (RO_RANGES.filter(function(x){ return x[0] === roRange(); })[0] || RO_RANGES[0])[1];
  return '<div class="ro-testa">'
    + (conRange ? '<button type="button" class="ro-range" onclick="roMenuRange(event)">' + esc(cur) + '<i></i></button>' : '')
    + '</div>';
}
async function roHtml(){
  const v = roVista();
  if (v === 'focus'){
    if (typeof scReport !== 'function' || typeof scFocusHtml !== 'function') return '';
    const r = await scReport(0);
    if (!r || !r.granted) return '<button class="bh-cta" onclick="openPerm(\'usage\')">Abilita i dati di utilizzo</button>';
    return scFocusHtml(scCompute(r), scStreak());
  }
  if (v === 'serie'){
    const sev = roSerieSevera(), ff = roSerieFF();
    return roStat('🔒', 'glow-mint', sev, 'mint', 'SEVERA DI FILA', 'Giorni di fila con la modalità severa accesa.', .62)
      + roStat('🔥', 'glow-fire', ff, 'gold', 'FULL FOCUS DI FILA', 'Giorni di fila con almeno una sessione di Full Focus portata a termine.', .78);
  }
  const r = roRange(), w = roFinestra(r);
  const dev = roDeviazioni().filter(function(e){ return e.at >= w.from && e.at < w.to; });
  const ses = roSessioni(w.from, w.to);
  if (v === 'tempo'){
    const devMs = dev.reduce(function(s, e){ return s + e.minuti * 60000; }, 0);
    const distrMs = await roDistrazioniMs(r, w);
    const ffMs = ses.reduce(function(s, x){ return s + (x.spentMs || 0); }, 0);
    const senza = dev.filter(function(e){ return !e.minuti; }).length;
    return roStat('🕳️', 'glow-red', roFmt(distrMs + devMs), 'red', 'TEMPO PERSO',
        'Distrazioni: ' + roFmt(distrMs) + '.\nDeviazioni fuori rotta: ' + roFmt(devMs) + (senza ? ' (' + senza + ' senza durata misurata)' : '') + '.', .62)
      + roStat('🎯', 'glow-mint', roFmt(ffMs), 'mint', 'TEMPO IN FULL FOCUS',
        'Il tempo passato dentro alle sessioni di Full Focus: ' + ses.length + (ses.length === 1 ? ' sessione' : ' sessioni') + '.', .78);
  }
  const ultima = dev.slice().sort(function(a, b){ return b.at - a.at; })[0];
  return roStat('🔀', 'glow-red', dev.length, 'red', 'DEVIAZIONI',
      'Le volte in cui hai aggiunto una cosa fuori rotta: ogni deviazione allontana l’arrivo.' + (ultima && ultima.motivo ? '\n\nL’ultima: ' + ultima.motivo + '.' : ''), .62)
    + roStat('🎯', 'glow-mint', ses.length, 'mint', 'SESSIONI FULL FOCUS',
      'Le sessioni di Full Focus portate a termine. Contano le sessioni, non le task.', .78);
}
let RO_T = 0;
async function roPaint(){
  const el = document.getElementById('sevHeroStats');
  if (!el) return;
  const mio = ++RO_T;
  const corpo = await roHtml();
  if (mio !== RO_T || !document.body.contains(el)) return;
  el.innerHTML = roTesta() + '<div class="ro-stats">' + corpo + '</div>';
  roDots(el);
  try{ if (typeof sevVistaProgressi === 'function') sevVistaProgressi(); }catch(_){ }
}
/** I tre puntini, in alto a destra della slide. */
function roDots(el){
  const slide = el.closest('.bh-slide, .sev-slide, [data-slide], .slide') || el.parentElement;
  if (!slide || slide.querySelector(':scope > .ro-dots')) return;
  if (getComputedStyle(slide).position === 'static') slide.style.position = 'relative';
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'pb-dots ro-dots'; b.setAttribute('aria-label', 'Cosa guardare'); b.textContent = '⋯';
  b.addEventListener('click', roMenuVista);
  slide.appendChild(b);
}
/* ---- i menu: stessa forma di quelli della mappa, fissati fuori dalle diapositive ---- */
function roMenuChiudi(){ ['roMenu', 'roVeil'].forEach(function(id){ const e = document.getElementById(id); if (e) e.remove(); }); }
function roMenu(ev, titolo, voci, attiva, azione){
  if (ev){ ev.stopPropagation(); ev.preventDefault(); }
  if (document.getElementById('roMenu')){ roMenuChiudi(); return; }
  const casa = (typeof flVeloCasa === 'function') ? flVeloCasa() : document.body;
  const veil = document.createElement('div'); veil.id = 'roVeil'; veil.className = 'arb-veil';
  veil.addEventListener('click', function(e){ e.stopPropagation(); roMenuChiudi(); });
  casa.appendChild(veil);
  const m = document.createElement('div'); m.id = 'roMenu'; m.className = 'arb-menu';
  m.innerHTML = '<p class="arb-mtit">' + titolo + '</p>' + voci.map(function(x){
    return '<button type="button" class="' + (x[0] === attiva ? 'on' : '') + '" onclick="' + azione + '(\'' + x[0] + '\')">' + x[1] + '</button>';
  }).join('');
  casa.appendChild(m);
  if (typeof flMenuFissa === 'function') flMenuFissa(m, ev && ev.currentTarget);
}
function roMenuVista(ev){ roMenu(ev, 'Cosa guardare', RO_VISTE, roVista(), 'roSetVista'); }
function roMenuRange(ev){ roMenu(ev, 'Periodo', RO_RANGES, roRange(), 'roSetRange'); }
function roSetVista(v){ try{ localStorage.setItem(RO_VISTA_K, v); }catch(_){ } roMenuChiudi(); roPaint(); }
function roSetRange(r){ try{ localStorage.setItem(RO_RANGE_K, r); }catch(_){ } roMenuChiudi(); roPaint(); }

/* LA SLIDE SI DIPINGE DA QUI: sevHeroStats (blkhero.js) mostrava ore di focus e mantra con una
   frase sotto; adesso chiama la rotta di oggi, e le ore di focus sono una delle quattro viste. */
if (typeof sevHeroStats === 'function'){
  sevHeroStats = async function(){
    if (typeof scMantraLoad === 'function') try{ await scMantraLoad(); }catch(_){ }
    return roPaint();
  };
}
document.addEventListener('fl:spunta', function(){ setTimeout(roPaint, 400); });
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(roPaint, 600); });
document.addEventListener('fl:deviazione', function(){ setTimeout(roPaint, 200); });

(function roStile(){
  const st = document.createElement('style');
  st.textContent = [
    '#sevHeroStats{position:relative;flex-wrap:wrap}',
    '.ro-testa{flex:0 0 100%;display:flex;justify-content:center;margin:-30px 0 12px}',
    '.ro-testa:empty{margin:0}',
    '.ro-range{display:inline-flex;align-items:center;gap:6px;border:0;background:rgba(255,255,255,.12);color:#fff;border-radius:99px;padding:5px 12px;font:700 12px var(--font-body);cursor:pointer}',
    '.ro-range i{width:0;height:0;border-left:4px solid transparent;border-right:4px solid transparent;border-top:5px solid rgba(255,255,255,.85)}',
    '.ro-stats{display:contents}',
    '.ro-dots{position:absolute;top:14px;right:14px;z-index:4}',
    /* sotto al cielo l'intestazione e' trasparente e alta --hdr-h: il pulsante scende sotto di lei */
    '.hero-top .ro-dots{top:calc(var(--hdr-h,64px) + 12px)}',
    '.pf-stat .glow-red{filter:drop-shadow(0 0 14px rgba(255,90,100,.85)) drop-shadow(0 0 4px rgba(255,120,120,.9))}',
    '.pf-stat .num.red{color:#FF8A94}'
  ].join('');
  document.head.appendChild(st);
})();
