/* ===========================================================================================
   AMICI — la parte sociale e di gioco dell'app, centrata sull'obiettivo, mai sul tempo in app

   Tre schede: AMICI (il pannello del Genio con l'invito, la classifica alla Sweatcoin, gli amici con i soli aggregati, la scheda amico con
   le reazioni, Focus insieme), SFIDE (sfide.js) e LEGA (la settimana, fino a trenta persone
   della stessa categoria, si sale e si scende). Il disegno viene dai prototipi di Claude Design
   del 26/09/2026 (progetti «Amici page design» e «DreamMap prototipo e direzioni»): card
   bianche, selettore a pillola, cielo notturno della Roadmap per la lega e per gli inviti,
   il Genio nello stato vuoto, una sola azione primaria per schermata.

   COSA VIAGGIA. Sul server (focuslockSocial.ts + focuslockArena.ts) vanno nome, soprannome,
   categoria e numeri, legati all'id casuale del telefono. Gli amici vedono ore di focus della
   settimana, giorni di fila, punteggio della partita e il delta settimanale, e dal 0.9.300 le metriche
   del confronto (tappe, giorni di severa, Full Focus, serie): niente app, niente rotta. Il tempo di
   schermo si condivide solo accendendolo a mano.

   IL PUNTEGGIO SETTIMANALE della classifica di sempre non cambia (frScore7). I PUNTI DELLA LEGA
   sono un'altra cosa: un punto per ogni minuto di Full Focus portato a termine (tetto 480 al
   giorno) e trenta per ogni passo della rotta spuntato. Li conta il telefono, li legge il server.
   =========================================================================================== */

const FR = { tab: 'amici', me: null, syncedAt: 0, amici: null, amiciAt: 0, lega: null, legaAt: 0, live: null, liveAt: 0, testi: null, offline: false, cat: '', scheda: null, inviati: {} };
const FR_SYNC_MS = 3 * 60 * 1000;
const FR_URL = 'https://dream-brothers.com/pages/focuslock';
/* 0.9.322, Andrea: "indaga quante leghe ha Duolingo e replicale". Sono dieci: stesso numero, nomi e colori nostri */
const FR_TIERS = ['bronzo', 'argento', 'oro', 'zaffiro', 'rubino', 'smeraldo', 'turchese', 'perla', 'ossidiana', 'diamante'];
const FR_REAZIONI = [{ k: 'cuore', e: '❤️' }, { k: 'grande', e: '👏' }, { k: 'continua', e: '🔥' }, { k: 'nonmollare', e: '💪' }, { k: 'centrato', e: '🎯' }];
const FR_CATEGORIE = ['studenti', 'imprenditori', 'lavoratori', 'creator', 'sportivi'];
const FR_CAT_ICO = { studenti: '🎓', imprenditori: '🚀', lavoratori: '💼', creator: '🎬', sportivi: '🏃' };
const FR_PAL = ['#3F9FF4', '#001E44', '#E63946', '#1B9E6A', '#005BB0', '#C2703E', '#0075E3'];
const FR_TIER = {
  bronzo:   { g: 'radial-gradient(circle at 35% 30%,#F3C49B,#C2703E 60%,#7A3F1C)', c: '#F3C49B' },
  argento:  { g: 'radial-gradient(circle at 35% 30%,#F2F5FA,#9AA6B8 60%,#5F6B7D)', c: '#DDE5EF' },
  oro:      { g: 'radial-gradient(circle at 35% 30%,#FFE9A8,#F5B301 60%,#B9741C)', c: '#FFD66B' },
  zaffiro:  { g: 'radial-gradient(circle at 35% 30%,#BCD4FF,#2F6FD6 60%,#163F8F)', c: '#7FB0FF' },
  rubino:   { g: 'radial-gradient(circle at 35% 30%,#FFC2C8,#E63946 60%,#8E1520)', c: '#FF8A92' },
  smeraldo: { g: 'radial-gradient(circle at 35% 30%,#BDF3D8,#1B9E6A 60%,#0D5C3D)', c: '#6FE3B4' },
  turchese: { g: 'radial-gradient(circle at 35% 30%,#C8F6F6,#2FB8C6 60%,#157582)', c: '#7FE4EC' },
  perla:    { g: 'radial-gradient(circle at 35% 30%,#FFFFFF,#E7DFD6 60%,#A99F93)', c: '#F2ECE4' },
  ossidiana:{ g: 'radial-gradient(circle at 35% 30%,#7E8AA0,#2A3142 60%,#0B0F18)', c: '#AEB8CC' },
  diamante: { g: 'radial-gradient(circle at 35% 30%,#E6F8FF,#6FC0FF 60%,#2F6FD6)', c: '#BCE8FF' }
};
const FR_TESTI_KEY = 'fl_amici_testi';
const FR_LEGA_CAP = 480;

/* ---------------------------------------------------------------- i testi */
function amT(k, vars){
  let v = FR.testi;
  String(k).split('.').forEach(function(p){ v = (v && typeof v === 'object') ? v[p] : undefined; });
  let s = (typeof v === 'string') ? v : String(k).split('.').pop();
  if (vars) Object.keys(vars).forEach(function(x){ s = s.split('{' + x + '}').join(String(vars[x])); });
  return s;
}
async function amTestiCarica(){
  if (!FR.testi){ try{ FR.testi = JSON.parse(localStorage.getItem(FR_TESTI_KEY) || 'null'); }catch(_){ } }
  try{
    const r = await fetch('content/amici.json', { cache: 'no-cache' });
    const j = await r.json();
    if (j && j.pagina){ FR.testi = j; try{ localStorage.setItem(FR_TESTI_KEY, JSON.stringify(j)); }catch(_){ } }
  }catch(_){ }
  return FR.testi;
}

/* ---------------------------------------------------------------- identita' e numeri */
function frDevice(){ return typeof ffDevice === 'function' ? ffDevice() : (localStorage.getItem('fl_device_id') || ''); }
function frName(){ try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); return u && u.name ? String(u.name).trim().slice(0, 24) : ''; }catch(_){ return ''; } }
function frNick(){ try{ return String(localStorage.getItem('fl_lega_nick') || '').trim().slice(0, 24); }catch(_){ return ''; } }
function frCategoria(){ try{ return String(localStorage.getItem('fl_lega_cat') || ''); }catch(_){ return ''; } }
/* la categoria suggerita dal sogno scelto con il Genio */
function frCategoriaSuggerita(){
  const c = frCategoria(); if (c) return c;
  try{
    const g = (typeof gnDati === 'function') ? gnDati() : null;
    const k = g && g.sognoK;
    if (k === 'lavoro' || k === 'soldi' || k === 'scrivo' || k === 'liberta' || k === 'progetto' || k === 'voce') return 'imprenditori';
    if (k === 'imparare' || k === 'sessione' || k === 'passione') return 'studenti';
  }catch(_){ }
  return 'lavoratori';
}
async function frApi(method, path, body){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.publicApi) throw new Error('offline');
  const r = await NATIVE.publicApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
  if (r && r.error) throw new Error(r.error);
  return r || {};
}
/* I numeri della settimana, da quello che il telefono tiene gia'. */
async function frStats(){
  let parts = null;
  if (typeof lvCompute === 'function'){ try{ parts = (await lvCompute()).parts; }catch(_){ parts = null; } }
  const info = typeof lvInfo === 'function' ? lvInfo() : { level: 1, xp: 0 };
  const since = Date.now() - 7 * 86400000;
  let ffMin7 = 0;
  try{ (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(s => { if (s && s.ok && s.at >= since) ffMin7 += (s.min || 0); }); }catch(_){ }
  let blocks7 = 0;
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getInsights){
    try{ const r = await NATIVE.getInsights({ days: 7 }); blocks7 = ((r && r.history) || []).reduce((a, h) => a + (h.blocks || 0), 0); }catch(_){ }
  }
  let neo = 0, old = 0;
  try{ const s = (typeof mtState === 'function') ? mtState() : null; if (s){ neo = +s.neo || 0; old = +s.old || 0; } }catch(_){ }
  let ffStreak = 0; try{ ffStreak = (typeof serStreak === 'function') ? serStreak() : 0; }catch(_){ }
  return { level: info.level, xp: info.xp, streak: parts ? parts.streak : 0, ffMin7: ffMin7, blocks7: blocks7, neo: neo, old: old, ffStreak: ffStreak };
}
/* LA FORMULA DELLA CLASSIFICA DI SEMPRE: non si tocca, sposterebbe la posizione di tutti. */
function frScore7(s){ return s.ffMin7 * 2 + s.blocks7 + s.streak * 5; }

/* ---- i punti della lega, contati sul telefono ---- */
function frSettimanaKey(t){
  const d = new Date(t || Date.now());
  const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const g = x.getUTCDay() || 7;
  x.setUTCDate(x.getUTCDate() + 4 - g);
  const inizio = new Date(Date.UTC(x.getUTCFullYear(), 0, 1));
  return x.getUTCFullYear() + '-W' + String(Math.ceil(((x - inizio) / 86400000 + 1) / 7)).padStart(2, '0');
}
function frLunedi(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); }
/* 0.9.335: il paese per la bandiera del podio, dalla lingua del telefono (it-IT -> IT); senza regione, dal fuso orario */
function frPaese(){
  try{
    const l = (navigator.languages && navigator.languages[0]) || navigator.language || '';
    const m = /[-_]([A-Za-z]{2})$/.exec(l); if (m) return m[1].toUpperCase();
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || '';
    const T = { 'Europe/Rome': 'IT', 'Europe/Madrid': 'ES', 'Europe/Paris': 'FR', 'Europe/Berlin': 'DE', 'Europe/London': 'GB', 'Europe/Lisbon': 'PT', 'Europe/Zurich': 'CH', 'America/New_York': 'US', 'America/Los_Angeles': 'US', 'America/Chicago': 'US' };
    return T[tz] || '';
  }catch(_){ return ''; }
}
/** Due lettere -> la bandiera (lettere regionali di Unicode). */
function frBandiera(p){ p = String(p || '').toUpperCase(); if (!/^[A-Z]{2}$/.test(p)) return ''; return String.fromCodePoint(0x1F1E6 + p.charCodeAt(0) - 65, 0x1F1E6 + p.charCodeAt(1) - 65); }
/** I punti di un giorno: minuti di Full Focus finiti (tetto 480) + 30 per passo della rotta. */
function frPuntiGiorno(dayStart){
  const a = dayStart, b = dayStart + 86400000;
  let min = 0;
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(h){ const t = h.start || h.at; if (h.ok && !h.meditazione && t >= a && t < b) min += Math.round((h.spentMs || (h.min || 0) * 60000) / 60000); }); }catch(_){ }
  min = Math.min(FR_LEGA_CAP, min);
  let passi = 0;
  try{
    const day = (typeof mtKey === 'function') ? mtKey(dayStart) : new Date(dayStart).toISOString().slice(0, 10);
    const oz = (typeof ozLeggi === 'function') ? ozLeggi() : {};
    Object.keys(oz).forEach(function(k){ ((oz[k] && oz[k].passi) || []).forEach(function(p){ if (p && p.fatto && p.il === day) passi++; }); });
  }catch(_){ }
  /* 0.9.287: anche l'XP delle tappe della Mappa conta per la lega (fine-tappa.js) */
  let xp = 0; try{ if (typeof ftXpDi === 'function') xp = ftXpDi(dayStart); }catch(_){ }
  return min + passi * 30 + xp;
}
function frPuntiLega(){
  let tot = 0;
  const lun = frLunedi();
  for (let t = lun; t <= Date.now(); t += 86400000) tot += frPuntiGiorno(t);
  return tot;
}

/* ---- la sync: i miei numeri su, il mio codice e la mia posizione giu' ---- */
/* ---- I COMANDI DELL'AGENTE (0.9.207): programmi, blocchi rapidi, roadmap, decisi dal tuo agente personale ---- */
function frComandiApplica(lista){
  const fatti = [];
  lista.forEach(function(c){
    let p = {}; try{ p = JSON.parse(c.payload || '{}'); }catch(_){ }
    try{
      if (c.tipo === 'programma') frProgrammaDaAgente(p, false);
      else if (c.tipo === 'blocco_rapido') frProgrammaDaAgente(p, true);
      /* 0.9.285: una regola su misura della partita, scritta dall'agente con i suoi strumenti */
      else if (c.tipo === 'regola'){ if (typeof rgmAggiungi === 'function'){ const ids = rgmAggiungi(p, 'agente'); if (ids.length) toast('Il tuo agente personale ha aggiunto una regola alla partita'); } }
      else if (c.tipo === 'imprevisto'){ if (typeof etaImprevistoDaAgente === 'function') etaImprevistoDaAgente(p); }
      else if (c.tipo === 'roadmap'){ localStorage.setItem('fl_roadmap_agente', JSON.stringify(Object.assign({ at: Date.now() }, p))); toast('Il tuo agente personale ha aggiornato la roadmap: ' + ((p.tappe || []).length) + ' tappe'); try{ document.dispatchEvent(new CustomEvent('fl:roadmap')); }catch(_){ } }
      fatti.push(c.id);
    }catch(_){ }
  });
  if (fatti.length) frApi('POST', '/api/focuslock/social/comandi/fatti', { device: frDevice(), ids: fatti }).catch(function(){ });
}
function frProgrammaDaAgente(p, rapido){
  if (typeof PROGRAMS === 'undefined' || typeof saveProgramsLocal !== 'function') return;
  const hhmm = function(d){ return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); };
  const now = new Date(), fine = new Date(Date.now() + (p.minuti || 25) * 60000);
  /* 0.9.279: anche il limite di utilizzo (minuti all'ora e/o al giorno), chiesto in chat al Genio */
  const limite = !rapido && (+p.minutiOra > 0 || +p.minutiGiorno > 0);
  const prog = {
    id: 'p' + Date.now().toString(36) + Math.random().toString(36).slice(2, 7),
    name: rapido ? 'Blocco rapido del tuo agente personale' : (p.nome || 'Dal tuo agente personale'), type: limite ? 'limite' : 'ora', icon: limite ? '⏳' : '🤖',
    from: rapido ? hhmm(now) : (p.dalle || '09:00'), to: rapido ? hhmm(fine) : (p.alle || '18:00'),
    qh: limite && +p.minutiOra > 0 ? Math.min(59, Math.round(+p.minutiOra)) : null, qd: limite && +p.minutiGiorno > 0 ? Math.min(1440, Math.round(+p.minutiGiorno)) : null,
    days: (!rapido && Array.isArray(p.giorni) && p.giorni.length === 7) ? p.giorni : [true, true, true, true, true, true, true],
    allDay: !rapido && !!p.tuttoIlGiorno, apps: p.app || [], sites: p.siti || [], keywords: p.parole || [], keywordsDove: p.dove || 'url', allow: [],
    blockLaunch: true, blockNotifications: true, on: true, agente: true, fine: rapido ? fine.getTime() : 0
  };
  PROGRAMS.push(prog); saveProgramsLocal();
  try{ if (typeof renderPrograms === 'function') renderPrograms(); }catch(_){ }
  try{ if (typeof pushRules === 'function') pushRules(); }catch(_){ }
  try{ if (typeof syncNative === 'function') syncNative(); }catch(_){ }
  if (!p.zitto) toast(rapido ? 'Il tuo agente personale ha acceso un blocco di ' + (p.minuti || 25) + ' minuti' : 'Il tuo agente personale ha creato "' + prog.name + '"');
  return prog.id;
}
async function frSync(force){
  const name = frName();
  if (!force && Date.now() - FR.syncedAt < FR_SYNC_MS) return FR.me;
  const st = await frStats();
  let rec = null; try{ rec = JSON.parse(localStorage.getItem('fl_records') || 'null'); }catch(_){ }
  const strictOn = !!(typeof sevState !== 'undefined' && sevState && sevState.level > 0);
  let motto = '';
  try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); motto = (u && u.bio) ? String(u.bio).trim().slice(0, 160) : ''; }catch(_){ }
  try{
    let goal = '', profile = '';
    try{ const o = JSON.parse(localStorage.getItem('fl_oracle') || 'null'); if (o){ goal = o.target || ''; profile = o.profile || ''; } }catch(_){ }
    const decisions = (typeof decPoints === 'function') ? decPoints() : 0;
    const prev = frLastWeek();
    /* 0.9.300: i numeri del confronto fra amici e in lega (tappe, severa, Full Focus, serie; lo schermo solo se condiviso) */
    let metriche = null; try{ metriche = frMetPubbliche(await frMetriche()); }catch(_){ }
    const r = await frApi('POST', '/api/focuslock/social/sync', Object.assign({ device: frDevice(), name: name, strictOn: strictOn, motto: motto, metriche: metriche,
      goal: goal, profile: profile, decisions: decisions,
      bestFocusH: rec ? rec.focusH || 0 : 0, bestStreak: rec ? rec.streak || 0 : 0,
      nick: frNick(), prevScore7: prev === null ? 0 : prev, attivita: frAttivitaMia(), emailHash: FR.emailHash || '', telHash: FR.telHash || '',
      legaPunti: frPuntiLega(), legaSettimana: frSettimanaKey(),
      sfide: (typeof sfAttive === 'function') ? sfAttive() : [] }, st));
    FR.me = Object.assign({ name: name, score7: frScore7(st) }, st, r);
    FR.syncedAt = Date.now();
    FR.offline = false;
    if (r.live) FR.live = r.live;
    frWeekRemember(st);
    frApplicaPass(r.premiumUntil);
    try{ if (r.comandi && r.comandi.length) frComandiApplica(r.comandi); }catch(_){ }
    try{ localStorage.setItem('fl_fr_me', JSON.stringify(FR.me)); }catch(_){ }
    return FR.me;
  }catch(e){
    FR.offline = true;
    if (!FR.me){ try{ FR.me = JSON.parse(localStorage.getItem('fl_fr_me') || 'null'); }catch(_){ } }
    return FR.me;
  }
}
function frSyncMaybe(){ frSync(false).catch(function(){}); }

/* ---------------------------------------------------------------- I NUMERI DEL CONFRONTO (0.9.300)
   Sotto "I tuoi amici", come su Sweatcoin: Oggi / Questa settimana / Questo mese / Serie, e cosa si
   confronta: tempo di schermo, tappe della roadmap, giorni di Modalita' severa, serie di giorni con
   almeno una tappa. Il telefono conta i suoi numeri (oggi, da lunedi', dal primo del mese) e li
   pubblica con la sync nel campo "metriche"; il server li passa agli amici (/social/amici) e alla
   lega (/social/lega). Il tempo di schermo esce dal telefono solo con l'interruttore della privacy
   acceso: per gli altri resta un trattino. Ogni numero ha la sua data: quello di un altro giorno non
   vale per oggi. */
const FR_PERIODI = ['oggi', 'settimana', 'mese'];
const FR_METRICHE = ['schermo', 'tappe', 'severa', 'serie'];
const FR_MET_ICO = { schermo: '📱', tappe: '🗺️', severa: '🔒', serie: '🔥' };
const FR_LEGA_ORD = ['punti', 'tappe', 'ff', 'schermo', 'severa', 'serie'];
/* L'OBIETTIVO DI OGNI LEGA, l'ordine con cui si apre la classifica. Studenti e lavoratori: le ore di
   concentrazione vera (studio e lavoro profondo). Imprenditori e creator: le tappe della roadmap,
   perche' per chi costruisce qualcosa conta il passo fatto verso il progetto, non le ore passate
   alla scrivania. Sportivi: la serie, perche' nello sport vince la costanza. La lega generale: i punti. */
const FR_LEGA_OBIETTIVO = { studenti: 'ff', lavoratori: 'ff', imprenditori: 'tappe', creator: 'tappe', sportivi: 'serie' };
function frK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function frMeseK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0'); }
function frMese0(t){ const d = new Date(t || Date.now()); d.setHours(0, 0, 0, 0); d.setDate(1); return d.getTime(); }
/** I giorni con la Modalita' severa accesa: quelli segnati qui ogni volta che l'app la trova accesa, piu'
    tutti i giorni della serie della severa in corso (fl_sev_streak, da quando e' stata armata). */
function frSevGiorni(){
  let l = []; try{ l = JSON.parse(localStorage.getItem('fl_sev_giorni') || '[]') || []; }catch(_){ l = []; }
  const oggi = frK(Date.now());
  const on = !!(typeof sevState !== 'undefined' && sevState && sevState.level > 0);
  if (on && l.indexOf(oggi) < 0){ l.push(oggi); l = l.slice(-120); try{ localStorage.setItem('fl_sev_giorni', JSON.stringify(l)); }catch(_){ } }
  const set = {}; l.forEach(function(k){ set[k] = 1; });
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (st && /^\d{4}-\d{2}-\d{2}$/.test(st.start || '')){
      const p = st.start.split('-').map(Number);
      let t = new Date(p[0], p[1] - 1, p[2], 12).getTime();
      for (let i = 0; i < 400 && frK(t) <= oggi; i++, t += 86400000) set[frK(t)] = 1;
    }
  }catch(_){ }
  return set;
}
/** I miei numeri: { giorno, lunedi, mese, tappe:{g,s,m}, severa:{g,s,m}, ff:{g,s,m}, schermo:{g,s,m}|null, serie }. */
async function frMetriche(){
  const ora = Date.now(), lun = frLunedi(), m0 = frMese0();
  const kG = frK(ora), kL = frK(lun), kM = frK(m0);
  const tre = function(somma){ return { g: somma(kG), s: somma(kL), m: somma(kM) }; };
  const sommaDa = function(mappa){ return function(da){ let n = 0; Object.keys(mappa).forEach(function(k){ if (k >= da && k <= kG && mappa[k] > 0) n += mappa[k]; }); return n; }; };
  let gf = {}; try{ if (typeof sdGiorniFatti === 'function') gf = sdGiorniFatti() || {}; }catch(_){ gf = {}; }
  const sev = frSevGiorni();
  const ffg = {};
  try{ (typeof ffHist === 'function' ? ffHist() : []).forEach(function(h){ const t = h.start || h.at; if (h && h.ok && !h.meditazione && t >= Math.min(lun, m0)){ const k = frK(t); ffg[k] = (ffg[k] || 0) + Math.round((h.spentMs || (h.min || 0) * 60000) / 60000); } }); }catch(_){ }
  let schermo = null;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getScreenTimeRange){
      const r = await NATIVE.getScreenTimeRange({ from: Math.min(lun, m0), to: ora, bucket: 'day' });
      if (r && r.granted !== false && Array.isArray(r.buckets)){
        const sg = {}; r.buckets.forEach(function(b){ const k = frK(b.start); sg[k] = (sg[k] || 0) + Math.round((b.ms || 0) / 60000); });
        schermo = tre(sommaDa(sg));
      }
    }
  }catch(_){ schermo = null; }
  let serie = 0; try{ serie = (typeof sdSerieMappa === 'function') ? sdSerieMappa() : ((typeof hdSerie === 'function') ? hdSerie() : 0); }catch(_){ }
  FR.mieMet = { v: 1, giorno: kG, lunedi: kL, mese: frMeseK(ora), tappe: tre(sommaDa(gf)), severa: tre(sommaDa(sev)), ff: tre(sommaDa(ffg)), schermo: schermo, serie: serie || 0, paese: frPaese() };
  return FR.mieMet;
}
/** Quello che esce dal telefono: il tempo di schermo solo con l'interruttore della privacy acceso. */
function frMetPubbliche(M){
  if (!M) return null;
  let extra = false; try{ extra = localStorage.getItem('fl_privacy_extra') === '1'; }catch(_){ }
  return Object.assign({}, M, { schermo: extra ? M.schermo : null });
}
/** Il numero di una persona per metrica e periodo; null = non lo sappiamo (trattino). */
function frMetVal(M, met, per){
  if (!M || typeof M !== 'object') return null;
  const oggi = frK(Date.now());
  if (met === 'serie' || per === 'serie'){
    /* una serie letta prima di ieri puo' essersi gia' spezzata: non la mostriamo */
    return (M.giorno === oggi || M.giorno === frK(Date.now() - 86400000)) ? (+M.serie || 0) : null;
  }
  const v = M[met]; if (!v || typeof v !== 'object') return null;
  const campo = per === 'oggi' ? 'g' : (per === 'mese' ? 'm' : 's');
  const suo = per === 'oggi' ? M.giorno : (per === 'mese' ? M.mese : M.lunedi);
  const mio = per === 'oggi' ? oggi : (per === 'mese' ? frMeseK(Date.now()) : frK(frLunedi()));
  if (suo === mio) return Math.max(0, +v[campo] || 0);
  /* numeri di un periodo passato: tappe e Full Focus si fanno solo dentro l'app, che li pubblica appena
     si apre; chi non l'ha aperta in questo periodo ne ha fatti zero. Severa e schermo invece no. */
  return (met === 'tappe' || met === 'ff') ? 0 : null;
}
function frMetFmt(met, v){
  if (v === null || v === undefined) return '-';
  if (met === 'punti') return (v || 0).toLocaleString('it-IT') + ' pt';
  if (met === 'tappe') return v === 1 ? '1 tappa' : v + ' tappe';
  if (met === 'severa' || met === 'serie') return v === 1 ? '1 giorno' : v + ' giorni';
  return frOre(v);
}
/** Ordina dal migliore: meno schermo e' meglio, per tutto il resto di piu' e' meglio; chi non ha il numero in fondo. */
function frMetOrdina(righe, met){
  return righe.sort(function(x, y){
    if (x.v === null && y.v === null) return x.a.me ? -1 : (y.a.me ? 1 : 0);
    if (x.v === null) return 1;
    if (y.v === null) return -1;
    const d = met === 'schermo' ? x.v - y.v : y.v - x.v;
    if (d) return d;
    return x.a.me ? -1 : (y.a.me ? 1 : 0);
  });
}
/* il pass ospite arriva dal server come data: si applica come quello del partner */
function frApplicaPass(premiumUntil){
  if (!premiumUntil) return;
  try{
    const cur = localStorage.getItem('fl_premium_until');
    const server = new Date(premiumUntil).getTime(), local = cur ? new Date(cur).getTime() : 0;
    if (server > local){ localStorage.setItem('fl_premium_until', new Date(server).toISOString()); if (typeof Premium !== 'undefined' && Premium._notify) Premium._notify(); if (typeof renderProfile === 'function') renderProfile(); }
  }catch(_){ }
}
/* Il punteggio della settimana scorsa, tenuto sul telefono: e' il «batti te stesso». */
function frWeekKey(d){ const x = new Date(d); x.setHours(0, 0, 0, 0); x.setDate(x.getDate() - ((x.getDay() + 6) % 7)); return x.getFullYear() + '-' + (x.getMonth() + 1) + '-' + x.getDate(); }
function frWeekRemember(st){
  let w = {}; try{ w = JSON.parse(localStorage.getItem('fl_fr_weeks') || '{}') || {}; }catch(_){ w = {}; }
  w[frWeekKey(Date.now())] = frScore7(st);
  try{ localStorage.setItem('fl_fr_weeks', JSON.stringify(w)); }catch(_){ }
}
function frLastWeek(){
  let w = {}; try{ w = JSON.parse(localStorage.getItem('fl_fr_weeks') || '{}') || {}; }catch(_){ w = {}; }
  const k = frWeekKey(Date.now() - 7 * 86400000);
  return typeof w[k] === 'number' ? w[k] : null;
}
async function frLiveLoad(){
  if (FR.liveAt && Date.now() - FR.liveAt < 2 * 60 * 1000) return FR.live;
  try{ const r = await frApi('GET', '/api/focuslock/social/live'); if (r && typeof r.installs === 'number'){ FR.live = r; FR.liveAt = Date.now(); try{ localStorage.setItem('fl_fr_live', JSON.stringify(r)); }catch(_){ } } }
  catch(_){ if (!FR.live){ try{ FR.live = JSON.parse(localStorage.getItem('fl_fr_live') || 'null'); }catch(__){ } } }
  return FR.live;
}
setTimeout(frSyncMaybe, 4000);
setTimeout(amTestiCarica, 1500);

/* ---------------------------------------------------------------- i dati della pagina */
async function frAmiciCarica(forza){
  if (!forza && FR.amici && Date.now() - FR.amiciAt < 60000) return FR.amici;
  try{
    const r = await frApi('GET', '/api/focuslock/social/amici?device=' + encodeURIComponent(frDevice()));
    FR.amici = r; FR.amiciAt = Date.now();
    try{ localStorage.setItem('fl_fr_amici', JSON.stringify(r)); }catch(_){ }
  }catch(_){ if (!FR.amici){ try{ FR.amici = JSON.parse(localStorage.getItem('fl_fr_amici') || 'null'); }catch(__){ } } }
  return FR.amici;
}
async function frLegaCarica(forza){
  if (!forza && FR.lega && Date.now() - FR.legaAt < 60000) return FR.lega;
  try{
    const r = await frApi('GET', '/api/focuslock/social/lega?device=' + encodeURIComponent(frDevice()));
    FR.lega = r; FR.legaAt = Date.now();
    try{ localStorage.setItem('fl_fr_lega', JSON.stringify(r)); }catch(_){ }
    if (r && r.optIn) frLegaAvviso();
  }catch(_){ if (!FR.lega){ try{ FR.lega = JSON.parse(localStorage.getItem('fl_fr_lega') || 'null'); }catch(__){ } } }
  return FR.lega;
}
async function frCarica(){
  await Promise.all([
    frAmiciCarica(true).catch(function(){}),
    frLegaCarica(true).catch(function(){}),
    (typeof sfCarica === 'function') ? sfCarica().then(function(){ return sfContaCarica(); }).then(function(){ return sfAggiorna(); }).catch(function(){}) : Promise.resolve(),
    (typeof inSync === 'function') ? inSync().catch(function(){}) : Promise.resolve()
  ]);
  frPaint();
}

/* ---------------------------------------------------------------- la pagina */
registerScreen('s-friends', `
  <div class="topbar"><button class="iconbtn" onclick="goId('s-home')">‹</button><b class="blk-title" id="frTitolo">Amici</b>
    <button class="iconbtn fr-tre blk-right" id="frTre" onclick="frMenu()" aria-label="Aggiungi un amico o condividi il tuo codice"><svg viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg></button></div>
  <div id="frBody"><div class="ins-load">Leggo…</div></div>
  <div class="spacer"></div>
`, { back: 's-home' });

async function frOpen(tab){
  if (tab) FR.tab = tab;
  goId('s-friends');
  await amTestiCarica();
  const t = document.getElementById('frTitolo'); if (t) t.textContent = amT('pagina.titolo');
  if (!frName()){ frPaintNoName(); return; }
  frPaint();
  await frSync(true);
  frCarica();
}
function frPaintNoName(){
  const b = document.getElementById('frBody'); if (!b) return;
  b.innerHTML = '<div class="am-vuoto"><div class="am-vuoto-art"><i class="am-glow"></i><img src="img/genio/genio-saluta.png" alt=""><span class="am-tu">Tu</span><span class="am-piu">+</span></div>'
    + '<h2>' + esc(amT('pagina.nome.titolo')) + '</h2><p>' + esc(amT('pagina.nome.sotto')) + '</p>'
    + '<button type="button" class="am-cta" onclick="profileAuth()">' + esc(amT('pagina.nome.btn')) + '</button></div>';
}
function frTab(t){ FR.tab = t; frPaint(); if (t === 'lega') frLegaCarica(false).then(frPaint); if (t === 'amici') frAmiciCarica(false).then(frPaint); }
function frPaint(){
  const b = document.getElementById('frBody'); if (!b) return;
  if (!frName()){ frPaintNoName(); return; }
  /* 0.9.309, Andrea: via il motto "Cambia il gioco: il mondo è già pieno di giocatori." sopra alle schede */
  let html = '';
  if (FR.offline) html += '<p class="am-offline">' + esc(amT('pagina.offline')) + '</p>';
  /* 0.9.332, Andrea: "cosa vedono gli amici sembra una lista della spesa": tre puntini accanto al +, solo nella scheda Social */
  /* 0.9.341: i tre puntini ci sono in tutte le schede (il "+" non c'e' piu') */
  html += '<div class="fr-tabs">' + ['amici', 'sfide', 'lega'].map(function(k){ return '<button type="button"' + (FR.tab === k ? ' class="on"' : '') + ' onclick="frTab(\'' + k + '\')">' + esc(amT('pagina.tab.' + k)) + '</button>'; }).join('') + '</div>';
  if (FR.tab === 'amici') html += frAmiciHtml();
  else if (FR.tab === 'lega') html += frLegaHtml();
  else html += (typeof sfPaginaHtml === 'function') ? sfPaginaHtml() : '';
  b.innerHTML = html;
}

/* ---------------------------------------------------------------- pezzi comuni */
function frColore(seed){ let h = 0; String(seed || '').split('').forEach(function(c){ h = (h * 31 + c.charCodeAt(0)) >>> 0; }); return FR_PAL[h % FR_PAL.length]; }
/* 0.9.323, Andrea: "nelle Sfide c'e' solo l'iniziale, deve esserci la stessa immagine dell'account" */
function flAvMio(cls){ let pic = ''; try{ pic = (typeof flImgGet === 'function' && typeof UF_AVATAR_KEY !== 'undefined') ? flImgGet(UF_AVATAR_KEY) : ''; }catch(_){ } return pic ? '<span class="am-av me' + (cls ? ' ' + cls : '') + '" style="background:url(' + pic + ') center/cover"></span>' : ''; }
function frAv(nome, seed, cls){ return '<span class="am-av' + (cls ? ' ' + cls : '') + '" style="background:' + frColore(seed || nome) + '">' + esc(String(nome || '?').charAt(0).toUpperCase()) + '</span>'; }
function frOre(min){ min = Math.max(0, Math.round(min || 0)); if (min < 60) return min + ' min'; return Math.floor(min / 60) + 'h ' + String(min % 60).padStart(2, '0') + 'm'; }
function frDeltaHtml(cur, prev, esteso){
  if (!prev && !cur) return '';
  const d = (cur || 0) - (prev || 0);
  const cls = d > 0 ? 'up' : (d < 0 ? 'down' : 'flat');
  const t = (d > 0 ? '↗ +' + d : (d < 0 ? '↘ ' + d : '= 0')) + ' ' + amT('amici.riga.pt');
  return '<span class="am-delta ' + cls + '">' + (esteso ? esc(amT('amici.scheda.delta', { d: t })) : t) + '</span>';
}
function frTierIco(t){ return { bronzo: '🥉', argento: '🥈', oro: '🥇', zaffiro: '🔷', rubino: '♦️', smeraldo: '💚', turchese: '💠', perla: '🤍', ossidiana: '🖤', diamante: '💎' }[t] || '🥉'; }
/* la coppa di una lega */
/* 0.9.326, Andrea: "tutte uguali, cambia solo il colore: fanno cagare, non variano come i trofei di Mario Kart". Ogni lega ha la sua forma, disegnata qui. */
const FR_COPPA_F = {
  /* bronzo: la tazza semplice, due maniglie tonde */
  bronzo: '<path d="M20 14h40v14c0 16-8 26-20 26S20 44 20 28z" fill="url(#G)" stroke="S" stroke-width="2"/><path d="M20 18H10v8c0 8 5 13 12 14M60 18h10v8c0 8-5 13-12 14" fill="none" stroke="C" stroke-width="4.500" stroke-linecap="round"/><rect x="35" y="54" width="10" height="12" fill="C"/><rect x="24" y="66" width="32" height="10" rx="3" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* argento: il calice alto, con le ali */
  argento: '<path d="M26 6h28l-3 26c-1 9-5 14-11 14s-10-5-11-14z" fill="url(#G)" stroke="S" stroke-width="2"/><path d="M27 12C14 10 6 14 4 24c8-3 15-1 24 8M53 12c13-2 21 2 23 12-8-3-15-1-24 8" fill="url(#G)" stroke="S" stroke-width="2" stroke-linejoin="round"/><path d="M37 46h6v20h-6z" fill="C"/><path d="M26 80c1-8 7-14 14-14s13 6 14 14z" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* oro: la coppa grande con la stella */
  oro: '<path d="M16 6h48v18c0 20-10 32-24 32S16 44 16 24z" fill="url(#G)" stroke="S" stroke-width="2"/><path d="M16 12H5c0 16 6 24 16 27M64 12h11c0 16-6 24-16 27" fill="none" stroke="C" stroke-width="4.500" stroke-linecap="round"/><path d="M40 14l4.500 9.500 10.500 1.300-7.700 7.200 2 10.300L40 37l-9.300 5 2-10.300L25 24.800l10.500-1.300z" fill="#fff" opacity=".92"/><rect x="35" y="56" width="10" height="10" fill="C"/><path d="M22 84l4-18h28l4 18z" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* zaffiro: la coppa a facce, con la gemma */
  zaffiro: '<path d="M20 6h40l8 14-10 26-18 10-18-10-10-26z" fill="url(#G)" stroke="S" stroke-width="2" stroke-linejoin="round"/><path d="M12 20h56M30 6l-6 14 16 36 16-36-6-14M24 20l16-14 16 14" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="1.600"/><rect x="36" y="56" width="8" height="12" fill="C"/><path d="M24 80l6-12h20l6 12z" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* rubino: la corona sull'orlo e la pietra al centro */
  rubino: '<path d="M16 4l9 9 7-11 8 11 8-11 7 11 9-9-2 24c-1 18-10 28-22 28S19 46 18 28z" fill="url(#G)" stroke="S" stroke-width="2" stroke-linejoin="round"/><path d="M40 22l10 10-10 12-10-12z" fill="#fff" opacity=".9"/><path d="M40 22v22M30 32h20" stroke="C" stroke-width="1.500"/><rect x="35" y="56" width="10" height="11" fill="C"/><rect x="22" y="67" width="36" height="11" rx="5.500" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* smeraldo: lo scudo a otto lati, taglio smeraldo */
  smeraldo: '<path d="M26 4h28l14 14v22L54 54H26L12 40V18z" fill="url(#G)" stroke="S" stroke-width="2" stroke-linejoin="round"/><path d="M31 14h18l9 9v12l-9 9H31l-9-9V23z" fill="#fff" fill-opacity=".28" stroke="#fff" stroke-opacity=".7" stroke-width="1.600"/><path d="M36 54h8v14h-8z" fill="C"/><path d="M20 84c0-10 9-16 20-16s20 6 20 16z" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* turchese: la coppa a onda, con la goccia */
  turchese: '<path d="M14 12c6-6 13-6 19 0s13 6 19 0 10-5 14-2c0 26-10 46-26 46S14 38 14 12z" fill="url(#G)" stroke="S" stroke-width="2"/><path d="M40 24c5 7 8 11 8 15a8 8 0 0 1-16 0c0-4 3-8 8-15z" fill="#fff" opacity=".9"/><path d="M37 56h6l3 12H34z" fill="C"/><path d="M24 80c0-7 7-12 16-12s16 5 16 12z" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* perla: la conchiglia aperta con la perla in cima */
  perla: '<path d="M40 56C22 56 10 42 10 26c6-4 10-4 14 0 2-6 6-8 8-8 3 0 5 2 8 6 3-4 5-6 8-6 2 0 6 2 8 8 4-4 8-4 14 0 0 16-12 30-30 30z" fill="url(#G)" stroke="S" stroke-width="2" stroke-linejoin="round"/><path d="M40 56L24 26M40 56V24M40 56l16-30" stroke="#fff" stroke-opacity=".7" stroke-width="1.600" fill="none"/><circle cx="40" cy="10" r="8" fill="#fff" stroke="S" stroke-width="2"/><path d="M36 56h8v12h-8z" fill="C"/><path d="M26 82l4-14h20l4 14z" fill="url(#G)" stroke="S" stroke-width="2"/>',
  /* ossidiana: lame scure e angoli vivi */
  ossidiana: '<path d="M40 2l8 14 16-8-4 18 14 2-16 14-6 14H28l-6-14L6 28l14-2-4-18 16 8z" fill="url(#G)" stroke="#8CC6FF" stroke-width="2" stroke-linejoin="round"/><path d="M40 16l9 14-9 16-9-16z" fill="#8CC6FF" opacity=".85"/><path d="M34 56h12l2 12H32z" fill="C" stroke="#8CC6FF" stroke-width="1.500"/><path d="M20 84l8-16h24l8 16z" fill="url(#G)" stroke="#8CC6FF" stroke-width="2"/>',
  /* diamante: il diamante sul piedistallo */
  diamante: '<path d="M22 6h36l16 18-34 36L6 24z" fill="url(#G)" stroke="S" stroke-width="2" stroke-linejoin="round"/><path d="M6 24h68M22 6l10 18 8 36 8-36 10-18M32 24l8-18 8 18" fill="none" stroke="#fff" stroke-opacity=".75" stroke-width="1.600"/><path d="M36 60h8v8h-8z" fill="C"/><path d="M18 84l6-16h32l6 16z" fill="url(#G)" stroke="S" stroke-width="2"/>'
};
function frCoppa(t, pre){
  const T = FR_TIER[t] || FR_TIER.bronzo, id = 'frC' + (pre || '') + t;
  const forma = (FR_COPPA_F[t] || FR_COPPA_F.bronzo).replace(/url\(#G\)/g, 'url(#' + id + ')').replace(/stroke="S"/g, 'stroke="rgba(0,20,60,.45)"').replace(/"C"/g, '"' + T.c + '"');
  return '<svg viewBox="0 0 80 92" aria-hidden="true"><defs><linearGradient id="' + id + '" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".9"/><stop offset=".45" stop-color="' + T.c + '"/><stop offset="1" stop-color="' + T.c + '" stop-opacity=".62"/></linearGradient></defs>' + forma + '</svg>';
}
function frJs(v){ return JSON.stringify(String(v == null ? '' : v)).replace(/"/g, '&quot;'); }

/* ---------------------------------------------------------------- scheda AMICI */
/* IL PANNELLO DEL GENIO (0.9.300, Andrea: "rimetti quello di prima"): il Genio al centro sul gradiente
   rosa-azzurro, "Tu" e "+" ai lati, "Concentrarsi è più facile in due", l'invito e il codice da copiare.
   Era lo stato vuoto del prototipo di Claude Design; adesso sta in cima alla scheda anche con gli amici,
   al posto della card "Pass Ospite". Con gli amici il pulsante dice "Invita un altro amico". */
function frGenioHtml(conAmici){
  const code = (FR.me && FR.me.code) || '';
  const premio = amT('amici.vuoto.premio');
  const sotto = esc(amT('amici.vuoto.sotto')).split(esc(premio)).join('<b>' + esc(premio) + '</b>');
  return '<div class="am-vuoto"><div class="am-vuoto-art"><i class="am-glow"></i><img src="img/genio/genio-saluta.png" alt=""><span class="am-tu">Tu</span><span class="am-piu">+</span></div>'
    + '<h2>' + esc(amT('amici.vuoto.titolo')) + '</h2><p>' + sotto + '</p>'
    + '<button type="button" class="am-cta" onclick="frInvite()">' + esc(amT(conAmici ? 'amici.vuoto.btnAltro' : 'amici.vuoto.btn')) + '</button>'
    + (code ? '<button type="button" class="am-link" onclick="frCopia()">' + esc(amT('amici.vuoto.copia')) + ' · <b>' + esc(code) + '</b></button>' : '') + '</div>';
}
/* ---------- LA CLASSIFICA DEGLI AMICI (0.9.300), come su Sweatcoin ----------
   Titolo "I tuoi amici" con "Cerca amici" a destra, le pillole del periodo, cosa si confronta, poi le
   righe numerate: tu e i tuoi amici, e i posti liberi fino a cinque ("Aggiungi amico"). */
const FR_LENTE = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>';
const FR_PIU = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>';
function frConf(){
  if (!FR.conf){
    let c = null; try{ c = JSON.parse(localStorage.getItem('fl_fr_conf') || 'null'); }catch(_){ c = null; }
    /* prima "Serie" era anche un periodo */
    if (c && c.per === 'serie') c = { per: 'settimana', met: 'serie' };
    FR.conf = (c && FR_PERIODI.indexOf(c.per) >= 0 && FR_METRICHE.indexOf(c.met) >= 0) ? c : { per: 'oggi', met: 'tappe' };
  }
  return FR.conf;
}
/* 0.9.316, Andrea: una fila sola di schede scorrevoli (cosa si confronta); il periodo sta nei tre puntini accanto a Cerca amici.
   La serie non ha un periodo: per lei i tre puntini non ci sono. */
function frConfScegli(per, met){
  const c = frConf();
  if (per) c.per = per;
  if (met) c.met = met;
  try{ localStorage.setItem('fl_fr_conf', JSON.stringify(c)); }catch(_){ }
  try{ flVibra(8); }catch(_){ }
  const w = document.getElementById('frClW'); if (w) w.outerHTML = frClassificaHtml();
  frChipInVista('.am-met');
}
const FR_TRE_PUNTI = '<svg viewBox="0 0 24 24" width="22" height="22" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="19" cy="12" r="2"/></svg>';
function frPeriodoApri(){
  if (typeof inSheet !== 'function') return;
  const c = frConf();
  inSheet('<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<b class="am-sh-title am-per-t">' + esc(amT('amici.classifica.periodoTitolo')) + '</b><div class="am-per">'
    + FR_PERIODI.map(function(p){ return '<button type="button" class="' + (c.per === p ? 'on' : '') + '" onclick="frPeriodoScegli(\'' + p + '\')"><span>' + esc(amT('amici.classifica.periodi.' + p)) + '</span>' + (c.per === p ? '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12.500l5 5 9-10.500"/></svg>' : '') + '</button>'; }).join('')
    + '</div></div>');
}
function frPeriodoScegli(p){ frConfScegli(p); try{ inSheetChiudi(); }catch(_){ } }
function frCercaDaAmici(){ FR.trovaDa = 'amici'; frCercaApri(); }
function frClassificaHtml(){
  /* la scheda scelta si vede sempre, anche quando sta in fondo alla fila */
  setTimeout(function(){ frChipInVista('.am-met'); }, 0);
  const c = frConf();
  const lista = (FR.amici && FR.amici.amici) || [];
  const io = { me: true, device: frDevice() || 'io', nome: frName() || amT('amici.classifica.tu'), metriche: FR.mieMet };
  const righe = frMetOrdina([io].concat(lista).map(function(a){ return { a: a, v: frMetVal(a.metriche, c.met, c.per) }; }), c.met);
  const trattino = righe.some(function(r){ return r.v === null && !r.a.me; });
  let h = '<div id="frClW">'
    + '<div class="am-cl-h"><b>' + esc(amT('amici.lista')) + '</b><button type="button" class="am-cerca" onclick="frCercaDaAmici()">' + FR_LENTE + '<span>' + esc(amT('amici.classifica.cerca')) + '</span></button>'
    + (c.met === 'serie' ? '' : '<button type="button" class="am-punti" onclick="frPeriodoApri()" aria-label="' + esc(amT('amici.classifica.periodoTitolo')) + '">' + FR_TRE_PUNTI + '</button>') + '</div>'
    + '<div class="am-met">' + FR_METRICHE.map(function(m){ return '<button type="button"' + (c.met === m ? ' class="on"' : '') + ' onclick="frConfScegli(null,\'' + m + '\')"><span class="am-met-i">' + FR_MET_ICO[m] + '</span>' + esc(amT('amici.classifica.metriche.' + m)) + '</button>'; }).join('') + '</div>'
    + '<p class="am-cl-sp">' + (c.met === 'serie' ? '' : '<b>' + esc(amT('amici.classifica.periodi.' + c.per)) + '.</b> ') + esc(amT('amici.classifica.spiega.' + c.met)) + '</p>'
    + '<div class="am-cl">';
  righe.forEach(function(r, i){
    const a = r.a;
    h += '<div class="am-cl-r' + (a.me ? ' me' : '') + '"' + (a.me ? '' : ' role="button" onclick="frScheda(' + frJs(a.device) + ')"') + '>'
      + '<span class="am-cl-n">' + (i + 1) + '</span>' + frAv(a.nome, a.device)
      + '<b>' + esc(a.nome) + '</b><span class="am-cl-v' + (r.v === null ? ' nd' : '') + '">' + esc(frMetFmt(c.met, r.v)) + '</span></div>';
  });
  for (let i = righe.length; i < 5; i++){
    h += '<button type="button" class="am-cl-r vuota" onclick="frAggiungiApri(\'amici\')"><span class="am-cl-n">' + (i + 1) + '</span><span class="am-av am-cl-piu">' + FR_PIU + '</span>'
      + '<b>' + esc(amT('amici.classifica.aggiungi')) + '</b><span class="am-cl-v nd">' + esc(c.met === 'schermo' ? '-' : frMetFmt(c.met, 0)) + '</span></button>';
  }
  h += '</div>';
  if (c.met === 'schermo') h += '<p class="am-hint">' + esc(amT('amici.classifica.schermoPrivato')) + '</p>';
  else if (trattino) h += '<p class="am-hint">' + esc(amT('amici.classifica.trattino')) + '</p>';
  if (lista.length) h += '<p class="am-hint">' + esc(amT('amici.tocca')) + '</p>';
  return h + '</div>';
}
/* ---------- AGGIUNGI AMICI (0.9.203), come dal profilo di Duolingo ----------
   Cerca per nome, condividi il tuo profilo (il codice), amici suggeriti dalla lega. Dai contatti
   del telefono: dopo, serve un permesso in piu'. */
registerScreen('s-amici-contatti',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-amici-trova\')">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Dai tuoi contatti</b></div>'
  + '<div class="fr-cerca-top"><span>🔍</span><input class="fin" id="frCtQ" placeholder="Cerca nella rubrica" autocomplete="off" oninput="FR.contattiQ=this.value;frContattiPaint()"></div>'
  + '<div id="frContattiRis"></div><div class="spacer"></div>', { back: 's-amici-trova' });
registerScreen('s-amici-trova',
  '<div class="topbar"><button class="iconbtn" onclick="frTrovaIndietro()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Trova i tuoi amici</b></div>'
  + '<div id="frTrovaBody"></div><div class="spacer"></div>',
  { back: function(){ const da = FR.trovaDa || 'account'; if (da === 'start'){ setTimeout(function(){ try{ switchTab('sveglia'); }catch(_){ } }, 0); return 's-home'; } if (da === 'amici'){ setTimeout(function(){ try{ frOpen('amici'); }catch(_){ } }, 0); return 's-friends'; } setTimeout(function(){ try{ profileAuth(); }catch(_){ } }, 0); return 's-account'; } });
/* da dove si arriva (0.9.209): dal Profilo si torna al Profilo, da START si torna a START */
function frTrovaIndietro(){ const da = FR.trovaDa || 'account'; if (da === 'start'){ if (!(typeof navTornaDietro === 'function' && navTornaDietro(order[cur]))){ goId('s-home'); try{ switchTab('sveglia'); }catch(_){ } } return; } if (da === 'amici'){ if (typeof frOpen === 'function') frOpen('amici'); return; } if (typeof profileAuth === 'function') profileAuth(); else goId('s-home'); }
function frAggiungiApri(da){
  FR.trovaDa = da || 'account';
  goId('s-amici-trova');
  frTrovaPaint();
}
function frTrovaPaint(){
  const box = document.getElementById('frTrovaBody'); if (!box) return;
  box.innerHTML = '<div class="fr-tr-sez">'
    + '<button type="button" class="fr-tr-row" onclick="frContattiVia()"><span class="fr-tr-ico">📒</span><div><b>Scegli dai tuoi contatti</b><small>Chi è già su DreamMap compare qui. La rubrica resta sul telefono.</small></div><span class="chev"></span></button>'
    + '<button type="button" class="fr-tr-row" onclick="frCercaApri()"><span class="fr-tr-ico">🔍</span><div><b>Cerca per nome</b><small>Il nome o il soprannome che usa nell’app.</small></div><span class="chev"></span></button>'
    + '<button type="button" class="fr-tr-row" onclick="if(typeof accQrApri===\'function\')accQrApri();else frInvite()"><span class="fr-tr-ico">📤</span><div><b>Condividi il tuo profilo</b><small>Il tuo codice: chi lo usa prende 14 giorni di Premium con te.</small></div><span class="chev"></span></button>'
    + '</div>'
    + '<div class="fr-tr-sez"><div class="am-sect first"><b>Amici suggeriti</b><button type="button" class="fr-tr-tutti" onclick="frSuggTutti()">Mostra tutti</button></div><div id="frSugg">' + ((typeof sfSuggeritiHtml === 'function') ? sfSuggeritiHtml() : '') + '</div></div>';
}
/* ---- CERCA I TUOI AMICI (0.9.207): una pagina, come su Duolingo ---- */
registerScreen('s-amici-cerca',
  '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-amici-trova\')">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px">Cerca i tuoi amici</b></div>'
  + '<div class="fr-cerca-top"><span>🔍</span><input class="fin" id="frCerca" placeholder="Nome o nome utente" autocomplete="off" oninput="frCercaDigita(this.value)"></div>'
  + '<div id="frCercaRis"></div><div class="am-sect first fr-sg-h"><b>Amici suggeriti</b></div><div id="frSuggCol"><p class="sf-mis-vuoto">Cerco…</p></div><div class="spacer"></div>', { back: 's-amici-trova' });
function frSuggX(){ try{ return JSON.parse(localStorage.getItem('fl_sugg_x') || '[]') || []; }catch(_){ return []; } }
function frSuggVia(device, el){ try{ const l = frSuggX(); if (l.indexOf(device) < 0) l.push(device); localStorage.setItem('fl_sugg_x', JSON.stringify(l.slice(-200))); }catch(_){ } if (el) el.remove(); }
function frSuggRiga(p, amici){
  const gia = amici.indexOf(p.device) >= 0;
  return '<div class="fr-sg">' + frAv(p.nome, p.device) + '<div><b>' + esc(p.nome) + '</b><small>' + (p.da ? 'Seguito da ' + esc(p.da) : (p.online ? '🟢 online adesso' : 'Persona che potresti conoscere')) + '</small></div>'
    + (gia ? '<span class="fr-gia">Amici</span>' : '<button type="button" class="fr-sg-piu" onclick="frSegui(\'' + esc(p.device) + '\',this)" aria-label="Segui"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"/><path d="M2 20c0-3.5 3-6 7-6s7 2.5 7 6"/><path d="M19 8v6M16 11h6"/></svg></button>')
    + '<button type="button" class="fr-sg-x" onclick="frSuggVia(\'' + esc(p.device) + '\',this.parentElement)" aria-label="Togli">✕</button></div>';
}
async function frCercaApri(){
  goId('s-amici-cerca');
  setTimeout(function(){ const i = document.getElementById('frCerca'); if (i) i.focus(); }, 300);
  const col = document.getElementById('frSuggCol'); if (!col) return;
  const amici = (FR.amici && FR.amici.amici || []).map(function(a){ return a.device; });
  let lista = [];
  try{ const r = await frApi('GET', '/api/focuslock/social/suggeriti?device=' + encodeURIComponent(frDevice())); lista = (r && r.giocatori) || []; }catch(_){ }
  if (!lista.length){ try{ lista = ((FR.lega && FR.lega.membri) || []).filter(function(m){ return !m.me; }).map(function(m){ return { device: m.device, nome: m.nome, da: '' }; }); }catch(_){ } }
  const via = frSuggX();
  lista = lista.filter(function(p){ return via.indexOf(p.device) < 0; });
  col.innerHTML = lista.length ? '<div class="fr-sg-l">' + lista.map(function(p){ return frSuggRiga(p, amici); }).join('') + '</div>' : '<p class="sf-mis-vuoto">Nessun suggerimento ancora: invita un amico con il tuo codice.</p>';
}
function frSuggTutti(){ FR.suggTutti = true; const h = document.getElementById('frSugg'); if (h && typeof sfSuggeritiHtml === 'function') h.innerHTML = sfSuggeritiHtml(40); }
/* ---- i contatti del telefono (0.9.205): si chiede il permesso ad Android, si leggono i numeri e
   le mail, si mandano al server SOLO come impronte (SHA-256). Chi ha la stessa impronta e' un
   contatto che usa l'app. La rubrica in chiaro non esce mai dal telefono. ---- */
async function frImpronta(t){
  try{ const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)); return Array.from(new Uint8Array(b)).map(function(x){ return x.toString(16).padStart(2, '0'); }).join(''); }catch(_){ return ''; }
}
function frTelNorm(t){
  let d = String(t || '').replace(/[^\d+]/g, '');
  if (d.indexOf('00') === 0) d = '+' + d.slice(2);
  if (d.indexOf('+') !== 0){ if (d.length === 10 && d.charAt(0) === '3') d = '+39' + d; else if (d.length >= 9 && d.charAt(0) === '0') d = '+39' + d.slice(1); else d = '+' + d; }
  return d.length >= 8 ? d : '';
}
async function frContattiVia(){
  goId('s-amici-contatti');
  const box = document.getElementById('frContattiRis'); if (!box) return;
  if (!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.leggiContatti)){ box.innerHTML = '<p class="sf-mis-vuoto">La rubrica si legge solo dal telefono.</p>'; return; }
  box.innerHTML = '<p class="sf-mis-vuoto">Leggo la rubrica…</p>';
  let r = null;
  try{ r = await NATIVE.leggiContatti(); }catch(e){ box.innerHTML = '<p class="sf-mis-vuoto">Senza il permesso dei contatti non posso leggere la rubrica. Lo dai dalle impostazioni dell’app.</p>'; return; }
  const lista = ((r && r.contatti) || []).filter(function(c){ return c && c.nome && ((c.tel || []).length || (c.email || []).length); }).sort(function(a, b){ return String(a.nome).localeCompare(String(b.nome)); });
  if (!lista.length){ box.innerHTML = '<p class="sf-mis-vuoto">La rubrica è vuota.</p>'; return; }
  /* LA LISTA SUBITO, dalla rubrica: chi usa gia' DreamMap ha «Segui», gli altri «Invita». Il server
     serve solo a sapere chi e' gia' dentro: se non risponde, restano tutti con «Invita». */
  FR.contatti = lista; FR.contattiDentro = {};
  frContattiPaint();
  const mappa = {}; const hash = [];
  for (let i = 0; i < lista.length && hash.length < 1500; i++){
    const c = lista[i];
    for (const t of (c.tel || [])){ const n = frTelNorm(t); if (!n) continue; const h = await frImpronta(n); if (h){ hash.push(h); mappa[h] = i; } }
    for (const e of (c.email || [])){ const n = String(e || '').trim().toLowerCase(); if (!n) continue; const h = await frImpronta(n); if (h){ hash.push(h); mappa[h] = i; } }
  }
  try{ const acc = NATIVE.googleAccount ? await NATIVE.googleAccount() : null; if (acc && acc.email){ FR.emailHash = await frImpronta(String(acc.email).toLowerCase()); } }catch(_){ }
  try{
    const res = await frApi('POST', '/api/focuslock/social/contatti', { device: frDevice(), hash: hash, emailHash: FR.emailHash || '' });
    ((res && res.giocatori) || []).forEach(function(p){ const i = mappa[p.hash]; if (i != null) FR.contattiDentro[i] = p; });
    frContattiPaint();
  }catch(_){ /* il confronto non e' riuscito: la lista resta, con «Invita» */ }
}
function frContattiPaint(){
  const box = document.getElementById('frContattiRis'); if (!box || !FR.contatti) return;
  const amici = (FR.amici && FR.amici.amici || []).map(function(a){ return a.device; });
  const dentro = Object.keys(FR.contattiDentro || {}).length;
  const q = (FR.contattiQ || '').toLowerCase();
  const righe = FR.contatti.map(function(c, i){ return { c: c, i: i, p: FR.contattiDentro[i] }; }).filter(function(x){ return !q || String(x.c.nome).toLowerCase().indexOf(q) >= 0; });
  box.innerHTML = '<div class="fr-ct-w"><div class="am-sect first"><b>' + (dentro ? dentro + ' già su DreamMap' : FR.contatti.length + ' contatti') + '</b><span>Invita chi non c’è ancora</span></div>'
    + '<div class="fr-sg-l">' + righe.slice(0, 200).map(function(x){
        const p = x.p; const tel = (x.c.tel || [])[0] || '';
        if (p) return '<div class="fr-sg">' + frAv(p.nome, p.device) + '<div><b>' + esc(x.c.nome) + '</b><small>Su DreamMap come ' + esc(p.nome) + '</small></div>' + (amici.indexOf(p.device) >= 0 ? '<span class="fr-gia">Amici</span>' : '<button type="button" class="fr-sg-piu" onclick="frSegui(\'' + esc(p.device) + '\',this)" aria-label="Segui">＋</button>') + '</div>';
        return '<div class="fr-sg">' + frAv(x.c.nome, x.c.nome) + '<div><b>' + esc(x.c.nome) + '</b><small>' + esc(tel || (x.c.email || [])[0] || '') + '</small></div><button type="button" class="fr-sg-inv" onclick="frInvitaContatto(' + x.i + ')">Invita</button></div>';
      }).join('') + (righe.length > 200 ? '<p class="sf-mis-vuoto">Mostro i primi 200: cerca per nome.</p>' : '') + '</div></div>';
}
/* L'INVITO (0.9.210): una SFIDA lanciata da un amico, non il riassunto dell'app. Chi lo legge
   deve sentirsi sfidato e voler sapere cosa c'e' dentro; il resto lo scopre entrando. Il nome
   senza emoji e senza cuoricini, solo la prima parola. */
function frInvitoTesto(nome){
  const code = (FR.me && FR.me.code) || '';
  const n = String(nome || '').split(/\s+/)[0].replace(/[^\p{L}'’-]/gu, '');
  let serie = 0; try{ serie = (typeof hdSerie === 'function') ? hdSerie() : 0; }catch(_){ }
  const url = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock') + (code ? '?invito=' + encodeURIComponent(code) : '');
  return (n ? n + ', ti' : 'Ti') + ' sfido: 7 giorni di fila.\n'
    + (serie > 0 ? 'Io sono al giorno ' + serie + '. ' : 'Io comincio oggi. ') + 'Scommetto che non arrivi al quinto.\n'
    + 'Non ti spiego niente: lo capisci al primo minuto.\n'
    + url;
}
async function frInvitaContatto(i){
  const c = (FR.contatti || [])[i]; if (!c) return;
  const txt = frInvitoTesto(c.nome);
  const tel = (c.tel || [])[0] || '';
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: txt, title: 'Invita ' + c.nome }); return; }catch(_){ } }
  if (tel && /Android/i.test(navigator.userAgent)){ try{ window.open('sms:' + tel + '?body=' + encodeURIComponent(txt), '_blank'); return; }catch(_){ } }
  try{ await navigator.clipboard.writeText(txt); toast('Invito copiato'); }catch(_){ }
}
let FR_CERCA_T = 0;
function frCercaDigita(v){
  clearTimeout(FR_CERCA_T);
  const q = String(v || '').trim();
  const box = document.getElementById('frCercaRis'); if (!box) return;
  if (q.length < 2){ box.innerHTML = ''; return; }
  FR_CERCA_T = setTimeout(async function(){
    try{
      const r = await frApi('GET', '/api/focuslock/social/cerca?device=' + encodeURIComponent(frDevice()) + '&q=' + encodeURIComponent(q));
      const l = (r && r.giocatori) || [];
      const amici = (FR.amici && FR.amici.amici || []).map(function(a){ return a.device; });
      box.innerHTML = l.length ? '<div class="fr-sg-l">' + l.map(function(p){ return frSuggRiga({ device: p.device, nome: p.nome, da: '', online: p.online }, amici); }).join('') + '</div>' : '<p class="sf-mis-vuoto">Nessuno con questo nome.</p>';
    }catch(_){ box.innerHTML = '<p class="sf-mis-vuoto">Non riesco a cercare adesso.</p>'; }
  }, 350);
}
async function frSegui(device, btn){
  if (btn){ btn.disabled = true; btn.textContent = '…'; }
  try{
    const r = await frApi('POST', '/api/focuslock/social/segui', { device: frDevice(), a: device });
    if (btn){ btn.textContent = 'Segui già'; btn.classList.add('on'); }
    try{ flVibra(14); }catch(_){ }
    toast(r && r.nome ? 'Ora segui ' + r.nome : 'Fatto');
    frAmiciCarica(true).then(function(){ if (document.getElementById('frBody')) frPaint(); });
  }catch(e){ if (btn){ btn.disabled = false; btn.textContent = 'Segui'; } toast(e && e.message ? e.message : 'Non riuscito'); }
}
function frAmiciHtml(){
  const A = FR.amici || { amici: [], reazioni: { totali: [], ultime: [] } };
  const lista = A.amici || [];
  let h = '';
  /* seguiti, follower e «Aggiungi amici» stanno nel Profilo (0.9.204) */
  /* Focus insieme: un mio invito in attesa, o inviti ricevuti */
  try{ if (typeof inHtml === 'function') h += inHtml(); }catch(_){ }
  /* 0.9.305: le pozioni ricevute e non ancora aperte, in cima (la notifica porta qui) */
  h += frDoniHtml(A.doni || []);
  /* 0.9.300: il pannello del Genio sempre in cima, poi la classifica alla Sweatcoin */
  h += lista.length ? frGenioHtml(true) : frVuotoHtml();
  /* 0.9.335, Andrea: il campo del codice sta subito sotto a "Concentrarsi è più facile in due", prima dei tuoi amici */
  h += '<div class="am-codici"><div class="fr-add am-code-blu"><input class="fin" id="frCode" data-no-mic placeholder="' + esc(amT('amici.invito.campo')) + '" maxlength="8" autocomplete="off" autocapitalize="characters"><button type="button" class="ghostmini" onclick="frAdd()">' + esc(amT('amici.invito.aggiungi')) + '</button></div></div>';
  h += frClassificaHtml();
  /* il codice di un amico (pass) e il codice di un Focus insieme */
  /* 0.9.321: i regali e il feed, per chi ha amici veri (l'anteprima mette i suoi in anteprima-social.js) */
  if (typeof dsoFeedHtml === 'function' && !(typeof asOn === 'function' && asOn())) h += dsoFeedHtml();
  /* le reazioni ricevute */
  const tot = (A.reazioni && A.reazioni.totali) || [];
  if (tot.length){
    const ult = (A.reazioni && A.reazioni.ultime) || [];
    h += '<div class="am-sect"><b>' + esc(amT('amici.reazioni.ricevute')) + '</b></div>'
      + '<div class="am-reaz-tot">' + tot.map(function(x){ const r = FR_REAZIONI.filter(function(z){ return z.k === x.tipo; })[0]; return '<span>' + (r ? r.e + ' ' : '') + esc(amT('amici.reazioni.' + x.tipo)) + ' <b>' + x.n + '</b></span>'; }).join('') + '</div>'
      + (ult.length ? '<div class="am-reaz-ult">' + ult.slice(0, 4).map(function(x){ return '<small>' + esc(amT('amici.reazioni.' + x.tipo)) + ' · ' + esc(amT('amici.reazioni.da', { nome: x.da })) + '</small>'; }).join('') + '</div>' : '');
  }
  return h;
}
/* ---- I DONI FRA AMICI VERI (0.9.305): la pozione della concentrazione ----
   Si manda dalla scheda dell'amico, una al giorno. A chi la riceve arriva la notifica (AmiciNovita.java, ogni
   quarto d'ora al massimo) e qui in cima la card per aprirla: aprendola partono i 15 minuti di XP doppi
   (sdBoostDai di sentiero-mappa.js, la stessa pozione del sentiero). Il server la segna aperta una volta sola. */
function frDoniHtml(doni){
  if (!doni || !doni.length) return '';
  return doni.slice(0, 3).map(function(d){
    return '<div class="am-dono-r">' + frAv(d.da, d.daDevice) + '<div class="am-dono-t"><b>' + esc(amT('amici.doni.ricevuto', { nome: d.da })) + '</b>'
      + '<small>' + esc(amT('amici.doni.ricevutoSotto')) + '</small>'
      + '<button type="button" onclick="frDonoApri(' + (+d.id || 0) + ',this)">' + esc(amT('amici.doni.apri')) + '</button></div></div>';
  }).join('');
}
async function frDonoManda(device, nome, btn){
  if (btn){ btn.disabled = true; }
  try{
    const r = await frApi('POST', '/api/focuslock/social/dono', { device: frDevice(), a: device, tipo: 'pozione' });
    if (btn) btn.innerHTML = '<b>' + esc(amT('amici.doni.giaOggi')) + '</b>';
    if (FR.amici){ (FR.amici.amici || []).forEach(function(a){ if (a.device === device) a.donoOggi = true; }); }
    try{ flVibra([20, 30, 60]); }catch(_){ }
    toast(r && r.gia ? amT('amici.doni.giaOggi') : amT('amici.doni.mandata', { nome: nome }));
  }catch(e){ if (btn) btn.disabled = false; toast(e && e.message ? e.message : 'Non riuscito'); }
}
async function frDonoApri(id, btn){
  if (!id) return;
  if (btn) btn.disabled = true;
  try{
    const r = await frApi('POST', '/api/focuslock/social/dono/apri', { device: frDevice(), id: id });
    if (r && r.gia){ toast(amT('amici.doni.giaAperta')); }
    else {
      try{ if (typeof sdBoostDai === 'function') sdBoostDai(15, 2); }catch(_){ }
      try{ flVibra([30, 40, 90]); }catch(_){ }
      toast(amT('amici.doni.aperta'));
    }
    if (FR.amici) FR.amici.doni = (FR.amici.doni || []).filter(function(d){ return +d.id !== +id; });
    frPaint();
  }catch(e){ if (btn) btn.disabled = false; toast(e && e.message ? e.message : 'Non riuscito'); }
}
/* Il servizio del telefono chiede al server le novita' degli amici per le notifiche: gli serve l'id di questo telefono. */
function frNovitaArma(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.amiciNovita || !frName()) return;
    NATIVE.amiciNovita({ device: frDevice(), on: true }).catch(function(){ });
  }catch(_){ }
}
setTimeout(frNovitaArma, 7000);

/* lo stato vuoto: il Genio, «Tu» e un posto libero. Sembra un invito, non un vuoto. */
function frVuotoHtml(){
  return frGenioHtml(false)
    + '<div class="am-tiles"><div><i>⏳</i>' + esc(amT('amici.vuoto.tile1')) + '</div><div><i>🤝</i>' + esc(amT('amici.vuoto.tile2')) + '</div><div><i>👏</i>' + esc(amT('amici.vuoto.tile3')) + '</div></div>';
}
/** Cosa sta facendo adesso, dal server: ff = in Full Focus, severa = Modalita' severa accesa. */
function frAttivita(k){ return k === 'ff' ? 'In Full Focus' : (k === 'severa' ? 'Modalità severa accesa' : 'Nell’app adesso'); }
function frAttivitaMia(){ try{ if (typeof FF !== 'undefined' && FF && FF.run) return 'ff'; if (typeof sevState !== 'undefined' && sevState && sevState.level > 0) return 'severa'; }catch(_){ } return 'app'; }
function frAmicoHtml(a){
  const inviato = !!FR.inviati[a.device];
  return '<div class="am-fr" onclick="frScheda(' + frJs(a.device) + ')">'
    + '<div class="am-fr-top">' + frAv(a.nome, a.device) + '<div class="am-fr-nm"><b>' + esc(a.nome) + ((a.streak || 0) >= 7 ? ' <span title="Compagnia della serie">🛡️</span>' : '') + (a.online ? '<i class="am-online" title="Online"></i>' : '') + '</b><div class="am-fr-meta">' + (a.online ? '<span class="am-att">' + esc(frAttivita(a.attivita)) + '</span>' : '') + '<span>⏳ ' + esc(frOre(a.ffMin7)) + '</span><span>🔥 ' + (a.streak || 0) + '</span></div></div>' + frDeltaHtml(a.score7, a.prevScore7) + '</div>'
    + '<div class="am-fr-bot"><div class="am-score">' + esc(amT('amici.riga.nuovoSe')) + ' <b>' + (a.neo || 0) + '</b><span>–</span><b class="old">' + (a.old || 0) + '</b> ' + esc(amT('amici.riga.vecchioSe')) + '</div>'
    + (inviato ? '<span class="am-fi sent">' + esc(amT('amici.riga.invitato')) + '</span>' : '<button type="button" class="am-fi" onclick="event.stopPropagation();inScegli(' + frJs(a.device) + ',' + frJs(a.nome) + ')">' + esc(amT('amici.riga.insieme')) + '</button>') + '</div>'
    + '</div>';
}
/* la scheda amico: la sua settimana e le reazioni */
function frScheda(device){
  const a = ((FR.amici && FR.amici.amici) || []).filter(function(x){ return x.device === device; })[0];
  if (!a || typeof inSheet !== 'function') return;
  FR.scheda = device;
  const tier = a.tier && FR_TIER[a.tier] ? frTierIco(a.tier) + ' ' + amT('lega.tier.' + a.tier) : amT('amici.scheda.fuoriLega');
  const html = '<div class="am-sheet"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button>'
    + '<div class="am-sh-top">' + frAv(a.nome, a.device, 'lg') + '<div><b>' + esc(a.nome) + '</b><div class="am-score">' + esc(amT('amici.riga.nuovoSe')) + ' <b>' + (a.neo || 0) + '</b><span>–</span><b class="old">' + (a.old || 0) + '</b> ' + esc(amT('amici.riga.vecchioSe')) + '</div></div></div>'
    + '<div class="am-stats"><div><small>' + esc(amT('amici.scheda.focus')) + '</small><b>' + esc(frOre(a.ffMin7)) + '</b></div><div><small>' + esc(amT('amici.scheda.serie')) + '</small><b>🔥 ' + (a.streak || 0) + '</b></div><div><small>' + esc(amT('amici.scheda.lega')) + '</small><b class="sm">' + esc(tier) + '</b></div></div>'
    + (frDeltaHtml(a.score7, a.prevScore7, true) ? '<div class="am-center">' + frDeltaHtml(a.score7, a.prevScore7, true) + '</div>' : '')
    + '<div class="am-sh-lbl">' + esc(amT('amici.scheda.manda')) + '</div>'
    + frReazioniHtml(a.device, a.nome, a.reazioniOggi || [])
    + '<p class="am-note" id="amNote">' + esc(amT('amici.scheda.nota')) + '</p>'
    /* 0.9.305: la pozione per un amico vero (uno al giorno); a lui arriva anche come notifica (AmiciNovita.java) */
    + '<button type="button" class="am-dono"' + (a.donoOggi ? ' disabled' : '') + ' onclick="frDonoManda(' + frJs(a.device) + ',' + frJs(a.nome) + ',this)"><b>' + esc(a.donoOggi ? amT('amici.doni.giaOggi') : amT('amici.doni.manda')) + '</b>'
    +   (a.donoOggi ? '' : '<small>' + esc(amT('amici.doni.mandaSotto')) + '</small>') + '</button>'
    + '<button type="button" class="am-cta" onclick="inSheetChiudi();inScegli(' + frJs(a.device) + ',' + frJs(a.nome) + ')">' + esc(amT('amici.riga.insieme')) + '</button>'
    /* 0.9.322, Andrea: "apri il suo profilo", lo stesso delle quattro schede del profilo pubblico */
    + '<button type="button" class="am-link" onclick="inSheetChiudi();frProfiloApri(' + frJs(a.device) + ',' + frJs(a.nome) + ')">Apri il suo profilo</button>'
    + '</div>';
  inSheet(html);
}
function frReazioniHtml(device, nome, mandate){
  return '<div class="am-reaz">' + FR_REAZIONI.map(function(r){
    const gia = (mandate || []).indexOf(r.k) >= 0;
    return '<button type="button" class="am-rx' + (gia ? ' on' : '') + '" onclick="frReagisci(' + frJs(device) + ',' + frJs(nome || '') + ',\'' + r.k + '\',this)"><span>' + r.e + '</span><small>' + esc(amT('amici.reazioni.' + r.k)) + '</small></button>';
  }).join('') + '</div>';
}
async function frReagisci(device, nome, tipo, btn){
  const r0 = FR_REAZIONI.filter(function(z){ return z.k === tipo; })[0] || { e: '' };
  /* 0.9.299: prima i coriandoli, poi il messaggio (quando la festa ha fatto il suo giro) */
  const festa = (typeof flCoriandoli === 'function') ? flCoriandoli() : Date.now();
  try{
    const r = await frApi('POST', '/api/focuslock/social/reazione', { device: frDevice(), a: device, tipo: tipo });
    const attesa = 1100 - (Date.now() - festa);
    if (attesa > 0) await new Promise(function(ok){ setTimeout(ok, attesa); });
    if (btn) btn.classList.add('on');
    const n = document.getElementById('amNote'); if (n){ n.textContent = r && r.gia ? amT('amici.reazioni.gia') : amT('amici.scheda.inviata', { nome: nome }); n.classList.add('ok'); }
    toast(r && r.gia ? amT('amici.reazioni.gia') : amT('amici.reazioni.mandata', { emoji: r0.e, testo: amT('amici.reazioni.' + tipo), nome: nome }));
    if (FR.amici){ (FR.amici.amici || []).forEach(function(a){ if (a.device === device){ a.reazioniOggi = a.reazioniOggi || []; if (a.reazioniOggi.indexOf(tipo) < 0) a.reazioniOggi.push(tipo); } }); }
  }catch(e){ toast(e && e.message ? e.message : 'Non mandata'); }
}
function frPrivacyExtra(){
  let on = false; try{ on = localStorage.getItem('fl_privacy_extra') === '1'; }catch(_){ }
  try{ localStorage.setItem('fl_privacy_extra', on ? '0' : '1'); }catch(_){ }
  try{ if (typeof accStoryMenu === 'function') accStoryMenu(); }catch(_){ }
}
function frDiarioAttr(r){
  if (!r || !r.device) return '';
  const js = r.me ? 'dvApri()' : 'dvApriDi(' + frJs(r.device) + ',' + frJs(r.name || '') + ')';
  return 'role="button" style="cursor:pointer" onclick="' + js + '"';
}
async function frInvite(){
  const me = FR.me || {};
  const code = me.code || '';
  if (!code){ toast(amT('amici.invito.primaNome')); if (!frName()) profileAuth(); return; }
  /* 0.9.210: la polaroid con il QR e la riga delle app, come su Duolingo */
  if (typeof accQrApri === 'function'){ accQrApri(); return; }
  const txt = frInvitoTesto('');
  /* con l'immagine: la stessa polaroid con il QR del Profilo (0.9.209) */
  try{
    if (typeof accQrCanvas === 'function' && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareImage){
      const cv = await accQrCanvas();
      await NATIVE.shareImage({ base64: cv.toDataURL('image/png'), text: txt, title: amT('amici.invito.titolo') });
      return;
    }
  }catch(_){ }
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ try{ await NATIVE.shareText({ text: txt, title: amT('amici.invito.titolo') }); return; }catch(_){ } }
  try{ await navigator.clipboard.writeText(txt); toast(amT('amici.invito.copiato')); }catch(_){ toast(code); }
}
async function frCopia(){
  const code = (FR.me && FR.me.code) || '';
  if (!code) return;
  try{ await navigator.clipboard.writeText(code); toast(amT('amici.invito.copiato')); }catch(_){ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText) frInvite(); }
}
/* 0.9.341, Andrea: "non voglio il + e i tre puntini: solo i tre puntini, con Aggiungi un nuovo amico e Condividi il tuo codice" */
function frMenu(){
  try{ flVibra(8); }catch(_){ }
  if (typeof inSheet !== 'function') return;
  const voce = function(ico, t, s, js){ return '<button type="button" class="fr-mn-r" onclick="' + js + '"><span>' + ico + '</span><div><b>' + esc(t) + '</b><small>' + esc(s) + '</small></div></button>'; };
  inSheet('<div class="fr-mn"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Amici</h3>'
    + voce('\ud83e\udd1d', 'Aggiungi un nuovo amico', 'Scrivi il codice che ti ha dato un amico.', 'inSheetChiudi();setTimeout(frAggiungiApri,260)')
    + voce('\ud83d\udcf2', 'Condividi il tuo codice', 'Manda la tua card con il QR a chi vuoi.', 'inSheetChiudi();setTimeout(frInvite,260)')
    + voce('\ud83d\udc41\ufe0f', 'Cosa vedono gli amici', 'Scegli cosa resta pubblico del tuo profilo.', 'inSheetChiudi();setTimeout(accStoryMenu,260)')
    + '</div>');
}
function frAggiungiApri(){
  if (typeof inSheet !== 'function') return;
  inSheet('<div class="fr-mn"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Aggiungi un nuovo amico</h3>'
    + '<p class="fr-mn-p">Scrivi qui il codice che ti ha dato il tuo amico.</p>'
    + '<div class="fr-add am-code-blu"><input class="fin" id="frCodeS" data-no-mic placeholder="' + esc(amT('amici.invito.campo')) + '" maxlength="8" autocomplete="off" autocapitalize="characters"><button type="button" class="ghostmini" onclick="frAdd(\'frCodeS\')">' + esc(amT('amici.invito.aggiungi')) + '</button></div></div>');
  setTimeout(function(){ const i = document.getElementById('frCodeS'); if (i) i.focus(); }, 320);
}
async function frAdd(campo){
  const inp = document.getElementById(campo || 'frCode'); const code = inp ? inp.value.trim().toUpperCase() : '';
  if (campo){ try{ inSheetChiudi(); }catch(_){ } }
  if (!code){ toast(amT('amici.invito.scrivi')); return; }
  /* un codice di Focus insieme (4 caratteri) va all'invito, non agli amici */
  if (code.length <= 4 && typeof inAccetta === 'function'){ inAccetta(code, 0); if (inp) inp.value = ''; return; }
  try{
    const r = await frApi('POST', '/api/focuslock/social/friend', { device: frDevice(), code: code });
    const nome = (r.friend && r.friend.name) || 'Amico';
    toast(r.pass ? amT('amici.invito.aggiuntoPass', { nome: nome, giorni: r.passDays || 14 }) : amT('amici.invito.aggiunto', { nome: nome }));
    if (r.premiumUntil) frApplicaPass(r.premiumUntil);
    if (inp) inp.value = '';
    await frAmiciCarica(true);
    frPaint();
  }catch(e){ toast(e && e.message ? e.message : amT('amici.invito.nonTrovato')); }
}

/* ---------------------------------------------------------------- scheda LEGA */
function frCountdown(ms){
  ms = Math.max(0, ms);
  const g = Math.floor(ms / 86400000), h = Math.floor((ms % 86400000) / 3600000), m = Math.floor((ms % 3600000) / 60000);
  return g ? g + 'g ' + h + 'h' : (h ? h + 'h ' + m + 'min' : m + ' min');
}
function frCatNome(k){ return FR_CATEGORIE.indexOf(k) >= 0 ? amT('lega.categorie.' + k) : ''; }
function frLegaNome(k){ const n = frCatNome(k); return n ? amT('lega.nome', { categoria: n }) : amT('lega.titolo'); }
function frTierSteps(tier){
  const i = FR_TIERS.indexOf(tier);
  return '<div class="am-steps">' + FR_TIERS.map(function(t, j){ return '<div><i style="background:' + (j === i ? FR_TIER[t].c : (j < i ? 'rgba(255,255,255,.55)' : 'rgba(255,255,255,.16)')) + '"></i><span' + (j === i ? ' class="on"' : '') + '>' + esc(amT('lega.tier.' + t)) + '</span></div>'; }).join('') + '</div>';
}
function frLegaHtml(){
  const L = FR.lega;
  let h = '';
  if (L && L.risultato) h += frRisultatoHtml(L.risultato);
  if (!L) return h + '<div class="ins-load">Leggo la lega…</div>';
  if (!L.optIn) return h + frLegaEntraHtml();
  const tier = FR_TIERS.indexOf(L.tier) >= 0 ? L.tier : 'bronzo';
  const T = FR_TIER[tier];
  const membri = L.membri || [];
  const n = membri.length, mio = L.mio;
  const form = L.stato === 'formazione';
  const catK = L.goal && FR_CATEGORIE.indexOf(L.goal) >= 0 ? L.goal : frCategoria();
  /* 0.9.300: cosa ordina la classifica (predefinito: l'obiettivo della lega) */
  const ord = frLegaOrd(L.goal === '*' ? '' : catK);
  const ordinati = frLegaOrdinati(membri, ord);
  if (form){
    const min = L.minimo || 5, manca = Math.max(0, min - n);
    h += '<div class="am-lega-hero center"><small style="color:#9EC1FF">' + esc(frLegaNome(catK)) + '</small><b>' + esc(amT('lega.formazione.titolo')) + '</b><p>' + esc(amT('lega.formazione.sotto')) + '</p>'
      + '<div class="am-slots">' + membri.slice(0, 5).map(function(m){ return m.me ? (flAvMio() || '<span class="am-av me">Tu</span>') : frAv(m.nome, m.device); }).join('') + Array.from({ length: Math.min(5, manca) }).map(function(){ return '<span class="am-av free">+</span>'; }).join('') + '</div>'
      + '<div class="am-conta">' + esc(manca === 1 ? amT('lega.formazione.conta1', { n: n, min: min }) : amT('lega.formazione.conta', { n: n, min: min, m: manca })) + '</div></div>'
      + '<button type="button" class="am-cta" onclick="frInvite()">' + esc(amT('lega.formazione.btn')) + '</button>'
      + frFormulaRow()
      + '<div class="am-sect"><b>' + esc(amT('lega.formazione.dentro')) + '</b><span>' + esc(amT('lega.formazione.reali')) + '</span></div>'
      + frLegaOrdHtml(L.goal === '*' ? '' : catK, ord)
      + '<div class="am-board">' + ordinati.map(function(m){ return frRigaLega(m, 0, n, false, ord); }).join('') + '</div>'
      + '<p class="am-hint">' + esc(amT('lega.formazione.nota')) + '</p>';
  } else {
    let riga = '';
    if (mio){
      const pos = mio.posizione;
      if (pos <= 5) riga = amT('lega.inPromo');
      else if (pos > n - 5 && n > 5){ const sopra = membri[n - 6]; riga = amT('lega.inRetro', { n: sopra ? sopra.punti - mio.punti + 1 : 1 }); }
      else { const quinto = membri[4]; riga = amT('lega.zonaPromo', { n: quinto ? quinto.punti - mio.punti + 1 : 1 }); }
      riga = amT('lega.posizione', { pos: pos, n: n }) + ' ' + riga;
    }
    FR.legaRiga = riga;
    /* 0.9.322, Andrea: "su Duolingo c'e' scritto solo Lega Smeraldo e quanti giorni mancano, e le leghe scorrono di lato". Tutto il resto sta nella (i) */
    const gg = Math.max(1, Math.ceil(((L.fine || 0) - Date.now()) / 86400000));
    /* 0.9.326, Andrea: "era meglio prima: Lega Argento in piccolo e accanto alla coppa Lega Imprenditori, se no non si capisce di quale lega". Le coppe scorrevoli al posto delle tacchette, il tempo dov'e' */
    h += '<div class="am-lg-car" id="frLgCar" onscroll="frLgDot()"><div class="am-lg-s am-lg-hero"><div class="am-lg-top"><span class="am-lg-med">' + frCoppa(tier, 'm') + '</span><div class="am-lg-nomi"><i>' + esc(amT('lega.titolo')) + ' ' + esc(amT('lega.tier.' + tier)) + '</i><b>' + esc(frLegaNome(catK)) + '</b><small>⏱ ' + gg + (gg === 1 ? ' GIORNO' : ' GIORNI') + '</small></div>'
      + '<button type="button" class="am-lg-i" onclick="frLegaFormula()" aria-label="Come funziona la lega">i</button></div>'
      + '<div class="am-coppe" id="frCoppe">' + FR_TIERS.map(function(t, k){ const qui = FR_TIERS.indexOf(tier); return '<span class="am-coppa' + (t === tier ? ' on' : (k > qui ? ' dopo' : '')) + '" aria-label="' + esc(amT('lega.tier.' + t)) + '">' + frCoppa(t) + '</span>'; }).join('') + '</div></div>'
      /* 0.9.335, Andrea: "il podio non sopra alla classifica: come slide del carosello della lega, e quando tocco un Ordina per
         il carosello va da solo su quella slide". Si disegna dai membri della lega gia' in mano, quindi c'e' dal primo fotogramma. */
      + '<div class="am-lg-s fr-pod-s" id="frPodioS">' + frPodioLegaHtml(ordinati, ord, n) + '</div>'
      + '<div class="am-lg-s">' + ((typeof dsoTorneoHtml === 'function') ? dsoTorneoHtml(L) : '') + '</div></div>'
      + '<div class="am-lg-dots" id="frLgDots"><i class="on"></i><i></i><i></i></div>'
      + frLegaOrdHtml(L.goal === '*' ? '' : catK, ord)
      + '<div class="am-board">' + ordinati.map(function(m, i){ return frRigaLega(m, i, n, true, ord); }).join('') + '</div>'
      + '<div id="rcfAltri" class="rcf-altri-lega"></div>';
    setTimeout(function(){ try{ if (typeof rcfLegaPaint === 'function') rcfLegaPaint(ord); }catch(_){ } }, 0);
    setTimeout(function(){ try{ const c = document.getElementById('frCoppe'), o = c && c.querySelector('.on'); if (c && o) c.scrollLeft = o.offsetLeft - c.offsetLeft - (c.clientWidth - o.offsetWidth) / 2; }catch(_){ } }, 0);
  }
  h += '<button type="button" class="am-esci" onclick="frLegaIscrivi(false)">' + esc(amT('lega.entra.esci')) + '</button>';
  return h;
}
function frFormulaRow(){ return '<button type="button" class="am-formula" onclick="frLegaFormula()"><i>i</i><span>' + esc(amT('lega.formula')) + '</span></button>'; }
function frRigaLega(m, i, n, conPos, ord){
  ord = ord || 'punti';
  const pos = i + 1;
  /* le zone di promozione e retrocessione le decidono i punti: si disegnano solo in quell'ordine */
  const zone = conPos && ord === 'punti';
  const top = zone && pos <= 5, bottom = zone && n > 5 && pos > n - 5;
  let h = '';
  if (zone && n > 10 && pos === n - 4) h += '<div class="am-zona giu"><i></i><span>' + esc(amT('lega.scendono')) + '</span><i></i></div>';
  let val;
  if (ord === 'punti') val = (m.punti || 0).toLocaleString('it-IT') + ' <small>pt</small>';
  else { const v = frLegaVal(m, ord); val = v === null ? '<small>-</small>' : esc(frMetFmt(ord, v)); }
  h += '<div class="am-row' + (m.me ? ' me' : '') + '"><span class="am-pos' + (top ? ' top' : (bottom ? ' low' : '')) + '">' + (conPos ? pos : '') + '</span>'
    + (m.me ? (flAvMio() || '<span class="am-av me">Tu</span>') : frAv(m.nome, m.device))
    + '<b>' + esc(m.me ? amT('lega.tu') : m.nome) + '</b><span class="am-pt' + (m.me ? ' me' : '') + '">' + val + '</span></div>';
  if (zone && n > 5 && pos === 5) h += '<div class="am-zona su"><i></i><span>' + esc(amT('lega.salgono')) + '</span><i></i></div>';
  return h;
}
/* ---- COSA ORDINA LA LEGA (0.9.300): chip sopra la classifica, predefinito l'obiettivo della lega ---- */
function frLegaOrd(catK){
  const ob = FR_LEGA_OBIETTIVO[catK] || 'punti';
  return (FR.legaOrd && FR_LEGA_ORD.indexOf(FR.legaOrd) >= 0) ? FR.legaOrd : ob;
}
function frLegaOrdina(k){
  if (FR_LEGA_ORD.indexOf(k) < 0) return;
  const c0 = document.getElementById('frLgCar'), sx = c0 ? c0.scrollLeft : 0;
  FR.legaOrd = k; try{ flVibra(8); }catch(_){ } frPaint(); frChipInVista('.am-ord-l');
  /* il carosello riparte da dov'era e scorre fino al podio */
  try{
    const c = document.getElementById('frLgCar'), sl = document.getElementById('frPodioS');
    if (c && sl){ c.scrollLeft = sx; requestAnimationFrame(function(){ c.scrollTo({ left: sl.offsetLeft - c.offsetLeft, behavior: 'smooth' }); }); }
  }catch(_){ }
}
/* IL PODIO DELLA LEGA (0.9.335), come Suitcase ma con i colori del brand: tre gradini 2-1-3, chi e' in cima sta piu' in alto,
   la bandiera accanto al nome, il numero in una pillola, e sotto una riga che dice a te quanto manca. */
const FR_POD_ICO = { punti: '⭐', tappe: '📍', ff: '⏱', schermo: '📱', severa: '🔒', serie: '🔥' };
const FR_POD_FIAMMA = '<svg class="fr-pod-fi" viewBox="0 0 100 130" aria-hidden="true"><defs><linearGradient id="frPodFG" x1="0" y1="1" x2="0" y2="0"><stop offset="0" stop-color="#E63946"/><stop offset=".55" stop-color="#FF6B7A"/><stop offset="1" stop-color="#FFC2C8" stop-opacity=".2"/></linearGradient></defs><path d="M50 2c6 22 32 34 38 66 4 26-14 58-38 60C26 126 8 96 12 68c3-20 15-28 20-44 5 10 9 14 13 16 2-14 2-26 5-38z" fill="url(#frPodFG)"/></svg>';
function frPodioLegaHtml(ordinati, ord, n){
  const val = function(m){ return ord === 'punti' ? (m.punti || 0) : frLegaVal(m, ord); };
  const top = ordinati.filter(function(m){ const v = val(m); return v !== null && (ord === 'schermo' || v > 0); }).slice(0, 3);
  const tit = '<p class="fr-pod-t">' + esc(amT('lega.ordina.' + ord)) + '</p>';
  if (!top.length) return tit + '<p class="fr-pod-vuoto">Ancora nessuno ha un numero qui questa settimana. Il primo che lo fa sale sul gradino più alto.</p>';
  const posti = top.length >= 3 ? [1, 0, 2] : (top.length === 2 ? [1, 0] : [0]);
  const col = function(i){
    const m = top[i], pos = i + 1;
    const paese = m.me ? ((FR.mieMet && FR.mieMet.paese) || frPaese()) : ((m.metriche && m.metriche.paese) || '');
    const av = m.me ? (flAvMio() || '<span class="am-av me">Tu</span>') : frAv(m.nome, m.device);
    return '<div class="fr-pod-c p' + pos + (m.me ? ' me' : '') + '"><div class="fr-pod-av">' + (ord === 'serie' ? FR_POD_FIAMMA : '<i class="fr-pod-alone"></i>') + av + '</div>'
      + '<b class="fr-pod-n">' + (frBandiera(paese) ? '<span class="fr-pod-fl">' + frBandiera(paese) + '</span>' : '') + esc(m.me ? amT('lega.tu') : m.nome) + '</b>'
      + '<span class="fr-pod-v">' + FR_POD_ICO[ord] + ' ' + esc(frMetFmt(ord, val(m))) + '</span>'
      + '<div class="fr-pod-g"><span>' + pos + '</span></div></div>';
  };
  const io = ordinati.filter(function(m){ return m.me; })[0];
  let riga = '';
  if (io){
    const pos = ordinati.indexOf(io) + 1, mio = val(io);
    const davanti = pos > 1 ? ordinati[pos - 2] : null;
    if (pos <= 3 && top.indexOf(io) >= 0) riga = '<b>Sei sul podio</b><small>Tieni il posto fino alla fine della settimana.</small>';
    else if (davanti && ord !== 'schermo' && val(davanti) !== null){
      const diff = Math.max(1, val(davanti) - (mio || 0) + (ord === 'punti' ? 1 : 0));
      riga = '<b>Sei ' + pos + '° su ' + n + '</b><small>Ancora ' + esc(frMetFmt(ord, diff)) + ' e superi ' + esc(davanti.nome) + '.</small>';
    } else riga = '<b>Sei ' + pos + '° su ' + n + '</b><small>Questa settimana si gioca su questo numero.</small>';
  }
  return tit + '<div class="fr-pod">' + posti.map(col).join('') + '</div>' + (riga ? '<div class="fr-pod-tu">' + riga + '</div>' : '');
}
/** La chip scelta resta visibile nella riga che scorre di lato. */
/* 0.9.321, Andrea: "toccando una pillola si spostavano tutte". La riga si ridisegna e si rimetteva con la scelta al centro: resta
   dov'era, e scorre solo quel che basta se la pillola scelta era fuori. */
const FR_RIGA = {};
document.addEventListener('scroll', function(e){ const t = e.target; if (!t || !t.classList) return; if (t.classList.contains('am-met')) FR_RIGA['.am-met'] = t.scrollLeft; else if (t.classList.contains('am-ord-l')) FR_RIGA['.am-ord-l'] = t.scrollLeft; }, true);
function frChipInVista(sel){
  try{
    const r = document.querySelector(sel), b = r && r.querySelector('button.on'); if (!r || !b) return;
    if (FR_RIGA[sel] !== undefined){ r.scrollLeft = FR_RIGA[sel]; }
    const qr = r.getBoundingClientRect(), qb = b.getBoundingClientRect();
    if (qb.left < qr.left) r.scrollLeft -= (qr.left - qb.left) + 16; else if (qb.right > qr.right) r.scrollLeft += (qb.right - qr.right) + 16;
  }catch(_){ }
}
/** Il numero di questa settimana di un membro della lega (io: dai miei conti; gli altri: dal server). */
function frLegaVal(m, ord){
  if (ord === 'punti') return m.punti || 0;
  return frMetVal(m.me ? FR.mieMet : m.metriche, ord, 'settimana');
}
function frLegaOrdinati(membri, ord){
  if (ord === 'punti') return membri.slice();
  return frMetOrdina(membri.map(function(m){ return { a: m, v: frLegaVal(m, ord) }; }), ord).map(function(r){ return r.a; });
}
function frLegaOrdHtml(catK, ord){
  const ob = FR_LEGA_OBIETTIVO[catK] || 'punti';
  const chiavi = [ob].concat(FR_LEGA_ORD.filter(function(k){ return k !== ob; }));
  const cat = frCatNome(catK);
  return '<div class="am-ord"><small>' + esc(amT('lega.ordina.etichetta')) + '</small><div class="am-ord-l">'
    + chiavi.map(function(k){ return '<button type="button"' + (k === ord ? ' class="on"' : '') + ' onclick="frLegaOrdina(\'' + k + '\')">' + (k === ob ? '🎯 ' : '') + esc(amT('lega.ordina.' + k)) + '</button>'; }).join('')
    + '</div><p class="am-ord-p">' + esc(amT('lega.ordina.riga.' + ord)) + '</p>'
    + (ord === ob && cat ? '<p class="am-ord-p ob">' + esc(amT('lega.ordina.obiettivo', { categoria: cat })) + '</p>' : '') + '</div>';
}
/* entrare: categoria e soprannome, una schermata sola */
function frLegaEntraHtml(){
  const sel = FR.cat || frCategoriaSuggerita();
  FR.cat = sel;
  return '<div class="am-lega-hero center"><small style="color:#9EC1FF">' + esc(amT('lega.entra.etichetta')) + '</small><b>' + esc(amT('lega.entra.titolo')) + '</b><p>' + esc(amT('lega.entra.sotto')) + '</p></div>'
    + '<div class="am-entra"><small class="am-lbl">' + esc(amT('lega.entra.categoria')) + '</small>'
    + '<div class="am-cats">' + FR_CATEGORIE.map(function(k){ return '<button type="button" class="am-cat' + (k === sel ? ' on' : '') + '" onclick="frCatScegli(\'' + k + '\')">' + (FR_CAT_ICO[k] || '') + ' ' + esc(amT('lega.categorie.' + k)) + '</button>'; }).join('') + '</div>'
    + '<small class="am-lbl">' + esc(amT('lega.entra.nick')) + '</small><input class="fin" id="frNick" maxlength="24" placeholder="' + esc(amT('lega.entra.nickPh')) + '" value="' + esc(frNick() || frName()) + '">'
    + '<button type="button" class="am-cta" onclick="frLegaIscrivi(true)">' + esc(amT('lega.entra.btn')) + '</button></div>';
}
function frCatScegli(k){ FR.cat = k; document.querySelectorAll('.am-cat').forEach(function(b){ b.classList.toggle('on', b.textContent.trim().indexOf(amT('lega.categorie.' + k)) >= 0); }); }
function frRisultatoHtml(r){
  const tier = amT('lega.tier.' + (r.tierOra || 'bronzo'));
  /* IL PREMIO DEL PODIO (0.9.203): chi chiude la settimana nei primi tre prende 40 monete per
     il negozio, una volta per settimana */
  let premio = '';
  try{
    const k = 'fl_lega_premio_' + r.settimana;
    if (r.posizione >= 1 && r.posizione <= 3 && r.esito !== 'formazione' && !localStorage.getItem(k)){
      localStorage.setItem(k, '1'); if (typeof ffAddCoins === 'function') ffAddCoins(40);
      try{ flVibra([20, 30, 60]); }catch(_){ }
    }
    if (r.posizione >= 1 && r.posizione <= 3 && r.esito !== 'formazione') premio = '<p class="am-ris-premio">🪙 <b>+40 monete</b> per il podio. Resta nei primi tre anche la prossima settimana.</p>';
  }catch(_){ }
  const titolo = amT('lega.risultato.' + (r.esito || 'confermato'), { tier: tier });
  return '<div class="am-ris ' + esc(r.esito || '') + '"><span>' + frTierIco(r.tierOra) + '</span><b>' + esc(titolo) + '</b>'
    + (r.esito !== 'formazione' ? '<p>' + esc(amT('lega.risultato.sotto', { pos: r.posizione, n: r.n, punti: r.punti })) + '</p>' : '') + premio
    + '<button type="button" class="ghostmini" onclick="frLegaVisto(\'' + esc(r.settimana) + '\')">' + esc(amT('lega.risultato.ok')) + '</button></div>';
}
async function frLegaIscrivi(optIn){
  const i = document.getElementById('frNick');
  const nick = i ? i.value.trim().slice(0, 24) : frNick();
  const cat = FR.cat || frCategoriaSuggerita();
  try{ localStorage.setItem('fl_lega_nick', nick); localStorage.setItem('fl_lega_cat', cat); }catch(_){ }
  try{
    await frApi('POST', '/api/focuslock/social/lega/iscrivi', { device: frDevice(), nick: nick, optIn: !!optIn, categoria: cat });
    await frSync(true);
    await frLegaCarica(true);
    if (!optIn) frLegaAvvisoAnnulla();
    frPaint();
  }catch(e){ toast(e && e.message ? e.message : 'Non riuscito'); }
}
async function frLegaVisto(settimana){
  try{ await frApi('POST', '/api/focuslock/social/lega/visto', { device: frDevice(), settimana: settimana }); }catch(_){ }
  if (FR.lega) FR.lega.risultato = null;
  frPaint();
}
/* 0.9.337, Andrea: "il podio allunga anche le altre slide: come il Gymshark slider, l'altezza deve seguire la slide che vedi" */
function frLgAltezza(c, i){
  const sl = c && c.children[i]; if (!sl) return;
  c.style.height = sl.scrollHeight + 'px';
}
function frLgDot(){ const c = document.getElementById('frLgCar'), d = document.getElementById('frLgDots'); if (!c || !d) return; const i = Math.round(c.scrollLeft / Math.max(1, c.clientWidth)); d.querySelectorAll('i').forEach(function(x, k){ x.classList.toggle('on', k === i); }); frLgAltezza(c, i); }
setInterval(function(){ const c = document.getElementById('frLgCar'); if (c && !c.style.height && c.offsetParent) frLgDot(); }, 400);
function frLegaFormula(){
  const L = FR.lega || {}, i = FR_TIERS.indexOf(L.tier);
  const su = i >= 0 && i < FR_TIERS.length - 1 ? amT('lega.tier.' + FR_TIERS[i + 1]) : '', giu = i > 0 ? amT('lega.tier.' + FR_TIERS[i - 1]) : '';
  const righe = [['⭐', 'Come fai i punti', '1 punto per ogni minuto di Full Focus finito, fino a 480 al giorno. 30 punti per ogni passo della rotta.']];
  if (su) righe.push(['⬆️', 'Chi sale', 'I primi 5 passano alla Lega ' + esc(su) + '.']);
  if (giu) righe.push(['⬇️', 'Chi scende', 'Gli ultimi 5 ripartono dalla Lega ' + esc(giu) + '.']);
  righe.push(['📅', 'Quando', 'La settimana va da lunedì a domenica, e ogni lunedì si ricomincia.']);
  if (FR.legaRiga) righe.push(['📍', 'Dove sei adesso', esc(FR.legaRiga)]);
  inSheet('<div class="en-foglio"><button type="button" class="am-x" aria-label="Chiudi" onclick="inSheetChiudi()">✕</button><h3>Come funziona la lega</h3>' + flInfoRighe(righe) + '</div>');
}
/* L'UNICA NOTIFICA DI QUESTA PAGINA: lunedi' alle 9, «la lega ha chiuso». Locale, e mai nelle
   ore di silenzio (Avvisi.java la fa slittare). */
function frLegaAvviso(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.avviso) return;
    const d = new Date(); d.setHours(9, 0, 0, 0);
    const giorni = (8 - d.getDay()) % 7 || 7;
    d.setDate(d.getDate() + giorni);
    NATIVE.avviso({ id: 1, at: d.getTime(), titolo: amT('lega.avviso.titolo'), testo: amT('lega.avviso.testo') });
  }catch(_){ }
}
function frLegaAvvisoAnnulla(){ try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.avvisoAnnulla) NATIVE.avvisoAnnulla({ id: 1 }); }catch(_){ } }
/* la notifica apre la pagina */
setTimeout(function(){ try{ if (/[?&]apri=amici/.test(location.search)) frOpen('lega'); }catch(_){ } }, 2500);

/* ---------------------------------------------------------------- lo stile (dai prototipi) */
(function frStyle(){
  const css = [
    '.am-motto{margin:0 0 16px 4px;font:500 12px/1.5 var(--font-body);font-style:italic;color:var(--muted);max-width:30ch}',
    '.am-offline{margin:-6px 0 12px;font:600 12px var(--font-body);color:var(--muted);text-align:center}',
    /* 0.9.340, Andrea: "l'intestazione degli Amici non e' attaccata in alto, c'e' uno spazio sopra": la schermata ha 22px di margine in alto e
       l'intestazione si fermava li'. Ora sale di 22px e li copre con il suo sfondo */
    '.fr-tabs{display:flex;background:rgba(0,30,68,.06);border-radius:99px;padding:3px;margin:0 0 16px}#s-friends .topbar{position:sticky;top:-22px;z-index:8;margin:-22px -4px 8px;padding:30px 4px 8px;background:var(--bg,#F4F7FB)}body.dark #s-friends .topbar{background:var(--bg,#00132B)}.fr-tre{position:absolute;right:4px;top:22px;bottom:0;margin:auto 0}.fr-tre[hidden]{display:none}',
    /* 0.9.304, Andrea: in scuro la linguetta scelta era grigia e quasi invisibile sul fondo. Ora blu notte del brand e la scelta in blu pieno */
    'body.dark .fr-tabs{background:#14234A;box-shadow:inset 0 0 0 1px #22376B}body.dark .fr-tabs button{color:#BCE0FF}',
    '.fr-tabs button{flex:1;border:none;background:transparent;border-radius:99px;padding:10px 0;font:700 13px var(--font-body);color:var(--muted);cursor:pointer;transition:background .2s}',
    '.fr-tabs button.on{background:#fff;color:#001E44;box-shadow:0 2px 8px rgba(0,30,68,.12)}',
    'body.dark .fr-tabs button.on{background:#0075E3;color:#fff;box-shadow:0 4px 12px rgba(0,117,227,.35)}',
    /* sezioni e card */
    '.am-sect{display:flex;align-items:baseline;justify-content:space-between;margin:24px 2px 10px}',
    '.am-sect b{font:800 19px var(--font-display);color:var(--navy);letter-spacing:-.01em}.am-sect span{font:600 11px var(--font-body);color:var(--faint)}',
    '.am-hint{margin:14px 8px 0;text-align:center;font:500 11px/1.5 var(--font-body);color:var(--faint)}',
    '.am-cta{display:block;width:100%;margin-top:20px;border:none;cursor:pointer;border-radius:99px;padding:18px 20px;font:700 16px var(--font-body);color:#fff;background:linear-gradient(135deg,#0075E3 0%,#005BB0 100%);box-shadow:0 12px 26px rgba(0,117,227,.35)}',
    '.am-cta:active{transform:scale(.97)}',
    '.am-link{display:block;width:100%;background:none;border:none;cursor:pointer;font:600 13px var(--font-body);color:var(--muted);padding:14px 0 0}.am-link b{letter-spacing:.12em;color:var(--navy)}',
    '.am-av{width:44px;height:44px;border-radius:50%;flex:none;display:inline-flex;align-items:center;justify-content:center;color:#fff;font:800 18px var(--font-display);background:#0075E3}',
    '.am-av.lg{width:60px;height:60px;font-size:24px}.am-av.me{background:#0075E3;font-size:14px;box-shadow:0 0 0 3px rgba(255,255,255,.9)}',
    '.am-av.free{background:transparent;border:2px dashed rgba(255,255,255,.55);box-sizing:border-box;font:600 20px var(--font-body);color:rgba(255,255,255,.8)}',
    '.am-delta{display:inline-block;flex:none;font:700 11px var(--font-body);padding:5px 10px;border-radius:99px;background:#E2F6F2;color:#0E7C6B;white-space:nowrap}',
    '.am-delta.down{background:#FDEAEC;color:#E63946}.am-delta.flat{background:rgba(0,30,68,.07);color:var(--muted)}',
    '.am-center{text-align:center;margin-top:12px}',
    /* la classifica degli amici, come su Sweatcoin (0.9.300) */
    '.am-cl-h{display:flex;align-items:center;gap:6px;margin:30px 0 14px}',
    '.am-cl-h b{flex:1;min-width:0;font:800 22px var(--font-display);color:var(--navy);letter-spacing:-.01em}body.dark .am-cl-h b{color:#fff}',
    '.am-cerca{display:inline-flex;align-items:center;gap:6px;flex:none;border:0;background:transparent;padding:8px 4px;color:#0075E3;font:700 14px var(--font-body);cursor:pointer}body.dark .am-cerca{color:#8CC6FF}',
    '.am-punti{flex:none;width:40px;height:40px;display:flex;align-items:center;justify-content:center;border:0;border-radius:50%;background:#E3F1FF;color:#0075E3;cursor:pointer}body.dark .am-punti{background:#14234A;color:#8CC6FF}',
    /* 0.9.316: una fila sola, dentro ai margini della pagina: scorre e si taglia al margine, come le card sotto. Niente grigio. */
    '.am-met{display:flex;gap:8px;overflow-x:auto;overflow-y:hidden;scrollbar-width:none;margin:0;padding:2px 0}.am-met::-webkit-scrollbar{display:none}',
    '.am-met button{flex:none;display:inline-flex;align-items:center;gap:7px;min-height:46px;box-sizing:border-box;border:1.5px solid #BCE0FF;border-radius:99px;padding:9px 16px;background:var(--card,#fff);color:var(--navy);font:700 14px var(--font-body);cursor:pointer;white-space:nowrap}',
    '.am-met-i{font-size:16px;line-height:1}',
    '.am-met button.on{border-color:#0075E3;background:#0075E3;color:#fff}',
    '.am-met button:not(.on) .am-met-i{display:none}',
    '.am-met button.on .am-met-i{display:inline-flex;width:24px;height:24px;margin-left:-6px;align-items:center;justify-content:center;border-radius:50%;background:#fff;font-size:14px}',
    'body.dark .am-met button{background:#14234A;border-color:rgba(188,224,255,.22);color:#fff}body.dark .am-met button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    '.am-per-t{display:block;margin:4px 40px 16px;text-align:center}',
    '.am-per{display:flex;flex-direction:column;gap:8px}',
    '.am-per button{display:flex;align-items:center;justify-content:space-between;width:100%;min-height:54px;padding:12px 18px;box-sizing:border-box;border:1.5px solid #BCE0FF;border-radius:18px;background:var(--card,#fff);color:var(--navy);font:700 15.5px var(--font-body);text-align:left;cursor:pointer}',
    '.am-per button.on{border-color:#0075E3;background:#E3F1FF;color:#0075E3}',
    'body.dark .am-per button{background:#14234A;border-color:rgba(188,224,255,.22);color:#fff}body.dark .am-per button.on{border-color:#3F9FF4;background:#22376B;color:#fff}',
    '.am-cl-sp{margin:12px 4px 14px;font:500 13.5px/1.45 var(--font-body);color:var(--muted)}.am-cl-sp b{font-weight:800;color:var(--navy)}body.dark .am-cl-sp b{color:#fff}',
    '.am-cl{display:flex;flex-direction:column;gap:8px}',
    '.am-cl-r{display:flex;align-items:center;gap:14px;width:100%;box-sizing:border-box;text-align:left;padding:12px 18px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line);box-shadow:0 4px 14px rgba(0,30,68,.05);cursor:pointer;font:inherit}',
    'body.dark .am-cl-r{background:#12203A;border-color:#22345A;box-shadow:none}',
    '.am-cl-r.me{cursor:default;border-color:#0075E3;box-shadow:inset 0 0 0 1px #0075E3}body.dark .am-cl-r.me{border-color:#3F9FF4;box-shadow:inset 0 0 0 1px #3F9FF4}',
    '.am-cl-r:not(.me):active{transform:scale(.985)}',
    '.am-cl-n{width:18px;flex:none;text-align:center;font:800 15px var(--font-display);color:var(--navy)}body.dark .am-cl-n{color:#fff}',
    '.am-cl-r .am-av{width:46px;height:46px;font-size:19px}',
    '.am-cl-r > b{flex:1;min-width:0;font:800 15px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body.dark .am-cl-r > b{color:#fff}',
    '.am-cl-v{flex:none;font:800 15px var(--font-body);color:var(--navy)}body.dark .am-cl-v{color:#fff}.am-cl-v.nd{color:var(--faint)}body.dark .am-cl-v.nd{color:#6F84A6}',
    '.am-cl-r.vuota > b{color:var(--muted)}body.dark .am-cl-r.vuota > b{color:#C9D6EE}',
    '.am-av.am-cl-piu{background:rgba(0,30,68,.07);color:var(--navy)}body.dark .am-av.am-cl-piu{background:rgba(255,255,255,.1);color:#fff}',
    /* cosa ordina la lega (0.9.300) */
    /* 0.9.309, Andrea: "Ordina per" era attaccato al pannello della lega: 18px di spazio vero sopra */
    '.am-lg-car{display:flex;align-items:flex-start;gap:12px;overflow-x:auto;overflow-y:hidden;scroll-snap-type:x mandatory;scrollbar-width:none;transition:height .3s ease}.am-lg-car::-webkit-scrollbar{display:none}.am-lg-s{flex:0 0 100%;box-sizing:border-box;scroll-snap-align:center;min-width:0;display:flex;flex-direction:column;border-radius:22px;background:linear-gradient(180deg,#06204A,#00132B);padding:16px 0 14px;color:#fff}',
    '.am-lg-hero{background:linear-gradient(180deg,rgba(2,9,38,.35),rgba(2,9,38,.85)),url(img/dream-night.jpg) center 35%/cover no-repeat,#020926}.am-lg-med{flex:none;width:58px;height:58px;display:flex;align-items:center;justify-content:center;border-radius:50%;background:rgba(255,255,255,.14)}.am-lg-med svg{width:38px;display:block}.am-lg-nomi{flex:1;min-width:0}.am-lg-nomi i{display:block;font:700 11px var(--font-body);font-style:normal;letter-spacing:.14em;text-transform:uppercase;color:#D6E8FF}.am-lg-top{display:flex;align-items:center;gap:12px;padding:0 16px}.am-lg-top b{display:block;margin-top:2px;font:800 22px/1.15 var(--font-display);font-style:italic;color:#fff}.am-lg-top small{display:block;margin-top:5px;font:800 12px var(--font-body);letter-spacing:.06em;color:#8CC6FF}',
    '.am-lg-i{flex:none;width:28px;height:28px;padding:0;border:1.5px solid rgba(188,224,255,.7);border-radius:50%;background:none;color:#BCE0FF;font:800 14px var(--font-body);cursor:pointer}',
    '.am-coppe{display:flex;align-items:center;gap:18px;overflow-x:auto;scrollbar-width:none;padding:18px 16px 4px}.am-coppe::-webkit-scrollbar{display:none}.am-coppa{flex:none;width:72px;opacity:.95;transition:transform .2s}.am-coppa svg{display:block;width:100%}.am-coppa.on{width:96px;filter:drop-shadow(0 0 16px rgba(140,198,255,.7))}.am-coppa.dopo{filter:saturate(.55) brightness(.62)}',
    '.fr-pod-s{padding:16px 14px 16px!important;background:radial-gradient(120% 70% at 50% 20%,#123E80 0%,#06204A 55%,#00132B 100%)!important}.fr-pod-t{margin:0 0 4px;text-align:center;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#8CC6FF}',
    '.fr-pod{display:flex;align-items:flex-end;justify-content:center;gap:8px;margin-top:6px}.fr-pod-c{flex:1;max-width:108px;min-width:0;display:flex;flex-direction:column;align-items:center}',
    '.fr-pod-av{position:relative;display:flex;align-items:flex-end;justify-content:center;width:84px;height:92px}.fr-pod-av .am-av{position:relative;z-index:1;width:52px;height:52px;font-size:20px;margin-bottom:8px;box-shadow:0 0 0 3px rgba(255,255,255,.9)}.fr-pod-c.p1 .fr-pod-av{height:112px}.fr-pod-c.p1 .fr-pod-av .am-av{width:64px;height:64px;font-size:24px}',
    '.fr-pod-fi{position:absolute;left:50%;bottom:0;width:84px;height:110px;transform:translateX(-50%);filter:drop-shadow(0 0 14px rgba(230,57,70,.55));animation:frPodFi 1.6s ease-in-out infinite alternate}.fr-pod-c.p1 .fr-pod-fi{width:100px;height:132px}@keyframes frPodFi{to{transform:translateX(-50%) scale(1.05,1.08)}}',
    '.fr-pod-alone{position:absolute;left:50%;bottom:-2px;width:84px;height:84px;transform:translateX(-50%);border-radius:50%;background:radial-gradient(circle,rgba(140,198,255,.55),rgba(140,198,255,0) 68%)}',
    '.fr-pod-n{display:flex;align-items:center;gap:5px;max-width:100%;margin-top:6px;font:800 13.5px var(--font-body);color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.fr-pod-fl{font-size:15px;line-height:1}',
    '.fr-pod-v{margin:6px 0 8px;padding:4px 10px;border:1.5px solid rgba(140,198,255,.55);border-radius:99px;font:800 12.5px var(--font-body);color:#D6E8FF;white-space:nowrap}',
    '.fr-pod-g{display:flex;align-items:flex-start;justify-content:center;width:100%;height:64px;border-radius:14px 14px 4px 4px;background:linear-gradient(180deg,#1C4E96,#0A2A5E);box-shadow:inset 0 3px 0 #8CC6FF}.fr-pod-c.p1 .fr-pod-g{height:96px;background:linear-gradient(180deg,#2A63B8,#0B3470)}.fr-pod-c.p3 .fr-pod-g{height:48px}',
    '.fr-pod-g span{margin-top:8px;font:900 34px/1 var(--font-display);color:#fff;text-shadow:0 0 18px rgba(140,198,255,.8)}.fr-pod-c.p1 .fr-pod-g span{font-size:44px}',
    '.fr-pod-tu{margin:14px 2px 0;padding:12px 14px;border-radius:16px;background:rgba(140,198,255,.12);border:1px solid rgba(140,198,255,.25);text-align:center}.fr-pod-tu b{display:block;font:800 15px var(--font-display);color:#fff}.fr-pod-tu small{display:block;margin-top:2px;font:500 13px/1.4 var(--font-body);color:#BFD3EC}',
    '.fr-pod-vuoto{margin:30px 10px;text-align:center;font:500 14px/1.5 var(--font-body);color:#BFD3EC}',
    '.am-lg-dots{display:flex;justify-content:center;gap:7px;margin:10px 0 2px}.am-lg-dots i{width:7px;height:7px;border-radius:50%;background:#C9D9EE}.am-lg-dots i.on{background:#0075E3}body.dark .am-lg-dots i{background:#2C4170}body.dark .am-lg-dots i.on{background:#8CC6FF}',
    /* le tre schede restano in cima; l'ombra piena copre quello che scorre sopra e attorno */
    '.fr-tabs{position:sticky;top:58px;z-index:7;background:#E6ECF4;box-shadow:0 0 0 8px var(--bg,#F4F7FB),0 -44px 0 8px var(--bg,#F4F7FB)}body.dark .fr-tabs{box-shadow:inset 0 0 0 1px #22376B,0 0 0 8px var(--bg,#00132B),0 -44px 0 8px var(--bg,#00132B)}',
    '.am-ord{margin:18px 0 12px}.am-ord > small{display:block;margin:0 2px 8px;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}',
    '.am-ord-l{display:flex;gap:8px;overflow-x:auto;scrollbar-width:none;margin:0;padding:2px 0}.am-ord-l::-webkit-scrollbar{display:none}',
    '.am-ord-l button{flex:none;border:1.5px solid #BCE0FF;border-radius:99px;padding:8px 13px;background:var(--card,#fff);color:var(--navy);font:700 13px var(--font-body);cursor:pointer;white-space:nowrap}',
    '.am-ord-l button.on{background:#0075E3;border-color:#0075E3;color:#fff}',
    'body.dark .am-ord-l button{background:#12203A;border-color:#22345A;color:#fff}body.dark .am-ord-l button.on{background:#0075E3;border-color:#0075E3}',
    '.am-ord-p{margin:8px 4px 0;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}.am-ord-p.ob{margin-top:2px;font-weight:800;color:#E63946}body.dark .am-ord-p.ob{color:#E63946}',
    /* la riga amico */
    '.am-lista{display:flex;flex-direction:column;gap:10px}',
    '.am-fr{background:var(--card,#fff);border:1px solid var(--line);border-radius:18px;padding:12px 12px 10px;box-shadow:0 4px 14px rgba(0,30,68,.05);cursor:pointer;transition:transform .15s}',
    '.am-fr:active{transform:scale(.985)}body.dark .am-fr{background:#12203A;border-color:#22345A}',
    '.am-fr-top{display:flex;align-items:center;gap:11px}.am-fr-nm{flex:1;min-width:0}',
    '.am-fr-nm b{display:block;font:700 14px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body.dark .am-fr-nm b{color:#fff}',
    '.am-fr-meta{display:flex;gap:10px;margin-top:1px;font:500 11.5px var(--font-body);color:var(--muted)}',
    '.am-fr-bot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:10px;padding-top:10px;border-top:1px solid var(--line)}',
    '.am-score{display:flex;align-items:baseline;gap:5px;font:600 10.5px var(--font-body);color:var(--muted);white-space:nowrap}',
    '.am-score b{font:800 16px var(--font-display);color:var(--navy)}.am-score b.old{color:var(--faint)}.am-score span{color:var(--faint)}body.dark .am-score b{color:#fff}',
    '.am-fi{flex:none;border:none;border-radius:99px;min-height:38px;padding:0 14px;background:var(--blue-soft,#E3F1FF);color:#0075E3;font:700 12px var(--font-body);cursor:pointer}',
    '.am-fi.sent{display:inline-flex;align-items:center;background:#E2F6F2;color:#0E7C6B}',
    '.fr-mn{padding:6px 2px 10px;text-align:center}.fr-mn h3{margin:4px 44px 18px;font:800 20px var(--font-display);color:var(--navy)}.fr-mn-p{margin:0 0 16px;font:500 14px/1.5 var(--font-body);color:var(--muted)}',
    '.fr-mn-r{display:flex;align-items:center;gap:14px;width:100%;margin:0 0 10px;padding:14px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);text-align:left;cursor:pointer}body.dark .fr-mn-r{background:#12203A;border-color:#22345A}',
    '.fr-mn-r > span{flex:none;width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:20px;background:var(--bg,#F4F9FF)}body.dark .fr-mn-r > span{background:#0F1B33}.fr-mn-r b{display:block;font:800 15px var(--font-body);color:var(--navy)}.fr-mn-r small{display:block;margin-top:2px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}',
    '.am-codici{margin-top:16px}.fr-add{display:flex;gap:8px;align-items:center}.fr-add .fin{flex:1;margin:0;text-transform:uppercase}.fr-add .fin::placeholder{text-transform:none}.fr-add .ghostmini{margin:0}',
    /* lo stato vuoto */
    /* UNA CARD SOLA, in tutte e due le modalita': notte, con il testo bianco. La versione
       «scura» a velo mezzo trasparente lasciava il gradiente sfalsato e il testo scuro. */
    /* IL GRADIENTE ROSA-AZZURRO DEL BRAND, SEMPRE (Andrea, 1/10): chiaro in modalita' chiara e
       chiaro in modalita' scura, con il testo scuro. Il gradiente e' scritto per esteso, e
       l'inchiostro e' fisso: cosi' il tema scuro non lo tocca. */
    '.am-vuoto{position:relative;border-radius:26px;overflow:hidden;padding:26px 20px 22px;text-align:center;background:linear-gradient(rgba(255,255,255,.35),rgba(255,255,255,.7) 75%),linear-gradient(135deg,#F6CCCC 0%,#F6CCE4 23%,#ECCFEF 31%,#DFD2F8 41%,#D0D7FD 50%,#C1DBFF 57%,#BCE0FF 67%,#B8E5FF 80%,#B6E9FE 88%,#BEEFFD 94%,#C7F4FC 97%,#D2F9FB 99%,#DDFEFC 100%);border:1px solid #DCE6F2}',
    '.am-vuoto .am-link{color:#5B6B85}.am-vuoto .am-link b{color:#001E44}',
    '.am-vuoto-art{position:relative;width:220px;height:210px;margin:0 auto}',
    '.am-glow{position:absolute;left:30px;top:18px;width:160px;height:160px;border-radius:50%;background:rgba(255,255,255,.7);box-shadow:0 20px 50px rgba(0,117,227,.18)}',
    '.am-vuoto-art img{position:absolute;left:50%;top:0;height:200px;width:auto;transform:translateX(-50%);filter:drop-shadow(0 12px 22px rgba(14,35,80,.25))}',
    '.am-tu{position:absolute;left:0;top:112px;width:52px;height:52px;border-radius:50%;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;font:800 15px var(--font-display);box-shadow:0 0 0 4px #fff,0 10px 22px rgba(0,30,68,.2)}',
    '.am-piu{position:absolute;right:0;top:112px;width:52px;height:52px;border-radius:50%;background:rgba(255,255,255,.85);border:2px dashed #0075E3;box-sizing:border-box;color:#0075E3;display:flex;align-items:center;justify-content:center;font:700 24px var(--font-body)}',
    '.am-vuoto h2,body.dark .am-vuoto h2{margin:10px 0 8px;font:800 24px/1.2 var(--font-display);font-style:italic;color:#001E44;text-wrap:balance}',
    '.am-vuoto p,body.dark .am-vuoto p{margin:0 auto;max-width:30ch;font:500 13px/1.6 var(--font-body);color:#5B6B85;text-wrap:pretty}',
    'body.dark .am-vuoto .am-link{color:#5B6B85}body.dark .am-vuoto .am-link b{color:#001E44}',
    '.am-vuoto p b,body.dark .am-vuoto p b{font-weight:800;color:#001E44}',
    '.am-tiles{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin-top:14px}',
    '.am-tiles div{background:var(--card,#fff);border:1px solid var(--line);border-radius:16px;padding:12px 8px;text-align:center;font:600 11px/1.35 var(--font-body);color:var(--muted)}.am-tiles i{display:block;font-size:20px;font-style:normal;margin-bottom:4px}',
    'body.dark .am-tiles div{background:#12203A;border-color:#22345A}',
    /* reazioni ricevute, privacy */
    '.am-reaz-tot{display:flex;gap:8px;flex-wrap:wrap}.am-reaz-tot span{padding:8px 12px;border-radius:999px;background:var(--blue-soft,#E3F1FF);font:700 12.5px var(--font-body);color:var(--navy)}body.dark .am-reaz-tot span{background:rgba(255,255,255,.08);color:#fff}',
    '.am-reaz-ult{display:flex;flex-direction:column;gap:4px;margin-top:10px}.am-reaz-ult small{font:500 12px var(--font-body);color:var(--muted)}',
    '.am-priv{margin-top:28px;padding:14px 16px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff)}body.dark .am-priv{background:#12203A;border-color:#22345A}',
    '.am-priv-top b{display:block;font:800 14px var(--font-body);color:var(--navy)}body.dark .am-priv-top b{color:#fff}.am-priv-top small{display:block;margin-top:2px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.am-priv-row{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-top:12px;padding-top:12px;border-top:1px solid var(--line)}',
    '.am-priv-row b{display:block;font:700 13px var(--font-body);color:var(--navy)}body.dark .am-priv-row b{color:#fff}.am-priv-row small{display:block;font:500 11.5px/1.4 var(--font-body);color:var(--muted)}',
    /* la scheda amico e i fogli */
    '.am-sheet{position:relative;text-align:left;padding-top:4px}',
    '.fr-testa{display:flex;flex-direction:column;align-items:center;gap:12px;padding:6px 0 14px}.fr-conta{display:flex;gap:34px}.fr-conta span{display:flex;flex-direction:column;align-items:center;font:600 12.5px var(--font-body);color:var(--muted)}.fr-conta b{font:900 24px/1.1 var(--font-display);color:var(--navy)}body.dark .fr-conta b{color:#fff}',
    '.fr-agg-cta{width:100%}.fr-agg-h{margin:4px 40px 14px 0;font:800 20px var(--font-display);color:var(--navy)}body.dark .fr-agg-h{color:#fff}.fr-agg-h2{margin:20px 0 10px;font:800 15px var(--font-body);color:var(--navy)}body.dark .fr-agg-h2{color:#fff}',
    '.fr-agg-r{display:flex;align-items:center;gap:12px;width:100%;padding:12px 14px;border-radius:14px;background:var(--card,#fff);border:1px solid var(--line);margin-top:10px;text-align:left}.fr-agg-r > span{font-size:20px}.fr-agg-r .fin{flex:1;margin:0;border:0;background:transparent;padding:0;font:600 15px var(--font-body)}.fr-agg-r.vai{cursor:pointer}.fr-agg-r.vai b{font:800 14.5px var(--font-body);color:var(--navy)}body.dark .fr-agg-r{background:#12203A;border-color:#22345A}body.dark .fr-agg-r.vai b{color:#fff}',
    '.fr-tr-sez{margin:22px 0 0}.fr-tr-row{display:flex;align-items:center;gap:14px;width:100%;text-align:left;padding:18px 16px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);margin-bottom:12px;cursor:pointer}body.dark .fr-tr-row{background:#12203A;border-color:#22345A}.fr-tr-ico{font-size:26px;width:36px;text-align:center}.fr-tr-row > div{flex:1;min-width:0}.fr-tr-row b{display:block;font:800 15.5px var(--font-body);color:var(--navy)}body.dark .fr-tr-row b{color:#fff}.fr-tr-row small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.fr-tr-cerca{margin:-2px 0 14px;padding:14px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff)}body.dark .fr-tr-cerca{background:#12203A;border-color:#22345A}.fr-tr-cerca .fin{margin:0}.fr-tr-tutti{border:0;background:transparent;font:800 12px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#0075E3;cursor:pointer}',
    '.am-online{display:inline-block;width:9px;height:9px;border-radius:50%;background:#1B9E6A;margin-left:7px;vertical-align:middle}.am-att{color:#1B9E6A;font-weight:700}.fr-cerca-r > div{flex:1}.fr-cerca-r small{display:block;font:500 11.5px var(--font-body);color:var(--muted)}',
    '.fr-cerca-top{display:flex;align-items:center;gap:10px;margin:6px 18px 14px;padding:4px 14px;border:2px solid #0075E3;border-radius:16px;background:var(--card,#fff)}body.dark .fr-cerca-top{background:#12203A}.fr-cerca-top span{font-size:20px}.fr-cerca-top .fin{flex:1;margin:0;border:0 !important;background:transparent;padding:10px 0;box-shadow:none !important;outline:none !important}.fr-cerca-top .fin:focus,.fr-cerca-top .fin:focus-visible{border:0 !important;box-shadow:none !important;outline:none !important}.fr-ct-cerca{margin:0 0 12px}.fr-sg-inv{border:1.5px solid #0075E3;border-radius:12px;background:transparent;color:#0075E3;font:800 12.5px var(--font-body);padding:9px 12px;cursor:pointer}#frCercaRis{padding:0 18px}.fr-sg-h{margin:18px 20px 10px}#frSuggCol{padding:0 18px}',
    '.fr-sg-l{display:flex;flex-direction:column;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);overflow:hidden}body.dark .fr-sg-l{background:#12203A;border-color:#22345A}.fr-sg{display:flex;align-items:center;gap:12px;padding:12px 14px;border-bottom:1px solid var(--line)}body.dark .fr-sg{border-color:#22345A}.fr-sg:last-child{border-bottom:0}.fr-sg > div{flex:1;min-width:0}.fr-sg b{display:block;font:800 15px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}body.dark .fr-sg b{color:#fff}.fr-sg small{display:block;font:500 12px var(--font-body);color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.fr-sg-piu{width:48px;height:40px;border:0;border-radius:12px;background:#0075E3;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 4px 0 #004FA0}.fr-sg-piu:disabled,.fr-sg-piu.on{background:#9DB7D6;box-shadow:none}.fr-sg-x{width:36px;height:40px;border:0;background:transparent;color:var(--muted);font-size:18px;cursor:pointer}',
    '.fr-ct-w{padding:0 18px}.fr-ct-w .am-sect{margin:6px 2px 10px}',
    '.fr-cerca-l{margin-top:8px}.fr-cerca-r{display:flex;align-items:center;gap:10px;padding:10px 4px;border-bottom:1px solid var(--line)}body.dark .fr-cerca-r{border-color:#22345A}.fr-cerca-r b{flex:1;font:800 14.5px var(--font-body);color:var(--navy)}body.dark .fr-cerca-r b{color:#fff}.fr-cerca-r .sf-segui{margin:0}.fr-gia{font:700 12px var(--font-body);color:var(--muted)}',
    '.am-ris-premio{margin:0 0 12px;padding:10px 12px;border-radius:12px;background:rgba(255,179,71,.18);font:600 13px/1.45 var(--font-body);color:var(--navy)}body.dark .am-ris-premio{color:#fff}',
    '.am-x{position:absolute;right:0;top:0;width:34px;height:34px;border:none;background:rgba(0,30,68,.07);border-radius:50%;font-size:14px;color:var(--ink);cursor:pointer}body.dark .am-x{background:rgba(255,255,255,.12);color:#fff}',
    '.am-sh-top{display:flex;align-items:center;gap:14px;padding-right:40px}.am-sh-top > div > b{display:block;font:800 21px var(--font-display);color:var(--navy)}body.dark .am-sh-top > div > b{color:#fff}',
    '.am-stats{display:flex;align-items:stretch;margin-top:18px;border:1px solid var(--line);border-radius:18px;padding:14px 4px}',
    '.am-stats > div{flex:1;text-align:center;padding:0 4px}.am-stats > div + div{border-left:1px solid var(--line)}',
    '.am-stats small{display:block;font:600 11px var(--font-body);color:var(--muted);margin-bottom:4px}.am-stats b{font:800 19px var(--font-display);color:var(--navy)}.am-stats b.sm{font-size:14px}body.dark .am-stats b{color:#fff}',
    '.am-sh-lbl{margin:20px 2px 10px;font:800 15px var(--font-display);color:var(--navy)}body.dark .am-sh-lbl{color:#fff}',
    '.am-reaz{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}',
    '.am-rx{border-radius:16px;padding:12px 4px 10px;cursor:pointer;display:flex;flex-direction:column;align-items:center;gap:5px;background:var(--card,#fff);border:1.5px solid var(--line);transition:all .2s}',
    '.am-rx.on{background:var(--blue-soft,#E3F1FF);border-color:#0075E3}body.dark .am-rx{background:#12203A;border-color:#22345A}body.dark .am-rx.on{background:#0F2A4A}',
    '.am-rx span{font-size:26px;line-height:1}.am-rx small{font:600 10.5px/1.25 var(--font-body);color:var(--navy);text-align:center}body.dark .am-rx small{color:#fff}',
    '.am-note{margin:12px 0 0;text-align:center;font:600 11.5px var(--font-body);color:var(--faint)}.am-note.ok{color:#0E7C6B}',
    /* 0.9.305: la pozione per un amico (scheda) e quella ricevuta (card in cima ad Amici) */
    '.am-dono{display:block;width:100%;margin-top:16px;padding:12px 14px;border:1.5px solid #0075E3;border-radius:16px;background:var(--blue-soft,#E3F1FF);text-align:center;cursor:pointer;font:inherit}',
    '.am-dono b{display:block;font:800 14px var(--font-body);color:#0075E3}.am-dono small{display:block;margin-top:3px;font:500 12px/1.4 var(--font-body);color:var(--muted)}',
    '.am-dono:disabled{cursor:default;border-color:var(--line);background:transparent}.am-dono:disabled b{color:var(--muted)}',
    'body.dark .am-dono{background:#0F2A4A;border-color:#3F9FF4}body.dark .am-dono b{color:#fff}body.dark .am-dono:disabled{background:transparent;border-color:#22345A}body.dark .am-dono:disabled b{color:#9EB0CC}',
    '.am-dono-r{display:flex;flex-direction:column;align-items:center;text-align:center;gap:10px;margin:0 0 14px;padding:18px 16px;border:1.5px solid #0075E3;border-radius:18px;background:var(--card,#fff);box-shadow:0 6px 18px rgba(0,117,227,.14)}',
    'body.dark .am-dono-r{background:#12203A;border-color:#3F9FF4;box-shadow:none}body.dark .am-dono-r .am-av{box-shadow:0 0 0 2px #8CC6FF}',
    '.am-dono-t{width:100%;min-width:0}.am-dono-t b{display:block;font:800 14.5px/1.35 var(--font-body);color:var(--navy)}body.dark .am-dono-t b{color:#fff}',
    '.am-dono-t small{display:block;margin-top:4px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}body.dark .am-dono-t small{color:#C9D6EE}',
    '.am-dono-t button{margin-top:10px;border:0;border-radius:99px;padding:10px 16px;background:#0075E3;color:#fff;font:800 13px var(--font-body);cursor:pointer}.am-dono-t button:disabled{opacity:.6}',
    '.am-sheet .am-cta{margin-top:16px}',
    '.am-sh-title{display:block;font:800 20px var(--font-display);font-style:italic;color:var(--navy);text-align:center}body.dark .am-sh-title{color:#fff}',
    '.am-code-blu .fin{border:2px solid #0075E3!important;background:#F0FBFF!important;color:#001E44!important;font-weight:700}.am-code-blu .fin::placeholder{color:#0075E3;opacity:1;font-weight:700}body.dark .am-code-blu .fin{background:#14305E!important;color:#fff!important}body.dark .am-code-blu .fin::placeholder{color:#8CC6FF}.am-code-blu .ghostmini{background:#0075E3!important;color:#fff!important;border-color:#0075E3!important}',
    '.am-sh-p{margin:10px 0 0;font:500 14px/1.55 var(--font-body);color:var(--muted);text-align:center}.am-sh-p + button,.am-sh-title + button{margin-top:26px}.am-sheet .dso-cta + .am-link,.am-sheet .am-cta + .am-link{margin-top:12px}',
    /* la lega */
    '.am-lega-hero{position:relative;border-radius:22px;overflow:hidden;padding:18px 18px 16px;color:#fff;background:linear-gradient(180deg,rgba(2,9,38,.35),rgba(2,9,38,.8)),url(img/dream-night.jpg) center 35%/cover no-repeat,#020926;box-shadow:0 10px 30px rgba(0,30,68,.18)}',
    '.am-lega-hero.center{text-align:center;padding:20px 18px 18px}',
    '.am-lega-hero small{display:block;font:700 10.5px var(--font-body);letter-spacing:.16em;text-transform:uppercase}',
    '.am-lega-hero b{display:block;margin-top:4px;font:800 22px/1.15 var(--font-display);font-style:italic;text-shadow:0 2px 12px rgba(0,0,0,.5)}',
    '.am-lega-hero p{margin:6px auto 0;max-width:28ch;font:500 12.5px/1.55 var(--font-body);color:rgba(255,255,255,.85)}',
    '.am-lega-top{display:flex;gap:14px;align-items:center}.am-lega-top > div{flex:1;min-width:0}',
    '.am-trofeo{width:58px;height:58px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;font-size:27px;box-shadow:0 0 0 4px rgba(255,255,255,.14),0 10px 24px rgba(0,0,0,.4)}',
    '.am-info{flex:none;width:30px;height:30px;border-radius:50%;border:1.5px solid rgba(255,255,255,.45);background:rgba(255,255,255,.12);color:#fff;font:800 13px var(--font-display);font-style:italic;cursor:pointer}',
    '.am-steps{display:flex;gap:6px;margin-top:16px}.am-steps > div{flex:1;text-align:center}.am-steps i{display:block;height:5px;border-radius:99px}',
    '.am-steps span{display:block;margin-top:5px;font:600 10.5px var(--font-body);color:rgba(255,255,255,.6)}.am-steps span.on{font-weight:800;color:#fff}',
    '.am-lega-riga{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:14px}',
    '.am-lega-riga span{font:500 12px/1.45 var(--font-body);color:rgba(255,255,255,.85)}.am-lega-riga em{flex:none;font-style:normal;background:rgba(255,255,255,.14);border-radius:99px;padding:6px 11px;font:700 11.5px var(--font-body);white-space:nowrap}',
    '.am-slots{display:flex;justify-content:center;gap:10px;margin-top:18px}.am-conta{margin-top:10px;font:700 12px var(--font-body);color:#fff}',
    '.am-formula{display:flex;align-items:center;gap:10px;width:100%;margin:12px 0 14px;background:var(--blue-soft,#E3F1FF);border:none;border-radius:14px;padding:10px 12px;cursor:pointer;text-align:left}',
    'body.dark .am-formula{background:#0F2A4A}',
    '.am-formula i{width:22px;height:22px;border-radius:50%;background:#0075E3;color:#fff;flex:none;display:flex;align-items:center;justify-content:center;font:800 12px var(--font-display);font-style:italic}',
    '.am-formula span{font:600 12px/1.4 var(--font-body);color:var(--navy)}body.dark .am-formula span{color:#fff}',
    '.am-board{background:var(--card,#fff);border:1px solid var(--line);border-radius:22px;padding:6px;box-shadow:0 10px 30px rgba(0,30,68,.06)}body.dark .am-board{background:#12203A;border-color:#22345A}',
    '.am-row{display:flex;align-items:center;gap:11px;padding:8px 10px;border-radius:14px}.am-row.me{background:var(--blue-soft,#E3F1FF);box-shadow:inset 0 0 0 1.5px #0075E3}body.dark .am-row.me{background:#0F2A4A}',
    '.am-row .am-av{width:36px;height:36px;font-size:15px}.am-row .am-av.me{font-size:13px;box-shadow:none}',
    '.am-pos{width:22px;text-align:center;flex:none;font:800 13px var(--font-display);color:var(--navy)}.am-pos.top{color:#0E7C6B}.am-pos.low{color:var(--faint)}body.dark .am-pos{color:#fff}',
    '.am-row b{flex:1;min-width:0;font:600 13.5px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.am-row.me b{font-weight:800}body.dark .am-row b{color:#fff}',
    '.am-pt{flex:none;font:800 14px var(--font-display);color:var(--navy)}.am-pt.me{color:#0075E3}.am-pt small{font:600 10.5px var(--font-body);color:var(--faint)}body.dark .am-pt{color:#fff}',
    '.am-zona{display:flex;align-items:center;gap:8px;padding:8px 8px 12px}.am-zona i{flex:1;height:2px;border-radius:99px;background:#1B9E6A}',
    '.am-zona span{font:700 10px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#0E7C6B;background:#E2F6F2;border-radius:99px;padding:5px 10px}',
    '.am-zona.giu{padding:12px 8px 8px}.am-zona.giu i{height:1px;background:var(--line)}.am-zona.giu span{color:var(--muted);background:rgba(0,30,68,.07)}',
    '.am-esci{display:block;margin:24px auto 0;border:0;background:transparent;color:var(--faint);font:700 12.5px var(--font-body);cursor:pointer}',
    '.am-entra{margin-top:16px}.am-lbl{display:block;margin:16px 2px 8px;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:var(--faint)}',
    '.am-cats{display:flex;flex-wrap:wrap;gap:8px}.am-cat{border:1.5px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:9px 14px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer}',
    '.am-cat.on{background:#001E44;border-color:#001E44;color:#fff}body.dark .am-cat{background:#12203A;border-color:#22345A;color:#fff}body.dark .am-cat.on{background:#0075E3;border-color:#0075E3}',
    '.am-entra .fin{margin:0}',
    '.am-ris{text-align:center;padding:20px 16px;border-radius:20px;border:1.5px solid var(--line);margin-bottom:16px;background:var(--card,#fff)}body.dark .am-ris{background:#12203A;border-color:#22345A}',
    '.am-ris span{font-size:36px;display:block}.am-ris b{display:block;margin-top:8px;font:800 18px var(--font-display);font-style:italic;color:var(--navy)}body.dark .am-ris b{color:#fff}',
    '.am-ris p{margin:6px 0 14px;font:500 13px/1.5 var(--font-body);color:var(--muted)}.am-ris .ghostmini{margin:0}.am-ris.promosso{border-color:#1B9E6A}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
