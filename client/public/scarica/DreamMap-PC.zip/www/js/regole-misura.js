/* ===========================================================================================
   LE REGOLE SU MISURA DELLA PARTITA (0.9.285) — il tuo agente personale fa da arbitro e da VAR

   Andrea: "il mio agente deve poter creare workflow e REGOLE per la partita del vecchio te contro
   il nuovo te: trasforma le mie idee in regole con condizioni e trigger che danno punti, su misura
   per il mio obiettivo". Il suo esempio: a lui serve la partita delle idee, perche' le idee nuove lo
   rallentano. A un altro servira' altro: per questo le regole le scrive l'agente, persona per persona.

   UNA REGOLA = un momento che l'app vede da sola (il "quando"), chi prende i punti, quanti, ed
   eventualmente un orario e delle parole. Una regola che l'app non puo' contare non e' una regola,
   e' un'intenzione (modelli.js): per questo i "quando" sono solo quelli qui sotto, e l'agente li
   conosce (le regole di scrittura del server, focuslockChat.ts).

   DA DOVE ARRIVANO
     - dalla chat: l'agente chiude la risposta con ```json {"regola": {...}} ``` (o una lista);
       la regola entra subito, con la card "Regola aggiunta" e il suo Annulla (come i programmi);
     - dagli strumenti dell'agente (focuslockAgentTools.ts, crea_regola_partita): un comando in coda
       che il telefono applica al sync (friends.js, frComandiApplica);
     - da te, in questa pagina.
   fl_regole_su_misura = [{ id, nome, quando, chi: 'neo'|'old', punti, entro, dopo, parole, perche, da, at, on, volte }]
   =========================================================================================== */
const RGM_KEY = 'fl_regole_su_misura';
const RGM_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
const RGM_FATTI = 'fl_regole_fatti';            // { <id del messaggio dell'agente>: [id delle regole] }
const RGM_DEV_VISTI = 'fl_regole_dev_visti';    // le deviazioni gia' contate
const RGM_GIORNO = 'fl_regole_giorno';          // l'ultimo giorno chiuso a mezzanotte
const RGM_QUANDO = {
  caveau:     { t: 'Quando metti un’idea nel caveau', lato: 'neo', ico: '🔒' },
  deviazione: { t: 'Quando aggiungi una cosa fuori rotta', lato: 'old', ico: '➕' },
  tieniRighe: { t: 'Quando tieni nel foglio righe nuove con la priorità ancora aperta', lato: 'old', ico: '📝' },
  taglia:     { t: 'Quando tagli un’idea', lato: 'neo', ico: '✂️' },
  passo:      { t: 'Quando chiudi un passo della roadmap', lato: 'neo', ico: '🛤️' },
  riga:       { t: 'Quando spunti una riga del foglio', lato: 'neo', ico: '✅' },
  sessione:   { t: 'Quando porti a termine una sessione di Full Focus', lato: 'neo', ico: '🚀' },
  mollata:    { t: 'Quando molli una sessione a metà', lato: 'old', ico: '🏳️' },
  ceduto:     { t: 'Quando interrompi un blocco', lato: 'old', ico: '🔓' },
  /* 0.9.303, Andrea: lo stile "Partita" della schermata di blocco c'e' solo con questa regola accesa. I tentativi li vede il
     telefono (la cronologia dei blocchi) e fuori-rotta.js li trasforma in punti (frPartitaTentativi). */
  tentativo:  { t: 'Quando provi ad aprire un’app o un sito bloccati', lato: 'old', ico: '🚫' },
  giornoSenzaDeviazioni: { t: 'Quando chiudi la giornata senza aggiunte fuori rotta', lato: 'neo', ico: '🌙', mezzanotte: true },
  giornoSenzaSessioni:   { t: 'Quando chiudi la giornata senza una sessione', lato: 'old', ico: '🌙', mezzanotte: true },
  /* 0.9.290, Andrea: "il mio agente deve poter creare QUALSIASI regola, con dei workflow come n8n". Una regola e' un
     piccolo flusso: QUANDO (il momento) + SE (le condizioni: orario, giorni, minuti, parole, la volta del giorno) +
     ALLORA (chi prende i punti e quanti). I momenti nuovi: */
  umore:          { t: 'Quando segni il tuo umore', lato: 'neo', ico: '🙂' },
  respiro:        { t: 'Quando finisci un esercizio di respiro', lato: 'neo', ico: '🫁' },
  tappa:          { t: 'Quando completi una tappa della mappa', lato: 'neo', ico: '🗺️' },
  tempoTelefono:  { t: 'Quando chiudi la giornata con il tempo passato sul telefono', lato: 'old', ico: '📱', mezzanotte: true },
  tempoApp:       { t: 'Quando chiudi la giornata con il tempo passato su un’app', lato: 'old', ico: '📲', mezzanotte: true },
  giornoSessioni: { t: 'Quando chiudi la giornata con le tue sessioni di Full Focus', lato: 'neo', ico: '🏁', mezzanotte: true }
};
const RGM_GIORNI = ['lun', 'mar', 'mer', 'gio', 'ven', 'sab', 'dom'];
function rgmGiorniNorm(v){
  if (!Array.isArray(v) || !v.length) return null;
  if (v.length === 7 && v.every(function(x){ return typeof x === 'boolean'; })) return v.some(Boolean) && !v.every(Boolean) ? v.slice() : null;
  const out = [false, false, false, false, false, false, false];
  v.forEach(function(x){ const k = String(x || '').trim().toLowerCase().slice(0, 3); const i = RGM_GIORNI.indexOf(k); if (i >= 0) out[i] = true; else if (/^\d$/.test(String(x))) out[(+x + 6) % 7] = true; });
  return out.some(Boolean) && !out.every(Boolean) ? out : null;
}
function rgmNum(v, a, b){ const n = Math.round(+v); return isFinite(n) && v !== null && v !== '' && v !== undefined ? Math.max(a, Math.min(b, n)) : null; }
const RGM_SINONIMI = { idea_caveau: 'caveau', caveau_idea: 'caveau', fuori_rotta: 'deviazione', idea_fuori_rotta: 'deviazione', righe_nuove: 'tieniRighe', taglio: 'taglia', idea_tagliata: 'taglia', passo_roadmap: 'passo', riga_spuntata: 'riga', sessione_fatta: 'sessione', sessione_mollata: 'mollata', blocco_interrotto: 'ceduto', tentativo_bloccato: 'tentativo', tentativo_distrazione: 'tentativo' };

function rgmLeggi(){ try{ const l = JSON.parse(localStorage.getItem(RGM_KEY) || '[]'); return Array.isArray(l) ? l.filter(function(r){ return r && r.id && RGM_QUANDO[r.quando]; }) : []; }catch(_){ return []; } }
function rgmScrivi(l){ try{ localStorage.setItem(RGM_KEY, JSON.stringify((l || []).slice(-60))); }catch(_){ } try{ document.dispatchEvent(new CustomEvent('fl:regole')); }catch(_){ } }
function rgmJ(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function rgmEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function rgmGiornoK(t){ const d = new Date(t || Date.now()); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function rgmOra(v){ const m = String(v == null ? '' : v).match(/^(\d{1,2})(?::\d{2})?$/); if (!m) return null; const h = +m[1]; return h >= 0 && h <= 23 ? h : null; }

/** Una regola pulita da quello che arriva (agente, strumento, pagina). null se il "quando" non si puo' contare. */
function rgmNorm(x, da){
  if (!x || typeof x !== 'object') return null;
  let q = String(x.quando || x.trigger || '').trim();
  if (RGM_SINONIMI[q]) q = RGM_SINONIMI[q];
  if (!RGM_QUANDO[q]) return null;
  const chi = /^(old|vecchio)/i.test(String(x.chi || '')) ? 'old' : /^(neo|nuovo|new)/i.test(String(x.chi || '')) ? 'neo' : RGM_QUANDO[q].lato;
  const parole = (Array.isArray(x.parole) ? x.parole : []).map(function(p){ return String(p || '').trim().toLowerCase(); }).filter(Boolean).slice(0, 8);
  return {
    id: 'rs' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    nome: String(x.nome || RGM_QUANDO[q].t).trim().slice(0, 80),
    quando: q, chi: chi,
    punti: Math.max(1, Math.min(3, Math.round(+x.punti || 1))),
    entro: rgmOra(x.entro), dopo: rgmOra(x.dopo),
    parole: parole,
    perche: String(x.perche || '').trim().slice(0, 200),
    /* le condizioni del flusso (0.9.290) */
    giorni: rgmGiorniNorm(x.giorni),
    piuDi: rgmNum(x.piuDi != null ? x.piuDi : (x.minuti && x.minuti.min), 1, 1440),
    menoDi: rgmNum(x.menoDi != null ? x.menoDi : (x.minuti && x.minuti.max), 1, 1440),
    app: String(x.app || '').trim().slice(0, 60),
    dallaVolta: rgmNum(x.dallaVolta, 2, 50),
    maxGiorno: rgmNum(x.maxGiorno, 1, 20),
    almeno: rgmNum(x.almeno, 1, 20),
    votoMax: rgmNum(x.votoMax, 1, 5), votoMin: rgmNum(x.votoMin, 1, 5),
    /* 0.9.294: il VAR, l'arbitro con l'intelligenza artificiale che giudica il senso del testo */
    var: !!(x.var || x.giudice || x.arbitro), minParole: rgmNum(x.minParole, 1, 100),
    da: da || 'tu', at: Date.now(), on: true, volte: 0
  };
}
/** Aggiunge una o piu' regole. Restituisce gli id aggiunti. Una regola uguale a una che c'e' gia' non si duplica. */
function rgmAggiungi(x, da){
  const lista = Array.isArray(x) ? x : [x];
  const l = rgmLeggi(); const ids = [];
  lista.forEach(function(y){
    const r = rgmNorm(y, da); if (!r) return;
    const firma = function(o){ return [o.quando, o.chi, o.entro, o.dopo, (o.parole || []).join('|'), JSON.stringify(o.giorni || null), o.piuDi, o.menoDi, String(o.app || '').toLowerCase(), o.dallaVolta, o.maxGiorno, o.almeno, o.votoMax, o.votoMin, !!o.var].join('~'); };
    const uguale = l.filter(function(o){ return firma(o) === firma(r); })[0];
    if (uguale){ uguale.punti = r.punti; uguale.nome = r.nome; if (r.perche) uguale.perche = r.perche; uguale.on = true; ids.push(uguale.id); return; }
    l.push(r); ids.push(r.id);
  });
  if (ids.length) rgmScrivi(l);
  return ids;
}
window.rgmAggiungi = rgmAggiungi;
function rgmTogli(ids){ const via = Array.isArray(ids) ? ids : [ids]; rgmScrivi(rgmLeggi().filter(function(r){ return via.indexOf(r.id) < 0; })); }

/* ---------------------------------------------------------------------------------------
   L'ARBITRO: quando l'app vede un momento, le regole su misura assegnano i loro punti
   --------------------------------------------------------------------------------------- */
function rgmVale(r, testo, at, dati){
  if (!r.on) return false;
  dati = dati || {};
  const quando = new Date(at || Date.now()), h = quando.getHours();
  if (r.entro !== null && r.entro !== undefined && h >= r.entro) return false;
  if (r.dopo !== null && r.dopo !== undefined && h < r.dopo) return false;
  if (r.giorni && r.giorni.length === 7 && !r.giorni[(quando.getDay() + 6) % 7]) return false;
  if (r.parole && r.parole.length){
    /* 0.9.294, Andrea: "ho scritto DreamMap e il punto non e' arrivato: la regola aveva Dream Map con lo spazio". Le parole
       si confrontano senza spazi, maiuscole, accenti e punteggiatura. */
    const t = rgmPiatto(testo);
    if (!r.parole.some(function(p){ const q = rgmPiatto(p); return q && t.indexOf(q) >= 0; })) return false;
  }
  if (dati.minuti != null){
    if (r.piuDi != null && !(dati.minuti > r.piuDi)) return false;
    if (r.menoDi != null && !(dati.minuti < r.menoDi)) return false;
  }
  if (dati.voto != null){
    if (r.votoMax != null && dati.voto > r.votoMax) return false;
    if (r.votoMin != null && dati.voto < r.votoMin) return false;
  }
  /* la volta del giorno: "dalla terza idea fuori rotta", "al massimo due volte al giorno" */
  const g = rgmGiornoK(quando.getTime());
  if (!r.oggi || r.oggi.g !== g) r.oggi = { g: g, n: 0, p: 0 };
  r.oggi.n++;
  if (r.dallaVolta != null && r.oggi.n < r.dallaVolta) return false;
  if (r.maxGiorno != null && r.oggi.p >= r.maxGiorno) return false;
  return true;
}
function rgmPiatto(x){ return String(x || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, ''); }
/* ---------------------------------------------------------------------------------------
   IL VAR (0.9.294). Prima il filtro gratuito (parole minime, doppioni), poi l'arbitro AI sul server: il punto arriva solo
   se il verdetto e' VALIDO. Se il server non risponde l'idea resta "in revisione" e si riprova: mai il punto regalato.
   --------------------------------------------------------------------------------------- */
const RGM_VAR_CODA = 'fl_var_coda', RGM_VAR_STORIA = 'fl_var_storia';
function rgmParole(t){ return (String(t || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').match(/[a-z0-9]{2,}/g) || []); }
function rgmSimile(a, b){
  const A = rgmParole(a), B = rgmParole(b); if (!A.length || !B.length) return 0;
  const sb = {}; B.forEach(function(w){ sb[w] = 1; });
  const comuni = A.filter(function(w){ return sb[w]; }).length;
  return comuni / Math.max(A.length, B.length);
}
function rgmVarFiltro(r, testo){
  const n = rgmParole(testo).length, min = r.minParole || 8;
  if (n < min) return 'Troppo corta: ' + n + (n === 1 ? ' parola' : ' parole') + ', ne servono almeno ' + min + '.';
  const storia = rgmJ(RGM_VAR_STORIA, []) || [];
  if (storia.some(function(x){ return x && x.t && rgmSimile(testo, x.t) > 0.85; })) return 'È uguale a un’idea che hai già messo nel caveau.';
  return '';
}
function rgmVarContesto(){
  let sogno = '', priorita = '', progetti = '';
  try{ sogno = (typeof nvSogno === 'function' && nvSogno()) || ''; }catch(_){ }
  try{ const m = (typeof stMissione === 'function') ? stMissione() : null; priorita = (m && m.t) || ''; }catch(_){ }
  try{ const a = (typeof agDati === 'function') ? agDati() : null; progetti = (a && (a.progetti || a.sogno)) || ''; }catch(_){ }
  return { sogno: sogno, priorita: priorita, progetti: typeof progetti === 'string' ? progetti : JSON.stringify(progetti).slice(0, 500) };
}
function rgmVarAvviso(ok, motivo){
  const t = ok ? '⚽ Punto convalidato dal VAR' + (motivo ? ': ' + motivo : '') : '🚩 Fuorigioco' + (motivo ? ': ' + motivo : '');
  try{ if (typeof toast === 'function') toast(t); }catch(_){ }
  try{ flVibra(ok ? [20, 40, 30] : [40]); }catch(_){ }
}
async function rgmVarGiudica(id, testo, at, silenzio){
  const ctx = rgmVarContesto();
  let v = null;
  try{
    if (typeof agApi !== 'function') throw new Error('nessuna rete');
    v = await agApi('POST', '/api/focuslock/agent/var', { testo: testo, sogno: ctx.sogno, progetti: ctx.progetti, priorita: ctx.priorita });
  }catch(e){ v = null; }
  if (!v || !v.verdetto){
    /* il VAR non ha risposto: in revisione, si riprova piu' tardi */
    const coda = rgmJ(RGM_VAR_CODA, []) || [];
    if (!coda.some(function(x){ return x.id === id && x.t === testo; })) coda.push({ id: id, t: testo, at: at || Date.now() });
    try{ localStorage.setItem(RGM_VAR_CODA, JSON.stringify(coda.slice(-30))); }catch(_){ }
    if (!silenzio) try{ if (typeof toast === 'function') toast('🕒 L’idea è in revisione dal VAR: il verdetto arriva appena c’è rete'); }catch(_){ }
    return;
  }
  const storia = rgmJ(RGM_VAR_STORIA, []) || [];
  storia.push({ at: Date.now(), t: String(testo).slice(0, 400), esito: v.verdetto, motivo: String(v.motivo || '').slice(0, 140) });
  try{ localStorage.setItem(RGM_VAR_STORIA, JSON.stringify(storia.slice(-200))); }catch(_){ }
  const l = rgmLeggi(); const reg = l.filter(function(x){ return x.id === id; })[0];
  if (!reg){ return; }
  if (v.verdetto === 'VALIDO'){
    const g = rgmGiornoK(Date.now());
    if (!reg.oggi || reg.oggi.g !== g) reg.oggi = { g: g, n: 0, p: 0 };
    if (reg.maxGiorno != null && reg.oggi.p >= reg.maxGiorno){ rgmVarAvviso(false, 'hai già preso i punti di oggi con questa regola'); return; }
    if (rgmPunti(reg, testo)){ reg.volte = (reg.volte || 0) + 1; reg.ultima = Date.now(); reg.oggi.p++; }
    rgmScrivi(l);
    rgmVarAvviso(true, v.motivo);
  } else {
    rgmVarAvviso(false, v.motivo);
  }
}
async function rgmVarRiprova(){
  const coda = rgmJ(RGM_VAR_CODA, []) || []; if (!coda.length) return;
  try{ localStorage.setItem(RGM_VAR_CODA, '[]'); }catch(_){ }
  for (const x of coda.slice(0, 10)) await rgmVarGiudica(x.id, x.t, x.at, true);
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(rgmVarRiprova, 3000); });
setTimeout(rgmVarRiprova, 15000);
/* la regola "VAR del Caveau" che l'agente aveva scritto il 20/10 solo con le parole chiave diventa un VAR vero, una volta */
(function rgmVarMigra(){
  try{
    if (localStorage.getItem('fl_var_mig294') === '1') return;
    const l = rgmLeggi(); let c = false;
    l.forEach(function(x){ if (x.quando === 'caveau' && /var/i.test(x.nome || '') && !x.var){ x.var = true; x.parole = []; x.maxGiorno = x.maxGiorno || 5; c = true; } });
    if (c) rgmScrivi(l);
    localStorage.setItem('fl_var_mig294', '1');
  }catch(_){ }
})();
function rgmPunti(r, testo){
  const n = Math.max(1, Math.min(3, +r.punti || 1));
  const motivo = 'regola su misura: ' + r.nome + (testo ? ' (' + String(testo).replace(/\s+/g, ' ').slice(0, 60) + ')' : '');
  if (r.chi === 'old'){
    try{ if (typeof mgCfg === 'function' && !mgCfg().oldScores) return false; }catch(_){ }
    try{ if (typeof mgLog === 'function') mgLog('old', motivo, { punti: n, regola: r.id }); }catch(_){ }
    try{ if (typeof mtOldPoint === 'function') for (let i = 0; i < n; i++) mtOldPoint(); }catch(_){ }
  } else {
    try{ if (typeof mgLog === 'function') mgLog('neo', motivo, { punti: n, regola: r.id }); }catch(_){ }
    try{ if (typeof mtFocusPoint === 'function') for (let i = 0; i < n; i++) mtFocusPoint(); }catch(_){ }
  }
  return true;
}
/** Un momento visto dall'app: tutte le regole che lo riguardano segnano. */
function rgmSegna(quando, testo, at, dati){
  const l = rgmLeggi(); let segnate = 0, contate = 0; const nomi = [];
  l.forEach(function(r){
    if (r.quando !== quando) return;
    contate++;
    if (!rgmVale(r, testo, at, dati)) return;
    if (r.var){
      /* il VAR: il filtro gratuito qui, il giudizio dopo (asincrono); il punto arriva solo con il verdetto */
      const no = rgmVarFiltro(r, testo);
      if (no){ rgmVarAvviso(false, no); return; }
      const id = r.id, t = testo;
      setTimeout(function(){ rgmVarGiudica(id, t, at); }, 50);
      return;
    }
    if (rgmPunti(r, testo)){ r.volte = (r.volte || 0) + 1; r.ultima = Date.now(); if (r.oggi) r.oggi.p++; segnate++; nomi.push((r.chi === 'old' ? '+' + r.punti + ' al vecchio te' : '+' + r.punti + ' al nuovo te') + ': ' + r.nome); }
  });
  if (contate) rgmScrivi(l);
  if (segnate){
    try{ if (typeof toast === 'function') toast('⚽ ' + nomi[0] + (nomi.length > 1 ? ' (e altre ' + (nomi.length - 1) + ')' : '')); }catch(_){ }
  }
  return segnate;
}

/* LA MEZZANOTTE: le regole sulla giornata intera si contano a giornata chiusa, una volta sola */
function rgmMezzanotte(){
  const R = rgmLeggi().filter(function(r){ return r.on && RGM_QUANDO[r.quando].mezzanotte; });
  const oggi = rgmGiornoK();
  let ultimo = String(localStorage.getItem(RGM_GIORNO) || '');
  if (!ultimo){ try{ localStorage.setItem(RGM_GIORNO, oggi); }catch(_){ } return; }
  if (ultimo >= oggi) return;
  const giorni = [];
  const d = new Date(ultimo + 'T12:00:00');
  for (let k = 0; k < 4; k++){ const g = rgmGiornoK(d.getTime()); if (g >= oggi) break; giorni.push(g); d.setDate(d.getDate() + 1); }
  try{ localStorage.setItem(RGM_GIORNO, oggi); }catch(_){ }
  if (!R.length) return;
  const dev = rgmJ('fl_deviazioni', []) || [];
  const partite = rgmJ('fl_match_hist', []) || [];
  const ff = rgmJ('fl_ff_hist', []) || [];
  giorni.forEach(function(g){
    const fuori = dev.some(function(e){ return e && rgmGiornoK(+e.at) === g; })
      || partite.some(function(p){ return p && p.day === g && (p.eventi || []).some(function(e){ return e && e.chi === 'old' && !e.stornato && /^(fuori rotta|Cose nuove aggiunte)/i.test(String(e.motivo || '')); }); });
    const nSess = ff.filter(function(h){ return h && h.ok && !h.meditazione && rgmGiornoK(+(h.start || h.at)) === g; }).length;
    const alle = new Date(g + 'T23:00:00').getTime();
    R.forEach(function(r){
      const giornoOk = !(r.giorni && r.giorni.length === 7 && !r.giorni[(new Date(g + 'T12:00:00').getDay() + 6) % 7]);
      if (!giornoOk) return;
      if (r.quando === 'giornoSenzaDeviazioni' && !fuori) rgmPunti(r, g);
      if (r.quando === 'giornoSenzaSessioni' && !nSess) rgmPunti(r, g);
      if (r.quando === 'giornoSessioni' && nSess >= (r.almeno || 1)) rgmPunti(r, g);
    });
    /* il tempo sul telefono e sulle app: lo misura il telefono, si legge il rapporto di quel giorno */
    const T = R.filter(function(r){ return r.quando === 'tempoTelefono' || r.quando === 'tempoApp'; });
    if (T.length && typeof scReport === 'function'){
      const off = Math.round((new Date(rgmGiornoK() + 'T12:00:00') - new Date(g + 'T12:00:00')) / 86400000);
      Promise.resolve(scReport(off)).then(function(rep){
        if (!rep || !rep.granted) return;
        T.forEach(function(r){
          let ms = 0;
          if (r.quando === 'tempoTelefono') ms = +rep.screenMs || +rep.totalMs || 0;
          else { const a = String(r.app || '').toLowerCase(); (rep.top || []).forEach(function(x){ if (a && (String(x.label || '').toLowerCase().indexOf(a) >= 0 || String(x.packageName || '').toLowerCase().indexOf(a) >= 0)) ms += +x.ms || 0; }); }
          if (rgmVale(r, r.app || '', alle, { minuti: Math.round(ms / 60000) })) rgmPunti(r, g);
        });
      }).catch(function(){ });
    }
  });
}

let RGM_UMORE_VISTO = '';
/* GLI AGGANCI: i momenti che l'app vede gia' */
(function(){
  document.addEventListener('fl:caveau', function(e){
    let t = ''; try{ const l = rgmJ('fl_caveau', []) || []; const u = l[l.length - 1]; t = u ? u.t : ''; }catch(_){ }
    rgmSegna('caveau', t);
  });
  document.addEventListener('fl:deviazione', function(){
    const reg = rgmJ('fl_deviazioni', []) || [];
    const visti = rgmJ(RGM_DEV_VISTI, null);
    if (visti === null){ try{ localStorage.setItem(RGM_DEV_VISTI, JSON.stringify(reg.map(function(e){ return e && e.id; }).filter(Boolean).slice(-300))); }catch(_){ } return; }
    const nuove = reg.filter(function(e){ return e && e.id && visti.indexOf(e.id) < 0; });
    nuove.forEach(function(e){ visti.push(e.id); rgmSegna('deviazione', e.motivo, +e.at || Date.now()); });
    if (nuove.length) try{ localStorage.setItem(RGM_DEV_VISTI, JSON.stringify(visti.slice(-300))); }catch(_){ }
  });
  document.addEventListener('fl:spunta', function(e){
    const d = e && e.detail;
    if (!d || !d.line || d.azione === 'ritirata') return;
    rgmSegna('riga', d.line);
  });
  document.addEventListener('fl:giorno', function(){ try{ rgmMezzanotte(); }catch(_){ } });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) try{ rgmMezzanotte(); }catch(_){ } });
  setTimeout(function(){ try{ rgmMezzanotte(); }catch(_){ } }, 6000);
  /* le funzioni dell'app che chiudono un momento: si avvolgono, il resto non cambia */
  const avvolgi = function(nome, dopo){
    const f = window[nome]; if (typeof f !== 'function' || f.__rs) return;
    const g = function(){ const r = f.apply(this, arguments); try{ dopo.apply(this, [r].concat(Array.prototype.slice.call(arguments))); }catch(_){ } return r; };
    /* le funzioni dichiarate con function stanno su window: cambiare window[nome] cambia anche chi le chiama per nome */
    g.__rs = true; window[nome] = g;
  };
  setTimeout(function(){
    avvolgi('ulFuoriTengo', function(){ rgmSegna('tieniRighe', ''); });
    avvolgi('ozSpunta', function(_, k, j){ try{ const a = ozAnello(k); const p = a && a.passi && a.passi[j]; if (p && p.fatto) rgmSegna('passo', p.t); }catch(_){ } });
    avvolgi('esTagliaVia', function(_, i){ try{ const r = ES.run; const v = r && r.voci && r.voci[i]; if (v && v.via && Date.now() - v.via < 2000) rgmSegna('taglia', v.t); }catch(_){ } });
    avvolgi('mgFocusPoint', function(r, motivo){ if (r && typeof mdEvento === 'function' && mdEvento('neo', motivo) === 'sessione'){ let min = null; try{ const h = rgmJ('fl_ff_hist', []) || []; const u = h[h.length - 1]; if (u && u.min) min = +u.min; else if (u && u.ms) min = Math.round(u.ms / 60000); }catch(_){ } rgmSegna('sessione', motivo, Date.now(), { minuti: min }); } });
    avvolgi('rsSalva', function(v){ rgmSegna('respiro', (v && v.k) || '', Date.now(), { minuti: v && v.sec ? Math.round(v.sec / 60) : null }); });
    avvolgi('umcSalva', function(_, st){ try{ const k = rgmGiornoK(); const g = st && st.giorni && st.giorni[k]; const v = g && +g.voto; if (v && RGM_UMORE_VISTO !== k + ':' + v){ RGM_UMORE_VISTO = k + ':' + v; rgmSegna('umore', '', Date.now(), { voto: v }); } }catch(_){ } });
    avvolgi('mgOldPoint', function(r, motivo){ if (!r || typeof mdEvento !== 'function') return; const ev = mdEvento('old', motivo); if (ev === 'mollata') rgmSegna('mollata', motivo); else if (ev === 'ceduto') rgmSegna('ceduto', motivo); });
  }, 1500);
  /* il Taglia del caveau: l'idea tagliata (ulisse.js, stato 'tagliata') */
  setTimeout(function(){
    try{
      const cvS = window.cvSalva; if (typeof cvS !== 'function' || cvS.__rs) return;
      const g = function(l){
        let prima = {}; try{ (rgmJ('fl_caveau', []) || []).forEach(function(x){ if (x && x.id) prima[x.id] = x.stato; }); }catch(_){ }
        const r = cvS.apply(this, arguments);
        try{ (l || []).forEach(function(x){ if (x && x.stato === 'tagliata' && prima[x.id] && prima[x.id] !== 'tagliata') rgmSegna('taglia', x.t); }); }catch(_){ }
        return r;
      };
      g.__rs = true; window.cvSalva = g; try{ cvSalva = g; }catch(_){ }
    }catch(_){ }
  }, 1600);
})();

/* ---------------------------------------------------------------------------------------
   DALLA CHAT: la card della regola scritta dall'agente (si applica una volta sola per messaggio)
   --------------------------------------------------------------------------------------- */
function rgmAgenteHtml(a, msgId){
  const fatti = rgmJ(RGM_FATTI, {}) || {};
  let ids = fatti[msgId];
  if (ids === 'annullate') return '';
  if (!ids){ ids = rgmAggiungi(a, 'agente'); fatti[msgId] = ids; try{ localStorage.setItem(RGM_FATTI, JSON.stringify(fatti)); }catch(_){ } }
  const l = rgmLeggi().filter(function(r){ return ids.indexOf(r.id) >= 0; });
  if (!l.length) return '<div class="jd-piano ag-piano ag-prog"><div class="jd-top"><span>⚽</span><b>Regola non creata</b></div><p class="jd-piano-sub">Questa regola parla di un momento che l’app non sa vedere da sola. Chiedi al tuo agente personale di riscriverla con uno dei momenti della partita.</p></div>';
  return '<div class="jd-piano ag-piano ag-prog"><div class="jd-top"><span>⚽</span><b>' + (l.length === 1 ? 'Regola aggiunta alla partita' : l.length + ' regole aggiunte alla partita') + '</b></div>'
    + l.map(function(r){ return '<p class="jd-piano-sub"><b>+' + r.punti + ' ' + (r.chi === 'old' ? 'al vecchio te' : 'al nuovo te') + '</b>: ' + rgmEsc(rgmFrase(r)) + '</p>'; }).join('')
    + '<div class="ag-prog-az"><button type="button" class="jd-applica ag-applica" onclick="rgmApri()"><span>Mostra le regole</span>' + ((typeof agSvg === 'function') ? agSvg('avanti', 16) : '') + '</button>'
    + '<button type="button" class="ag-prog-no" onclick="rgmAnnullaAgente(' + JSON.stringify(String(msgId)).replace(/"/g, '&quot;') + ')">Annulla</button></div></div>';
}
function rgmAnnullaAgente(msgId){
  const fatti = rgmJ(RGM_FATTI, {}) || {};
  const ids = fatti[msgId];
  if (Array.isArray(ids)) rgmTogli(ids);
  fatti[msgId] = 'annullate';
  try{ localStorage.setItem(RGM_FATTI, JSON.stringify(fatti)); }catch(_){ }
  try{ if (typeof agRidisegna === 'function') agRidisegna(); }catch(_){ }
  try{ toast('Regola tolta dalla partita'); }catch(_){ }
}
/** La regola detta a parole: il momento, l'orario, le parole. */
function rgmFrase(r){
  let t = RGM_QUANDO[r.quando].t;
  if (r.quando === 'tempoApp' && r.app) t = 'Quando chiudi la giornata con il tempo passato su ' + r.app;
  if (r.quando === 'giornoSessioni' && r.almeno) t = 'Quando chiudi la giornata con almeno ' + r.almeno + (r.almeno === 1 ? ' sessione' : ' sessioni') + ' di Full Focus';
  if (r.parole && r.parole.length) t += ' che parla di ' + r.parole.map(function(p){ return '"' + p + '"'; }).join(' o ');
  if (r.var) t += ', se il VAR la giudica un’idea tua e legata al tuo progetto';
  if (r.piuDi != null) t += ', sopra i ' + r.piuDi + ' minuti';
  if (r.menoDi != null) t += ', sotto i ' + r.menoDi + ' minuti';
  if (r.votoMax != null) t += ', con un voto fino a ' + r.votoMax;
  if (r.votoMin != null) t += ', con un voto da ' + r.votoMin + ' in su';
  if (r.entro !== null && r.entro !== undefined) t += ', prima delle ' + r.entro + ':00';
  if (r.dopo !== null && r.dopo !== undefined) t += ', dalle ' + r.dopo + ':00 in poi';
  if (r.giorni && r.giorni.length === 7){ const N = ['lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato', 'domenica']; t += ', solo ' + N.filter(function(_, i){ return r.giorni[i]; }).join(', '); }
  if (r.dallaVolta != null) t += ', dalla ' + r.dallaVolta + 'ª volta del giorno';
  if (r.maxGiorno != null) t += ', al massimo ' + r.maxGiorno + (r.maxGiorno === 1 ? ' volta' : ' volte') + ' al giorno';
  return t;
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA: le regole su misura, una per riga, con interruttore, punti e cestino
   --------------------------------------------------------------------------------------- */
registerScreen('s-regole-misura',
  '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + RGM_INDIETRO + '</button><b class="blk-title">Regole su misura</b></div>'
  + '<div id="rgmBody"></div><div class="spacer"></div>');
const RGM_W = { nuova: null };
function rgmApri(){ RGM_W.nuova = null; goId('s-regole-misura'); rgmPaint(); }
function rgmPaint(){
  const host = document.getElementById('rgmBody'); if (!host) return;
  const l = rgmLeggi();
  if (RGM_W.nuova){ host.innerHTML = rgmNuovaHtml(); return; }
  const righe = l.map(function(r){
    const q = RGM_QUANDO[r.quando];
    return '<div class="rs-r' + (r.on ? '' : ' off') + '">'
      + '<span class="md-pt ' + r.chi + '">+' + r.punti + '</span>'
      + '<div class="rs-t"><b>' + rgmEsc(r.nome) + '</b><small>' + rgmEsc(q.ico + ' ' + rgmFrase(r)) + '</small>'
      +   (r.perche ? '<em>' + rgmEsc(r.perche) + '</em>' : '')
      +   '<small class="rs-da">' + (r.chi === 'old' ? 'Punto al vecchio te' : 'Punto al nuovo te') + (r.da === 'agente' ? ' · scritta dal tuo agente personale' : '') + (r.volte ? ' · ha segnato ' + r.volte + (r.volte === 1 ? ' volta' : ' volte') : '') + '</small></div>'
      + '<div class="rs-ctl"><div class="md-step"><button type="button" onclick="rgmPt(\'' + r.id + '\',-1)" aria-label="Meno punti">−</button><button type="button" onclick="rgmPt(\'' + r.id + '\',1)" aria-label="Più punti">+</button></div>'
      +   '<button class="switch' + (r.on ? ' on' : '') + '" onclick="rgmOnOff(\'' + r.id + '\')" aria-label="Accendi o spegni la regola"></button>'
      +   '<button type="button" class="rs-via" onclick="rgmVia(\'' + r.id + '\')" aria-label="Togli la regola">✕</button></div>'
      + '</div>';
  }).join('');
  host.innerHTML = '<p class="rs-intro">Le regole scritte per <b>il tuo obiettivo</b>: il tuo agente personale le crea dalle tue idee, i punti li conta l’app.</p>'
    + (righe ? '<div class="rs-lista">' + righe + '</div>' : '<p class="rs-vuoto">Ancora nessuna regola su misura. Racconta al tuo agente personale cosa ti frena: la trasforma in una regola.</p>')
    + '<button type="button" class="am-cta" onclick="rgmChiediAgente()">Chiedi una regola al tuo agente personale</button>'
    + '<button type="button" class="am-link" onclick="RGM_W.nuova={quando:\'caveau\',punti:1};rgmPaint()">Scrivila da solo</button>';
}
function rgmPt(id, d){ const l = rgmLeggi(); const r = l.filter(function(x){ return x.id === id; })[0]; if (!r) return; r.punti = Math.max(1, Math.min(3, (+r.punti || 1) + d)); rgmScrivi(l); rgmPaint(); }
function rgmOnOff(id){ const l = rgmLeggi(); const r = l.filter(function(x){ return x.id === id; })[0]; if (!r) return; r.on = !r.on; rgmScrivi(l); rgmPaint(); }
async function rgmVia(id){
  const r = rgmLeggi().filter(function(x){ return x.id === id; })[0]; if (!r) return;
  let ok = true;
  try{ if (typeof blkConfirm === 'function') ok = await blkConfirm('Togliere la regola "' + r.nome + '"?', 'I punti che ha già segnato restano nella partita.', 'Togli', true); }catch(_){ }
  if (!ok) return;
  rgmTogli(id); rgmPaint();
}
function rgmChiediAgente(){
  const testo = 'Crea una regola su misura per la mia partita contro il vecchio te: ';
  if (typeof agApri === 'function'){ Promise.resolve(agApri()).then(function(){ try{ AG.vista = 'chat'; agPaint(); }catch(_){ } }); setTimeout(function(){ try{ agBozza(testo); }catch(_){ } }, 900); }
  else try{ toast('Apri il tuo agente personale dalla scheda Sogno'); }catch(_){ }
}
function rgmNuovaHtml(){
  const n = RGM_W.nuova;
  const q = RGM_QUANDO[n.quando] || RGM_QUANDO.caveau;
  const chi = n.chi || q.lato;
  return '<p class="rs-intro">Scegli il momento: <b>l’app lo vede da sola</b> e segna i punti.</p>'
    + '<div class="rs-scelte">' + Object.keys(RGM_QUANDO).map(function(k){ const x = RGM_QUANDO[k]; return '<button type="button" class="' + (k === n.quando ? 'on' : '') + '" onclick="RGM_W.nuova.quando=\'' + k + '\';RGM_W.nuova.chi=null;rgmPaint()"><span>' + x.ico + '</span>' + rgmEsc(x.t) + '</button>'; }).join('') + '</div>'
    + '<div class="md-ctl">'
    +   '<div class="md-row"><span>Chi prende i punti</span><div class="rs-chi"><button type="button" class="' + (chi === 'neo' ? 'on' : '') + '" onclick="RGM_W.nuova.chi=\'neo\';rgmPaint()">Nuovo te</button><button type="button" class="' + (chi === 'old' ? 'on old' : '') + '" onclick="RGM_W.nuova.chi=\'old\';rgmPaint()">Vecchio te</button></div></div>'
    +   '<div class="md-row"><span>Quanti punti</span><div class="md-step"><button type="button" onclick="RGM_W.nuova.punti=Math.max(1,(RGM_W.nuova.punti||1)-1);rgmPaint()" aria-label="Meno">−</button><b>' + (n.punti || 1) + '</b><button type="button" onclick="RGM_W.nuova.punti=Math.min(3,(RGM_W.nuova.punti||1)+1);rgmPaint()" aria-label="Più">+</button></div></div>'
    + '</div>'
    + '<button type="button" class="am-cta" onclick="rgmSalvaNuova()">Aggiungi la regola</button>'
    + '<button type="button" class="am-link" onclick="RGM_W.nuova=null;rgmPaint()">Annulla</button>';
}
function rgmSalvaNuova(){
  const n = RGM_W.nuova; if (!n) return;
  const ids = rgmAggiungi({ quando: n.quando, chi: n.chi || RGM_QUANDO[n.quando].lato, punti: n.punti || 1 }, 'tu');
  RGM_W.nuova = null; rgmPaint();
  if (ids.length) try{ toast('Regola aggiunta alla partita'); }catch(_){ }
}
/** La riga nel riepilogo della partita (modelli.js) e nel riquadro della pagina della partita. */
function rgmRigaHtml(){
  const n = rgmLeggi().filter(function(r){ return r.on; }).length;
  return '<div class="md-rie-r rs-entra" onclick="rgmApri()"><span class="md-pt neo">⚽</span><div><b>Regole su misura</b><small>' + (n ? (n === 1 ? 'Una regola scritta per te' : n + ' regole scritte per te') : 'Il tuo agente personale le scrive dalle tue idee') + '</small></div><span class="chev"></span></div>';
}
(function(){
  /* il riepilogo della partita e il riquadro: la riga che porta qui */
  setTimeout(function(){
    try{
      if (typeof mdPaint === 'function' && !mdPaint.__rs){
        const vero = mdPaint;
        const g = function(){
          const r = vero.apply(this, arguments);
          try{
            /* 0.9.290: le regole su misura si raggiungono SOLO da "Regole mie" */
            const host = document.getElementById('mdBody');
            const rie = host && host.querySelector('.md-rie');
            const mie = typeof mdLeggi === 'function' && mdLeggi() && mdLeggi().k === 'mie';
            if (mie && rie && !host.querySelector('.rs-entra')) rie.insertAdjacentHTML('afterend', '<div class="md-rie" style="margin-top:8px">' + rgmRigaHtml() + '</div>');
          }catch(_){ }
          return r;
        };
        g.__rs = true; window.mdPaint = g; try{ mdPaint = g; }catch(_){ }
      }
      if (typeof mdRiquadroHtml === 'function' && !mdRiquadroHtml.__rs){
        const veroR = mdRiquadroHtml;
        const h = function(){ const html = veroR.apply(this, arguments); const mie = typeof mdLeggi === 'function' && mdLeggi() && mdLeggi().k === 'mie'; return mie ? html.replace(/<\/div>$/, '<div class="md-rie" style="margin-top:10px">' + rgmRigaHtml() + '</div></div>') : html; };
        h.__rs = true; window.mdRiquadroHtml = h; try{ mdRiquadroHtml = h; }catch(_){ }
      }
    }catch(_){ }
  }, 1200);
  const css = [
    '.rs-intro{margin:4px 2px 14px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}.rs-intro b{color:var(--navy)}body.dark .rs-intro b{color:#fff}',
    '.rs-lista{display:flex;flex-direction:column;gap:10px;margin-bottom:18px}',
    '.rs-r{display:grid;grid-template-columns:auto 1fr;gap:8px 12px;align-items:start;padding:14px;border-radius:18px;background:var(--card,#fff);border:1px solid var(--line)}body.dark .rs-r{background:#12203A;border-color:#22345A}',
    '.rs-r.off{opacity:.55}',
    '.rs-t b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .rs-t b{color:#fff}',
    '.rs-t small{display:block;margin-top:3px;font:500 12.5px/1.4 var(--font-body);color:var(--muted)}.rs-t em{display:block;margin-top:6px;font:500 12.5px/1.45 var(--font-body);font-style:normal;color:var(--navy);background:var(--blue-soft,#E3F1FF);border-radius:10px;padding:6px 9px}body.dark .rs-t em{background:rgba(63,159,244,.15);color:#fff}',
    '.rs-t .rs-da{font-size:11.5px;margin-top:6px}',
    '.rs-ctl{grid-column:1/-1;display:flex;align-items:center;justify-content:flex-end;gap:10px}',
    '.rs-via{width:34px;height:34px;border-radius:17px;border:1px solid var(--line);background:transparent;color:var(--muted);font:700 13px var(--font-body);cursor:pointer}',
    '.rs-vuoto{margin:10px 6px 18px;text-align:center;font:500 14px/1.55 var(--font-body);color:var(--muted)}',
    '.rs-scelte{display:flex;flex-direction:column;gap:8px;margin-bottom:14px}.rs-scelte button{display:flex;align-items:center;gap:10px;text-align:left;border:1.5px solid var(--line);background:var(--card,#fff);border-radius:14px;padding:11px 12px;font:600 13.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .rs-scelte button{background:#12203A;border-color:#22345A;color:#fff}',
    '.rs-scelte button.on{border-color:#0B84FF;box-shadow:0 0 0 1.5px #3F9FF4}.rs-scelte span{font-size:18px}',
    '.rs-chi{display:flex;gap:6px}.rs-chi button{border:1px solid var(--line);background:transparent;border-radius:99px;padding:7px 12px;font:700 12.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .rs-chi button{color:#fff}.rs-chi button.on{background:#0075E3;border-color:#0075E3;color:#fff}.rs-chi button.on.old{background:#E63946;border-color:#E63946}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();


/* 0.9.288, Andrea: "non so dove sia Regole su misura: nella pagina La partita non c'e' nessun pannello". La porta sta in
   cima alla pagina della partita, dove si leggono le regole del gioco. */
function rgmPortaHtml(){
  const n = rgmLeggi().length;
  return '<button type="button" class="rgm-porta" onclick="rgmApri()"><span class="rgm-porta-i">✍️</span><div><b>Regole su misura</b><small>'
    + (n ? (n === 1 ? 'Una regola inventata da te' : n + ' regole inventate da te') : 'Inventa le tue regole: il tuo agente personale le trasforma in punti della partita')
    + '</small></div><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg></button>';
}
/* 0.9.290, Andrea: "al posto del pannello Regole su misura voglio la pagina Come vuoi giocare, con le card; le regole su
   misura solo dentro Regole mie". In cima alla pagina della partita ci sono le carte dei modi di giocare (modelli.js). */
function rgmPortaMetti(){
  const b = document.getElementById('mgBody'); if (!b) return;
  let p = document.getElementById('rgmPorta');
  if (!p){ p = document.createElement('div'); p.id = 'rgmPorta'; }
  if (b.firstChild !== p) b.insertBefore(p, b.firstChild);
  const html = typeof mdInlineHtml === 'function' ? mdInlineHtml() : rgmPortaHtml();
  if (p.__h !== html){ p.innerHTML = html; p.__h = html; const sel = p.querySelector('.md-card.sel'); if (sel) try{ sel.scrollIntoView({ block: 'nearest', inline: 'center' }); }catch(_){ } }
}
if (typeof document !== 'undefined'){
  (function(){
    const avvolgi = function(){
      if (typeof mgPaint !== 'function' || mgPaint.__rgm) return;
      const v = mgPaint;
      const w = function(){ const r = v.apply(this, arguments); try{ rgmPortaMetti(); Promise.resolve(r).then(function(){ try{ rgmPortaMetti(); }catch(_){ } }); }catch(_){ } return r; };
      w.__rgm = true; window.mgPaint = w;
    };
    avvolgi(); setTimeout(avvolgi, 1500);
    document.addEventListener('fl:screen', function(e){ if (e.detail === 's-match') setTimeout(rgmPortaMetti, 60); });
    document.addEventListener('fl:regole', function(){ try{ rgmPortaMetti(); }catch(_){ } });
    const st = document.createElement('style');
    st.textContent = '#rgmPorta{margin:0 0 16px}.rgm-porta{display:flex;align-items:center;gap:14px;width:100%;padding:16px;border:0;border-radius:18px;background:linear-gradient(135deg,#0075E3,#3F9FF4);color:#fff;text-align:left;cursor:pointer;font:inherit;box-shadow:0 10px 24px rgba(0,117,227,.25)}'
      + '.rgm-porta > div{flex:1;min-width:0}.rgm-porta b{display:block;font:800 16px var(--font-body);color:#fff}.rgm-porta small{display:block;margin-top:3px;font:600 13px/1.4 var(--font-body);color:#D8ECFF}'
      + '.rgm-porta-i{flex:none;width:42px;height:42px;border-radius:14px;display:grid;place-items:center;background:rgba(255,255,255,.18);font-size:20px}';
    document.head.appendChild(st);
  })();
}
