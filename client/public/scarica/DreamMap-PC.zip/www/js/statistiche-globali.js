/* ===========================================================================================
   STATISTICHE DI UTILIZZO GLOBALE (0.9.300, Andrea)

   "Una nuova sezione, un pannello nel Report che porta a una pagina dedicata": la replica della pagina
   "Statistiche di Utilizzo Globale" di StayFree. Due schede:
     · Confronto globale: per ogni app che usi davvero E che ha una media globale pubblicata, la tua media
       giornaliera su questo telefono (ultimi 7 o 30 giorni) contro la media nel mondo, con la freccia e la
       percentuale. In cima, "Utilizzo totale".
     · App di tendenza: le app con il maggior utilizzo medio giornaliero nel mondo, col loro tempo.

   I NUMERI GLOBALI NON SONO NEL CODICE: stanno in content/medie-globali.json, ognuno con la sua fonte,
   l'anno e l'indirizzo della pubblicazione. Un'app senza fonte li' dentro non compare.
   I numeri del telefono arrivano dal motore nativo (getTopApps, getScreenTimeRange), gli stessi del Report.

   L'ingresso e' un pannello piccolo e fisso in fondo al Report, prima di "Personalizza la pagina Report":
   non e' un blocco da ordinare. Il Report si ridisegna da capo a ogni vista, e report-blocchi.js riordina i
   suoi blocchi dopo ogni disegno: qui si aggancia scsOrdinaBlocchi('report') e il pannello viene rimesso
   al suo posto ogni volta, senza toccare ne' report.js ne' insights.js.
   =========================================================================================== */

const SG = { dati: null, scheda: 'confronto', giorni: 7, token: 0, info: null };

const SG_ICO = {
  indietro: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
  info: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="9.2"/><path d="M12 11v5.2"/><circle cx="12" cy="7.8" r=".6" fill="currentColor"/></svg>',
  chiudi: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
  chev: '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5l7 7-7 7"/></svg>',
  mondo: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.2"/><path d="M2.8 12h18.4"/><path d="M12 2.8c2.6 2.6 3.8 5.7 3.8 9.2s-1.2 6.6-3.8 9.2c-2.6-2.6-3.8-5.7-3.8-9.2S9.4 5.4 12 2.8z"/></svg>',
  su: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.2"/><path d="M12 16.6V8M8.4 11.6L12 8l3.6 3.6"/></svg>',
  giu: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9.2"/><path d="M12 7.4V16M8.4 12.4L12 16l3.6-3.6"/></svg>',
  uguale: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><circle cx="12" cy="12" r="9.2"/><path d="M8.2 12h7.6"/></svg>',
  /* l'icona di "Utilizzo totale": una clessidra dentro un anello blu e rosso */
  totale: '<svg width="42" height="42" viewBox="0 0 42 42"><rect width="42" height="42" rx="12" fill="#E3F1FF"/><circle cx="21" cy="21" r="14" fill="none" stroke="#0075E3" stroke-width="3.2" stroke-dasharray="58 30" stroke-linecap="round" transform="rotate(-90 21 21)"/><circle cx="21" cy="21" r="14" fill="none" stroke="#E63946" stroke-width="3.2" stroke-dasharray="22 66" stroke-dashoffset="-62" stroke-linecap="round" transform="rotate(-90 21 21)"/><path d="M16.2 13.2h9.6M16.2 28.8h9.6M17.4 13.2c0 4 2.6 5.2 3.6 7.8-1 2.6-3.6 3.8-3.6 7.8M24.6 13.2c0 4-2.6 5.2-3.6 7.8 1 2.6 3.6 3.8 3.6 7.8" fill="none" stroke="#001E44" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

/* ---------------------------------------------------------------------------------------
   FORMATI: il telefono con i secondi (come nel riferimento), il mondo al minuto (e' la precisione della fonte)
   --------------------------------------------------------------------------------------- */
function sgFmtSec(ms){
  const t = Math.max(0, Math.round((ms || 0) / 1000));
  const h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = t % 60;
  if (h) return h + 'h ' + m + 'm ' + s + 's';
  if (m) return m + 'm ' + s + 's';
  return s + 's';
}
function sgFmtMin(min){
  min = Math.max(0, Math.round(min || 0));
  const h = Math.floor(min / 60), m = min % 60;
  if (h) return h + 'h ' + m + 'm';
  return m + 'm';
}
function sgEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }

/* ---------------------------------------------------------------------------------------
   I DATI GLOBALI (content/medie-globali.json)
   --------------------------------------------------------------------------------------- */
async function sgCaricaGlobali(){
  if (SG.dati) return SG.dati;
  try{
    const r = await fetch('content/medie-globali.json', { cache: 'no-cache' });
    if (r.ok){
      const d = await r.json();
      /* un numero senza fonte non entra: la regola e' di Andrea, "mai numeri inventati" */
      d.app = (d.app || []).filter(function(a){ return a && a.minuti > 0 && a.fonte && a.anno && a.pacchetti && a.pacchetti.length; });
      SG.dati = d;
    }
  }catch(_){ }
  return SG.dati;
}

/* ---------------------------------------------------------------------------------------
   I NUMERI DEL TELEFONO: la media dei giorni in cui hai usato il telefono, negli ultimi N giorni interi
   --------------------------------------------------------------------------------------- */
async function sgLeggiTelefono(giorni){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getTopApps || !NATIVE.getScreenTimeRange) return null;
  const dammi = function(k, fn){ return (typeof insGet === 'function') ? insGet(k, fn) : fn(); };
  const g0 = (typeof insDayStart === 'function') ? insDayStart(Date.now()) : (function(){ const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); })();
  const piu = function(ts, n){ const d = new Date(ts); d.setDate(d.getDate() + n); return d.getTime(); };
  let da = piu(g0, -giorni), a = g0;
  let range = await dammi('sg:r:' + giorni + ':' + g0, function(){ return NATIVE.getScreenTimeRange({ from: da, to: a, bucket: 'day' }); });
  /* telefono appena installato: nessun giorno intero ancora, si parte da oggi */
  if (!range || !(range.ms > 0)){
    da = g0; a = Date.now();
    range = await dammi('sg:r0:' + Math.floor(a / 60000), function(){ return NATIVE.getScreenTimeRange({ from: da, to: a, bucket: 'day' }); });
  }
  const top = await dammi('sg:t:' + giorni + ':' + da + ':' + Math.floor(a / 60000), function(){ return NATIVE.getTopApps({ from: da, to: a, limit: 60, icons: 30 }); });
  const usati = Math.max(1, (range.buckets || []).filter(function(b){ return b && b.ms > 0; }).length);
  return { ms: range.ms || 0, giorni: usati, apps: (top && top.apps) || [] };
}

/* le app che usi e che hanno una media globale, dalla piu' usata */
function sgRighe(tel, glob){
  const perPkg = {};
  glob.app.forEach(function(g){ g.pacchetti.forEach(function(p){ perPkg[p] = g; }); });
  const escl = (typeof insExcl === 'function') ? insExcl() : [];
  const somme = {};
  tel.apps.forEach(function(a){
    if (!a || a.self || escl.indexOf(a.packageName) >= 0) return;
    const g = perPkg[a.packageName]; if (!g) return;
    const s = somme[g.id] || (somme[g.id] = { g: g, ms: 0, icona: '' });
    s.ms += a.ms || 0;
    if (!s.icona && a.icon && String(a.icon).indexOf('data:') === 0) s.icona = a.icon;
  });
  return Object.keys(somme).map(function(k){ return somme[k]; })
    .filter(function(s){ return s.ms >= 60000; })
    .map(function(s){ return { g: s.g, icona: s.icona, mediaMs: s.ms / tel.giorni, globMs: s.g.minuti * 60000 }; })
    .sort(function(a, b){ return b.mediaMs - a.mediaMs; });
}

/* ---------------------------------------------------------------------------------------
   DISEGNO
   --------------------------------------------------------------------------------------- */
function sgIcona(g, icona){
  const lett = (g.nome || '?').charAt(0).toUpperCase();
  const col = (typeof insIcoColor === 'function') ? insIcoColor(g.pacchetti[0]) : '#0075E3';
  let ico;
  if (icona) ico = '<img src="' + icona + '" alt="">';
  else if (typeof insIconeFonti === 'function' && typeof insIcoImg === 'function'){
    const f = insIconeFonti(g.dominio, g.nome);
    ico = f.length ? insIcoImg(f[0], f.slice(1), col, lett) : '<span class="ic-lettera" style="background:' + col + '">' + sgEsc(lett) + '</span>';
  } else ico = '<span class="ic-lettera" style="background:' + col + '">' + sgEsc(lett) + '</span>';
  return '<span class="sg-ico" data-g="' + sgEsc(g.id) + '">' + ico + '</span>';
}
function sgPct(mediaMs, globMs){
  const p = Math.round((mediaMs - globMs) / globMs * 100);
  const cls = p > 0 ? 'su' : (p < 0 ? 'giu' : 'uguale');
  return '<span class="sg-pct ' + cls + '">' + SG_ICO[cls] + '<b>' + Math.abs(p) + '%</b></span>';
}
function sgRiga(icoHtml, nome, mediaMs, globMs){
  return '<div class="sg-riga">' + icoHtml
    + '<b class="sg-nome">' + sgEsc(nome) + '</b>'
    + '<span class="sg-val"><i>' + sgFmtSec(mediaMs) + '</i><em><s class="sg-mondo" aria-label="Media globale">🌍</s>' + sgFmtMin(globMs / 60000) + '</em></span>'
    + sgPct(mediaMs, globMs) + '</div>';
}
function sgSchede(){
  const t = function(k, n){ return '<button type="button" role="tab" aria-selected="' + (SG.scheda === k) + '" class="' + (SG.scheda === k ? 'on' : '') + '" onclick="sgScheda(\'' + k + '\')">' + n + '</button>'; };
  return '<div class="sg-tabs" role="tablist">' + t('confronto', 'Confronto globale') + t('tendenza', 'App di tendenza') + '</div>';
}
function sgScheda(k){ SG.scheda = k; sgPaint(); }
function sgGiorni(n){ SG.giorni = n; sgPaint(); }

async function sgPaint(){
  const box = document.getElementById('sgBody'); if (!box) return;
  const token = ++SG.token;
  const glob = await sgCaricaGlobali();
  if (token !== SG.token) return;
  let corpo = '';
  if (!glob){
    corpo = '<p class="sg-vuoto">Non riesco a caricare le medie globali: riprova fra un momento.</p>';
  } else if (SG.scheda === 'tendenza'){
    corpo = sgTendenza(glob);
  } else {
    corpo = await sgConfronto(glob, token);
    if (token !== SG.token) return;
  }
  box.innerHTML = sgSchede() + '<div class="sg-corpo">' + corpo + '</div>';
  if (SG.scheda === 'tendenza') sgIconeInstallate(glob, token);
  else sgIconeRecenti(token);
}

async function sgConfronto(glob, token){
  const pill = function(n){ return '<button type="button" class="' + (SG.giorni === n ? 'on' : '') + '" onclick="sgGiorni(' + n + ')">Ultimi ' + n + ' giorni</button>'; };
  const testa = '<div class="sg-per">' + pill(7) + pill(30) + '</div>'
    /* 0.9.305, Andrea: le due intestazioni andavano a capo su due righe ciascuna. Adesso e' una legenda vera, una riga
       con due voci, ognuna con il suo segno: la riga in grassetto per il tuo tempo, il mondo per la media di tutti. */
    + '<div class="sg-cap"><span class="sg-leg-tuo"><i></i>Il tuo tempo medio al giorno</span><span class="sg-leg-mondo"><s class="sg-mondo">🌍</s>La media di tutti</span></div>';
  if (typeof insStatOn === 'function' && !insStatOn())
    return testa + '<p class="sg-vuoto">Le statistiche sono spente, quindi non ho numeri del telefono da confrontare.</p>';
  let tel = null;
  try{ tel = await sgLeggiTelefono(SG.giorni); }catch(_){ tel = null; }
  if (token !== SG.token) return '';
  if (!tel) return testa + '<p class="sg-vuoto">I numeri di utilizzo arrivano dal telefono: apri DreamMap dal telefono per vedere il confronto.</p>';
  if (!(tel.ms > 0)) return testa + '<p class="sg-vuoto">Non ho ancora abbastanza giorni di utilizzo per fare una media.</p>';
  const t = glob.totale;
  let html = testa;
  if (t && t.minuti > 0) html += sgRiga(SG_ICO.totale.replace('<svg ', '<svg class="sg-tot" '), t.nome || 'Utilizzo totale', tel.ms / tel.giorni, t.minuti * 60000);
  const righe = sgRighe(tel, glob);
  righe.forEach(function(r){ html += sgRiga(sgIcona(r.g, r.icona), r.g.nome, r.mediaMs, r.globMs); });
  if (!righe.length) html += '<p class="sg-vuoto">Nessuna delle app che usi ha una media globale pubblicata.</p>';
  let recenti = null;
  try{ recenti = await sgRecenti(glob, righe); }catch(_){ recenti = null; }
  if (token !== SG.token) return '';
  if (recenti && recenti.length) html += sgRecentiHtml(recenti);
  return html;
}

/* ---------------------------------------------------------------------------------------
   LE APP SCARICATE DI RECENTE (0.9.303, Andrea: "come StayFree")

   Le app installate negli ultimi trenta giorni (getInstalls: la data della prima installazione che Android tiene per
   ogni app con un'icona nel launcher, gia' usata dalla riserva di dopamina), con il tuo tempo medio al giorno da
   quando l'hai scaricata. Accanto, la media degli altri SOLO se esiste davvero: per le app di medie-globali.json la
   media pubblicata; per le altre non c'e' una statistica anonima sul server, quindi si dice che non c'e' ancora.
   Mai un numero inventato. Le app gia' nell'elenco sopra non si ripetono.
   --------------------------------------------------------------------------------------- */
const SG_RECENTI_GIORNI = 30, SG_RECENTI_MAX = 8;
async function sgRecenti(glob, righe){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getInstalls || !NATIVE.getTopApps) return null;
  const ora = Date.now();
  const g0 = (typeof insDayStart === 'function') ? insDayStart(ora) : (function(){ const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); })();
  const da = g0 - SG_RECENTI_GIORNI * 86400000;
  const dammi = function(k, fn){ return (typeof insGet === 'function') ? insGet(k, fn) : fn(); };
  const inst = await dammi('sg:inst:' + g0, function(){ return NATIVE.getInstalls({ from: da, to: ora }); });
  let lista = ((inst && inst.items) || []).filter(function(x){ return x && x.p && +x.t > 0; });
  if (!lista.length) return [];
  const escl = (typeof insExcl === 'function') ? insExcl() : [];
  const giaSopra = {};
  (righe || []).forEach(function(r){ (r.g.pacchetti || []).forEach(function(p){ giaSopra[p] = 1; }); });
  lista = lista.filter(function(x){ return escl.indexOf(x.p) < 0 && !giaSopra[x.p] && x.p !== 'com.dreambrothers.focuslock'; })
    .sort(function(a, b){ return b.t - a.t; }).slice(0, SG_RECENTI_MAX);
  if (!lista.length) return [];
  const top = await dammi('sg:instTop:' + Math.floor(ora / 60000), function(){ return NATIVE.getTopApps({ from: da, to: ora, limit: 200, icons: 0 }); });
  const perPkg = {};
  ((top && top.apps) || []).forEach(function(a){ if (a && a.packageName) perPkg[a.packageName] = (perPkg[a.packageName] || 0) + (a.ms || 0); });
  const globPer = {};
  (glob.app || []).forEach(function(g){ g.pacchetti.forEach(function(p){ globPer[p] = g; }); });
  return lista.map(function(x){
    /* i giorni da quando c'e': quello dell'installazione conta, oggi conta */
    const giornoInst = (typeof insDayStart === 'function') ? insDayStart(+x.t) : new Date(new Date(+x.t).setHours(0, 0, 0, 0)).getTime();
    const giorni = Math.max(1, Math.min(SG_RECENTI_GIORNI + 1, Math.round((g0 - giornoInst) / 86400000) + 1));
    const ms = perPkg[x.p] || 0;
    const g = globPer[x.p] || null;
    return { p: x.p, nome: x.l || x.p, t: +x.t, ms: ms, mediaMs: ms / giorni, globMs: g ? g.minuti * 60000 : 0 };
  });
}
function sgQuando(t){
  const g0 = new Date(); g0.setHours(0, 0, 0, 0);
  const g = new Date(t); g.setHours(0, 0, 0, 0);
  const diff = Math.round((g0 - g) / 86400000);
  if (diff <= 0) return 'Scaricata oggi';
  if (diff === 1) return 'Scaricata ieri';
  const mesi = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  const n = g.getDate();
  return 'Scaricata ' + (n === 8 || n === 11 ? 'l’' : 'il ') + n + ' ' + mesi[g.getMonth()];
}
function sgRecentiHtml(lista){
  return '<div class="sg-sez"><b>Le app che hai scaricato di recente</b><small>Il tuo tempo medio al giorno da quando le hai scaricate, a confronto con quello degli altri</small></div>'
    + lista.map(function(r){
        const lett = (r.nome || '?').charAt(0).toUpperCase();
        const col = (typeof insIcoColor === 'function') ? insIcoColor(r.p) : '#0075E3';
        const ico = '<span class="sg-ico" data-p="' + sgEsc(r.p) + '"><span class="ic-lettera" style="background:' + col + '">' + sgEsc(lett) + '</span></span>';
        const sotto = r.ms > 0
          ? (r.globMs ? sgQuando(r.t) : sgQuando(r.t) + '. La media degli altri non c’è ancora')
          : sgQuando(r.t) + '. Non l’hai ancora usata';
        return '<div class="sg-riga sg-nuova">' + ico
          + '<span class="sg-nome"><b>' + sgEsc(r.nome) + '</b><small>' + sotto + '</small></span>'
          + '<span class="sg-val"><i>' + sgFmtSec(r.mediaMs) + '</i>' + (r.globMs ? '<em><s class="sg-mondo" aria-label="Media globale">🌍</s>' + sgFmtMin(r.globMs / 60000) + '</em>' : '') + '</span>'
          + (r.globMs && r.ms > 0 ? sgPct(r.mediaMs, r.globMs) : '<span class="sg-pct"></span>') + '</div>';
      }).join('');
}
/* le icone vere delle app scaricate di recente, dopo il disegno */
async function sgIconeRecenti(token){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getAppIcon) return;
  const els = Array.prototype.slice.call(document.querySelectorAll('#sgBody .sg-ico[data-p]'));
  for (let i = 0; i < els.length; i++){
    if (token !== SG.token) return;
    try{
      const r = await NATIVE.getAppIcon({ packageName: els[i].getAttribute('data-p') });
      if (r && r.icon && String(r.icon).indexOf('data:') === 0) els[i].innerHTML = '<img src="' + r.icon + '" alt="">';
    }catch(_){ }
  }
}

function sgTendenza(glob){
  const lista = glob.app.slice().sort(function(a, b){ return b.minuti - a.minuti; });
  let html = '<div class="sg-tit"><span class="sg-tit-i">' + SG_ICO.info + '</span><p>App social con il maggior utilizzo medio giornaliero nel mondo</p></div>';
  html += lista.map(function(g){
    return '<div class="sg-riga sg-tr">' + sgIcona(g, '') + '<b class="sg-nome">' + sgEsc(g.nome) + '</b><span class="sg-val sg-solo"><i>' + sgFmtMin(g.minuti) + '</i></span></div>';
  }).join('');
  return html;
}
/* la scheda "tendenza" mostra anche app che non hai: dove sono installate si usa la loro icona vera */
async function sgIconeInstallate(glob, token){
  if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getAppIcon) return;
  for (let i = 0; i < glob.app.length; i++){
    const g = glob.app[i];
    for (let k = 0; k < g.pacchetti.length; k++){
      if (token !== SG.token) return;
      try{
        const r = await NATIVE.getAppIcon({ packageName: g.pacchetti[k] });
        if (r && r.icon && String(r.icon).indexOf('data:') === 0){
          const el = document.querySelector('#sgBody .sg-ico[data-g="' + g.id + '"]');
          if (el) el.innerHTML = '<img src="' + r.icon + '" alt="">';
          break;
        }
      }catch(_){ }
    }
  }
}

/* ---------------------------------------------------------------------------------------
   IL FOGLIO "INFO": X, velo scuro, si chiude anche toccando fuori
   --------------------------------------------------------------------------------------- */
function sgInfoApri(){
  sgInfoChiudi();
  const frase = (SG.dati && SG.dati.fraseInfo) || 'I numeri globali sono medie pubblicate da Similarweb e da Sensor Tower.';
  const v = document.createElement('div');
  v.className = 'sg-velo'; v.id = 'sgInfo';
  v.setAttribute('onclick', 'if(event.target===this)sgInfoChiudi()');
  v.innerHTML = '<div class="sg-foglio" role="dialog" aria-label="Info">'
    + '<button type="button" class="sg-x" aria-label="Chiudi" onclick="sgInfoChiudi()">' + SG_ICO.chiudi + '</button>'
    + '<div class="sg-fh"><span>' + SG_ICO.info + '</span><b>Info</b></div>'
    + '<p>La tua media giornaliera è calcolata esclusivamente in base all\'uso delle app da questo dispositivo.</p>'
    + '<p>' + sgEsc(frase) + '</p>'
    + '<p>La media del telefono conta solo i giorni in cui lo hai usato.</p>'
    + '</div>';
  const ph = document.getElementById('phone') || document.body;
  ph.appendChild(v);
  SG.info = v;
  requestAnimationFrame(function(){ v.classList.add('on'); });
}
function sgInfoChiudi(){
  const v = document.getElementById('sgInfo'); if (!v) return;
  SG.info = null; v.classList.remove('on');
  setTimeout(function(){ if (v.parentNode) v.parentNode.removeChild(v); }, 180);
  /* subito fuori dalla pagina, cosi' il tasto indietro non lo trova piu' */
  v.hidden = true;
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA
   --------------------------------------------------------------------------------------- */
function sgApri(){
  SG.scheda = 'confronto';
  goId('s-statglob');
  sgPaint();
  setTimeout(function(){ try{ document.getElementById('s-statglob').scrollTop = 0; }catch(_){ } }, 0);
}

registerScreen('s-statglob',
  '<div class="topbar">'
  + '<button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + SG_ICO.indietro + '</button>'
  + '<b class="blk-title">Statistiche di utilizzo globale</b>'
  + '<button class="iconbtn sg-ib" onclick="sgInfoApri()" aria-label="Info">' + SG_ICO.info + '</button></div>'
  + '<div id="sgBody"></div><div class="spacer"></div>',
  { back: function(){ try{ if (typeof switchTab === 'function') switchTab('insights'); }catch(_){ } return 's-home'; } });

/* ---------------------------------------------------------------------------------------
   IL PANNELLO NEL REPORT: piccolo, fisso, in fondo, prima di "Personalizza la pagina Report"
   --------------------------------------------------------------------------------------- */
function sgPannelloHtml(){
  /* 0.9.325, Andrea: un carosello: le statistiche globali e il podio, con le schede e il pulsante per la classifica */
  setTimeout(function(){ try{ if (typeof rcfPodioPaint === 'function') rcfPodioPaint(); }catch(_){ } }, 0);
  return '<section id="sgPannello" class="sg-car-w"><div class="sg-car" onscroll="rcfCarDot(this)"><button type="button" class="sg-pan" onclick="sgApri()">'
    + '<span class="sg-pan-i">' + SG_ICO.mondo + '</span>'
    + '<span class="sg-pan-t"><b>Statistiche di utilizzo globale</b><small>Il tuo uso a confronto con il mondo</small></span>'
    + '<span class="sg-pan-c">' + SG_ICO.chev + '</span></button><div id="rcfPodio"></div></div><div class="sg-car-d"><i class="on"></i><i></i></div></section>';
}
function sgPannelloMetti(){
  const body = document.getElementById('insBody'); if (!body) return;
  try{ if (typeof rcfMetti === 'function') rcfMetti(); }catch(_){ }
  /* solo dove ci sono i blocchi del Report: senza (statistiche spente, pagina in caricamento) non c'e' niente da mettere */
  if (!body.querySelector(':scope > .rp-blk')){ const v = document.getElementById('sgPannello'); if (v) v.remove(); return; }
  let p = document.getElementById('sgPannello');
  if (!p){ const t = document.createElement('div'); t.innerHTML = sgPannelloHtml(); p = t.firstChild; }
  const piede = body.querySelector(':scope > .hd-piede');
  const share = body.querySelector(':scope > #insShareText');
  const dopo = piede || share || null;
  if (p.parentElement === body && p.nextElementSibling === dopo) return;
  body.insertBefore(p, dopo);
}
(function(){
  /* come revisione.js: dopo ogni ordinamento dei blocchi del Report il pannello torna al suo posto */
  const aggancia = function(){
    if (typeof scsOrdinaBlocchi !== 'function' || scsOrdinaBlocchi.__sg) return;
    const vero = scsOrdinaBlocchi;
    const g = function(p){ const r = vero.apply(this, arguments); try{ if (p === 'report') sgPannelloMetti(); }catch(_){ } return r; };
    g.__sg = true; window.scsOrdinaBlocchi = g; try{ scsOrdinaBlocchi = g; }catch(_){ }
  };
  aggancia(); setTimeout(aggancia, 500);
  document.addEventListener('fl:tab', function(e){ if (e.detail === 'insights') setTimeout(sgPannelloMetti, 400); });

  const css = [
    '#insBody > .sg-pan{display:flex;align-items:center;gap:12px;width:100%;margin:14px 0 6px;padding:12px 14px;background:var(--card);color:var(--ink);border:1px solid var(--line);border-radius:var(--r-md);text-align:left;font:inherit;cursor:pointer}',
    '.sg-pan-i{width:38px;height:38px;border-radius:12px;flex:none;display:flex;align-items:center;justify-content:center;background:var(--blue-soft);color:var(--blue)}',
    'body.dark .sg-pan-i{background:#0E1E3A;color:#6DB6FF}',
    '.sg-pan-t{flex:1;min-width:0}',
    '.sg-pan-t b{display:block;font:600 13.5px var(--font-body);color:var(--ink)}',
    '.sg-pan-t small{display:block;margin-top:2px;font:500 11.5px/1.4 var(--font-body);color:var(--muted)}',
    '.sg-pan-c{flex:none;color:var(--faint);display:flex}',

    '#s-statglob .sg-ib{color:var(--muted)}',
    '#s-statglob .topbar{gap:8px}',
    '#s-statglob .blk-title{font-size:16px;line-height:1.2;white-space:normal;overflow-wrap:break-word}',
    '#sgBody{padding:0 2px}',
    '.sg-tabs{display:flex;border-bottom:1px solid var(--line);margin:6px 0 0}',
    '.sg-tabs button{flex:1;padding:14px 4px 12px;background:none;border:0;border-bottom:3px solid transparent;margin-bottom:-1px;font:600 14.5px var(--font-body);color:var(--muted);cursor:pointer}',
    '.sg-tabs button.on{color:var(--blue);border-bottom-color:var(--blue)}',
    'body.dark .sg-tabs button.on{color:#6DB6FF;border-bottom-color:#6DB6FF}',
    '.sg-corpo{padding:18px 4px 30px}',
    '.sg-per{display:flex;gap:8px;margin:0 0 16px}',
    '.sg-per button{padding:7px 13px;border-radius:999px;border:1px solid var(--line);background:var(--card);color:var(--muted);font:600 12px var(--font-body);cursor:pointer}',
    '.sg-per button.on{background:var(--blue);border-color:var(--blue);color:#fff}',
    /* 0.9.304, Andrea: senza leggere la didascalia non si capiva quale dei due numeri fosse il proprio. Il numero grande e' il tuo; il piccolo ha il mondo davanti. */
    '.sg-cap{display:flex;flex-wrap:wrap;justify-content:center;align-items:center;gap:6px 14px;margin:0 0 12px;padding:8px 0 10px;border-bottom:1px solid var(--line);font:600 11.5px/1.4 var(--font-body);color:var(--muted)}',
    '.sg-cap span{display:inline-flex;align-items:center;white-space:nowrap}',
    '.sg-cap .sg-leg-tuo{font-weight:800;color:var(--ink)}',
    '.sg-leg-tuo i{display:inline-block;width:14px;height:4px;border-radius:2px;background:var(--ink);margin-right:6px}',
    '.sg-mondo{text-decoration:none;font-size:11px;margin-right:4px;font-family:initial}',
    '.sg-riga{display:flex;align-items:center;gap:14px;padding:11px 0}',
    /* 0.9.303, Andrea: le icone stavano dentro a un riquadro bianco col bordo. L'icona e' pulita, come nel telefono */
    '.sg-ico{width:42px;height:42px;border-radius:12px;flex:none;display:flex;align-items:center;justify-content:center;overflow:hidden;background:transparent}',
    '.sg-ico img{width:100%;height:100%;object-fit:contain;display:block}',
    '.sg-sez{text-align:center;margin:26px 0 8px;padding-top:20px;border-top:1px solid var(--line)}',
    '.sg-sez b{display:block;font:700 16px var(--font-display);color:var(--ink)}',
    '.sg-sez small{display:block;margin-top:4px;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    'span.sg-nome b{display:block;font:600 15px/1.3 var(--font-body);color:var(--ink)}',
    'span.sg-nome small{display:block;margin-top:2px;font:500 11.5px/1.4 var(--font-body);color:var(--muted)}',
    '.sg-ico .ic-lettera{width:100%;height:100%;display:flex;align-items:center;justify-content:center;font:800 17px var(--font-display);color:#fff}',
    '.sg-tot{width:42px;height:42px;flex:none;border-radius:12px;display:block}',
    '.sg-nome{flex:1;min-width:0;font:600 15px/1.3 var(--font-body);color:var(--ink)}',
    /* 0.9.305, Andrea: il tuo tempo molto piu' in grassetto e piu' grande della media di tutti, che resta smorzata */
    '.sg-val{display:flex;flex-direction:column;align-items:flex-end;flex:none;font-variant-numeric:tabular-nums}',
    '.sg-val i{font:800 16px/1.3 var(--font-body);font-style:normal;font-variant-numeric:tabular-nums;color:var(--ink)}',
    '.sg-val em{font:400 11.5px/1.4 var(--font-body);font-style:normal;font-variant-numeric:tabular-nums;color:var(--muted);opacity:.85;margin-top:1px}',
    '.sg-val.sg-solo i{font:700 13.5px/1.3 var(--font-body)}',
    '.sg-pct{display:flex;flex-direction:column;align-items:center;width:48px;flex:none;font:600 12px ui-monospace,"Roboto Mono",Menlo,Consolas,monospace}',
    '.sg-pct.su{color:var(--red)}',
    '.sg-pct.giu{color:#14A38B}',
    '.sg-pct.uguale{color:var(--faint)}',
    'body.dark .sg-pct.su{color:#FF6B78}',
    'body.dark .sg-pct.giu{color:#3CCDB1}',
    '.sg-pct b{font-weight:600;margin-top:1px}',
    '.sg-tit{display:flex;gap:14px;align-items:flex-start;margin:0 0 10px}',
    '.sg-tit-i{width:42px;display:flex;justify-content:center;color:var(--faint);flex:none;padding-top:1px}',
    '.sg-tit p{font:500 14.5px/1.5 var(--font-body);color:var(--muted)}',
    '.sg-vuoto{font:500 13.5px/1.6 var(--font-body);color:var(--muted);padding:14px 2px}',

    '.sg-velo{position:fixed;inset:0;z-index:700;background:rgba(0,10,30,.6);display:flex;align-items:flex-end;opacity:0;transition:opacity .18s}',
    '.sg-velo.on{opacity:1}',
    '.sg-foglio{position:relative;width:100%;background:var(--card);color:var(--ink);border-radius:22px 22px 0 0;padding:22px 22px 30px;transform:translateY(24px);transition:transform .2s}',
    '.sg-velo.on .sg-foglio{transform:none}',
    '.sg-x{position:absolute;top:14px;right:14px;width:34px;height:34px;border-radius:50%;border:0;background:var(--blue-soft);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .sg-x{background:#1C2A44;color:#C8D6EC}',
    '.sg-fh{display:flex;align-items:center;gap:12px;margin:0 0 16px;color:var(--ink)}',
    '.sg-fh b{font:700 17px var(--font-display)}',
    '.sg-foglio p{font:500 15px/1.6 var(--font-body);color:var(--ink);margin:0 0 12px}',
    '.sg-foglio p:last-child{margin-bottom:0}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
