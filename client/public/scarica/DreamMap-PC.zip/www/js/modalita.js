/* =========================================================================================
   LA DIFFICOLTA' DEL PERCORSO, AD EFFETTO FARFALLA (0.9.281)

   Andrea, 17/10: "nel livello Crea il tuo piano su misura voglio la domanda ad effetto farfalla che
   chiede di confermare o cambiare la difficolta' del percorso. La data che si e' dato corrisponde a
   facile, normale o difficile. Difficile non e' solo la strada piu' tortuosa: e' quella con i pedaggi,
   e chi rischia di piu' arriva prima. Sotto alle opzioni un grafico con l'arrivo stimato per ognuna,
   cosi' sa che facile arriva dopo, normale un po' prima, difficile prima di tutti. E la domanda sui
   pedaggi: li paga per arrivare prima, o li evita".

   La modalita' e' quella di sempre (fl_modalita: 1, 3 o 5 passi al giorno, foglio-sync.js) e
   l'arrivo usa lo stesso conto del navigatore (eta.js: le ore di strada diviso le ore a settimana
   di ogni modalita'). La scelta entra nel primo messaggio dell'intervista del piano.
   ========================================================================================= */
const MD_NOMI = { facile: 'Facile', normale: 'Normale', difficile: 'Difficile' };
const MD_PASSI = { facile: 1, normale: 3, difficile: 5 };
function mdModalita(){ try{ return localStorage.getItem('fl_modalita') || 'normale'; }catch(_){ return 'normale'; } }
/** L'arrivo stimato per ogni modalita': le ore di strada (eta.js) diviso le ore a settimana di quella modalita'. */
function mdArrivi(){
  let v = null; try{ v = (typeof etaViaggio === 'function') ? etaViaggio() : null; }catch(_){ }
  const cap = (typeof ETA_CFG !== 'undefined' && ETA_CFG.capacita) || { facile: 5, normale: 10, difficile: 17.5 };
  const W = (v && v.W) || 12 * 10 * (365.25 / 12 / 7);
  const out = {};
  ['facile', 'normale', 'difficile'].forEach(function(m){
    const sett = W / (cap[m] || 10);
    out[m] = { min: Date.now() + sett * 0.85 * 7 * 86400000, max: Date.now() + sett * 1.25 * 7 * 86400000, sett: sett };
  });
  return out;
}
function mdMese(ts){ const d = new Date(ts); return ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'][d.getMonth()] + ' ' + d.getFullYear(); }
/* la data che la persona si e' data nell'onboarding ("entro 6 mesi"), contata da quando l'ha detto */
function mdScadenza(){
  try{
    const d = (typeof gnDati === 'function') ? gnDati() : {};
    const mesi = +d.scadenza || 0; if (!mesi) return null;
    const t = new Date(d.at || Date.now()); t.setMonth(t.getMonth() + mesi);
    return { mesi: mesi, at: t.getTime() };
  }catch(_){ return null; }
}
function mdQuando(mesi){ return mesi === 12 ? 'entro un anno' : mesi < 12 ? 'entro ' + mesi + ' mesi' : 'entro ' + Math.round(mesi / 12) + ' anni'; }
/* 0.9.284, Andrea: "i grafici di confronto sulla data d'arrivo fanno schifo e sono poco chiari". Una barra per strada
   che parte da oggi e finisce dove arrivi (piu' corta = prima), il mese scritto accanto al nome, e la linea tratteggiata
   della data che ti sei dato: si vede a colpo d'occhio quale strada ci arriva in tempo. */
function mdGraficoHtml(){
  const A = mdArrivi(), sc = mdScadenza(), ora = Date.now();
  const medio = function(m){ return Date.now() + A[m].sett * 7 * 86400000; };
  const fine = Math.max(medio('facile'), sc ? sc.at : 0) * 1 + 1;
  const x = function(t){ return Math.max(2, Math.min(100, (t - ora) / (fine - ora) * 100)); };
  const linea = sc ? '<i class="md-scad" style="left:' + x(sc.at).toFixed(1) + '%"></i>' : '';
  return '<div class="md-graf"><p class="md-graf-t">Quando arrivi, con ogni strada</p>'
    + ['difficile', 'normale', 'facile'].map(function(m){
        const t = medio(m), inTempo = !sc || t <= sc.at;
        return '<div class="md-r"><div class="md-r-top"><b>' + MD_NOMI[m] + '</b><span class="' + (inTempo ? 'ok' : 'tardi') + '">' + mdMese(t) + '</span></div>'
          + '<div class="md-barra2"><i class="' + m + '" style="width:' + x(t).toFixed(1) + '%"></i>' + linea + '</div></div>';
      }).join('')
    + '<div class="md-asse"><span>Oggi</span>' + (sc ? '<span class="md-asse-s"><i></i>La tua data: ' + mdMese(sc.at) + '</span>' : '') + '</div></div>';
}
/** La scena: tre strade da tenere premute, il grafico sotto. Poi i pedaggi. Poi `poi()`. */
function mdStradaScegli(poi){
  if (typeof faScena !== 'function'){ if (poi) poi(); return; }
  const sc = mdScadenza();
  const cur = mdModalita();
  /* 0.9.284, Andrea: "la tua scelta di adesso? L'utente non ha mai scelto Difficile: devi spiegargli che la data che
     aveva deciso all'inizio corrisponde a quella strada". */
  faScena({
    kick: 'La tua partita',
    titolo: sc ? 'All’inizio hai detto che vuoi arrivarci ' + mdQuando(sc.mesi) + ': è la strada ' + MD_NOMI[cur] + ', ' + MD_PASSI[cur] + (MD_PASSI[cur] === 1 ? ' passo' : ' passi') + ' al giorno.'
               : 'Scegli la tua strada verso il sogno.',
    sotto: sc ? 'Puoi tenerla o sceglierne un’altra. Più passi al giorno, prima arrivi.' : 'Più passi al giorno, prima arrivi.',
    pannelli: true, verticale: true,
    attuale: cur,
    attualeEti: sc ? 'per arrivare ' + mdQuando(sc.mesi) : 'la strada di partenza',
    opzioni: [
      { k: 'facile', ico: '🌱', n: 'Facile', s: '1 passo al giorno. La strada più lunga, senza fretta.', colore: '#8CC6FF' },
      { k: 'normale', ico: '🚶', n: 'Normale', s: '3 passi al giorno. Il ritmo di chi vuole arrivare.', colore: '#4FB8FF' },
      { k: 'difficile', ico: '🧗', n: 'Difficile', s: '5 passi al giorno, con i pedaggi. Arrivi prima di tutti.', colore: '#FF5A66' }
    ],
    dopoHtml: mdGraficoHtml(),
    onScelta: function(k){ try{ localStorage.setItem('fl_modalita', k); }catch(_){ } try{ if (typeof etaRicalcola === 'function') etaRicalcola(); }catch(_){ } },
    dopoTitolo: function(k){ return 'Hai scelto la strada ' + MD_NOMI[k].toLowerCase(); },
    dopoSotto: function(k){ return MD_PASSI[k] + (MD_PASSI[k] === 1 ? ' passo al giorno' : ' passi al giorno') + '. Il tuo agente personale ricalcola il percorso su questa strada.'; },
    poi: function(){ mdPedaggi(poi); }
  });
}
function mdPedaggi(poi){
  let o = {}; try{ o = (typeof serOpzioni === 'function') ? serOpzioni() : {}; }catch(_){ }
  faScena({
    /* 0.9.287, Andrea: "pagare" sembra che stiamo vendendo qualcosa noi. E' un investimento: i soldi comprano tempo. */
    /* 0.9.290, Andrea: "non voglio che dica la strada piu' lunga o la scorciatoia: ci deve arrivare l'utente, altrimenti
       sembra che vendiamo il trucchetto magico". Niente cartelli e niente "scorciatoie"; una scelta blu e una rossa. */
    kick: 'Effetto farfalla',
    titolo: 'Sei disposto a investire per arrivare prima?',
    sotto: '',
    /* 0.9.288: un bivio disegnato (bivio.js): a sinistra la strada lunga, a destra la scorciatoia */
    pannelli: true, bivio: true,
    attuale: o.pedaggi ? 'si' : (o.pedaggiScelti ? 'no' : ''),
    opzioni: [
      /* 0.9.299, Andrea: "le due opzioni sui cartelli devono essere una blu e una rossa, dello stesso colore dei pannelli".
         Gli stessi colori del bivio "Pianifico io | Seguo il Genio": cartello pieno, pannello con il bordo del suo colore */
      { k: 'no', ico: '🛤️', n: 'Uso solo il mio tempo', s: 'Ci metto di più, ma non spendo niente.', colore: '#4FB8FF', tinta: 'blu', fondo: 'linear-gradient(160deg,rgba(0,117,227,.34),rgba(0,117,227,.12))' },
      { k: 'si', ico: '🛣️', n: 'Investo per arrivare prima', s: 'Software, strumenti, pubblicità, persone che lavorano per te: i soldi comprano tempo.', colore: '#FF5A66', tinta: 'rosso', fondo: 'linear-gradient(160deg,rgba(230,57,70,.34),rgba(230,57,70,.12))' }
    ],
    onScelta: function(k){ try{ if (typeof serOpzioniSalva === 'function') serOpzioniSalva({ pedaggi: k === 'si', pedaggiScelti: true }); }catch(_){ } },
    dopoTitolo: function(k){ return k === 'si' ? 'Investi per arrivare prima' : 'Usi solo il tuo tempo'; },
    dopoSotto: function(){ return 'Adesso il tuo agente personale ti fa qualche domanda e costruisce il piano.'; },
    poi: function(){ if (poi) poi(); }
  });
}
/** Per l'intervista: la strada scelta, in una riga. */
function mdPerAgente(){
  let o = {}; try{ o = (typeof serOpzioni === 'function') ? serOpzioni() : {}; }catch(_){ }
  const m = mdModalita();
  return 'Strada scelta: ' + MD_NOMI[m] + ' (' + MD_PASSI[m] + (MD_PASSI[m] === 1 ? ' passo' : ' passi') + ' al giorno). Pedaggi: ' + (o.pedaggi ? 'sì, investo soldi (software, strumenti, pubblicità, persone) per arrivare prima' : 'no, solo il mio tempo') + '.';
}
(function mdStile(){
  const st = document.createElement('style');
  st.textContent = [
    /* 0.9.284, Andrea: "la tua partita tocca la barra delle notifiche, Non adesso tocca la barra di Android, zero spazio".
       La scena verticale scorre e ha i margini sicuri; ogni blocco ha la sua aria. */
    /* 0.9.287, Andrea: "il testo e' tutto in alto, la pagina scorre e si sposta anche di lato". La nebbia (inset -20%)
       allargava l'area da scorrere in tutte e due le direzioni; il contenuto ora sta al centro e scorre solo se non ci sta */
    '.fa-scena.fa-vert{align-items:flex-start;overflow-y:auto;overflow-x:hidden;overscroll-behavior:none;touch-action:pan-y;-webkit-overflow-scrolling:touch}',
    '.fa-vert .fa-nebbia{position:fixed}',
    '.fa-vert .fa-in{padding:calc(env(safe-area-inset-top,0px) + 40px) 22px calc(env(safe-area-inset-bottom,0px) + 40px);margin:auto}',
    '.fa-vert .fa-kick{margin-bottom:16px}',
    '.fa-vert .fa-in h2{font-size:23px!important;line-height:1.3!important;margin:0 0 12px!important}',
    '.fa-vert .fa-sotto{margin:0 auto 30px!important}',
    '.fa-vert .fa-qte{flex-direction:column;align-items:stretch;gap:16px}',
    '.fa-vert .fa-pan{max-width:none!important;display:grid!important;grid-template-columns:56px 1fr;grid-template-areas:"ico n" "ico s";align-items:center!important;column-gap:14px!important;row-gap:4px!important;text-align:left;padding:18px 18px!important}',
    '.fa-vert .fa-pan .fa-pan-ico{grid-area:ico;height:auto;font-size:34px}',
    '.fa-vert .fa-pan b{grid-area:n;margin:0;font:800 18px/1.2 var(--font-display);letter-spacing:0;text-transform:none;text-align:left}',
    '.fa-vert .fa-pan small{grid-area:s;max-width:none;text-align:left;font-size:13.5px;line-height:1.45}',
    '.fa-vert .fa-pan em{position:absolute;right:16px;top:-11px;background:#0B1A3D;padding:2px 8px;border-radius:8px;font-size:11.5px}',
    '.fa-vert .fa-hint{margin-top:30px}',
    '.fa-vert .fa-x{margin-top:18px;padding:14px 24px;font-size:14px}',
    '.md-graf{margin:34px 0 0;padding:20px 18px 16px;border-radius:22px;background:rgba(255,255,255,.07);text-align:left;opacity:0;animation:faSu .6s 1.9s cubic-bezier(.2,.8,.3,1) forwards}',
    '.md-graf-t{margin:0 0 18px;font:800 12px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:#BCE0FF}',
    '.md-r{margin-bottom:16px}',
    '.md-r-top{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:8px}',
    '.md-r-top b{font:800 15px var(--font-body);color:#fff}.md-r-top span{font:700 14px var(--font-body)}.md-r-top span.ok{color:#9FE3B5}.md-r-top span.tardi{color:rgba(255,255,255,.62)}',
    '.md-barra2{position:relative;height:12px;border-radius:99px;background:rgba(255,255,255,.1)}',
    '.md-barra2 > i:not(.md-scad){position:absolute;left:0;top:0;bottom:0;border-radius:99px}',
    '.md-barra2 i.difficile{background:#FF5A66}.md-barra2 i.normale{background:#4FB8FF}.md-barra2 i.facile{background:#8CC6FF}',
    '.md-scad{position:absolute;top:-6px;bottom:-6px;width:0;border-left:2px dashed #fff;opacity:.85}',
    '.md-asse{display:flex;justify-content:space-between;align-items:center;margin-top:4px;font:600 12px var(--font-body);color:rgba(255,255,255,.62)}',
    '.md-asse-s{display:flex;align-items:center;gap:6px}.md-asse-s i{width:14px;border-top:2px dashed #fff;opacity:.85}'
  ].join('\n');
  document.head.appendChild(st);
})();
