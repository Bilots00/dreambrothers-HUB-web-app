/* ===========================================================================================
   LA RICARICA DELLE CONGELAZIONI E I WIDGET DA SBLOCCARE (0.9.260)

   Andrea, come Duolingo:
   - "Che bello rivederti! Ricarica le congelazioni della serie che hai usato." Quando una
     congelazione ha coperto un giorno saltato (sdCopriBuchi, snAggiorna), al ritorno nell'app
     compare il foglio con le congelazioni piene e quelle usate (tratteggiate), il saldo delle
     monete in alto e RICARICA con il prezzo. Si paga con le monete (lo stesso prezzo del
     negozio, content/esercizi.json comune.gettone). "No, grazie" lo chiude fino alla prossima.
   - I widget da sbloccare: ogni tanto la mystery box regala un widget nuovo per la schermata
     iniziale (il Genio su uno sfondo suo) e 15 monete. Il widget scelto resta fisso al posto
     dello sfondo che cambia ogni giorno (FocusWidget.java, preferenza "skin").
   =========================================================================================== */
const GR_PENDENTE = 'fl_gelo_ricarica';          // { n: congelazioni usate da ricaricare, at }
const GR_MAX = 2;                                // come il negozio (comune.gettone.max)
const GR_COSTO = 300;                            // monete per congelazione (comune.gettone.costo)
function grEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function grGettoni(){ try{ return snStato().serie.gettoni || 0; }catch(_){ return 0; } }
function grMonete(){ try{ return (typeof ffCoins === 'function') ? ffCoins() : 0; }catch(_){ return 0; } }
function grCosto(){ try{ return (ES && ES.cfg && ES.cfg.comune && ES.cfg.comune.gettone && ES.cfg.comune.gettone.costo) || GR_COSTO; }catch(_){ return GR_COSTO; } }

/** Una o piu' congelazioni hanno appena coperto dei giorni: al ritorno si propone la ricarica. */
function flGeloUsato(n){
  n = Math.max(1, Math.round(+n || 1));
  /* 0.9.265: alla prossima tappa fatta arriva il premio "Genio scongelato" (come "Duo scongelato" di Duolingo) */
  try{ localStorage.setItem('fl_scongelo_attesa', String(Date.now())); }catch(_){ }
  let p = null; try{ p = JSON.parse(localStorage.getItem(GR_PENDENTE) || 'null'); }catch(_){ }
  const tot = Math.min(GR_MAX, ((p && p.n) || 0) + n);
  try{ localStorage.setItem(GR_PENDENTE, JSON.stringify({ n: tot, at: Date.now() })); }catch(_){ }
  setTimeout(grControlla, 1800);
}
function grPendente(){ try{ const p = JSON.parse(localStorage.getItem(GR_PENDENTE) || 'null'); return p && p.n > 0 ? p : null; }catch(_){ return null; } }
function grLibero(){
  /* il foglio non si mette sopra a un'altra cosa che sta succedendo */
  if (document.getElementById('grSheet')) return false;
  const a = document.querySelector('.screen.active');
  if (!a || a.id !== 's-home') return false;
  if (document.querySelector('.wk, #inSheet.in, .sd-sheet:not([hidden]), #wgSheet, #faScena, .am-overlay.show')) return false;
  try{ if (!localStorage.getItem('fl_onboarding') && !localStorage.getItem('fl_first_run')) return false; }catch(_){ }
  return true;
}
let GR_T = 0;
function grControlla(tentativo){
  clearTimeout(GR_T);
  if (!grPendente()) return;
  if (grGettoni() >= GR_MAX){ try{ localStorage.removeItem(GR_PENDENTE); }catch(_){ } return; }
  if (!grLibero()){ if ((tentativo || 0) < 20) GR_T = setTimeout(function(){ grControlla((tentativo || 0) + 1); }, 3000); return; }
  grApri();
}
function grApri(){
  const hai = grGettoni(), manca = Math.max(0, GR_MAX - hai);
  if (!manca) return;
  const costo = grCosto(), mon = grMonete();
  const tutte = manca * costo;
  const quante = mon >= tutte ? manca : (mon >= costo ? 1 : 0);
  let w = document.getElementById('grSheet');
  if (!w){ w = document.createElement('div'); w.id = 'grSheet'; w.className = 'gr-sheet'; w.addEventListener('click', function(e){ if (e.target === w) grChiudi(); }); document.body.appendChild(w); }
  const ico = function(pieno, i){ return '<div class="gr-gelo' + (pieno ? ' pieno' : ' vuoto') + '" data-i="' + i + '"><span>🧊</span></div>'; };
  let icone = ''; for (let i = 0; i < GR_MAX; i++) icone += ico(i < hai, i);
  w.innerHTML = '<div class="gr-in"><i class="gr-grip"></i>'
    + '<div class="gr-saldo">🪙 <b id="grSaldo">' + mon + '</b></div>'
    + '<h3 class="gr-tit">Che bello rivederti! Ricarica le <em>protezioni della serie</em> che hai usato.</h3>'
    + '<div class="gr-icone">' + icone + '</div>'
    + (quante
        ? '<button type="button" class="gr-cta" onclick="grRicarica(' + quante + ')">RICARICA' + (quante < manca ? ' UNA' : '') + ' <span>🪙 ' + (quante * costo) + '</span></button>'
        : '<p class="gr-poche">Per ricaricarle servono ' + costo + ' monete: ne hai ' + mon + '. Le monete arrivano dalle tappe e dalle mystery box.</p>')
    + '<button type="button" class="gr-no" onclick="grChiudi(true)">NO, GRAZIE</button></div>';
  w.hidden = false;
  requestAnimationFrame(function(){ w.classList.add('in'); });
  try{ flVibra(12); }catch(_){ }
}
function grChiudi(rifiuta){
  const w = document.getElementById('grSheet'); if (!w) return;
  if (rifiuta){ try{ localStorage.removeItem(GR_PENDENTE); }catch(_){ } }
  w.classList.remove('in'); setTimeout(function(){ w.remove(); }, 260);
}
function grRicarica(quante){
  const costo = grCosto();
  if (grMonete() < quante * costo) return;
  try{ if (typeof ffAddCoins === 'function') ffAddCoins(-quante * costo); }catch(_){ }
  try{ const sn = snStato(); sn.serie.gettoni = Math.min(GR_MAX, (sn.serie.gettoni || 0) + quante); snSalva(sn); }catch(_){ }
  try{ localStorage.removeItem(GR_PENDENTE); }catch(_){ }
  try{ if (typeof hdrContatoriApply === 'function') hdrContatoriApply(); }catch(_){ }
  const s = document.getElementById('grSaldo'); if (s) s.textContent = grMonete();
  /* le tratteggiate si riempiono una alla volta, con il suono della moneta */
  const vuote = document.querySelectorAll('#grSheet .gr-gelo.vuoto');
  for (let i = 0; i < Math.min(quante, vuote.length); i++){
    (function(el, k){ setTimeout(function(){ el.classList.remove('vuoto'); el.classList.add('pieno', 'pop'); try{ if (typeof muJingle === 'function') muJingle('moneta'); flVibra([20, 30, 60]); }catch(_){ } }, 250 + k * 380); })(vuote[i], i);
  }
  const b = document.querySelector('#grSheet .gr-cta'); if (b){ b.disabled = true; b.textContent = 'Fatto'; }
  setTimeout(function(){ grChiudi(); try{ toast(quante === 1 ? 'Congelazione ricaricata: la serie è protetta' : 'Congelazioni ricaricate: la serie è protetta'); }catch(_){ } }, 1500 + quante * 380);
  try{ if (typeof sdPaint === 'function') sdPaint(); }catch(_){ }
}
/* al ritorno nell'app e quando si torna alla Home */
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'visible') setTimeout(grControlla, 1500); });
document.addEventListener('fl:screen', function(e){ if (e && e.detail === 's-home') setTimeout(grControlla, 1200); });
setTimeout(grControlla, 4000);

/* ---------------------------------------------------------------------------------------
   I WIDGET DA SBLOCCARE
   --------------------------------------------------------------------------------------- */
const WG_SKIN = [
  { id: 'aurora', n: 'Genio dell’aurora' },
  { id: 'notte', n: 'Genio pensieroso' },
  { id: 'tramonto', n: 'Genio al tramonto' },
  { id: 'bosco', n: 'Genio nel bosco' },
  { id: 'alba', n: 'Genio dell’alba' },
  /* non esce dalla mystery box: si guadagna riprendendo il cammino dopo una congelazione (0.9.265) */
  { id: 'scongelato', n: 'Genio scongelato', speciale: true }
];
function wgSkinSbloccate(){ try{ const l = JSON.parse(localStorage.getItem('fl_widget_skins') || '[]'); return Array.isArray(l) ? l : []; }catch(_){ return []; } }
function wgSkinAttiva(){ try{ return localStorage.getItem('fl_widget_skin') || ''; }catch(_){ return ''; } }
function wgSkinDaSbloccare(){ const s = wgSkinSbloccate(); return WG_SKIN.filter(function(x){ return !x.speciale && s.indexOf(x.id) < 0; }); }
function wgSkinNome(id){ const x = WG_SKIN.filter(function(k){ return k.id === id; })[0]; return x ? x.n : ''; }
/** La mystery box: un widget a caso fra quelli ancora chiusi. Torna il premio da mostrare. */
function wgSkinPremio(){
  const l = wgSkinDaSbloccare(); if (!l.length) return null;
  const x = l[Math.floor(Math.random() * l.length)];
  const s = wgSkinSbloccate(); s.push(x.id);
  try{ localStorage.setItem('fl_widget_skins', JSON.stringify(s)); }catch(_){ }
  try{ if (typeof ffAddCoins === 'function') ffAddCoins(15); }catch(_){ }
  return { eti: 'EPICO', ico: '🖼️', t: 'Il widget ' + x.n, s: 'e 15 monete', widget: x.id, img: 'img/widget/skin-' + x.id + '.jpg' };
}
/** Il widget scelto va sulla schermata iniziale (e se il widget non c'e' ancora, si chiede di metterlo). */
function wgSkinUsa(id){
  try{ localStorage.setItem('fl_widget_skin', id || ''); }catch(_){ }
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.widgetSet){
      const n = (typeof wgSerie === 'function') ? wgSerie() : 0;
      NATIVE.widgetSet({ serie: n, testo: '', skin: id || 'giorno' }).then(function(r){
        try{ if (typeof wgAggiorna === 'function') wgAggiorna(); }catch(_){ }
        if (!(r && r.pinned > 0) && typeof wgMetti === 'function') wgMetti();
        else try{ toast('Il widget ' + wgSkinNome(id) + ' è sulla tua schermata iniziale'); }catch(_){ }
      }).catch(function(){ });
    } else { try{ toast('Il widget ' + wgSkinNome(id) + ' è pronto'); }catch(_){ } }
  }catch(_){ }
}
/** Il premio della mystery box disegnato come su Duolingo: il telefono con il widget sopra. */
function wgSkinPremioHtml(premio){
  return '<div class="wg-premio"><div class="wg-tel"><div class="wg-tel-schermo">'
    + '<div class="wg-tel-w" style="background-image:url(' + premio.img + ')"><span>🔥 ' + ((typeof wgSerie === 'function') ? wgSerie() : 0) + '</span></div>'
    + '<i></i><i></i><i></i><i></i><i></i><i></i></div></div>'
    + '<b class="wg-premio-t">Hai ricevuto il widget <em>' + grEsc(wgSkinNome(premio.widget)) + '</em> e 15 monete!</b>'
    + '<button type="button" class="cta" onclick="wgSkinUsa(\'' + premio.widget + '\');sdScrignoContinua()">Mettilo sulla schermata iniziale</button>'
    + '<button type="button" class="sd-btn-link" onclick="sdScrignoContinua()">Continua</button></div>';
}

(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.gr-sheet{position:fixed;inset:0;z-index:9700;background:rgba(5,12,30,.55);display:flex;align-items:flex-end;justify-content:center;opacity:0;transition:opacity .25s}',
    '.gr-sheet.in{opacity:1}',
    '.gr-in{position:relative;width:100%;max-width:520px;background:#fff;color:#0E2350;border-radius:26px 26px 0 0;padding:14px 22px calc(18px + env(safe-area-inset-bottom));transform:translateY(40px);transition:transform .32s cubic-bezier(.2,.8,.2,1);text-align:center}',
    '.gr-sheet.in .gr-in{transform:none}',
    '.gr-grip{display:block;width:44px;height:5px;border-radius:3px;background:#D5DEEC;margin:0 auto 6px}',
    '.gr-saldo{text-align:right;font:800 16px var(--font-body);color:#0075E3}',
    '.gr-tit{font:800 22px/1.3 var(--font-display,var(--font-body));margin:10px 4px 22px}',
    '.gr-tit em{font-style:normal;color:#0075E3}',
    '.gr-icone{display:flex;justify-content:center;gap:26px;margin:0 0 26px}',
    '.gr-gelo{width:104px;height:116px;border-radius:30px;display:grid;place-items:center;position:relative}',
    '.gr-gelo span{font-size:62px;line-height:1}',
    '.gr-gelo.pieno{background:linear-gradient(160deg,#BFE8FF,#4FB3FF);box-shadow:0 8px 0 #2E8FE0,0 14px 24px rgba(0,117,227,.25)}',
    '.gr-gelo.vuoto{border:3px dashed #B7C4D8;background:#F4F7FB}',
    '.gr-gelo.vuoto span{filter:grayscale(1);opacity:.28}',
    '.gr-gelo.pop{animation:grPop .5s cubic-bezier(.2,1.6,.4,1)}@keyframes grPop{0%{transform:scale(.7)}60%{transform:scale(1.12)}100%{transform:scale(1)}}',
    '.gr-cta{display:flex;justify-content:center;align-items:center;gap:10px;width:100%;height:56px;border:0;border-radius:16px;background:#2E9BFF;color:#fff;font:900 16px var(--font-body);letter-spacing:.06em;box-shadow:0 5px 0 #1B78D1;cursor:pointer}',
    '.gr-cta:active{transform:translateY(3px);box-shadow:0 2px 0 #1B78D1}.gr-cta:disabled{opacity:.7}',
    '.gr-cta span{letter-spacing:0}',
    '.gr-poche{font:600 14px/1.5 var(--font-body);color:#5B6B86;margin:0 6px 6px}',
    '.gr-no{display:block;width:100%;margin-top:12px;padding:14px;border:0;background:transparent;color:#0075E3;font:900 15px var(--font-body);letter-spacing:.06em;cursor:pointer}',
    'body.dark .gr-in{background:#0F1C3A;color:#EEF4FF}body.dark .gr-gelo.vuoto{background:#14234A;border-color:#2C4170}body.dark .gr-grip{background:#2C4170}',
    /* il premio-widget della mystery box */
    '.wg-premio{display:flex;flex-direction:column;align-items:center;text-align:center;width:100%}',
    '.wg-tel{width:210px;height:250px;border-radius:34px 34px 0 0;background:linear-gradient(180deg,#9DB3E8,#7C95D6);padding:12px 12px 0;box-shadow:inset 0 0 0 3px rgba(255,255,255,.35);margin:6px auto 18px;-webkit-mask-image:linear-gradient(180deg,#000 70%,transparent);mask-image:linear-gradient(180deg,#000 70%,transparent)}',
    '.wg-tel-schermo{height:100%;border-radius:24px 24px 0 0;background:linear-gradient(180deg,#DDE7FB,#C9D7F4);display:grid;grid-template-columns:1fr 1fr 1fr;grid-auto-rows:46px;gap:10px;padding:14px}',
    '.wg-tel-schermo i{border-radius:12px;background:rgba(255,255,255,.55)}',
    '.wg-tel-w{grid-column:1 / 3;grid-row:1 / 3;border-radius:16px;background-size:cover;background-position:right center;display:flex;align-items:flex-start;justify-content:flex-start;padding:8px;box-shadow:0 6px 16px rgba(14,35,80,.3);animation:grPop .6s cubic-bezier(.2,1.6,.4,1)}',
    '.wg-tel-w span{font:900 15px var(--font-body);color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.6)}',
    '.wg-premio-t{display:block;font:800 21px/1.3 var(--font-display,var(--font-body));margin:0 6px 18px}',
    '.wg-premio-t em{font-style:normal;color:#0E2350}',
    '.wg-skin-row{display:flex;gap:10px;overflow-x:auto;padding:4px 2px 10px;margin:4px 0 8px}',
    '.wg-skin-row button{flex:none;width:120px;height:60px;border-radius:12px;border:3px solid transparent;background-size:cover;background-position:right center;cursor:pointer}',
    '.wg-skin-row button.on{border-color:#0075E3}',
    '.wg-skin-row button.giorno{background:linear-gradient(135deg,#1E2A5A,#0F2041);color:#fff;font:800 12px var(--font-body)}'
  ].join('');
  document.head.appendChild(st);
})();

/* ---------------------------------------------------------------------------------------
   L'ICONA DELL'APP (0.9.264), come Duolingo: il logo di DreamMap; dalle 18, se la serie e' a rischio
   (giorni di fila e tappa di oggi non fatta), il Genio triste (IconaApp.java). La pagina dice al
   telefono quando la tappa di oggi e' fatta e quanti giorni di serie ci sono.
   --------------------------------------------------------------------------------------- */
function iaSync(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.iconaApp) return;
    const fatta = (typeof sdTappeOggi === 'function') ? sdTappeOggi() > 0 : false;
    const serie = (typeof sdSerie === 'function') ? sdSerie() : 0;
    const oggi = (typeof sdK === 'function') ? sdK(Date.now()) : '';
    const dati = { serie: serie, attivo: true };
    if (fatta) dati.tappa = oggi;
    NATIVE.iconaApp(dati).catch(function(){ });
  }catch(_){ }
}
setTimeout(iaSync, 5000);
document.addEventListener('visibilitychange', function(){ if (document.visibilityState === 'hidden') iaSync(); });
(function(){
  if (typeof sdFineApri === 'function'){ const v = sdFineApri; window.sdFineApri = sdFineApri = function(){ const r = v.apply(this, arguments); setTimeout(iaSync, 400); return r; }; }
})();


/* ---------------------------------------------------------------------------------------
   IL GENIO SCONGELATO (0.9.265, Andrea), come "Duo scongelato" di Duolingo: dopo che una
   congelazione ha salvato la serie, la prima tappa fatta sblocca un widget nuovo, con una
   schermata sua e il pulsante per metterlo sulla schermata iniziale.
   --------------------------------------------------------------------------------------- */
function scgControlla(){
  let at = 0; try{ at = +localStorage.getItem('fl_scongelo_attesa') || 0; }catch(_){ }
  if (!at) return;
  if (!(typeof sdTappeOggi === 'function' && sdTappeOggi() > 0)) return;
  try{ localStorage.removeItem('fl_scongelo_attesa'); }catch(_){ }
  const sb = wgSkinSbloccate();
  if (sb.indexOf('scongelato') < 0){ sb.push('scongelato'); try{ localStorage.setItem('fl_widget_skins', JSON.stringify(sb)); }catch(_){ } }
  setTimeout(scgApri, 900);
}
function scgApri(){
  if (document.getElementById('scgW')) return;
  const n = (typeof wgSerie === 'function') ? wgSerie() : ((typeof sdSerie === 'function') ? sdSerie() : 0);
  const w = document.createElement('div'); w.id = 'scgW'; w.className = 'scg-w';
  w.innerHTML = '<div class="scg-in">'
    + '<div class="scg-img" style="background-image:url(img/widget/skin-scongelato.jpg)"><span>🔥 ' + n + '</span></div>'
    + '<h2>Hai ripreso il cammino dopo una protezione della serie e hai sbloccato il <em>Genio scongelato</em>.</h2>'
    + '<button type="button" class="scg-cta" onclick="wgSkinUsa(\'scongelato\');scgChiudi()">Mettilo sul widget</button>'
    + '<button type="button" class="scg-no" onclick="scgChiudi()">Continua</button></div>';
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('su'); });
  try{ if (typeof flVibra === 'function') flVibra([20, 40, 60]); }catch(_){ }
}
function scgChiudi(){ const w = document.getElementById('scgW'); if (!w) return; w.classList.remove('su'); setTimeout(function(){ w.remove(); }, 260); }
(function(){
  if (typeof sdFineApri === 'function'){ const v = sdFineApri; window.sdFineApri = sdFineApri = function(){ const r = v.apply(this, arguments); setTimeout(scgControlla, 600); return r; }; }
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(scgControlla, 1500); });
  const st = document.createElement('style');
  st.textContent = [
    '.scg-w{position:fixed;inset:0;z-index:9800;display:flex;align-items:center;justify-content:center;background:#0A2A5E;opacity:0;transition:opacity .25s}.scg-w.su{opacity:1}',
    '.scg-in{width:100%;max-width:420px;padding:24px 22px calc(28px + env(safe-area-inset-bottom));text-align:center;color:#fff;display:flex;flex-direction:column;align-items:center;min-height:100%;justify-content:center}',
    '.scg-img{width:280px;height:280px;border-radius:44px;background-size:cover;background-position:80% center;box-shadow:0 24px 60px rgba(0,0,0,.35);position:relative;margin-bottom:34px}',
    '.scg-img span{position:absolute;left:0;right:0;top:22px;font:900 34px var(--font-display);color:#FFC53D;text-shadow:0 2px 8px rgba(0,0,0,.3)}',
    '.scg-in h2{margin:0 0 30px;font:800 24px/1.35 var(--font-display,var(--font-body))}.scg-in h2 em{font-style:normal;color:#8FCBFF}',
    '.scg-cta{width:100%;border:0;border-radius:18px;padding:16px;background:#3F9FF4;color:#fff;font:900 16px var(--font-body);letter-spacing:.06em;text-transform:uppercase;box-shadow:0 5px 0 #0075E3;cursor:pointer}',
    '.scg-no{margin-top:14px;border:0;background:none;color:#C9D9EE;font:700 14px var(--font-body);cursor:pointer}'
  ].join('');
  document.head.appendChild(st);
})();
