/* ===========================================================================================
   IL DIARIO DI VIAGGIO — il taccuino di Nathan Drake, dentro all'app

   Un quaderno di carta che si sfoglia come in un videogioco: foto con lo scotch, timbri, appunti
   scritti a mano, il numero grande di un traguardo. Le pagine non le scrive l'utente: le scrive
   il viaggio. La lettura del Genio (da dove parte), il mantra dell'inizio, i traguardi della
   Modalita' severa, la prima sessione di Full Focus e i record, i passi della rotta spuntati,
   le foto lasciate come prova, le lettere dell'Io Futuro, gli scrigni d'oro. Ogni pagina ha una
   data, e si sfogliano in ordine: e' la storia di come si e' arrivati fin qui.

   E' anche la parte sociale: dal profilo (scheda Story) il diario si puo' rendere pubblico, e
   allora gli amici, toccando la bolla nella classifica, lo sfogliano. Le foto restano sul
   telefono: agli amici arrivano testo, date e disegni. Un diario con le pagine bianche si vede,
   ed e' fatto apposta: chi sa che qualcuno lo leggera' scrive pagine migliori.

   Sfogliare: un foglio solo alla volta, che gira sul bordo sinistro (rotateY) e scopre la
   pagina sotto. Tocco a destra o scorri verso sinistra = avanti; a sinistra = indietro.
   =========================================================================================== */
const DV = { pagine: [], i: 0, di: null, giro: false };
const DV_PUB_KEY = 'fl_diario_pubblico';
const DV_PUBBLICATO_KEY = 'fl_diario_pubblicato_at';
const DV_MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
const DV_GIORNI = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'];
const DV_TIPI = {
  copertina: { cat: 'Inizio',    ico: '📔' },
  inizio:    { cat: 'Inizio',    ico: '🧞' },
  mantra:    { cat: 'Inizio',    ico: '✍️' },
  traguardo: { cat: 'Traguardi', ico: '🔒' },
  sessione:  { cat: 'Sessioni',  ico: '🌱' },
  record:    { cat: 'Sessioni',  ico: '🏆' },
  passi:     { cat: 'Rotta',     ico: '🧭' },
  foto:      { cat: 'Prove',     ico: '📷' },
  lettera:   { cat: 'Lettere',   ico: '✉️' },
  scrigno:   { cat: 'Mystery box', ico: '🏆' },
  prossima:  { cat: 'Domani',    ico: '✏️' }
};

function dvEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function dvLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function dvIso(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function dvDaIso(iso){ return new Date(iso + 'T12:00:00').getTime(); }
/* L'ora h di quel giorno (0.9.214). Prima si faceva dvDaIso(iso) + h ore, ma dvDaIso e' gia'
   mezzogiorno: le 21 diventavano le 9 del giorno dopo, e la pagina finiva sul giorno sbagliato
   ("Modifica" apriva il giorno dopo, vuoto; la pagina di oggi slittava a domani). */
function dvOra(iso, h){ return new Date(iso + 'T' + String(h).padStart(2, '0') + ':00:00').getTime(); }
function dvDataLunga(t){ const d = new Date(t); return DV_GIORNI[d.getDay()] + ' ' + d.getDate() + ' ' + DV_MESI[d.getMonth()] + ' ' + d.getFullYear(); }
function dvDataCorta(t){ const d = new Date(t); return d.getDate() + ' ' + DV_MESI[d.getMonth()].slice(0, 3) + ' ' + d.getFullYear(); }
function dvSrc(u){ try{ return (u && window.Capacitor && Capacitor.convertFileSrc && !/^(data:|https?:)/.test(u)) ? Capacitor.convertFileSrc(u) : u; }catch(_){ return u; } }
function dvNome(){ try{ const u = JSON.parse(localStorage.getItem('fl_user') || 'null'); return (u && u.name) ? String(u.name).trim() : ''; }catch(_){ return ''; } }
/** Il nome di battesimo, per firmare: quello detto al Genio, se no quello del profilo. */
function dvPrimoNome(){
  let n = ''; try{ n = (typeof gnNome === 'function') ? gnNome() : ''; }catch(_){ }
  if (!n) n = dvNome();
  return String(n || '').trim().split(/\s+/)[0] || '';
}
function dvDataFirma(t){ const d = new Date(t); return d.getDate() + ' ' + DV_MESI[d.getMonth()] + ' ' + d.getFullYear(); }

/* ---- LA LINGUA DEI TIMBRI. Il diario e' scritto in italiano; i timbri sono le uniche parole
   stampate, e seguono la lingua scelta in Impostazioni (o quella del telefono). ---- */
function dvLingua(){
  try{ if (typeof dcoLingua === 'function') return dcoLingua(); }catch(_){ }
  let v = 'system'; try{ v = localStorage.getItem('fl_lang') || 'system'; }catch(_){ }
  if (v !== 'system') return String(v).slice(0, 2).toLowerCase();
  try{ return (typeof flLingua === 'function') ? flLingua() : String(navigator.language || 'it').slice(0, 2).toLowerCase(); }catch(_){ return 'it'; }
}
const DV_TIMBRI = {
  severa: { it: 'MODALITÀ SEVERA', en: 'STRICT MODE', es: 'MODO ESTRICTO', fr: 'MODE STRICT', de: 'STRENGER MODUS', pt: 'MODO RIGOROSO' },
  fatto:  { it: 'FATTO', en: 'DONE', es: 'HECHO', fr: 'FAIT', de: 'ERLEDIGT', pt: 'FEITO' }
};
function dvTimbro(k){ const m = DV_TIMBRI[k] || {}; return m[dvLingua()] || m.en || m.it || ''; }

/* ---- I FATTI DEL GIORNO ---- */
const DV_UMORE_FRASI = ['Una giornata pesante', 'Una giornata storta', 'Una giornata così così', 'Una bella giornata', 'Una giornata splendida'];
const DV_SCHERMO_KEY = 'fl_dv_schermo';
/** «40 minuti», «1 h 05», «2 h». */
function dvDur(min){
  min = Math.max(0, Math.round(min));
  if (min < 60) return min + (min === 1 ? ' minuto' : ' minuti');
  const h = Math.floor(min / 60), m = min % 60;
  return h + ' h' + (m ? ' ' + String(m).padStart(2, '0') : '');
}
/* Accorcia senza mai spezzare una parola (0.9.219): si taglia all'ultimo spazio prima del limite. */
function dvCorto(s, n){
  s = String(s || '').replace(/\s+/g, ' ').trim();
  if (s.length <= n) return s;
  let t = s.slice(0, n - 1); const sp = t.lastIndexOf(' ');
  if (sp > n * 0.5) t = t.slice(0, sp);
  return t.replace(/[\s,;:.\-–]+$/, '') + '…';
}
/** Una riga del foglio o un passo del percorso, ridotti a confronto (come stNormRiga). */
function dvNorm(t){ return String(t || '').replace(/^[☐☑•]\s*/, '').trim().toLowerCase().replace(/\s+/g, ' '); }
/* Le righe che l'app aggiungeva da sola fino alla 0.9.216 («Umore: …», «In numeri: …», il carico
   di lavoro): se qualcuno ha toccato "Modifica" e salvato, sono finite dentro i suoi appunti.
   Ora l'umore e i fatti si disegnano a parte: quelle righe si tolgono, il resto e' suo. */
function dvSenzaRigheVecchie(t){
  return String(t || '').split('\n').filter(function(r){
    const x = r.replace(/^[^A-Za-zÀ-ÿ]+/, '');
    return !/^(Umore: |Perché: |Cosa ha deciso la giornata: |Il carico di lavoro della settimana: |In numeri: )/.test(x);
  }).join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
/** Il tempo sul telefono per giorno, come lo misura Android: { 'AAAA-MM-GG': minuti }. */
function dvSchermo(){ const c = dvLeggi(DV_SCHERMO_KEY, null); return (c && c.g) || {}; }
/* Si chiede al telefono all'apertura del diario (al massimo ogni venti minuti) e si tiene da
   parte: dvPagine e' sincrona e non puo' aspettare il motore. Quando arriva, la pagina aperta
   si ridisegna con il dato. */
async function dvSchermoCarica(){
  try{
    if (typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.getScreenTimeRange) return false;
    const c = dvLeggi(DV_SCHERMO_KEY, null);
    if (c && Date.now() - (c.at || 0) < 20 * 60000) return false;
    const d0 = new Date(); d0.setHours(0, 0, 0, 0);
    const r = await NATIVE.getScreenTimeRange({ from: d0.getTime() - 45 * 86400000, to: Date.now(), bucket: 'day' });
    const g = {};
    ((r && r.buckets) || []).forEach(function(b){
      const ms = b ? (b.ms != null ? +b.ms : (+b.minutes || 0) * 60000) : 0;
      /* oltre le 18 ore non e' un giorno: e' il registro di Android che si e' accorciato */
      if (b && b.start && ms > 60000 && ms <= 18 * 3600000) g[dvIso(b.start)] = Math.round(ms / 60000);
    });
    localStorage.setItem(DV_SCHERMO_KEY, JSON.stringify({ at: Date.now(), g: g }));
    return true;
  }catch(_){ return false; }
}
/** Tutto quello che serve per scrivere i fatti di un giorno, letto una volta sola. */
function dvFattiCtx(){
  const c = { ff: {}, lista: {}, mappa: {}, serieG: {}, schermo: dvSchermo(), sev: null, passi: [] };
  /* i passi del percorso (gli Orizzonti), una volta sola per testo: { t, n, fatto, il, k } */
  try{
    if (typeof ozLeggi === 'function'){
      const oz = ozLeggi(); const visti = {};
      ['oggi', 'settimana', 'mese', 'anno', 'cinque'].forEach(function(k){
        ((oz[k] && oz[k].passi) || []).forEach(function(p){
          if (!p || !p.t) return; const n = dvNorm(p.t); if (!n || visti[n]) return; visti[n] = 1;
          c.passi.push({ t: String(p.t), n: n, fatto: !!p.fatto, il: p.il || '', k: k });
        });
      });
    }
  }catch(_){ }
  try{
    (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).forEach(function(x){
      if (!x || !x.ok || x.meditazione || !x.at) return;
      (c.ff[dvIso(x.at)] = c.ff[dvIso(x.at)] || []).push(x);
    });
  }catch(_){ }
  try{
    const d = (typeof stDone === 'function') ? stDone() : (JSON.parse(localStorage.getItem('fl_notes_done') || '[]') || []);
    d.forEach(function(x){ if (x && x.day && x.text) (c.lista[x.day] = c.lista[x.day] || []).push(x); });
  }catch(_){ }
  /* le tappe della mappa, numerate come sulla mappa (la prima tappa e' la 1) */
  try{
    if (typeof sdTutti === 'function' && typeof sdStato === 'function'){
      const s = sdStato();
      sdTutti().forEach(function(nd, i){
        const t = s.fatti[nd.id]; if (!t || nd.tipo === 'sc') return;
        const nome = nd.tipo === 'ep' ? ((typeof sdTitoloEp === 'function' ? sdTitoloEp(nd.n, '') : '') || (nd.cap && nd.cap.titolo) || '') : ((typeof SD_NOMI !== 'undefined' && SD_NOMI[nd.tipo]) || '');
        (c.mappa[dvIso(t)] = c.mappa[dvIso(t)] || []).push({ n: i + 1, nome: nome, t: t });
      });
    }
  }catch(_){ }
  try{ c.serieG = (typeof sdGiorniFatti === 'function') ? sdGiorniFatti() : {}; }catch(_){ }
  try{ const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null'); if (st && st.start) c.sev = st.start; }catch(_){ }
  return c;
}
/** La serie della mappa com'era la sera di quel giorno: i giorni di fila con almeno una tappa. */
function dvSerieAl(iso, g){
  if (!(g[iso] > 0)) return 0;
  let n = 0; const t0 = dvDaIso(iso);
  for (let i = 0; i < 400; i++){
    const k = dvIso(t0 - i * 86400000);
    if (g[k] > 0){ n++; continue; }
    if (g[k] === -1) continue;
    break;
  }
  return n;
}
/**
 * I passi del percorso di quel giorno (0.9.219): quanti erano in programma e quanti sono stati
 * fatti. Fatto = spuntato quel giorno (il). In programma = i fatti, piu' quelli ancora aperti (o
 * chiusi in un giorno dopo) che stavano nel foglio di quel giorno; oggi anche i passi aperti
 * dell'orizzonte «Oggi», che sono la roadmap di oggi anche prima di finire nel foglio.
 * Torna { fatti: [passi], tot } oppure null.
 */
function dvRottaDi(iso, c){
  if (!c.passi || !c.passi.length) return null;
  const oggi = iso === dvIso(Date.now());
  let foglio = null;
  const nelFoglio = function(n){
    if (!foglio){
      foglio = {};
      try{ (localStorage.getItem('fl_notes_' + iso) || '').split('\n').forEach(function(r){ const k = dvNorm(r); if (k) foglio[k] = 1; }); }catch(_){ }
    }
    return !!foglio[n];
  };
  const fatti = []; let tot = 0;
  c.passi.forEach(function(p){
    if (p.fatto && p.il === iso){ fatti.push(p); tot++; return; }
    const aperto = !p.fatto || (p.il && p.il > iso);
    if (aperto && ((oggi && p.k === 'oggi' && !p.fatto) || nelFoglio(p.n))) tot++;
  });
  return fatti.length ? { fatti: fatti, tot: tot } : null;
}
/**
 * I fatti di un giorno, gia' scritti come appunti: al massimo quattro, i piu' importanti prima.
 * Ognuno dice che cos'e' («sul telefono», «di Full Focus», «della mappa»): un numero senza il
 * suo nome sulla pagina non dice niente.
 */
function dvFattiDi(iso, c){
  const out = [];
  const oggi = iso === dvIso(Date.now());
  /* il telefono, contro il giorno prima */
  const sm = c.schermo[iso];
  if (sm){
    const ieri = c.schermo[dvIso(dvDaIso(iso) - 86400000)];
    let t = dvDur(sm) + ' sul telefono', dir = '';
    if (oggi) t += ', fin qui';
    else if (ieri){
      const d = sm - ieri;
      if (Math.abs(d) < 5) t += ', come ieri';
      else { t += ', ' + dvDur(Math.abs(d)) + (d < 0 ? ' meno di ieri' : ' più di ieri'); dir = d < 0 ? 'giu' : 'su'; }
    }
    out.push({ k: 'schermo', t: t, dir: dir, peso: dir === 'giu' ? 9 : 7 });
  }
  /* le sessioni di Full Focus */
  const ses = c.ff[iso] || [];
  if (ses.length){
    const minDi = function(x){ return Math.round((x.spentMs || 0) / 60000) || x.min || 0; };
    const tot = ses.reduce(function(a, x){ return a + minDi(x); }, 0);
    const lunga = ses.slice().sort(function(a, b){ return minDi(b) - minDi(a); })[0];
    const su = lunga && lunga.intent ? ' su "' + dvCorto(lunga.intent, 32) + '"' : '';
    out.push({ k: 'ff', peso: 8, t: ses.length === 1
      ? 'Una sessione di Full Focus da ' + dvDur(tot) + su
      : ses.length + ' sessioni di Full Focus, ' + dvDur(tot) + ' in tutto' });
  }
  /* la roadmap del giorno: un «x su y» solo con il suo nome accanto, come Drake che tiene il
     conto dei pezzi dell'enigma (regola 15 del copy: niente voti senza contesto) */
  const rotta = dvRottaDi(iso, c);
  const giaContati = {};
  if (rotta){
    rotta.fatti.forEach(function(p){ giaContati[p.n] = 1; });
    const nf = rotta.fatti.length;
    out.push({ k: 'rotta', peso: 8.8, t: rotta.tot === 1
      ? 'Fatto il passo del percorso di oggi: "' + dvCorto(rotta.fatti[0].t, 34) + '"'
      : (nf === 1 ? 'Fatto 1 passo' : 'Fatti ' + nf + ' passi') + ' su ' + rotta.tot + ' del percorso di oggi' });
  }
  /* la lista del giorno: la cosa piu' importante, se e' stata fatta (i passi del percorso sono
     gia' contati sopra: non si scrivono due volte) */
  const fatte = (c.lista[iso] || []).filter(function(x){ return !giaContati[dvNorm(x.text)]; }).sort(function(a, b){ return (a.at || 0) - (b.at || 0); });
  if (fatte.length){
    let imp = null;
    try{
      if (typeof stEtichetta === 'function'){
        imp = fatte.filter(function(x){ return stEtichetta(x.text).k === 'fai'; })[0] || fatte.filter(function(x){ return stEtichetta(x.text).k === 'passo'; })[0] || null;
      }
    }catch(_){ imp = null; }
    const altre = fatte.length - 1;
    if (imp) out.push({ k: 'lista', peso: 8.5, t: 'Fatta la cosa più importante: "' + dvCorto(imp.text, 44) + '"' + (altre ? ', più altre ' + altre + ' dalla lista' : '') });
    else out.push({ k: 'lista', peso: 6, t: fatte.length === 1 ? 'Spuntata dalla lista: "' + dvCorto(fatte[0].text, 44) + '"' : fatte.length + ' cose spuntate dalla lista, l’ultima è "' + dvCorto(fatte[fatte.length - 1].text, 36) + '"' });
  }
  /* la mappa */
  const tappe = (c.mappa[iso] || []).sort(function(a, b){ return a.n - b.n; });
  if (tappe.length === 1) out.push({ k: 'mappa', peso: 7.5, t: 'Tappa ' + tappe[0].n + ' della mappa superata' + (tappe[0].nome ? ': "' + dvCorto(tappe[0].nome, 34) + '"' : '') });
  else if (tappe.length > 1){
    const fila = tappe[tappe.length - 1].n - tappe[0].n === tappe.length - 1;
    out.push({ k: 'mappa', peso: 7.5, t: fila ? 'Tappe dalla ' + tappe[0].n + ' alla ' + tappe[tappe.length - 1].n + ' della mappa superate' : tappe.length + ' tappe della mappa superate, l’ultima è la ' + tappe[tappe.length - 1].n });
  }
  /* la serie, quando comincia a contare */
  const serie = dvSerieAl(iso, c.serieG || {});
  if (serie >= 3) out.push({ k: 'serie', peso: 5, t: 'Serie della mappa: ' + serie + ' giorni di fila' });
  /* la Modalita' severa */
  if (c.sev && iso >= c.sev){
    const n = Math.round((dvDaIso(iso) - dvDaIso(c.sev)) / 86400000) + 1;
    if (n >= 2) out.push({ k: 'severa', peso: 4, t: 'Giorno ' + n + ' con la Modalità severa accesa' });
  }
  return out.sort(function(a, b){ return b.peso - a.peso; }).slice(0, 4);
}

/* ---------------------------------------------------------------------------------------
   LE PAGINE, dal viaggio
   --------------------------------------------------------------------------------------- */
function dvPagine(){
  const P = [];
  const oggi = Date.now();
  const add = function(p){ if (p && p.t && p.t <= oggi + 60000) P.push(p); };

  /* da dove parto: la lettura del Genio */
  let inizioT = 0;
  try{
    const o = (typeof orLast === 'function') ? orLast() : null;
    const L = (typeof gnLettura === 'function') ? gnLettura() : null;
    const r = (typeof rtStato === 'function') ? rtStato() : null;
    const n = function(x){ return x ? (typeof x === 'string' ? x : (x.nome || x.n || x.name || '')) : ''; };
    if (o){
      inizioT = +o.at || +o.t || +o.when || 0;
      if (!inizioT){ try{ inizioT = +localStorage.getItem('fl_or_at') || 0; }catch(_){ } }
      const prof = (L && L.prof && L.prof.name) || (o.profile && (o.profile.name || o.profile)) || '';
      const dest = (r && r.a) ? n(r.a) : ((typeof orTargetName === 'function' && o.target) ? orTargetName(o.target) : '');
      let av = ''; try{ av = localStorage.getItem('fl_avatar_img') || ''; }catch(_){ }
      add({ id: 'inizio', tipo: 'inizio', t: inizioT || oggi, titolo: 'Da dove parto',
        testo: (prof ? 'Oggi sono ' + String(prof).trim() + '.' : '') + (dest ? ' Voglio arrivare a ' + dest + '.' : '') + (L && L.sogno ? '\nIl sogno: ' + String(L.sogno).trim() : ''),
        nota: (r && r.da) ? 'Partenza: ' + n(r.da) : '', ico: '🧞', foto: av, didascalia: dvNome() || 'io, il primo giorno' });
    }
  }catch(_){ }
  /* il mantra dell'inizio */
  try{
    const u = JSON.parse(localStorage.getItem('fl_user') || 'null');
    const bio = (u && u.bio) ? String(u.bio).trim() : ((typeof whyMantra === 'function') ? String(whyMantra() || '').trim() : '');
    if (bio) add({ id: 'mantra', tipo: 'mantra', t: (inizioT || oggi) + 1, titolo: 'La promessa', testo: bio, nota: 'scritta il primo giorno', ico: '✍️' });
  }catch(_){ }
  /* i traguardi della Modalita' severa */
  try{
    const st = JSON.parse(localStorage.getItem('fl_sev_streak') || 'null');
    if (st && st.start && typeof BLK_PIETRE !== 'undefined'){
      const t0 = dvDaIso(st.start);
      Object.keys(BLK_PIETRE).map(Number).sort(function(a, b){ return a - b; }).forEach(function(n){
        const t = t0 + (n - 1) * 86400000;
        if (t > oggi) return;
        const c = BLK_PIETRE[n];
        add({ id: 'sev' + n, tipo: 'traguardo', t: t + 9 * 3600000, titolo: c.t, testo: c.p + (c.f ? ' ' + c.f : ''), n: n, nota: 'giorno ' + n + ' con la Modalità severa accesa', ico: '🔒' });
      });
    }
  }catch(_){ }
  /* le sessioni di Full Focus: la prima, i record, ogni dieci */
  try{
    const h = (JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || []).filter(function(x){ return x && x.ok && !x.meditazione; }).sort(function(a, b){ return (a.at || 0) - (b.at || 0); });
    /* un record e' pagina solo quando supera una soglia (45, 60, 90, 120, 180 minuti): senza
       soglie le prime settimane erano un record al giorno, e un diario di soli record annoia */
    const soglie = [45, 60, 90, 120, 180];
    let max = 0;
    h.forEach(function(x, i){
      const min = Math.round((x.spentMs || 0) / 60000) || x.min || 0;
      if (i === 0) add({ id: 'ff0', tipo: 'sessione', t: x.at, titolo: 'La prima sessione', testo: min + ' minuti di Full Focus' + (x.intent ? ' su "' + x.intent + '"' : '') + '. Il primo albero della foresta.', ico: '🌱', min: min });
      else if ((i + 1) % 10 === 0) add({ id: 'ff' + (i + 1), tipo: 'sessione', t: x.at, titolo: (i + 1) + ' sessioni', testo: 'La numero ' + (i + 1) + ': ' + min + ' minuti' + (x.intent ? ' su "' + x.intent + '"' : '') + '.', ico: '🌳', min: min });
      const soglia = soglie.filter(function(s){ return min >= s && max < s; }).pop();
      if (soglia && i > 0) add({ id: 'record' + soglia, tipo: 'record', t: x.at + 1, titolo: 'Record: ' + min + ' minuti', testo: 'La sessione più lunga fino a qui' + (x.intent ? ', su "' + x.intent + '"' : '') + '. Prima volta sopra i ' + soglia + '.', ico: '🏆', min: min });
      if (min > max) max = min;
    });
  }catch(_){ }
  /* i passi della rotta spuntati, per giorno */
  try{
    if (typeof ozLeggi === 'function'){
      const oz = ozLeggi(); const nomi = { oggi: 'Oggi', settimana: 'Settimana', mese: 'Mese', anno: 'Anno', cinque: 'Cinque anni', ungiorno: 'Un giorno' };
      const perGiorno = {};
      Object.keys(oz).forEach(function(k){
        ((oz[k] && oz[k].passi) || []).forEach(function(p){
          if (p && p.fatto && p.il && p.t){ (perGiorno[p.il] = perGiorno[p.il] || []).push({ t: String(p.t), dove: nomi[k] || k }); }
        });
      });
      Object.keys(perGiorno).forEach(function(il){
        add({ id: 'passi' + il, tipo: 'passi', t: dvOra(il, 20), titolo: 'Passi della rotta', passi: perGiorno[il].slice(0, 6), testo: perGiorno[il].map(function(x){ return x.t; }).join('; '), ico: '🧭' });
      });
    }
  }catch(_){ }
  /* le prove in foto */
  try{
    const all = (typeof stMetaAll === 'function') ? stMetaAll() : {};
    Object.keys(all).forEach(function(k){
      const m = all[k]; if (!m || !m.foto) return;
      const parti = k.split('|'); const day = parti[0], riga = parti.slice(1).join('|');
      const t = (m.fotoAt || (/^\d{4}-\d{2}-\d{2}$/.test(day) ? dvOra(day, 18) : 0));
      if (t) add({ id: 'foto' + k.slice(0, 40), tipo: 'foto', t: t, titolo: 'Fatto', testo: riga, foto: m.foto, didascalia: riga, ico: '📷' });
    });
  }catch(_){ }
  /* le lettere dell'Io Futuro */
  try{
    (dvLeggi('fl_if_diario', []) || []).forEach(function(m){
      if (!m || !m.testo) return;
      add({ id: 'let' + (m.id || m.t), tipo: 'lettera', t: m.t || dvDaIso(m.giorno), titolo: 'Dal mio io futuro', testo: String(m.testo), ico: '✉️' });
    });
  }catch(_){ }
  /* gli scrigni d'oro e leggendari */
  try{
    ((dvLeggi('fl_scrigni', {}) || {}).aperti || []).forEach(function(s, i){
      if (!s || (s.tier !== 'oro' && s.tier !== 'leggendario')) return;
      add({ id: 'scr' + i, tipo: 'scrigno', t: s.at, titolo: 'Mystery box ' + (s.tier === 'oro' ? 'd’oro' : 'leggendaria'), testo: (s.min ? s.min + ' minuti di Full Focus. ' : '') + (s.frase ? '"' + s.frase + '"' : ''), ico: s.tier === 'oro' ? '🏆' : '💎' });
    });
  }catch(_){ }

  P.sort(function(a, b){ return a.t - b.t; });
  /* senza la lettura del Genio, la promessa dell'inizio va comunque all'inizio */
  if (!inizioT){
    const m = P.filter(function(p){ return p.tipo === 'mantra'; })[0];
    const primoVero = P.filter(function(p){ return p.tipo !== 'mantra'; })[0];
    if (m && primoVero){ m.t = primoVero.t - 1; P.sort(function(a, b){ return a.t - b.t; }); }
  }
  /* LE PAGINE DEL GIORNO (0.9.208): se un giorno ha fatti (sessioni, tappe, umore) ma nessuna
     pagina, il Genio ne scrive una corta: meglio di una pagina bianca. E le note scritte a mano. */
  /* LE PAGINE DEL GIORNO (0.9.210). In un diario vengono prima gli appunti e l'umore, con il
     perche'; i numeri vanno in fondo, in una riga. Una pagina per giorno: se hai scritto degli
     appunti, l'umore e i numeri si aggiungono sotto ai tuoi appunti; se non li hai scritti, la
     pagina comincia dall'umore. Il giorno solo di numeri resta l'ultima scelta. */
  /* LA PAGINA DEL GIORNO (0.9.217), come il taccuino di Nathan Drake. Al centro le parole di chi
     scrive (gli appunti, o quello che ha detto dell'umore); sopra l'umore con la faccina
     disegnata; sotto al massimo quattro fatti, scritti come appunti a mano e sempre con il loro
     contesto: "2 h 10 sul telefono, 40 minuti meno di ieri", non "In numeri: 1 tappa". Le
     risposte della chat dell'umore non si stampano mai come "domanda: risposta": se il modulo
     dell'umore sa dirle in frasi (umDiarioRighe), si usano quelle; se no resta il voto. */
  try{
    const note = dvNote();
    const giorniCon = {}; P.forEach(function(p){ giorniCon[dvIso(p.t)] = true; });
    const ctx = dvFattiCtx();
    const VOCI = (typeof UM_VOCI !== 'undefined') ? UM_VOCI : ['Malissimo', 'Storta', 'Così così', 'Bene', 'Benissimo'];
    const giorni = {};
    Object.keys(note).forEach(function(iso){ giorni[iso] = true; });
    for (let i = 0; i <= 45; i++) giorni[dvIso(Date.now() - i * 86400000)] = true;
    Object.keys(giorni).forEach(function(iso){
      const n = note[iso] && note[iso].testo ? note[iso] : null;
      let u = null; try{ u = (typeof umLeggi === 'function') ? umLeggi(iso) : null; }catch(_){ }
      const voto = u && (u.sodd || u.v || u.voto) ? +(u.sodd || u.v || u.voto) : 0;
      const hoVoto = voto >= 1 && voto <= 5;
      /* le frasi dell'umore e le parole libere: dal modulo dell'umore, se le sa scrivere */
      let righe = [], detto = '';
      if (hoVoto || u){
        try{ if (typeof umDiarioRighe === 'function') righe = (umDiarioRighe(iso) || []).map(function(x){ return String(x || '').trim(); }).filter(Boolean); }catch(_){ righe = []; }
        try{ detto = (typeof umDiarioNota === 'function') ? String(umDiarioNota(iso) || '').trim() : String((u && u.nota) || '').trim(); }catch(_){ detto = ''; }
      }
      const fatti = dvFattiDi(iso, ctx);
      const parole = n ? dvSenzaRigheVecchie(n.testo) : '';
      /* la frase del voto la scrive il modulo dell'umore (la prima delle sue righe): se c'e', va
         accanto alla faccina al posto della nostra, cosi' la pagina non dice due volte la stessa cosa */
      const fraseUm = (hoVoto && righe.length && typeof UM_DIARIO_VOTO !== 'undefined' && UM_DIARIO_VOTO.indexOf(righe[0]) >= 0) ? righe.shift() : '';
      righe = righe.slice(0, 3);
      const umoreFrase = hoVoto ? (fraseUm || DV_UMORE_FRASI[voto - 1]) : '';
      /* il testo semplice: per la Timeline del profilo, per gli amici e per «Leggi di più» */
      const piano = [parole, umoreFrase ? umoreFrase + ' (umore: ' + VOCI[voto - 1].toLowerCase() + ')' : '', righe.join('\n'), detto && detto !== parole ? '"' + detto + '"' : '', fatti.map(function(f){ return f.t; }).join('\n')].filter(Boolean).join('\n\n');
      const base = { iso: iso, voto: hoVoto ? voto : 0, umore: umoreFrase, righe: righe, detto: detto, parole: parole, fatti: fatti };
      if (n){
        add(Object.assign(base, { id: 'nota' + iso, tipo: 'nota', t: Math.min(dvOra(iso, 21), Date.now()), titolo: n.titolo || '', testo: piano, foto: n.foto || '', ico: '🪶' }));
      } else if (hoVoto || detto){
        add(Object.assign(base, { id: 'umore' + iso, tipo: 'nota', t: Math.min(dvOra(iso, 21), Date.now()), titolo: '', testo: piano, ico: '🪶' }));
      } else if (fatti.length && !giorniCon[iso] && iso !== dvIso(Date.now())){
        add(Object.assign(base, { id: 'giorno' + iso, tipo: 'giorno', t: Math.min(dvOra(iso, 20), Date.now()), titolo: '', testo: piano, ico: '🧭' }));
      }
    });
    P.sort(function(a, b){ return a.t - b.t; });
    /* il numero del giorno di viaggio, dal primo giorno del diario */
    if (P.length){
      /* il primo giorno si ricorda: se una pagina sparisce (una serie severa che si spezza), i
         numeri dei giorni non devono slittare */
      let g0 = dvDaIso(dvIso(Math.min(inizioT || Infinity, P[0].t)));
      try{ const k = 'fl_dv_giorno1', v = +localStorage.getItem(k) || 0; if (v && v < g0) g0 = v; else localStorage.setItem(k, String(g0)); }catch(_){ }
      P.forEach(function(p){ if (p.iso) p.giornoN = Math.round((dvDaIso(p.iso) - g0) / 86400000) + 1; });
    }
  }catch(_){ }
  const primo = P.length ? P[0].t : oggi;
  const nome = dvNome();
  return [{ id: 'cover', tipo: 'copertina', t: primo, titolo: 'Diario di viaggio', testo: nome, nota: dvDataCorta(primo) }]
    .concat(P)
    .concat([{ id: 'next', tipo: 'prossima', t: oggi, titolo: '', testo: 'La prossima pagina la scrivi domani.', ico: '✏️' }]);
}
/* LA PAGINA DI OGGI E' APERTA. Prima, finche' oggi non c'era una nota o un umore, dopo
   l'ultima pagina veniva subito "La prossima pagina la scrivi domani": oggi non si poteva scrivere.
   Le pagine scritte dall'app sono solo il ripiego per i giorni rimasti bianchi, a giornata finita
   (dvPagine non le fa mai per oggi). Per oggi, se manca la sua pagina, il libro ne mette una aperta,
   con l'invito a scriverla e sotto i fatti di oggi fin qui; "domani" resta l'ultima pagina, e solo
   quella. Si aggiunge solo al libro aperto: i conteggi delle pagine, la Timeline e il diario
   pubblico continuano a leggere dvPagine e non contano una pagina ancora da scrivere. */
function dvPagineLibro(){
  const P = dvPagine();
  const iso = dvIso(Date.now());
  if (P.some(function(p){ return p && p.iso === iso; })) return P;
  let fatti = []; try{ fatti = dvFattiDi(iso, dvFattiCtx()); }catch(_){ fatti = []; }
  let giornoN = 0;
  try{ const g0 = +localStorage.getItem('fl_dv_giorno1') || 0; if (g0) giornoN = Math.round((dvDaIso(iso) - g0) / 86400000) + 1; }catch(_){ }
  const oggiP = { id: 'oggi' + iso, tipo: 'oggi', iso: iso, t: Date.now(), titolo: '', testo: '', voto: 0, umore: '', righe: [], detto: '', parole: '', fatti: fatti, giornoN: giornoN > 0 ? giornoN : 0 };
  const k = P.length && P[P.length - 1].tipo === 'prossima' ? P.length - 1 : P.length;
  P.splice(k, 0, oggiP);
  return P;
}
/** Le pagine davvero scritte (senza copertina, pagina di oggi ancora bianca e «domani»). */
function dvScritte(lista){ return (lista || []).filter(function(p){ return p && p.tipo !== 'copertina' && p.tipo !== 'prossima' && p.tipo !== 'oggi'; }).length; }
/** La penna, disegnata: per i pulsanti che aprono il foglio dove si scrive. */
function dvPenna(colore){
  return '<svg class="dv-penna" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="' + (colore || 'currentColor') + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20l4.2-1L19.4 7.8a2 2 0 0 0 0-2.8l-.4-.4a2 2 0 0 0-2.8 0L5 15.8 4 20z"/><path d="M14.6 6.2l3.2 3.2"/></svg>';
}
/** Per la Timeline del profilo: gli eventi, dal piu' recente, con la loro categoria. */
function dvEventi(){
  return dvPagine().filter(function(p){ return p.tipo !== 'copertina' && p.tipo !== 'prossima'; })
    .map(function(p){ const q = Object.assign({ cat: (DV_TIPI[p.tipo] || {}).cat || '', ico: p.ico || (DV_TIPI[p.tipo] || {}).ico || '' }, p); if (!q.titolo && q.iso) q.titolo = q.giornoN ? 'Giorno ' + q.giornoN + ' del viaggio' : 'Appunti del giorno'; return q; })
    .sort(function(a, b){ return b.t - a.t; });
}
/** Per la scheda Media: tutte le foto del viaggio. */
function dvFoto(){
  const out = [];
  dvPagine().forEach(function(p){ if (p.foto) out.push({ src: p.foto, didascalia: p.didascalia || p.titolo || '', t: p.t }); });
  try{ const w = localStorage.getItem('fl_why_img'); if (w) out.push({ src: w, didascalia: 'Il mio perché', t: 0 }); }catch(_){ }
  return out;
}

/* ---------------------------------------------------------------------------------------
   GLI SCARABOCCHI: disegni a penna, color seppia, come sul taccuino di Drake. SVG in riga,
   leggeri: tratti un po' storti apposta, niente immagini da scaricare.
   --------------------------------------------------------------------------------------- */
const DV_INK = '#5a4634', DV_ROSSO = '#b23a3a', DV_VERDE = '#2f7d4f';
function dvSvg(vb, corpo, cls, w){
  return '<svg class="dv-doodle ' + (cls || '') + '" viewBox="' + vb + '"' + (w ? ' width="' + w + '"' : '') + ' fill="none" stroke="' + DV_INK + '" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + corpo + '</svg>';
}
/** La faccina dell'umore, da 1 (malissimo) a 5 (benissimo). */
function dvFaccia(v){
  const testa = '<path d="M24 5C35 4.5 43.5 13 43 24.5C42.6 35.5 34 43.4 23.4 43C12.6 42.6 4.8 34.2 5.2 23.6C5.6 13.2 13.6 5.6 24.6 5.2"/><path d="M9 15C12 9.5 17 6.8 23 6.4" stroke-width="1" opacity=".55"/>';
  const occhiPunti = '<circle cx="17.5" cy="20" r="1.7" fill="' + DV_INK + '"/><circle cx="30.5" cy="20" r="1.7" fill="' + DV_INK + '"/>';
  let viso = '';
  /* 0.9.219: la faccina della giornata splendida ridisegnata (la bocca aperta con le lineette
     sulle guance era brutta): gli stessi occhi a punto delle altre, un sorriso largo a una sola
     linea un po' storta e le guance rosse, come fatte con un colpo di matita */
  if (v >= 5) viso = '<circle cx="17.5" cy="19.6" r="1.9" fill="' + DV_INK + '"/><circle cx="30.5" cy="19.6" r="1.9" fill="' + DV_INK + '"/>'
    + '<path d="M14.8 26.2C16.8 35.4 31.4 35.6 33.4 26"/>'
    + '<ellipse cx="10.2" cy="24.6" rx="2.7" ry="1.8" fill="rgba(178,58,58,.24)" stroke="none"/><ellipse cx="37.8" cy="24.6" rx="2.7" ry="1.8" fill="rgba(178,58,58,.24)" stroke="none"/>';
  else if (v === 4) viso = occhiPunti + '<path d="M15.5 28.5Q24 36 32.5 28.5"/>';
  else if (v === 3) viso = occhiPunti + '<path d="M16.5 31.2L31.5 30.4"/>';
  else if (v === 2) viso = occhiPunti + '<path d="M16 33Q24 27.5 32 33"/>';
  else viso = '<path d="M14.5 17.5l5 2.5M33.5 17.5l-5 2.5"/>' + occhiPunti + '<path d="M15.5 34.5Q24 25.5 32.5 34.5"/><path d="M38 13c1.5 2.4 2.2 3.8 1 5-1.2 1-2.7.2-2.6-1.4.1-1.1.9-2.2 1.6-3.6Z" stroke-width="1.2"/>';
  return dvSvg('0 0 48 48', testa + viso, 'dv-faccia', 46);
}
/** Il tempo che faceva dentro: sole, sole e nuvola, nuvola, pioggia, temporale. */
function dvMeteo(v){
  const nuvola = function(dx, dy){ return '<path transform="translate(' + dx + ' ' + dy + ')" d="M16 34C9 34 8 25.5 15 24.5C15 16.5 26 14.5 29 20.5C32 13.5 45 15.5 44 24.5C51 24.5 51 34 44 34Z" fill="#efe3c6"/>'; };
  const sole = function(cx, cy, r){
    let raggi = '';
    for (let i = 0; i < 8; i++){ const a = i * Math.PI / 4 + .2; raggi += 'M' + (cx + Math.cos(a) * (r + 3)).toFixed(1) + ' ' + (cy + Math.sin(a) * (r + 3)).toFixed(1) + 'L' + (cx + Math.cos(a) * (r + 8)).toFixed(1) + ' ' + (cy + Math.sin(a) * (r + 8)).toFixed(1); }
    return '<path d="M' + (cx + r) + ' ' + cy + 'A' + r + ' ' + r + ' 0 1 1 ' + (cx + r - .5) + ' ' + (cy - 2) + '"/><path d="' + raggi + '"/>';
  };
  let c = '';
  if (v >= 5) c = sole(30, 22, 9);
  else if (v === 4) c = sole(22, 16, 7) + nuvola(4, 2);
  else if (v === 3) c = nuvola(0, -4);
  else if (v === 2) c = nuvola(0, -8) + '<path d="M18 30l-2 6M27 31l-2 6M36 30l-2 6" stroke-width="1.4"/>';
  else c = nuvola(0, -9) + '<path d="M29 26l-4 7h5l-4 8" stroke="' + DV_ROSSO + '"/><path d="M17 29l-2 6M40 29l-2 6" stroke-width="1.4"/>';
  return dvSvg('0 0 60 44', c, 'dv-meteo', 58);
}
/** Le icone a penna dei fatti. */
const DV_ICO = {
  schermo: '<path d="M12 3.2C17 3 21 7 20.8 12.2C20.6 17 16.8 20.8 12 20.8C7 20.8 3.2 17 3.2 12C3.2 7.2 7 3.4 12.4 3.2"/><path d="M12 7v5l3.2 2.2"/><path d="M12 4.6v1M19.4 12h-1M12 19.4v-1M4.6 12h1" stroke-width="1.2"/>',
  ff: '<path d="M12 21.5C12 16 12 12.5 12 9"/><path d="M12 13.5C7 13.5 4.8 9.6 5 6.2C9 6.2 12 9 12 13.5Z"/><path d="M12 10.5C13.4 6.4 16.6 4.2 20 4.4C20 8.4 17 11 12 11"/><path d="M4.5 21.5C9 20.6 15 20.6 19.5 21.5"/>',
  lista: '<path d="M12 3C17.2 2.8 21.2 6.8 21 12C20.8 17 17 21 12 21C7 21 3 17.2 3 12C3 7.4 6.4 3.6 11 3.2"/><path d="M7.5 12.5L10.8 16L17 8.2" stroke="' + DV_VERDE + '" stroke-width="2.2"/>',
  mappa: '<path d="M1.8 21.5L8.8 9.2L12.6 15.2L15.6 11.2L22.2 21.5"/><path d="M8.8 9.2V2.6L14 4.2L8.8 6"/><path d="M6.4 13.4l1.6 1M11 17.6l1.4.8" stroke-width="1"/>',
  serie: '<path d="M12 22C7 22 4.8 18 6 14C7 11 9 10 9 6.5C12 8.5 13 11 13 13C14 11.2 15 10 15 8.6C18.2 11.8 19.2 15.6 18.2 18C17.2 20.6 15 22 12 22Z"/><path d="M12 22C10.4 22 9.6 20.4 10.2 19C10.8 17.6 12 17 12 15.4C13.6 17 14.2 18.6 13.8 20C13.5 21.2 12.8 22 12 22Z" stroke-width="1.2"/>',
  severa: '<path d="M6.5 11V8C6.5 4.6 9 2.8 12 2.8C15 2.8 17.5 4.6 17.5 8V11"/><path d="M4.6 11.2C9.6 10.8 14.4 10.8 19.4 11.2L19 21C14.4 21.4 9.6 21.4 5 21Z"/><path d="M12 15v2.6"/>',
  /* la roadmap: il sentiero a puntini che arriva alla bandierina */
  rotta: '<path d="M3 21.2C6.4 20.4 7.2 17.2 10 16.4C12.8 15.6 14.6 13.8 15.6 11" stroke-dasharray="2.2 2.8"/><path d="M16 12.4V2.8L21.6 4.8L16 7"/><circle cx="3.4" cy="21" r="1.2" fill="' + DV_INK + '"/>'
};
function dvIco(k){ return dvSvg('0 0 24 24', DV_ICO[k] || DV_ICO.lista, 'dv-ico', 22); }
/** La freccia a mano accanto al tempo sul telefono: giu' e verde se e' sceso, su e rossa se e' salito. */
function dvFrecciaSu(dir){
  if (dir === 'giu') return '<svg class="dv-doodle dv-frec" viewBox="0 0 26 22" width="26" fill="none" stroke="' + DV_VERDE + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 4C8 8.6 13.4 13.4 21 17.6"/><path d="M13.4 18.6L21.4 17.8L19.6 10.4"/></svg>';
  if (dir === 'su') return '<svg class="dv-doodle dv-frec" viewBox="0 0 26 22" width="26" fill="none" stroke="' + DV_ROSSO + '" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 18C8 13.4 13.4 8.6 21 4.4"/><path d="M13.4 3.4L21.4 4.2L19.6 11.6"/></svg>';
  return '';
}
/** Il numero cerchiato a penna, come si cerchia un dato importante. */
function dvCerchiato(testo, colore){
  return '<span class="dv-cerchio"><svg viewBox="0 0 64 40" fill="none" stroke="' + (colore || DV_ROSSO) + '" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><path d="M10 22C7 10 22 4.5 34 5C48 5.6 59 12 57 22C55 32 41 36.4 29 35.6C16 34.8 6.8 28 9.6 16.4"/></svg><b>' + dvEsc(testo) + '</b></span>';
}
/** La riga ondulata sotto al titolo. */
function dvSottolinea(){ return '<svg class="dv-onda" viewBox="0 0 160 8" preserveAspectRatio="none" fill="none" stroke="' + DV_ROSSO + '" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M2 5C22 1.5 42 7.5 64 4.5C86 1.5 108 7 130 4C142 2.6 151 3.6 158 5"/></svg>'; }
/** Gli schizzi d'angolo: una bussola, l'aereo sulla rotta tratteggiata, le montagne, la mappa con la X. */
const DV_SCHIZZI = [
  /* bussola */
  '<path d="M60 8C82 7 98 23 97 44C96 64 80 78 59 77C39 76 23 61 24 41C25 22 40 9 58 8.4"/><path d="M60 16C76 16 88 28 88 43C88 58 75 69 60 69C45 69 33 57 33 42C33 28 44 17 58 16.2" stroke-width="1" opacity=".7"/><path d="M60 22L66 42L60 62L54 42Z"/><path d="M60 22L66 42L54 42Z" fill="' + DV_ROSSO + '" stroke="' + DV_ROSSO + '" opacity=".75"/><circle cx="60" cy="42" r="2"/><path d="M60 2v4M60 79v4M18 42h4M98 42h4" stroke-width="1.2"/><path d="M57.4 15V9.4L62.6 15V9.4" stroke-width="1.1"/>',
  /* aereo sulla rotta */
  '<path d="M6 74C24 70 30 54 42 46C54 38 66 44 80 34" stroke-dasharray="4 5"/><path d="M4 66l7 7M11 66l-7 7" stroke="' + DV_ROSSO + '" stroke-width="2.2"/><path d="M84 31L100 18C103 15.8 106.6 18.6 104.4 21.4L92 37"/><path d="M94 24L80 21L77 24L90 28.6"/><path d="M98 30L101 44L98 47L93 34"/><path d="M84 31L78 30.6L77.4 32.6L83.6 34.8"/>',
  /* montagne */
  '<path d="M4 76L34 30L50 52L64 34L96 76"/><path d="M26 42L34 30L42 42L37 39L33 44L29 40Z" stroke-width="1.2"/><path d="M58 42L64 34L70 42" stroke-width="1.2"/><path d="M80 14C84 13.8 87 16.6 87 20.4C87 24 84 27 80.4 27C76.6 27 74 24 74 20.4C74 17 76.4 14.4 79.6 14.2"/><path d="M14 76C30 70 46 72 60 76" stroke-width="1" opacity=".6"/><path d="M34 30V20L42 23L34 26" stroke="' + DV_ROSSO + '"/>',
  /* la mappa con la X */
  '<path d="M8 20L34 12L62 20L92 12L94 70L64 78L36 70L10 78Z"/><path d="M34 12L36 70M62 20L64 78" stroke-width="1" opacity=".7"/><path d="M16 64C26 56 30 44 44 46C58 48 60 32 74 30" stroke-dasharray="3.5 4.5"/><path d="M72 22l8 8M80 22l-8 8" stroke="' + DV_ROSSO + '" stroke-width="2.4"/>'
];
function dvSchizzo(i){ return '<svg class="dv-schizzo" viewBox="0 0 110 86" fill="none" stroke="' + DV_INK + '" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + DV_SCHIZZI[((i % DV_SCHIZZI.length) + DV_SCHIZZI.length) % DV_SCHIZZI.length] + '</svg>'; }
/* gli schizzi grandi delle pagine dei traguardi delle sessioni */
const DV_DISEGNI = {
  germoglio: '<path d="M32 58C32 46 32 36 32 26"/><path d="M32 38C20 38 14 28 15 19C25 19 32 26 32 38Z" fill="rgba(47,125,79,.12)"/><path d="M32 30C35 20 43 14 51 14.6C51 24 44 31 32 31" fill="rgba(47,125,79,.12)"/><path d="M12 58C24 55.6 40 55.6 52 58"/><path d="M16 61.5C26 60 38 60 48 61.5" stroke-width="1" opacity=".6"/>',
  albero: '<path d="M32 60V36M32 44L24 36M32 40L40 33"/><path d="M32 8C42 8 48 15 47 22C53 24 54 34 47 37C44 42 36 42 32 39C28 42 19 42 16 37C9 34 10 24 17 22C16 15 22 8 32 8Z" fill="rgba(47,125,79,.12)"/><path d="M14 60C26 58 38 58 50 60"/>',
  coppa: '<path d="M20 8H44C44 26 40 34 32 36C24 34 20 26 20 8Z" fill="rgba(214,170,60,.18)"/><path d="M20 12C12 12 11 22 20 24M44 12C52 12 53 22 44 24"/><path d="M32 36V46M24 52H40L38 46H26Z"/><path d="M30 16.5l1.8 3.6 4 .6-2.9 2.8.7 4-3.6-1.9-3.6 1.9.7-4-2.9-2.8 4-.6Z" stroke-width="1.2"/>',
  scrigno: '<path d="M10 30H54V56H10Z" fill="rgba(214,170,60,.14)"/><path d="M10 30C10 18 18 12 32 12C46 12 54 18 54 30"/><path d="M10 38H54M28 34H36V44H28Z"/><path d="M32 39v2.4"/><path d="M14 8l3 3M50 8l-3 3M32 3v4" stroke="' + DV_ROSSO + '" stroke-width="1.4"/>'
};
function dvDisegno(k){ return '<svg class="dv-disegno" viewBox="0 0 64 64" fill="none" stroke="' + DV_INK + '" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (DV_DISEGNI[k] || DV_DISEGNI.germoglio) + '</svg>'; }

/* ---------------------------------------------------------------------------------------
   IL DISEGNO DI UNA PAGINA
   --------------------------------------------------------------------------------------- */
/**
 * La pagina del giorno, alla Drake: il numero del giorno di viaggio scritto a mano e
 * sottolineato, il tempo che faceva dentro (sole, nuvola, temporale), la faccina con l'umore
 * cerchiato, le parole di chi scrive su un foglietto strappato e attaccato con lo scotch, e in
 * fondo i fatti, ciascuno col suo scarabocchio.
 */
function dvGiornoHtml(p){
  const iso = p.iso || dvIso(p.t);
  const strutturata = Array.isArray(p.fatti);
  const auto = p.giornoN ? 'Giorno ' + p.giornoN + ' del viaggio' : 'Appunti del giorno';
  const titolo = p.titolo || auto;
  const kicker = (p.titolo && p.giornoN && p.titolo !== auto) ? '<small class="dv-kick">giorno ' + p.giornoN + ' del viaggio</small>' : '';
  /* il diario di un amico puo' arrivare dal server con il solo testo (pagine di prima della
     0.9.217): il voto si ripesca dalla vecchia riga "Umore: …, 4 su 5", il resto si legge com'e' */
  const vecchioVoto = strutturata ? 0 : (+((/Umore: [^\n,]*, ([1-5]) su 5/.exec(String(p.testo || '')) || [])[1]) || 0);
  const voto = p.voto || vecchioVoto;
  const h = (voto ? dvMeteo(voto) : '') + kicker + '<h2 class="dv-h-mano">' + dvEsc(titolo) + '</h2>' + dvSottolinea();
  /* 0.9.219: niente piu' «5/5» cerchiato accanto all'umore: sembrava il voto del professore */
  const umoreHtml = function(frase){
    return '<div class="dv-blk dv-umore" data-ruolo="umore">' + dvFaccia(voto) + '<div><b class="dv-mano' + (String(frase || '').length > 26 ? ' lunga' : '') + '">' + dvEsc(frase || '') + '</b><small>umore della giornata</small></div></div>';
  };
  /* il testo intero va sempre nella pagina: quanto ne entra lo decide dvAdatta, misurando */
  const cuoreHtml = function(t, virgolette){
    return '<div class="dv-blk dv-strappo-w" data-ruolo="cuore"><i class="dv-tape"></i><div class="dv-strappo">' + (p.foto ? dvPolaroid(p, 'dx mini') : '')
      + (t ? '<p class="dv-mano dv-cuore' + (virgolette ? ' q' : '') + '">' + dvEsc(t) + '</p>' : '') + '</div></div>';
  };
  /* i bottoni: «Mostra tutto» compare solo se dvAdatta ha dovuto accorciare le parole */
  const bottoni = function(scrivi){
    const mostra = '<button type="button" class="dv-scrivi pieno dv-mostra" hidden onclick="event.stopPropagation();dvNotaLeggi(\'' + iso + '\')">Mostra tutto</button>';
    const mod = (!DV.di && scrivi) ? '<button type="button" class="dv-scrivi" onclick="event.stopPropagation();dvNotaApri(\'' + iso + '\')">' + dvPenna() + ' ' + scrivi + '</button>' : '';
    return '<div class="dv-blk dv-bott" data-ruolo="bott">' + mostra + mod + '</div>';
  };
  if (!strutturata){
    const t = dvSenzaRigheVecchie(p.testo);
    return h + '<div class="dv-g">' + (voto ? umoreHtml(DV_UMORE_FRASI[voto - 1]) : '') + (t || p.foto ? cuoreHtml(t, false) : '') + bottoni('') + '</div>'
      + dvSchizzo(p.giornoN || iso.charCodeAt(9));
  }
  const parole = p.parole || '';
  const detto = (p.detto && p.detto !== parole) ? p.detto : '';
  const cuore = parole || detto;
  let g = '';
  const oggi = iso === dvIso(Date.now());
  /* oggi, finche' la pagina e' bianca: il foglietto vuoto che invita a scrivere, e il pulsante */
  if (p.tipo === 'oggi'){
    const apri = DV.di ? '' : ' onclick="event.stopPropagation();dvNotaApri(\'' + iso + '\')"';
    g += '<div class="dv-blk dv-strappo-w dv-aperta" data-ruolo="invito"' + apri + '><i class="dv-tape"></i><div class="dv-strappo">'
      + '<p class="dv-mano dv-aperta-t">Oggi la pagina è ancora bianca.</p><p class="dv-aperta-s">La scrivi tu: cosa è successo, come ti senti, cosa hai imparato.</p></div></div>';
    if (!DV.di) g += '<div class="dv-blk dv-bott" data-ruolo="bott"><button type="button" class="dv-scrivi dv-oggi-btn" onclick="event.stopPropagation();dvNotaApri(\'' + iso + '\')">' + dvPenna('#ffffff') + ' Scrivi la pagina di oggi</button></div>';
    if ((p.fatti || []).length){
      g += '<div class="dv-blk" data-ruolo="fatti"><small class="dv-finqui">Quello che hai fatto oggi, fin qui</small><ul class="dv-fatti">' + p.fatti.map(function(f){
        return '<li class="k-' + f.k + '" data-k="' + dvEsc(f.k) + '">' + dvIco(f.k) + '<span>' + dvEsc(f.t) + (f.k === 'mappa' ? ' <em class="dv-ok">✓</em>' : '') + '</span>' + dvFrecciaSu(f.dir) + '</li>';
      }).join('') + '</ul></div>';
    }
    return h + '<div class="dv-g">' + g + '</div>';
  }
  if (p.voto) g += umoreHtml(p.umore);
  /* le frasi dell'umore, una per volta: dvAdatta le toglie dall'ultima se manca il posto */
  const righe = (p.righe || []).slice(0, cuore ? 2 : 3);
  if (righe.length) g += '<p class="dv-blk dv-mano dv-righe-um" data-ruolo="righe">' + righe.map(function(r){ return '<span>' + dvEsc(r) + '</span>'; }).join(' ') + '</p>';
  if (parole && detto) g += '<p class="dv-blk dv-mano dv-detto" data-ruolo="detto">"' + dvEsc(dvCorto(detto, 90)) + '"</p>';
  /* il cuore della pagina: le sue parole, sul foglietto strappato; la foto ci sta attaccata sopra */
  if (cuore || p.foto) g += cuoreHtml(cuore, !parole);
  /* i fatti, i piu' importanti prima: quelli che non ci stanno li toglie dvAdatta */
  if ((p.fatti || []).length){
    g += '<ul class="dv-blk dv-fatti" data-ruolo="fatti">' + p.fatti.map(function(f){
      return '<li class="k-' + f.k + '" data-k="' + dvEsc(f.k) + '">' + dvIco(f.k) + '<span>' + dvEsc(f.t) + (f.k === 'mappa' ? ' <em class="dv-ok">✓</em>' : '') + '</span>' + dvFrecciaSu(f.dir) + '</li>';
    }).join('') + '</ul>';
  }
  /* oggi, se ci sono solo l'umore e i fatti, il pulsante dice che la pagina si puo' ancora scrivere */
  g += bottoni(p.tipo === 'giorno' ? 'Aggiungi i tuoi appunti' : (oggi && !parole ? 'Scrivi la pagina di oggi' : 'Modifica'));
  /* lo schizzo d'angolo: resta solo se in fondo c'e' posto (lo decide dvAdatta) */
  return h + '<div class="dv-g">' + g + '</div>' + dvSchizzo(p.giornoN || iso.charCodeAt(9));
}
/* ---------------------------------------------------------------------------------------
   LA PAGINA CHE NON TRABOCCA (0.9.219). Il foglio ha l'altezza che ha: niente deve uscire dal
   fondo. Si disegna tutto, si misura com'e' venuto davvero (dopo l'impaginazione, con i font
   veri e la larghezza del telefono) e si toglie quello che non ci sta, in quest'ordine:
   · testo corto: via i fatti dall'ultimo (i meno importanti), poi la frase detta in chat, poi le
     frasi dell'umore dall'ultima;
   · testo lungo (le parole occupano gia' gran parte della pagina): la pagina e' solo sua. Restano
     l'umore e al massimo due fatti (la mappa, la serie, il tempo sul telefono), e le parole si
     accorciano alla fine di una frase o di una parola, mai a meta', con "Mostra tutto" che apre
     il testo intero nel foglio a tutto schermo, dove si legge e si modifica.
   Si rifa' a ogni disegno della pagina, quando cambia la misura dello schermo e quando arrivano
   i font: sono le misure vere a decidere, non un numero di caratteri.
   --------------------------------------------------------------------------------------- */
const DV_FATTI_PREF = ['mappa', 'serie', 'schermo'];
function dvAdatta(pg){
  const g = pg && pg.querySelector('.dv-g');
  if (!g || !pg.clientHeight) return;
  const limite = pg.clientHeight - 28;   /* sotto: il margine della carta e il numero di pagina */
  const fondo = function(){ const l = g.lastElementChild; return l ? l.offsetTop + l.offsetHeight : 0; };
  const ci = function(){ return fondo() <= limite; };
  const via = function(el){ if (el && el.parentNode) el.parentNode.removeChild(el); };
  const blk = function(r){ return g.querySelector('[data-ruolo="' + r + '"]'); };
  const fattiLi = function(){ return Array.prototype.slice.call(g.querySelectorAll('.dv-fatti li')); };
  const togliFatto = function(){ const l = fattiLi(); if (!l.length) return false; via(l[l.length - 1]); if (l.length === 1) via(blk('fatti')); return true; };
  const testo = g.querySelector('.dv-cuore');
  const pieno = testo ? testo.textContent : '';
  const fine = function(){ const sk = pg.querySelector('.dv-schizzo'); if (sk && limite - fondo() < 120) via(sk); };
  if (ci()) return fine();
  /* le parole sono lunghe se da sole prendono piu' di due quinti dello spazio sotto al titolo */
  const primo = g.firstElementChild;
  const spazio = limite - (primo ? primo.offsetTop : 0);
  const cw = blk('cuore');
  const lungo = !!(testo && cw && pieno.length > 120 && cw.offsetHeight > spazio * 0.4);
  if (!lungo){
    while (!ci() && togliFatto()){ }
    if (!ci()) via(blk('detto'));
    const r = blk('righe');
    while (!ci() && r && r.children.length > 1) via(r.lastElementChild);
    if (!ci()) via(r);
    if (ci() || !testo) return fine();
  }
  /* la pagina e' delle sue parole */
  via(blk('detto'));
  via(blk('righe'));
  const ul = blk('fatti');
  if (ul){
    fattiLi().filter(function(li){ return DV_FATTI_PREF.indexOf(li.getAttribute('data-k')) < 0; }).forEach(via);
    fattiLi().sort(function(a, b){ return DV_FATTI_PREF.indexOf(a.getAttribute('data-k')) - DV_FATTI_PREF.indexOf(b.getAttribute('data-k')); })
      .forEach(function(li, i){ if (i < 2) ul.appendChild(li); else via(li); });
    if (!fattiLi().length) via(ul);
  }
  const mostra = g.querySelector('.dv-mostra');
  if (mostra) mostra.hidden = false;
  for (;;){
    const visti = dvTagliaFino(testo, pieno, ci);
    if (visti >= pieno.length){
      /* entra tutto: «Mostra tutto» non serve (e senza di lui c'e' ancora piu' posto) */
      if (mostra) mostra.hidden = true;
      break;
    }
    /* un fatto lascia il posto alle parole se le parole restano troppo poche */
    if (!fattiLi().length || visti >= Math.min(260, pieno.length * 0.6)) break;
    togliFatto();
  }
  return fine();
}
/**
 * Mette in el le parole che ci stanno: la fine di una frase se ce n'e' una abbastanza avanti,
 * se no la fine di una parola con «…». Torna quanti caratteri del testo si vedono.
 */
function dvTagliaFino(el, pieno, ci){
  if (!el) return 0;
  el.textContent = pieno;
  if (ci()) return pieno.length;
  const tagli = []; const re = /\s+/g; let m;
  while ((m = re.exec(pieno))) if (m.index > 0) tagli.push(m.index);
  const pulito = function(i){ return pieno.slice(0, i).replace(/[\s,;:\-–]+$/, ''); };
  const prova = function(i){ el.textContent = pulito(i) + '…'; return ci(); };
  let lo = -1, hi = tagli.length - 1;
  while (lo < hi){ const mid = (lo + hi + 1) >> 1; if (prova(tagli[mid])) lo = mid; else hi = mid - 1; }
  if (lo < 0){ el.textContent = ''; return 0; }
  const fin = tagli[lo];
  /* la fine di una frase, se non butta via troppo */
  const parte = pieno.slice(0, fin); const fr = /[.!?…]+[""”)]?(?=\s|$)|\n/g; let e = -1;
  while ((m = fr.exec(parte))) e = m.index + m[0].length;
  if (e > 0 && e >= fin * 0.6){ el.textContent = pieno.slice(0, e).trim(); return e; }
  el.textContent = pulito(fin) + '…';
  return fin;
}
/** Disegna la pagina idx dentro el e la fa stare nel foglio. */
function dvMetti(el, idx){
  if (!el) return;
  el.innerHTML = dvPaginaHtml(DV.pagine[idx], idx, DV.pagine.length);
  try{ const pg = el.querySelector('.dv-pg'); if (pg && pg.querySelector('.dv-g')) dvAdatta(pg); }catch(_){ }
}
function dvPolaroid(p, cls){
  if (!p.foto) return '';
  return '<figure class="dv-pol ' + (cls || '') + '"><i class="dv-tape"></i><img src="' + dvEsc(dvSrc(p.foto)) + '" alt="">'
    + '<figcaption>' + dvEsc(p.didascalia || '') + '</figcaption></figure>';
}
/** La firma della lettera dell'Io Futuro: il nome e il giorno in cui e' stata scritta. */
function dvFirmaLettera(p){
  const nome = DV.di ? String(DV.di.nome || '').trim().split(/\s+/)[0] : dvPrimoNome();
  const data = p.t ? dvDataFirma(p.t) : '';
  return [nome, data].filter(Boolean).join(', ');
}
function dvPaginaHtml(p, num, tot){
  if (!p) return '<div class="dv-pg dv-vuota"></div>';
  const data = '<small class="dv-data">' + dvEsc(dvDataLunga(p.t)) + '</small>';
  let corpo = '';
  if (p.tipo === 'copertina'){
    return '<div class="dv-pg dv-cover"><div class="dv-cover-in"><small>DREAMMAP</small><b>Diario<br>di viaggio</b>'
      + (p.testo ? '<span class="dv-cover-nome">' + dvEsc(p.testo) + '</span>' : '')
      + '<em>dal ' + dvEsc(p.nota || '') + '</em><i class="dv-cover-band"></i></div></div>';
  }
  if (p.tipo === 'prossima'){
    /* la pagina di domani: solo la frase, e nessun modo di scriverci. Le pagine scritte si contano
       senza la copertina, senza questa e senza la pagina di oggi ancora bianca */
    const scritte = DV.pagine && DV.pagine.length === tot ? dvScritte(DV.pagine) : tot - 2;
    return '<div class="dv-pg dv-righe"><div class="dv-pross"><span>' + dvSvg('0 0 24 24', '<path d="M4 20l4.2-1L19.4 7.8a2 2 0 0 0 0-2.8l-.4-.4a2 2 0 0 0-2.8 0L5 15.8 4 20z"/><path d="M14.6 6.2l3.2 3.2"/>', 'dv-pross-ico', 40) + '</span><p>' + dvEsc(p.testo) + '</p>'
      + '<small>' + scritte + (scritte === 1 ? ' pagina scritta' : ' pagine scritte') + ' fino a qui</small></div></div>';
  }
  if (p.tipo === 'inizio'){
    corpo = '<h2>' + dvEsc(p.titolo) + '</h2>' + dvPolaroid(p, 'dx')
      + '<p class="dv-mano">' + dvEsc(p.testo).replace(/\n/g, '<br>') + '</p>'
      + (p.nota ? '<p class="dv-nota">' + dvEsc(p.nota) + '</p>' : '')
      + '<svg class="dv-freccia" viewBox="0 0 120 40"><path d="M4 30 C 40 5, 70 5, 112 22" fill="none" stroke="#5a4634" stroke-width="2" stroke-linecap="round"/><path d="M100 14 L112 22 L99 28" fill="none" stroke="#5a4634" stroke-width="2" stroke-linecap="round"/></svg>';
  } else if (p.tipo === 'mantra'){
    corpo = '<div class="dv-cit"><p class="dv-mano dv-grande">“' + dvEsc(p.testo) + '”</p><i class="dv-sotto"></i><small>' + dvEsc(p.nota) + '</small></div>';
  } else if (p.tipo === 'traguardo'){
    corpo = '<div class="dv-num">' + p.n + '<small>giorn' + (p.n === 1 ? 'o' : 'i') + '</small></div>'
      + '<h2>' + dvEsc(p.titolo) + '</h2><p class="dv-mano">' + dvEsc(p.testo) + '</p>'
      + '<span class="dv-timbro">' + dvEsc(dvTimbro('severa')) + '</span>';
  } else if (p.tipo === 'sessione' || p.tipo === 'record'){
    corpo = dvDisegno(p.tipo === 'record' ? 'coppa' : (p.ico === '🌳' ? 'albero' : 'germoglio')) + '<h2>' + dvEsc(p.titolo) + '</h2><p class="dv-mano">' + dvEsc(p.testo) + '</p>'
      + (p.min ? '<span class="dv-tag">' + p.min + ' min</span>' : '');
  } else if (p.tipo === 'passi'){
    corpo = '<h2>' + dvEsc(p.titolo) + '</h2><ul class="dv-lista">' + (p.passi || []).map(function(x){ return '<li><i>✓</i>' + dvEsc(x.t) + '<small>' + dvEsc(x.dove) + '</small></li>'; }).join('') + '</ul>'
      + ((p.passi || []).length <= 4 ? dvSchizzo(0) : '');
  } else if (p.tipo === 'giorno' || p.tipo === 'nota' || p.tipo === 'oggi'){
    corpo = dvGiornoHtml(p);
  } else if (p.tipo === 'foto'){
    corpo = dvPolaroid(p, 'grande') + '<p class="dv-mano">' + dvEsc(p.testo) + '</p><span class="dv-timbro verde">' + dvEsc(dvTimbro('fatto')) + '</span>';
  } else if (p.tipo === 'lettera'){
    corpo = '<div class="dv-lettera"><small>' + dvEsc(p.titolo) + '</small><p class="dv-mano">' + dvEsc(p.testo).replace(/\n/g, '<br>') + '</p><em>' + dvEsc(dvFirmaLettera(p)) + '</em></div>'
      + (String(p.testo).length < 260 ? dvSchizzo(1) : '');
  } else if (p.tipo === 'scrigno'){
    corpo = dvDisegno('scrigno') + '<h2>' + dvEsc(p.titolo) + '</h2><p class="dv-mano">' + dvEsc(p.testo) + '</p>';
  } else {
    corpo = '<h2>' + dvEsc(p.titolo) + '</h2><p class="dv-mano">' + dvEsc(p.testo) + '</p>';
  }
  return '<div class="dv-pg dv-carta ' + dvEsc(p.tipo) + '">' + data + corpo + '<small class="dv-npag">' + num + '</small></div>';
}

/* ---------------------------------------------------------------------------------------
   IL LIBRO: aprire, sfogliare, chiudere
   --------------------------------------------------------------------------------------- */
function dvApri(pagine, di){
  DV.pagine = pagine || dvPagineLibro();
  DV.di = di || null;
  /* si apre sull'ultima pagina scritta (quella prima di «La prossima pagina la scrivi domani»);
     se oggi la pagina e' ancora bianca, sull'ultima scritta prima: oggi e' il foglio subito dopo */
  DV.i = di ? 0 : Math.max(0, DV.pagine.length - 2);
  if (!di && DV.pagine[DV.i] && DV.pagine[DV.i].tipo === 'oggi' && DV.i > 1) DV.i--;
  let box = document.getElementById('dvBook');
  if (!box){
    box = document.createElement('div'); box.id = 'dvBook'; box.className = 'dv-wrap';
    (document.getElementById('phone') || document.body).appendChild(box);
  }
  const mio = !DV.di;
  box.innerHTML = '<div class="dv-top"><button type="button" class="dv-x" onclick="dvChiudi()" aria-label="Chiudi">✕</button>'
    + '<b>' + (mio ? 'Il mio diario di viaggio' : 'Il diario di ' + dvEsc(DV.di.nome || 'un amico')) + '</b>'
    + (mio ? '<button type="button" class="dv-x" onclick="dvMenu()" aria-label="Altro">⋯</button>' : '<span class="dv-x"></span>') + '</div>'
    + '<div class="dv-stage" id="dvStage"><div class="dv-book"><div class="dv-under" id="dvUnder"></div>'
    +   '<div class="dv-leaf" id="dvLeaf"><div class="dv-face dv-front" id="dvFront"></div><div class="dv-face dv-back"><div class="dv-pg dv-retro"></div></div></div></div></div>'
    + '<div class="dv-nav"><button type="button" onclick="dvVai(-1)" aria-label="Indietro">‹</button><span id="dvConta"></span><button type="button" onclick="dvVai(1)" aria-label="Avanti">›</button></div>';
  requestAnimationFrame(function(){ box.classList.add('in'); });
  dvDisegna();
  /* il tempo sul telefono arriva dal motore dopo: quando c'e', le pagine si riscrivono con il dato */
  if (!DV.di) dvSchermoCarica().then(function(nuovo){ if (nuovo) dvRiscrivi(); });
  const st = document.getElementById('dvStage');
  let x0 = 0, y0 = 0;
  st.addEventListener('touchstart', function(e){ const t = e.touches[0]; x0 = t.clientX; y0 = t.clientY; }, { passive: true });
  st.addEventListener('touchend', function(e){
    const t = e.changedTouches[0]; const dx = t.clientX - x0, dy = t.clientY - y0;
    if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy)) dvVai(dx < 0 ? 1 : -1);
    else if (Math.abs(dx) < 10 && Math.abs(dy) < 10) dvTocco(t.clientX, st);
  }, { passive: true });
  st.addEventListener('click', function(e){ if (!('ontouchstart' in window)) dvTocco(e.clientX, st); });
  document.addEventListener('keydown', dvTasti);
  /* le pagine si rimisurano quando cambia lo schermo e quando arrivano i font scritti a mano */
  window.addEventListener('resize', dvRimisura);
  try{ if (document.fonts && document.fonts.ready) document.fonts.ready.then(dvRimisura); }catch(_){ }
  try{ window.addEventListener('popstate', dvChiudi, { once: true }); history.pushState({ dv: 1 }, ''); }catch(_){ }
}
/** Ridisegna le pagine aperte (e le rifa' stare nel foglio), al massimo una volta ogni 150 ms. */
function dvRimisura(){
  clearTimeout(DV.rimT);
  DV.rimT = setTimeout(function(){
    if (!document.getElementById('dvBook')) return;
    if (DV.giro){ dvRimisura(); return; }
    dvDisegna();
  }, 150);
}
function dvRiscrivi(){
  if (DV.di || !document.getElementById('dvBook')) return;
  if (DV.giro){ setTimeout(dvRiscrivi, 800); return; }
  const cur = DV.pagine[DV.i] && DV.pagine[DV.i].id;
  DV.pagine = dvPagineLibro();
  const i = DV.pagine.findIndex(function(p){ return p.id === cur; });
  DV.i = i >= 0 ? i : Math.min(DV.i, DV.pagine.length - 1);
  dvDisegna();
}
function dvTocco(x, st){ const r = st.getBoundingClientRect(); const f = (x - r.left) / r.width; if (f > 0.55) dvVai(1); else if (f < 0.3) dvVai(-1); }
function dvTasti(e){ if (e.key === 'ArrowRight') dvVai(1); else if (e.key === 'ArrowLeft') dvVai(-1); else if (e.key === 'Escape') dvChiudi(); }
function dvChiudi(){
  const b = document.getElementById('dvBook'); if (!b) return;
  document.removeEventListener('keydown', dvTasti);
  window.removeEventListener('resize', dvRimisura);
  b.classList.remove('in');
  setTimeout(function(){ b.remove(); }, 260);
}
function dvDisegna(){
  const n = DV.pagine.length;
  const front = document.getElementById('dvFront'), under = document.getElementById('dvUnder'), leaf = document.getElementById('dvLeaf');
  if (!front || !under || !leaf) return;
  leaf.style.transition = 'none'; leaf.style.transform = 'none';
  dvMetti(front, DV.i);
  dvMetti(under, DV.i + 1);
  const c = document.getElementById('dvConta'); if (c) c.textContent = (DV.i + 1) + ' / ' + n;
  const w = document.getElementById('dvBook'); if (w) w.classList.toggle('dv-inizio', DV.i === 0);
}
function dvVai(d){
  if (DV.giro) return;
  const n = DV.pagine.length, j = DV.i + d;
  if (j < 0 || j >= n) return;
  const leaf = document.getElementById('dvLeaf'), front = document.getElementById('dvFront'), under = document.getElementById('dvUnder');
  if (!leaf) return;
  DV.giro = true;
  if (d > 0){
    /* il foglio gira a sinistra e scopre quello sotto, che e' gia' la pagina dopo */
    dvMetti(under, j);
    leaf.style.transition = 'transform .7s cubic-bezier(.4,.1,.2,1)';
    requestAnimationFrame(function(){ leaf.style.transform = 'rotateY(-180deg)'; });
  } else {
    /* torna indietro: sotto resta la pagina di adesso, il foglio della pagina prima rientra da sinistra */
    dvMetti(under, DV.i);
    dvMetti(front, j);
    leaf.style.transition = 'none'; leaf.style.transform = 'rotateY(-180deg)';
    requestAnimationFrame(function(){ requestAnimationFrame(function(){ leaf.style.transition = 'transform .7s cubic-bezier(.4,.1,.2,1)'; leaf.style.transform = 'rotateY(0deg)'; }); });
  }
  try{ flVibra(8); }catch(_){ }
  setTimeout(function(){ DV.i = j; DV.giro = false; dvDisegna(); }, 720);
}

/* ---------------------------------------------------------------------------------------
   PUBBLICO O PRIVATO, e il diario degli amici
   --------------------------------------------------------------------------------------- */
function dvPubblico(){ try{ return localStorage.getItem(DV_PUB_KEY) === '1'; }catch(_){ return false; } }
async function dvPubblicoSet(on){
  try{ localStorage.setItem(DV_PUB_KEY, on ? '1' : '0'); }catch(_){ }
  await dvPubblica(true);
  if (typeof toast === 'function') toast(on ? 'Diario pubblico: gli amici possono sfogliarlo' : 'Diario privato: lo vedi solo tu');
  try{ if (typeof accTabsPaint === 'function') accTabsPaint(); }catch(_){ }
}
/** Manda al server le pagine (senza foto) se il diario e' pubblico; altrimenti lo ritira. */
async function dvPubblica(forza){
  if (typeof frApi !== 'function' || typeof frDevice !== 'function') return;
  const dev = frDevice(); if (!dev) return;
  const pub = dvPubblico();
  if (!forza && (!pub || Date.now() - (+localStorage.getItem(DV_PUBBLICATO_KEY) || 0) < 6 * 3600000)) return;
  try{
    const pagine = pub ? dvPagine().map(function(p){
      const q = { id: p.id, tipo: p.tipo, t: p.t, titolo: p.titolo || (p.iso && p.giornoN ? 'Giorno ' + p.giornoN + ' del viaggio' : ''), testo: p.testo || '', nota: p.nota || '', ico: p.ico || '' };
      /* la pagina del giorno viaggia anche a pezzi, cosi' l'amico la vede disegnata; il tempo
         sul telefono resta sul telefono */
      if (Array.isArray(p.fatti)){
        const fatti = p.fatti.filter(function(f){ return f.k !== 'schermo'; }).map(function(f){ return { k: f.k, t: f.t }; });
        Object.assign(q, { iso: p.iso || '', giornoN: p.giornoN || 0, voto: p.voto || 0, umore: p.umore || '', righe: p.righe || [], detto: p.detto || '', parole: p.parole || '', fatti: fatti });
        q.testo = String(q.testo).split('\n').filter(function(r){ return !/ sul telefono(,|$)/.test(r); }).join('\n');
      }
      return q;
    }) : [];
    await frApi('POST', '/api/focuslock/social/diario', { device: dev, pubblico: pub, pagine: pagine });
    try{ localStorage.setItem(DV_PUBBLICATO_KEY, String(Date.now())); }catch(_){ }
  }catch(_){ }
}
async function dvApriDi(device, nome){
  if (typeof frApi !== 'function'){ if (typeof toast === 'function') toast('Serve l’app installata'); return; }
  try{
    const r = await frApi('GET', '/api/focuslock/social/diario?device=' + encodeURIComponent(frDevice()) + '&of=' + encodeURIComponent(device));
    if (!r || !r.pubblico){ if (typeof toast === 'function') toast((nome || 'Questa persona') + ' tiene il diario privato'); return; }
    const pagine = (r.pagine || []).map(function(p){ return Object.assign({}, p, { n: p.tipo === 'traguardo' ? parseInt((p.nota || '').replace(/\D+/g, ''), 10) || '' : undefined, foto: '' }); });
    if (!pagine.some(function(p){ return p.tipo === 'copertina'; })) pagine.unshift({ id: 'cover', tipo: 'copertina', t: (pagine[0] || {}).t || Date.now(), titolo: 'Diario di viaggio', testo: r.nome || nome || '', nota: dvDataCorta((pagine[0] || {}).t || Date.now()) });
    dvApri(pagine, { nome: r.nome || nome, device: device });
  }catch(e){ if (typeof toast === 'function') toast('Non riesco a leggere il diario adesso'); }
}
function dvMenu(){
  const old = document.getElementById('dvMenu'); if (old){ old.remove(); return; }
  DV.calMese = 0;
  const m = document.createElement('div'); m.id = 'dvMenu'; m.className = 'dv-drawer';
  m.addEventListener('click', function(e){ if (e.target === m) m.remove(); });
  document.getElementById('dvBook').appendChild(m);
  dvMenuPaint();
  requestAnimationFrame(function(){ m.classList.add('in'); });
}
function dvMenuChiudi(){ const x = document.getElementById('dvMenu'); if (x) x.remove(); }
function dvMenuPaint(){
  const m = document.getElementById('dvMenu'); if (!m) return;
  const pub = dvPubblico();
  const cur = DV.pagine[DV.i]; const iso = cur && cur.t ? dvIso(cur.t) : dvIso(Date.now());
  m.innerHTML = '<div class="dv-drawer-in"><i class="pr-grab"></i><button type="button" class="dv-dr-x" onclick="dvMenuChiudi()" aria-label="Chiudi">✕</button>'
    + '<div class="dv-dr-sez"><div class="dv-dr-row"><span class="dv-dr-ico">🌐</span><div><b>Diario pubblico</b><small>Gli amici lo sfogliano dalla classifica. Le foto restano sul telefono.</small></div><button type="button" class="switch' + (pub ? ' on' : '') + '" onclick="dvPubblicoSet(!this.classList.contains(\'on\'));this.classList.toggle(\'on\')" aria-label="Diario pubblico"></button></div>'
    + '<button type="button" class="dv-dr-row vai" onclick="dvMenuChiudi();dvChiudi();if(typeof ifIdentitaApri===\'function\')ifIdentitaApri()"><span class="dv-dr-ico">🌅</span><div><b>Chi sarò</b><small>La persona che stai diventando, scritta da te.</small></div><span class="chev"></span></button></div>'
    + '<div class="dv-dr-sez"><h4 class="dv-cal-h">Vai a un giorno</h4><p class="dv-cal-p">Tocca un giorno nel calendario, oppure scrivi la data qui sotto <small>(puoi scriverla a mano: 2026-10-06)</small>. I giorni senza pagina si aprono vuoti: ci scrivi tu.</p>'
    + '<div class="dv-cal-riga"><input class="dv-cal-in" id="dvCalIn" inputmode="numeric" placeholder="AAAA-MM-GG" value="' + iso + '" onkeydown="if(event.key===\'Enter\')dvVaiData(this.value)" onchange="dvVaiData(this.value)"><button type="button" class="dv-cal-go" onclick="dvVaiData(document.getElementById(\'dvCalIn\').value)" aria-label="Vai">›</button></div>'
    + dvCalHtml() + '</div></div>';
}
/** Il calendario del mese: i giorni con una pagina sono tondi e scuri, gli altri spenti. */
function dvCalHtml(){
  const giorni = {}; DV.pagine.forEach(function(p, i){ if (p && p.t && p.tipo !== 'prossima'){ const k = dvIso(p.t); if (giorni[k] == null) giorni[k] = i; } });
  const base = new Date(); base.setDate(1); base.setHours(12, 0, 0, 0); base.setMonth(base.getMonth() + (DV.calMese || 0));
  const anno = base.getFullYear(), mese = base.getMonth();
  const primo = (new Date(anno, mese, 1).getDay() + 6) % 7, n = new Date(anno, mese + 1, 0).getDate();
  const cur = DV.pagine[DV.i]; const curK = cur && cur.t ? dvIso(cur.t) : '';
  let celle = ''; for (let i = 0; i < primo; i++) celle += '<i></i>';
  for (let d = 1; d <= n; d++){
    const k = anno + '-' + String(mese + 1).padStart(2, '0') + '-' + String(d).padStart(2, '0');
    const ha = giorni[k] != null;
    const futuro = k > dvIso(Date.now());
    celle += futuro ? '<i class="no">' + d + '</i>' : '<button type="button" class="' + (k === curK ? 'cur' : (ha ? 'ha' : 'vuoto')) + '" onclick="dvVaiData(\'' + k + '\')">' + d + '</button>';
  }
  const M = DV_MESI[mese]; const titolo = M.charAt(0).toUpperCase() + M.slice(1) + ' ' + anno;
  return '<div class="dv-cal"><div class="dv-cal-top"><button type="button" onclick="DV.calMese--;dvMenuPaint()" aria-label="Mese prima">‹</button><b>' + titolo + '</b><button type="button" onclick="DV.calMese++;dvMenuPaint()" aria-label="Mese dopo">›</button></div>'
    + '<div class="dv-cal-g">' + ['L', 'M', 'M', 'G', 'V', 'S', 'D'].map(function(x){ return '<span>' + x + '</span>'; }).join('') + '</div><div class="dv-cal-d">' + celle + '</div></div>';
}
/** Alla pagina di quel giorno (o dell'ultimo giorno scritto prima). Accetta 2026-10-06 e 06/10/2026. */
function dvVaiData(v){
  let iso = String(v || '').trim();
  const it = iso.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{4})$/); if (it) iso = it[3] + '-' + it[2].padStart(2, '0') + '-' + it[1].padStart(2, '0');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)){ toast('Scrivi la data così: 2026-10-06'); return; }
  /* un giorno che deve ancora venire: l'ultima pagina, «La prossima pagina la scrivi domani» */
  if (iso > dvIso(Date.now())){
    const k = DV.pagine.findIndex(function(p){ return p && p.tipo === 'prossima'; });
    if (k < 0){ toast('Quel giorno deve ancora arrivare'); return; }
    dvMenuChiudi(); DV.i = k; dvDisegna();
    try{ flVibra(8); }catch(_){ }
    return;
  }
  const t = dvDaIso(iso) + 12 * 3600000;
  /* la prima pagina di quel giorno; se quel giorno e' bianco, l'ultima pagina scritta prima */
  let j = -1, esatto = -1; DV.pagine.forEach(function(p, i){ if (!p || !p.t || p.tipo === 'prossima') return; if (dvIso(p.t) === iso && esatto < 0) esatto = i; if (p.t <= t) j = i; });
  if (esatto >= 0) j = esatto;
  /* oggi si va alla pagina del giorno, quella dove si scrive, anche se oggi ci sono altre pagine */
  if (iso === dvIso(Date.now())){ const g = DV.pagine.findIndex(function(p){ return p && p.iso === iso; }); if (g >= 0){ j = g; esatto = g; } }
  if (esatto < 0 && !DV.di){ dvMenuChiudi(); dvNotaApri(iso); return; }   /* giorno senza pagina: la scrivi tu */
  if (j < 0){ toast('Nessuna pagina prima di quel giorno'); return; }
  dvMenuChiudi();
  DV.i = j; dvDisegna();
  try{ flVibra(8); }catch(_){ }
}
/* ---- LE NOTE SCRITTE A MANO (0.9.208): una pagina per ogni giorno, se vuoi ---- */
const DV_NOTE_KEY = 'fl_diario_note';
function dvNote(){ try{ return JSON.parse(localStorage.getItem(DV_NOTE_KEY) || '{}') || {}; }catch(_){ return {}; } }
registerScreen('s-dv-nota',
  '<div class="topbar"><button class="iconbtn" onclick="dvNotaChiudi()">‹</button><b class="blk-title" style="flex:1;text-align:center;margin-right:34px" id="dvNotaTit">Appunti</b></div>'
  + '<div id="dvNotaBody"></div><div class="spacer"></div>', { back: 's-home' });
function dvNotaApri(iso){
  /* le pagine dei giorni che devono ancora venire non si scrivono */
  if (!iso || iso > dvIso(Date.now())){ if (typeof toast === 'function') toast('La prossima pagina la scrivi domani'); return; }
  DV.notaIso = iso; DV.ritorno = null; let n = dvNote()[iso] || {};
  /* le righe che l'app ci aveva scritto dentro prima della 0.9.217 non tornano nel foglio */
  if (n.testo) n = Object.assign({}, n, { testo: dvSenzaRigheVecchie(n.testo) });
  /* 0.9.213: la pagina scritta dall'app (umore, numeri) si modifica partendo dal suo testo, non
     da un foglio bianco: chi tocca "Modifica" vuole correggere quello che sta leggendo */
  if (!n.testo){
    /* 0.9.217: la pagina dell'app ora e' fatta di umore e fatti, che si ridisegnano da soli; nel
       foglio si scrivono le proprie parole, partendo da quelle gia' dette nella chat dell'umore */
    try{ const p = dvPagine().filter(function(x){ return x.id === 'umore' + iso || x.id === 'giorno' + iso; })[0]; if (p) n = { titolo: '', testo: p.detto || '', foto: n.foto || '' }; }catch(_){ }
  }
  try{ dvChiudi(); }catch(_){ }
  goId('s-dv-nota');
  const t = document.getElementById('dvNotaTit'); if (t) t.textContent = dvDataLunga(dvDaIso(iso));
  const h = document.getElementById('dvNotaBody'); if (!h) return;
  h.innerHTML = '<p class="dv-nota-p">La pagina di questo giorno la scrivi tu. Resta sul telefono; agli amici arriva solo il testo, se il diario è pubblico.</p>'
    + '<input class="fin" id="dvNotaTitolo" placeholder="Un titolo (facoltativo)" maxlength="60" value="' + dvEsc(n.titolo || '') + '">'
    + '<textarea class="fin dv-nota-txt" id="dvNotaTesto" rows="10" placeholder="Cosa è successo, cosa hai imparato, cosa rifaresti diverso…">' + dvEsc(n.testo || '') + '</textarea>'
    + '<div class="dv-nota-foto">' + (n.foto ? '<img src="' + dvEsc(dvSrc(n.foto)) + '" alt=""><button type="button" class="ghostmini" onclick="dvNotaFoto(\'\')">Togli la foto</button>' : '<button type="button" class="ghostmini" onclick="dvNotaScegliFoto()">📷 Allega una foto</button>') + '</div>'
    + '<button type="button" class="cta" onclick="dvNotaSalva()">Salva la pagina</button>'
    + (n.testo ? '<button type="button" class="sd-btn-link" onclick="dvNotaCancella()">Cancella la pagina</button>' : '');
}
function dvNotaChiudi(){
  /* dal diario di un amico si torna al suo diario, sulla stessa pagina */
  const r = DV.ritorno; DV.ritorno = null;
  if (r){ goId('s-home'); setTimeout(function(){ try{ dvApri(r.pagine, r.di); DV.i = r.i; dvDisegna(); }catch(_){ } }, 250); return; }
  goId('s-home'); setTimeout(function(){ try{ dvApri(); const i = DV.pagine.findIndex(function(p){ return p.id === 'nota' + DV.notaIso || p.id === 'umore' + DV.notaIso || p.id === 'giorno' + DV.notaIso || p.id === 'oggi' + DV.notaIso; }); if (i >= 0){ DV.i = i; dvDisegna(); } }catch(_){ } }, 250); }
function dvNotaSalva(){
  const iso = DV.notaIso; const note = dvNote(); const n = note[iso] || {};
  n.titolo = ((document.getElementById('dvNotaTitolo') || {}).value || '').trim(); n.testo = ((document.getElementById('dvNotaTesto') || {}).value || '').trim(); n.at = Date.now();
  if (!n.testo && !n.foto){ delete note[iso]; } else note[iso] = n;
  try{ localStorage.setItem(DV_NOTE_KEY, JSON.stringify(note)); }catch(_){ }
  toast('Pagina salvata'); dvNotaChiudi();
}
function dvNotaCancella(){ const note = dvNote(); delete note[DV.notaIso]; try{ localStorage.setItem(DV_NOTE_KEY, JSON.stringify(note)); }catch(_){ } toast('Pagina cancellata'); dvNotaChiudi(); }
function dvNotaFoto(src){ const note = dvNote(); const n = note[DV.notaIso] || {}; n.foto = src || ''; note[DV.notaIso] = n; try{ localStorage.setItem(DV_NOTE_KEY, JSON.stringify(note)); }catch(_){ } dvNotaApri(DV.notaIso); }
function dvNotaScegliFoto(){ if (typeof flImgPick !== 'function') return; flImgPick('fl_dv_tmp', function(out){ if (out) dvNotaFoto(out); try{ localStorage.removeItem('fl_dv_tmp'); }catch(_){ } }, true); }
/* «Mostra tutto» (0.9.219): le parole intere di quel giorno, nel foglio a tutto schermo. Nel
   diario di un amico si leggono le SUE pagine (prima si apriva la nota del proprio telefono). */
function dvNotaLeggi(iso){
  const amico = DV.di ? { pagine: DV.pagine, di: DV.di, i: DV.i } : null;
  let n = amico ? null : dvNote()[iso];
  if (!n || !n.testo){
    try{
      const lista = amico ? amico.pagine : dvPagine();
      const p = lista.filter(function(x){ return x && (x.iso === iso || x.id === 'nota' + iso || x.id === 'umore' + iso || x.id === 'giorno' + iso); })[0];
      if (p) n = { titolo: p.titolo || (p.giornoN ? 'Giorno ' + p.giornoN + ' del viaggio' : ''), testo: p.parole || p.detto || dvSenzaRigheVecchie(p.testo) || '' };
    }catch(_){ }
  }
  else n = { titolo: n.titolo || '', testo: dvSenzaRigheVecchie(n.testo) };
  if (!n) return;
  DV.ritorno = amico;
  try{ dvChiudi(); }catch(_){ }
  goId('s-dv-nota');
  const t = document.getElementById('dvNotaTit'); if (t) t.textContent = dvDataLunga(dvDaIso(iso));
  const h = document.getElementById('dvNotaBody'); if (h) h.innerHTML = (n.titolo ? '<h2 class="dv-nota-h">' + dvEsc(n.titolo) + '</h2>' : '') + '<p class="dv-nota-corpo">' + dvEsc(n.testo).replace(/\n/g, '<br>') + '</p>' + (DV.di ? '' : '<button type="button" class="ghostmini" onclick="dvNotaApri(\'' + iso + '\')">✍️ Modifica</button>');
  DV.notaIso = iso;
}
/* il diario pubblico si riallinea da solo, ogni tanto */
setTimeout(function(){ try{ dvPubblica(false); }catch(_){ } }, 9000);
/* «il diario dei progressi» dell'Io Futuro ora e' questo */
function ifDiarioApri(){ dvApri(); }

(function(){
  const css = [
    '.dv-wrap{position:fixed;inset:0;z-index:9200;display:flex;flex-direction:column;background:radial-gradient(120% 80% at 50% 0%,#3b2a1c 0%,#1d140c 60%,#120c07 100%);opacity:0;transition:opacity .25s}',
    '.dv-wrap.in{opacity:1}',
    '.dv-top{display:flex;align-items:center;gap:8px;padding:calc(env(safe-area-inset-top,0px) + 12px) 14px 8px;color:#f2e6cf}',
    '.dv-top b{flex:1;text-align:center;font:800 16px var(--font-display);font-style:italic}',
    '.dv-x{width:38px;height:38px;border:0;border-radius:50%;background:rgba(255,255,255,.1);color:#f2e6cf;font:700 16px var(--font-body);cursor:pointer}',
    '.dv-stage{flex:1;display:flex;align-items:center;justify-content:center;perspective:1600px;padding:8px 14px;touch-action:pan-y}',
    '.dv-book{position:relative;width:min(100%,400px);aspect-ratio:3/4.15;max-height:100%;transform-style:preserve-3d}',
    '.dv-under,.dv-leaf{position:absolute;inset:0}',
    '.dv-leaf{transform-origin:left center;transform-style:preserve-3d;will-change:transform;z-index:2}',
    '.dv-face{position:absolute;inset:0;backface-visibility:hidden;-webkit-backface-visibility:hidden}',
    '.dv-back{transform:rotateY(180deg)}',
    '.dv-pg{position:absolute;inset:0;border-radius:6px 14px 14px 6px;overflow:hidden;box-shadow:0 18px 40px rgba(0,0,0,.45),inset 0 0 0 1px rgba(0,0,0,.08)}',
    '.dv-carta,.dv-retro,.dv-righe{background:#efe3c6;background-image:radial-gradient(ellipse at 20% 10%,rgba(255,255,255,.35),transparent 55%),radial-gradient(ellipse at 90% 90%,rgba(120,80,30,.16),transparent 50%),repeating-linear-gradient(0deg,transparent 0 27px,rgba(90,70,50,.09) 27px 28px);color:#3b2d20;padding:18px 18px 22px 26px;font:500 14.5px/1.45 var(--font-body)}',
    '.dv-carta::before,.dv-righe::before{content:"";position:absolute;left:18px;top:0;bottom:0;width:1px;background:rgba(190,60,60,.35)}',
    '.dv-righe{padding:26px}',
    '.dv-retro{background:#e6d8b8;background-image:radial-gradient(ellipse at 60% 40%,rgba(255,255,255,.25),transparent 60%)}',
    '.dv-carta h2{margin:10px 0 6px;font:700 24px/1.15 "Caveat","Segoe Print","Bradley Hand",cursive;color:#2b1f14}',
    '.dv-data{display:block;font:700 11px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:#8a7358}',
    '.dv-mano{margin:6px 0;font:500 19px/1.35 "Caveat","Segoe Print","Bradley Hand",cursive;color:#3b2d20;white-space:normal}',
    '.dv-grande{font-size:26px;line-height:1.3}',
    '.dv-nota{margin:8px 0 0;font:600 12px var(--font-body);color:#8a7358}',
    '.dv-npag{position:absolute;right:14px;bottom:8px;font:600 11px var(--font-body);color:#a08a68}',
    '.dv-num{display:flex;align-items:baseline;gap:6px;font:800 64px/1 "Caveat","Segoe Print",cursive;color:#2b1f14;margin:8px 0 0}',
    '.dv-num small{font:600 13px var(--font-body);color:#8a7358}',
    '.dv-emo{font-size:44px;line-height:1;margin:10px 0 2px}',
    '.dv-tag{display:inline-block;margin-top:8px;padding:4px 10px;border:1.5px solid #5a4634;border-radius:999px;font:700 12px var(--font-body);color:#5a4634}',
    '.dv-timbro{position:absolute;right:16px;bottom:34px;transform:rotate(-14deg);padding:6px 10px;border:3px double #b23a3a;border-radius:8px;color:#b23a3a;font:800 13px var(--font-body);letter-spacing:.14em;opacity:.8}',
    '.dv-timbro.verde{border-color:#2f7d4f;color:#2f7d4f}',
    '.dv-pol{position:relative;width:46%;margin:8px 0 8px auto;padding:8px 8px 22px;background:#fff;box-shadow:0 6px 14px rgba(0,0,0,.25);transform:rotate(3deg)}',
    '.dv-pol.dx{float:right;margin-left:10px}',
    '.dv-pol.grande{width:78%;margin:8px auto 10px;transform:rotate(-2deg)}',
    '.dv-pol img{display:block;width:100%;aspect-ratio:1;object-fit:cover;background:#ddd}',
    '.dv-pol figcaption{position:absolute;left:8px;right:8px;bottom:4px;font:500 12px "Caveat","Segoe Print",cursive;color:#444;text-align:center;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.dv-tape{position:absolute;left:50%;top:-8px;width:58px;height:16px;margin-left:-29px;background:rgba(235,214,150,.75);transform:rotate(-4deg);box-shadow:0 1px 2px rgba(0,0,0,.15)}',
    '.dv-freccia{position:absolute;left:24px;bottom:40px;width:90px;opacity:.7}',
    '.dv-cit{display:flex;flex-direction:column;justify-content:center;height:calc(100% - 20px);text-align:center;padding:0 6px}',
    '.dv-sotto{display:block;width:60%;height:3px;margin:2px auto 10px;background:#b23a3a;border-radius:2px;transform:rotate(-1.5deg);opacity:.6}',
    '.dv-cit small{font:600 12px var(--font-body);color:#8a7358}',
    '.dv-lista{list-style:none;margin:8px 0 0;padding:0}',
    '.dv-lista li{display:flex;align-items:baseline;gap:8px;padding:5px 0;font:500 18px/1.3 "Caveat","Segoe Print",cursive;color:#3b2d20}',
    '.dv-lista li i{font-style:normal;color:#2f7d4f;font-weight:800}',
    '.dv-lista li small{margin-left:auto;font:600 10.5px var(--font-body);color:#a08a68;text-transform:uppercase;letter-spacing:.06em}',
    '.dv-lettera{margin-top:8px;padding:14px 14px 12px;background:rgba(255,250,235,.8);border:1px solid rgba(120,90,50,.25);box-shadow:0 4px 10px rgba(0,0,0,.12);transform:rotate(-1deg)}',
    '.dv-lettera small{display:block;font:800 11px var(--font-body);letter-spacing:.1em;text-transform:uppercase;color:#8a7358;margin-bottom:6px}',
    '.dv-lettera em{display:block;text-align:right;margin-top:8px;font:500 15px "Caveat","Segoe Print",cursive;color:#5a4634}',
    '.dv-cover{background:#4a2c1c;background-image:radial-gradient(ellipse at 30% 20%,rgba(255,255,255,.12),transparent 50%),repeating-linear-gradient(135deg,rgba(0,0,0,.08) 0 3px,transparent 3px 7px);border:6px solid #3a2114;box-shadow:0 18px 40px rgba(0,0,0,.5),inset 0 0 0 2px rgba(214,178,110,.35)}',
    '.dv-cover-in{position:absolute;inset:14px;border:1.5px solid rgba(214,178,110,.55);border-radius:4px;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#e9d3a3;padding:20px}',
    '.dv-cover-in small{font:800 11px var(--font-body);letter-spacing:.3em;opacity:.8}',
    '.dv-cover-in b{margin:14px 0 8px;font:800 34px/1.05 var(--font-display);font-style:italic;text-shadow:0 2px 0 rgba(0,0,0,.4)}',
    '.dv-cover-nome{font:600 20px "Caveat","Segoe Print",cursive;opacity:.95}',
    '.dv-cover-in em{margin-top:6px;font:600 12px var(--font-body);opacity:.75}',
    '.dv-cover-band{position:absolute;right:-6px;top:22%;width:22px;height:56%;background:#b23a3a;box-shadow:-2px 0 4px rgba(0,0,0,.3)}',
    '.dv-pross{height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#8a7358}',
    '.dv-pross span{font-size:40px;margin-bottom:8px}',
    '.dv-pross p{margin:0;font:500 22px/1.3 "Caveat","Segoe Print",cursive;color:#3b2d20}',
    '.dv-pross small{margin-top:10px;font:600 12px var(--font-body)}',
    '.dv-nav{display:flex;align-items:center;justify-content:center;gap:18px;padding:6px 0 calc(env(safe-area-inset-bottom,0px) + 16px);color:#e9d3a3;font:700 13px var(--font-body)}',
    '.dv-nav button{width:44px;height:44px;border:0;border-radius:50%;background:rgba(255,255,255,.1);color:#f2e6cf;font:800 24px/1 var(--font-body);cursor:pointer}',
    '.dv-drawer{position:absolute;inset:0;z-index:6;background:rgba(0,0,0,.5);display:flex;align-items:flex-end}.dv-drawer-in{width:100%;height:90%;overflow-y:auto;background:var(--bg,#F4F7FB);border-radius:26px 26px 0 0;padding:12px 20px calc(env(safe-area-inset-bottom,0px) + 40px);transform:translateY(100%);transition:transform .26s cubic-bezier(.2,.8,.3,1)}.dv-drawer.in .dv-drawer-in{transform:none}body.dark .dv-drawer-in{background:#0E1A30}',
    '.dv-dr-x{position:absolute;right:16px;top:14px;width:36px;height:36px;border:0;border-radius:50%;background:rgba(0,30,68,.08);color:var(--navy);font-size:16px;cursor:pointer}body.dark .dv-dr-x{background:rgba(255,255,255,.12);color:#fff}.dv-drawer-in{position:relative}.dv-cal-in{min-width:0;width:100%;box-sizing:border-box}.dv-cal-p small{display:block;margin-top:2px;color:var(--muted)}.dv-cal-d button.vuoto{color:var(--navy);background:transparent;cursor:pointer}body.dark .dv-cal-d button.vuoto{color:#fff}',
    '.dv-scrivi{margin-top:12px;border:1.5px solid #5a4634;border-radius:12px;background:transparent;color:#5a4634;font:700 12.5px var(--font-body);padding:8px 12px;cursor:pointer}#dvNotaBody{padding:0 18px}.dv-nota-p{margin:14px 0;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}#dvNotaBody .fin{margin:0 0 12px;width:100%;box-sizing:border-box}.dv-nota-foto{margin:0 0 16px}.dv-nota-foto img{display:block;width:100%;border-radius:14px;margin-bottom:8px}.dv-nota-h{margin:14px 0 8px;font:800 22px var(--font-display);color:var(--navy)}body.dark .dv-nota-h{color:#fff}.dv-nota-corpo{margin:0 0 18px;font:500 16px/1.7 var(--font-body);color:var(--navy)}body.dark .dv-nota-corpo{color:#fff}#dvNotaBody .cta{width:100%}',
    '.dv-dr-sez{margin-top:26px}.dv-dr-sez:first-of-type{margin-top:18px}.dv-dr-row{display:flex;align-items:center;gap:14px;width:100%;text-align:left;padding:16px 16px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff);margin-bottom:12px}body.dark .dv-dr-row{background:#12203A;border-color:#22345A}.dv-dr-row.vai{cursor:pointer}.dv-dr-ico{font-size:24px;width:32px;text-align:center}.dv-dr-row > div{flex:1}.dv-dr-row b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .dv-dr-row b{color:#fff}.dv-dr-row small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}.dv-cal-p{margin:0 2px 14px;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.dv-cal-h{margin:0 2px 6px;font:800 19px var(--font-display);color:var(--navy)}body.dark .dv-cal-h{color:#fff}.dv-cal-riga{display:flex;gap:10px}.dv-cal-in{flex:1;border:2px solid #0075E3;border-radius:14px;padding:12px 14px;font:700 17px var(--font-body);color:var(--navy);background:var(--card,#fff)}body.dark .dv-cal-in{color:#fff;background:#0B1830}.dv-cal-go{width:50px;border:0;border-radius:14px;background:#0075E3;color:#fff;font-size:26px;cursor:pointer}',
    '.dv-cal{margin-top:18px;padding:14px 10px 12px;border:1px solid var(--line);border-radius:18px;background:var(--card,#fff)}body.dark .dv-cal{background:#12203A;border-color:#22345A}.dv-cal-top{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}.dv-cal-top b{font:800 16px var(--font-body);color:var(--navy)}body.dark .dv-cal-top b{color:#fff}.dv-cal-top button{width:40px;height:40px;border:0;border-radius:50%;background:transparent;color:var(--navy);font-size:24px;cursor:pointer}body.dark .dv-cal-top button{color:#fff}',
    '.dv-cal-g,.dv-cal-d{display:grid;grid-template-columns:repeat(7,1fr);gap:4px}.dv-cal-g span{text-align:center;font:800 11px var(--font-body);color:var(--muted)}.dv-cal-d i,.dv-cal-d button{height:42px;display:flex;align-items:center;justify-content:center;border-radius:12px;font:700 15px var(--font-body);font-style:normal;border:0;background:transparent}.dv-cal-d i.no{color:#B4C0D2}.dv-cal-d button.ha{color:var(--navy);background:rgba(0,117,227,.1);cursor:pointer}.dv-cal-d button.cur{color:#fff;background:#001E44;cursor:pointer}body.dark .dv-cal-d button.ha{color:#fff;background:rgba(79,184,255,.18)}body.dark .dv-cal-d button.cur{background:#4FB8FF;color:#001E44}',
    '.dv-menu{position:absolute;right:14px;top:calc(env(safe-area-inset-top,0px) + 56px);min-width:220px;padding:6px;border-radius:14px;background:#fff;box-shadow:0 12px 32px rgba(0,0,0,.35);z-index:5}',
    '.dv-menu button{width:100%;border:0;background:transparent;padding:12px;text-align:left;font:700 14px var(--font-body);color:#001E44;cursor:pointer}',
    /* la carta e' chiara in tutti e due i temi: l'inchiostro resta scuro anche in body.dark, e
       nessuna regola generale (body.dark h2, la guardia del contrasto) lo deve sbiancare */
    'body.dark .dv-carta h2,body.dark .dv-mano,body.dark .dv-num,body.dark .dv-lista li,body.dark .dv-pross p,body.dark .dv-carta{color:#2b1f14 !important}',
    'body.dark .dv-data,body.dark .dv-nota,body.dark .dv-npag,body.dark .dv-cit small,body.dark .dv-lettera small,body.dark .dv-pross small{color:#8a7358 !important}',
    'body.dark .dv-lettera em{color:#5a4634 !important}',
    /* 0.9.217: la pagina del giorno alla Drake: scarabocchi, foglietto strappato, fatti a penna */
    '.dv-doodle{display:inline-block;vertical-align:middle;flex:none;overflow:visible}',
    '.dv-meteo{position:absolute;right:14px;top:10px;width:56px;height:auto;opacity:.9;z-index:1}',
    '.dv-kick{display:block;margin-top:6px;font:500 16px/1 "Caveat","Segoe Print",cursive;color:#8a7358}',
    '.dv-carta h2.dv-h-mano{margin:8px 62px 0 0;font-size:27px;line-height:1.05}',
    '.dv-onda{display:block;width:58%;height:8px;margin:2px 0 16px;opacity:.7}',
    '.dv-umore{display:flex;align-items:center;gap:12px;margin:0}',
    '.dv-umore > div{flex:1;min-width:0}',
    '.dv-umore b.dv-mano{display:block;margin:0;font-weight:700;font-size:21px;line-height:1.1}',
    '.dv-umore b.dv-mano.lunga{font-size:18px;line-height:1.15}',
    '.dv-umore small{display:block;margin-top:1px;font:700 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#8a7358}',
    '.dv-faccia{width:44px;height:44px}',
    '.dv-cerchio{position:relative;width:60px;height:38px;flex:none;display:flex;align-items:center;justify-content:center;transform:rotate(-6deg)}',
    '.dv-cerchio svg{position:absolute;inset:0;width:100%;height:100%}',
    '.dv-cerchio b{position:relative;font:700 21px/1 "Caveat","Segoe Print",cursive;color:#b23a3a}',
    '.dv-righe-um{margin:0;font-size:17px;line-height:1.3;color:#4a3a2a}',
    '.dv-detto{margin:0;font-size:17px;color:#6b5540}',
    '.dv-strappo-w{position:relative;margin:12px 6px 8px 2px;filter:drop-shadow(0 3px 4px rgba(0,0,0,.2));transform:rotate(-1.2deg)}',
    '.dv-strappo-w .dv-tape{top:-8px;left:26%;z-index:2}',
    '.dv-strappo{background:#fbf6e6;background-image:repeating-linear-gradient(0deg,transparent 0 23px,rgba(90,110,150,.12) 23px 24px);padding:14px 14px 13px;clip-path:' + (function(){
      const su = [], giu = [];
      for (let i = 0; i <= 25; i++){ su.push((i * 4) + '% ' + (i % 2 ? 0 : 4) + 'px'); giu.push((100 - i * 4) + '% calc(100% - ' + ((i * 7) % 3 === 0 ? 0 : (i % 2 ? 4 : 2)) + 'px)'); }
      return 'polygon(' + su.concat(giu).join(',') + ')';
    })() + '}',
    '.dv-strappo .dv-mano{margin:0;font-size:19px;line-height:24px}',
    '.dv-fatti{list-style:none;margin:0;padding:0;position:relative;z-index:1}',
    '.dv-fatti li{display:flex;align-items:center;gap:10px;padding:2px 0;font:600 17.5px/1.15 "Caveat","Segoe Print",cursive;color:#3b2d20}',
    '.dv-fatti li > span{flex:1;min-width:0}',
    '.dv-ico{width:22px;height:22px}',
    '.dv-frec{width:26px;height:22px;margin-left:-2px}',
    '.dv-ok{font-style:normal;color:#2f7d4f;font-weight:800}',
    '.dv-schizzo{position:absolute;right:16px;bottom:28px;width:100px;height:auto;opacity:.36;pointer-events:none;z-index:0;transform:rotate(-4deg)}',
    '.dv-disegno{display:block;width:64px;height:64px;margin:10px 0 0}',
    '.dv-pol.mini{width:34%;padding:6px 6px 16px;margin:4px 0 6px 10px;transform:rotate(4deg)}',
    '.dv-carta .dv-scrivi{position:relative;z-index:1}',
    /* 0.9.219: aria fra i pezzi della pagina del giorno, perche' l'occhio riposi (regola 18 del copy) */
    '.dv-g > .dv-blk{margin:0 0 18px}',
    '.dv-g > .dv-blk:last-child{margin-bottom:0}',
    '.dv-g > .dv-strappo-w{margin:6px 6px 20px 2px}',
    '.dv-righe-um span{display:block}.dv-righe-um span + span{margin-top:6px}',
    '.dv-fatti li + li{margin-top:7px}',
    /* 0.9.294: era content:""" (il cambio da «» a "" fatto a mano): la terza virgoletta apriva una stringa che si mangiava
       il codice fino alla regola dopo, e a schermo compariva "}.dv-cuore.q::after{content:". Le virgolette si scrivono col codice. */
    '.dv-cuore{white-space:pre-line}.dv-cuore.q::before{content:"\\0022"}.dv-cuore.q::after{content:"\\0022"}',
    '.dv-bott{display:flex;flex-wrap:wrap;gap:10px;position:relative;z-index:1}.dv-bott:empty{display:none}.dv-bott .dv-scrivi{margin:0}.dv-bott .dv-scrivi[hidden]{display:none}',
    '.dv-scrivi.pieno{background:#5a4634;border-color:#5a4634;color:#f6ecd6}body.dark .dv-scrivi.pieno{color:#f6ecd6 !important}',
    /* la pagina di oggi, aperta: il foglietto bianco da scrivere e il pulsante blu */
    '.dv-penna{display:inline-block;vertical-align:-3px;flex:none}',
    '.dv-scrivi{display:inline-flex;align-items:center;gap:6px}',
    '.dv-aperta{cursor:pointer}',
    '.dv-aperta .dv-strappo{padding:16px 16px 18px}',
    '.dv-aperta-t{margin:0;font-size:22px !important;line-height:26px !important;font-weight:700;color:#14234A}',
    '.dv-aperta-s{margin:6px 0 0;font:500 14px/1.4 var(--font-body);color:#4a3a2a}',
    '.dv-carta .dv-scrivi.dv-oggi-btn{background:#0075E3;border-color:#0075E3;color:#ffffff;font-size:15px;padding:12px 16px;border-radius:14px;width:100%;justify-content:center}',
    'body.dark .dv-carta .dv-scrivi.dv-oggi-btn{color:#ffffff !important}body.dark .dv-aperta-t{color:#14234A !important}body.dark .dv-aperta-s{color:#4a3a2a !important}',
    '.dv-finqui{display:block;margin:0 0 8px;font:700 10.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#8a7358}body.dark .dv-finqui{color:#8a7358 !important}',
    '.dv-pross-ico{width:40px;height:40px}',
    'body.dark .dv-fatti li,body.dark .dv-umore b{color:#3b2d20 !important}body.dark .dv-kick,body.dark .dv-umore small{color:#8a7358 !important}body.dark .dv-righe-um{color:#4a3a2a !important}body.dark .dv-detto{color:#6b5540 !important}body.dark .dv-cerchio b{color:#b23a3a !important}',
    'body.dark .dv-timbro{color:#b23a3a !important}body.dark .dv-timbro.verde{color:#2f7d4f !important}',
    'body.dark .dv-cover-in,body.dark .dv-cover-in b,body.dark .dv-cover-nome,body.dark .dv-cover-in em,body.dark .dv-cover-in small{color:#e9d3a3 !important}'
  ].join('\n');
  const st = document.createElement('style'); st.id = 'dv-css'; st.textContent = css;
  document.head.appendChild(st);
})();
