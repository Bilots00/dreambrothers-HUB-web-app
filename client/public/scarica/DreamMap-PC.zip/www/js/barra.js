/* ===========================================================================================
   LA BARRA DEGLI STRUMENTI DEL FOGLIO

   Quella di Samsung Notes, sopra alla tastiera: caselle da spuntare, elenchi puntati e
   numerati, rientri, e la grandezza del testo. Sono i comandi che servono davvero a un foglio
   di cose da fare — e sono anche gli unici che si possono fare onestamente qui.

   PERCHÉ NON C'È IL GRASSETTO. Questo foglio è testo semplice, e lo è per un motivo: la stessa
   frase finisce sulla schermata di blocco, nel promemoria della sera, nel widget. Il grassetto
   richiede un formato che quegli altri posti non sanno leggere, e un pulsante che sembra
   funzionare e poi non lascia traccia è peggio di un pulsante che non c'è. Le caselle e gli
   elenchi invece sono caratteri veri: viaggiano ovunque, e si vedono anche fuori da qui.

   La grandezza del testo è un'altra cosa ancora: non è formattazione, è come lo vedi tu su
   questo telefono. Si ricorda, e non tocca il contenuto.
   =========================================================================================== */

const BR_SIZES = [15, 18, 21, 25];

function brSize(){
  try{ const v = +localStorage.getItem('fl_note_size'); return BR_SIZES.indexOf(v) >= 0 ? v : 18; }
  catch(_){ return 18; }
}

function brSetSize(v){
  try{ localStorage.setItem('fl_note_size', String(v)); }catch(_){ }
  brApplySize();
}

function brApplySize(){
  /* Il pulsante «Testo» non c'e' piu' (non l'aveva chiesto nessuno): la grandezza si cambia
     dalla barra dell'editor, sul testo selezionato. Questa resta per compatibilita'. */
  const lbl = document.getElementById('brSizeLbl');
  if (lbl) lbl.textContent = brSize();
}

function brCycleSize(){
  const i = BR_SIZES.indexOf(brSize());
  brSetSize(BR_SIZES[(i + 1) % BR_SIZES.length]);
  try{ toast('Testo del foglio: ' + brSize() + ' — tocca ancora per cambiare'); }catch(_){ }
}

/* La barra non si costruisce piu'. Se un aggiornamento la trova ancora appesa al foglio,
   la toglie: un comando che non ha piu' niente da comandare non deve restare a schermo. */
function brEnsure(){
  const vecchia = document.getElementById('brBar');
  if (vecchia) vecchia.remove();
  brApplySize();
}

(function brStyle(){
  const st = document.createElement('style');
  st.textContent = [
    '.br-size{flex:none;height:34px;padding:0 10px;border:0;border-radius:10px;background:transparent;',
      'color:var(--muted);font:700 13px var(--font-body);cursor:pointer}',
    '.br-size b{font-weight:800}'
  ].join('');
  document.head.appendChild(st);
})();

/* La grandezza si applica ogni volta che il foglio si apre. */
(function brHook(){
  if (typeof stFullOpen !== 'function') return;
  const orig = stFullOpen;
  window.stFullOpen = function(){
    const r = orig.apply(this, arguments);
    setTimeout(brEnsure, 30);
    return r;
  };
})();
