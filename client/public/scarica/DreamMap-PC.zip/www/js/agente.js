/* ===========================================================================================
   IL TUO AGENTE — l'agente personale di ogni utente

   PERCHE' ESISTE. La Roadmap chiedeva all'utente di scriversi gli orizzonti da zero. Chi
   arriva dall'onboarding ha appena detto al Genio chi e', cosa sogna e dove vuole arrivare:
   fargli rifare un piano bianco e' attrito puro, e un piano bianco non lo compila nessuno.
   Qui l'agente parte da quello che l'app sa gia' (come il «Superagent» di Base44: «start with
   an agent that already knows you») e la roadmap la propone lui, con i passi di oggi.

   DOVE SI PARLA. In app, su Telegram, su WhatsApp: una conversazione sola. Il telefono manda
   il messaggio al server della web app (con il token Google dell'account) e rilegge la risposta.
   CHI PAGA LA RISPOSTA: l'abbonamento Max di Andrea risponde SOLO ad Andrea (serratura sul
   server e sul VPS). Ogni altro utente usa i SUOI crediti prepagati, come su Base44: un
   messaggio = un credito, e senza crediti il modello non viene chiamato.
   I canali esterni si agganciano con un codice generato qui.

   COSA VIAGGIA. Il «brief»: le cose che l'utente vede gia' nell'app (sogno, destinazione,
   profilo, ore a settimana, passo, arrivo stimato, orizzonti, righe di oggi). Mai le regole di
   blocco, mai la cronologia al granello.

   CHI CE L'HA. Lo dice il server (FOCUSLOCK_AGENT_EMAILS, o tutti con FOCUSLOCK_AGENT_OPEN):
   senza, resta la pagina «Arriva con Premium». I testi stanno in content/agente.json.
   =========================================================================================== */

const AG = { testi: null, abil: null, stato: null, poll: 0, attesa: false, tab: 'chat', link: null, pollLink: 0, invio: false };
const AG_K = { stato: 'fl_agente', abil: 'fl_agente_abil', testi: 'fl_agente_testi' };
const AG_ABIL_MS = 6 * 3600000;
const AG_ANELLI = ['cinque', 'anno', 'mese', 'settimana', 'oggi'];

function agLeggi(k, d){ try{ const v = JSON.parse(localStorage.getItem(AG_K[k] || k) || 'null'); return v === null ? d : v; }catch(_){ return d; } }
function agScrivi(k, v){ try{ localStorage.setItem(AG_K[k] || k, JSON.stringify(v)); }catch(_){ } }
function agEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function agPuo(){ try{ return !!(typeof NATIVE !== 'undefined' && NATIVE && NATIVE.accountApi); }catch(_){ return false; } }
function agT(path, vars){
  let cur = AG.testi;
  String(path).split('.').forEach(function(p){ cur = cur ? cur[p] : undefined; });
  if (cur === undefined || cur === null) return '';
  if (typeof cur !== 'string') return cur;
  return cur.replace(/\{(\w+)\}/g, function(m, k){ return (vars && vars[k] !== undefined) ? String(vars[k]) : m; });
}
async function agTestiCarica(){
  if (!AG.testi){ const c = agLeggi('testi', null); if (c && c.chat) AG.testi = c; }
  try{
    const t = await (await fetch('content/agente.json')).json();
    if (t && t.chat){ AG.testi = t; agScrivi('testi', t); }
  }catch(_){ }
}
async function agApi(method, path, body){
  return NATIVE.accountApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
}
function agStato(){
  if (!AG.stato){
    AG.stato = agLeggi('stato', null) || { nome: '', impostato: false, ultimoId: 0, msgs: [], canali: {} };
    if (!Array.isArray(AG.stato.msgs)) AG.stato.msgs = [];
    agSessNorm(AG.stato);
  }
  return AG.stato;
}
function agSalva(){ if (AG.stato) agSessNorm(AG.stato); agScrivi('stato', AG.stato); }

/* ---------------------------------------------------------------------------------------
   LE ICONE (0.9.219): sempre SVG, mai caratteri come «›», «☰», «⋯», «✕» o «➤».
   --------------------------------------------------------------------------------------- */
const AG_ICO = {
  /* le pill dei suggerimenti (0.9.252): un'icona a tratto per ognuna, al posto delle emoji */
  mappa: '<path d="M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3z"/><path d="M9 3v15M15 6v15"/>',
  oggi: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  ostacolo: '<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
  fulmine: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
  collo: '<path d="M10 2h4v4c0 2 4 3 4 8v6a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2v-6c0-5 4-6 4-8z"/><path d="M9 2h6"/>',
  settimana: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 11h18"/>',
  indietro: '<path d="M15 18l-6-6 6-6"/>',
  avanti: '<path d="M9 18l6-6-6-6"/>',
  giu: '<path d="M6 9l6 6 6-6"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  altro: '<circle cx="5" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><circle cx="19" cy="12" r="1.6" fill="currentColor" stroke="none"/>',
  chiudi: '<path d="M18 6L6 18M6 6l12 12"/>',
  cerca: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>',
  scrivi: '<path d="M11 4H5a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2v-6"/><path d="M18.4 2.6a2 2 0 0 1 2.9 2.9L12 14.8l-3.9 1 1-3.9z"/>',
  matita: '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z"/>',
  condividi: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
  fissa: '<path d="M12 17v5"/><path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/>',
  sfissa: '<path d="M12 17v5"/><path d="M9 3h6l-1 6 3 3v2H7v-2l3-3z"/><path d="M3 3l18 18"/>',
  cestino: '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/>',
  espandi: '<path d="M15 3h6v6"/><path d="M9 21H3v-6"/><path d="M21 3l-7 7"/><path d="M3 21l7-7"/>',
  invia: '<path d="M3.4 20.4l17.45-7.48a1 1 0 0 0 0-1.84L3.4 3.6a.99.99 0 0 0-1.38.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .71.73 1.2 1.39.91z" fill="currentColor" stroke="none"/>',
  play: '<path d="M7 4v16l13-8z" fill="currentColor"/>',
  galleria: '<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="9" cy="9" r="2"/><path d="M21 15l-4-4L6 21"/>',
  persona: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  canali: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 21l1.9-5.4A8 8 0 1 1 21 12z"/>',
  piu: '<path d="M12 5v14M5 12h14"/>',
  mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
  doc: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  spunta: '<path d="M5 12l5 5L20 7"/>',
  grafico: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
  modello: '<path d="M12 3l1.9 4.6L18.5 9l-4.6 1.9L12 15.5l-1.9-4.6L5.5 9l4.6-1.4z"/><path d="M19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8z"/>'
};
/** L'icona di una pill dei suggerimenti, scelta dalle parole della pill (vale in ogni lingua). */
function agSugIco(t){
  const s = String(t || '').toLowerCase();
  /* 0.9.335, Andrea: "aumenta la mia produttivita' con il sole non c'entra niente: un fulmine, l'energia" */
  const n = /collo di bottiglia|bottleneck/.test(s) ? 'collo' : /produttiv|productiv/.test(s) ? 'fulmine' : /roadmap|percorso/.test(s) ? 'mappa' : /oggi|today/.test(s) ? 'oggi' : /ostacolo|imprevist|obstacle/.test(s) ? 'ostacolo' : /settimana|week/.test(s) ? 'settimana' : '';
  return n ? agSvg(n, 15) : '';
}
function agSvg(nome, px){
  const n = px || 20;
  return '<svg class="ag-ic" viewBox="0 0 24 24" width="' + n + '" height="' + n + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (AG_ICO[nome] || '') + '</svg>';
}

/* ---------------------------------------------------------------------------------------
   CHI E' IL TUO AGENTE (0.9.219). Con Premium si sceglie: parlare con «il Genio» (quello
   dell'app, che ti conosce dal primo giorno) o creare un agente tutto tuo, con un nome e
   un'immagine (un'emoji o una foto dalla galleria, ridotta a 256 pixel).
   fl_agente_identita = { tipo: 'genio'|'mio', nome, emoji, img }. Il brief e' lo stesso:
   l'agente tuo sa tutto quello che sa il Genio. Il nome viaggia al server (nomeAgente).
   --------------------------------------------------------------------------------------- */
const AG_IDK = 'fl_agente_identita';
const AG_EMOJI = ['🤖', '🦉', '🦁', '🐺', '🦊', '🐉', '🦅', '🐬', '🚀', '⭐', '🔥', '🧠', '🎯', '👑', '🌙', '⚡', '🧭', '🌱'];
function agIdentita(){
  let x = null;
  try{ x = JSON.parse(localStorage.getItem(AG_IDK) || 'null'); }catch(_){ x = null; }
  if (!x || (x.tipo !== 'genio' && x.tipo !== 'mio')){
    /* chi aveva gia' dato un nome al suo agente prima della 0.9.219 lo ritrova come «suo» */
    const vecchio = String(((AG.stato || agLeggi('stato', null) || {}).nome) || '').trim();
    x = (vecchio && vecchio.toLowerCase() !== 'genio') ? { tipo: 'mio', nome: vecchio, emoji: '🤖', img: '' } : { tipo: 'genio' };
  }
  if (x.tipo === 'genio') return { tipo: 'genio', nome: 'Genio', emoji: '🧞', img: '' };
  return { tipo: 'mio', nome: String(x.nome || '').trim().slice(0, 40) || 'Il mio agente', emoji: x.emoji || '🤖', img: (typeof x.img === 'string' && x.img.indexOf('data:image/') === 0) ? x.img : '' };
}
/** Il nome com'e': «Genio» o quello scelto. E' quello che va al server. */
function agNomeAgente(){ return agIdentita().nome; }
/** Il nome all'inizio di una frase: «Il Genio sta scrivendo…», «Leo sta scrivendo…». */
function agNomeSoggetto(){ const i = agIdentita(); return i.tipo === 'genio' ? 'Il Genio' : i.nome; }
/** Dopo «a»: «Chiedi al Genio…», «Chiedi a Leo…». */
function agNomeA(){ const i = agIdentita(); return i.tipo === 'genio' ? 'al Genio' : 'a ' + i.nome; }
function agAvatarHtml(cls, idn){
  const i = idn || agIdentita();
  return '<span class="ag-av ' + (cls || '') + '" aria-hidden="true">' + (i.img ? '<img src="' + i.img + '" alt="">' : agEsc(i.emoji || '🧞')) + '</span>';
}
function agIdScrivi(x){
  const v = x.tipo === 'genio' ? { tipo: 'genio' } : { tipo: 'mio', nome: String(x.nome || '').trim().slice(0, 40), emoji: x.emoji || '🤖', img: x.img || '' };
  try{ localStorage.setItem(AG_IDK, JSON.stringify(v)); }
  catch(_){ /* la memoria e' piena: la foto non entra, resta l'emoji */ try{ v.img = ''; localStorage.setItem(AG_IDK, JSON.stringify(v)); }catch(__){ } }
  const s = agStato(); s.nome = agNomeAgente(); agSalva();
  agTitoloPaint();
}
/** Il titolo della pagina dell'agente: l'immagine e il nome. */
function agTitoloPaint(){
  const t = document.getElementById('agTitolo'); if (!t) return;
  if (!agStato().impostato){ t.textContent = agT('chat.titolo') || 'Il tuo agente personale'; return; }
  t.innerHTML = '<span class="ag-tit">' + agAvatarHtml('ag-av-s') + '<span>' + agEsc(agNomeSoggetto()) + '</span></span>';
}

/* ---- la scelta: il Genio o il tuo agente personale (nella creazione e dal menu ⋯) ---- */
function agIdHtml(){
  const b = AG.idBozza || (AG.idBozza = agIdentita());
  const mio = b.tipo === 'mio';
  const op = function(tipo, ico, tit, sotto){
    return '<button type="button" class="ag-id-op' + (b.tipo === tipo ? ' on' : '') + '" onclick="agIdTipo(\'' + tipo + '\')" aria-pressed="' + (b.tipo === tipo) + '">'
      + '<span class="ag-id-ico">' + ico + '</span><span class="ag-id-txt"><b>' + agEsc(tit) + '</b><small>' + agEsc(sotto) + '</small></span></button>';
  };
  let h = '<div class="ag-id">'
    + op('genio', '🧞', agT('identita.genio') || 'Il Genio', agT('identita.genioSotto') || 'Il Genio dell’app ti conosce dal primo giorno: parli con lui.')
    + op('mio', mio ? agAvatarHtml('ag-av-m', { emoji: b.emoji, img: b.img }) : '✨', agT('identita.mio') || 'Un agente tutto tuo', agT('identita.mioSotto') || 'Scegli tu il nome e l’immagine del tuo agente personale. Il tuo agente personale sa tutto quello che sa il Genio.');
  if (mio){
    h += '<div class="ag-id-mio">'
      + '<label class="ag-nome"><span>' + agEsc(agT('identita.nome') || 'Come si chiama il tuo agente personale?') + '</span>'
      +   '<input class="fin" id="agIdNome" maxlength="40" autocomplete="off" placeholder="' + agEsc(agT('identita.nomeEsempio') || 'Per esempio: Leo') + '" value="' + agEsc(b.nome === 'Il mio agente' ? '' : (b.nome || '')) + '" oninput="AG.idBozza.nome=this.value"></label>'
      + '<span class="ag-id-lab">' + agEsc(agT('identita.immagine') || 'Scegli l’immagine del tuo agente personale') + '</span>'
      + '<div class="ag-id-emo">'
      +   AG_EMOJI.map(function(e){ return '<button type="button" class="' + (!b.img && b.emoji === e ? 'on' : '') + '" onclick="agIdEmoji(\'' + e + '\')" aria-label="' + e + '">' + e + '</button>'; }).join('')
      + '</div>'
      + '<button type="button" class="ag-id-foto' + (b.img ? ' on' : '') + '" onclick="document.getElementById(\'agIdFile\').click()">'
      +   (b.img ? '<img src="' + b.img + '" alt="">' : agSvg('galleria', 20)) + '<span>' + agEsc(b.img ? (agT('identita.fotoCambia') || 'Cambia la foto') : (agT('identita.foto') || 'Scegli una foto dalla galleria')) + '</span></button>'
      + '<input type="file" id="agIdFile" accept="image/*" hidden onchange="agIdFoto(this)">'
      + '</div>';
  }
  return h + '</div>';
}
function agIdRidisegna(){ const box = document.getElementById('agIdBox'); if (box) box.innerHTML = agIdHtml(); }
function agIdTipo(t){
  if (!AG.idBozza) AG.idBozza = agIdentita();
  /* nelle pagine (0.9.258): il Genio si salva subito e si torna; «un agente tuo» apre la pagina del nome */
  const pag = document.getElementById('s-agente-id'); const inPag = !!(pag && pag.classList.contains('active'));
  if (inPag){
    AG.idBozza.tipo = t;
    if (t === 'mio'){ if (!AG.idBozza.emoji || AG.idBozza.emoji === '🧞') AG.idBozza.emoji = '🤖'; if (AG.idBozza.nome === 'Genio') AG.idBozza.nome = ''; try{ flVibra(10); }catch(_){ } agIdMioApri(); return; }
    try{ flVibra(10); }catch(_){ }
    agIdSalvaFoglio(); goId('s-agente-pers'); agPersPaint(); return;
  }
  const n = document.getElementById('agIdNome'); if (n) AG.idBozza.nome = n.value;
  AG.idBozza.tipo = t;
  if (t === 'mio' && (!AG.idBozza.emoji || AG.idBozza.emoji === '🧞')) AG.idBozza.emoji = '🤖';
  if (t === 'mio' && AG.idBozza.nome === 'Genio') AG.idBozza.nome = '';
  try{ flVibra(10); }catch(_){ }
  agIdRidisegna();
  if (t === 'mio') setTimeout(function(){ const i = document.getElementById('agIdNome'); if (i && !i.value) try{ i.focus(); }catch(_){ } }, 60);
}
function agIdEmoji(e){
  const n = document.getElementById('agIdNome'); if (n) AG.idBozza.nome = n.value;
  AG.idBozza.emoji = e; AG.idBozza.img = '';
  try{ flVibra(8); }catch(_){ }
  agIdRidisegna();
}
/** La foto dalla galleria: ritagliata al centro e ridotta a 256 x 256 pixel. */
function agIdFoto(input){
  const f = input && input.files && input.files[0];
  if (!f) return;
  const n = document.getElementById('agIdNome'); if (n) AG.idBozza.nome = n.value;
  const rd = new FileReader();
  rd.onload = function(){
    const im = new Image();
    im.onload = function(){
      try{
        const L = 256, c = document.createElement('canvas'); c.width = L; c.height = L;
        const lato = Math.min(im.naturalWidth, im.naturalHeight);
        const sx = (im.naturalWidth - lato) / 2, sy = (im.naturalHeight - lato) / 2;
        c.getContext('2d').drawImage(im, sx, sy, lato, lato, 0, 0, L, L);
        AG.idBozza.img = c.toDataURL('image/jpeg', 0.85);
        agIdRidisegna();
      }catch(_){ if (typeof toast === 'function') toast(agT('identita.fotoErrore') || 'Questa foto non si apre: prova con un’altra'); }
    };
    im.onerror = function(){ if (typeof toast === 'function') toast(agT('identita.fotoErrore') || 'Questa foto non si apre: prova con un’altra'); };
    im.src = rd.result;
  };
  rd.readAsDataURL(f);
}
/** Controlla la bozza: con «un agente tutto tuo» serve il nome. Torna true se si puo' salvare. */
function agIdBozzaOk(){
  const b = AG.idBozza || agIdentita();
  const n = document.getElementById('agIdNome'); if (n) b.nome = n.value;
  if (b.tipo === 'mio' && !String(b.nome || '').trim()){
    if (typeof toast === 'function') toast(agT('identita.serveNome') || 'Scrivi il nome del tuo agente personale');
    if (n) try{ n.focus(); }catch(_){ }
    return false;
  }
  return true;
}
/** Dal menu ⋯ della chat: «Il tuo agente personale: nome e immagine». */
/* 0.9.258, Andrea: niente foglio dal basso. Prima una pagina con la scelta (il Genio o un agente tuo);
   scegliendo «un agente tutto tuo» si passa a UN'ALTRA pagina con il nome e l'immagine. Un passo alla volta. */
function agIdApri(){
  agFoglioChiudi(true);
  AG.idBozza = agIdentita();
  if (AG.idBozza.tipo === 'mio' && AG.idBozza.nome === 'Il mio agente') AG.idBozza.nome = '';
  goId('s-agente-id');
  const h = document.getElementById('agIdPag'); if (h) h.innerHTML = '<div id="agIdBox">' + agIdHtml() + '</div>';
}
function agIdMioApri(){
  goId('s-agente-id-mio');
  const h = document.getElementById('agIdMioPag'); if (h) h.innerHTML = '<div id="agIdBox">' + agIdHtml() + '</div><button type="button" class="cta" style="margin-top:16px" onclick="agIdSalvaPagina()">Salva</button>';
  setTimeout(function(){ const i = document.getElementById('agIdNome'); if (i && !i.value) try{ i.focus(); }catch(_){ } }, 120);
}
function agIdSalvaPagina(){
  if (!agIdBozzaOk()) return;
  agIdSalvaFoglio();
  goId('s-agente-pers'); agPersPaint();
}
function agIdApriFoglio(){
  agFoglioChiudi(true);
  AG.idBozza = agIdentita();
  if (AG.idBozza.tipo === 'mio' && AG.idBozza.nome === 'Il mio agente') AG.idBozza.nome = '';
  agFoglio('<p class="ag-fg-tit">' + agEsc(agT('identita.titolo') || 'Il tuo agente personale: nome e immagine') + '</p>'
    + '<div id="agIdBox">' + agIdHtml() + '</div>'
    + '<div class="ag-fg-az"><button type="button" class="ag-fg-no" onclick="agFoglioChiudi()">' + agEsc(agT('foglio.annulla') || 'Annulla') + '</button>'
    + '<button type="button" class="ag-fg-si" onclick="agIdSalvaFoglio()">' + agEsc(agT('foglio.salva') || 'Salva') + '</button></div>', 'alto');
}
function agIdSalvaFoglio(){
  if (!agIdBozzaOk()) return;
  agIdScrivi(AG.idBozza);
  AG.idBozza = null;
  agFoglioChiudi();
  if (agPuo()) agApi('POST', '/api/focuslock/agent/chat/profilo', { nome: agNomeAgente(), brief: agBrief() }).catch(function(){ });
  try{ flVibra(15); }catch(_){ }
  if (document.getElementById('agBody') && document.getElementById('s-agente').classList.contains('active')) agPaint();
  if (document.getElementById('agPop')) agPopTesta();
  if (typeof toast === 'function') toast(agT('identita.salvato', { nome: agIdentita().tipo === 'genio' ? 'il Genio' : agNomeAgente() }) || 'Salvato');
}

/* ---------------------------------------------------------------------------------------
   IL FOGLIO DAL BASSO (come Gemini): il menu di una conversazione, «Rinomina», «Elimina»,
   il nome e l'immagine dell'agente, il menu ⋯. Uno alla volta, sopra a tutto.
   --------------------------------------------------------------------------------------- */
function agFoglio(html, cls){
  agFoglioChiudi(true);
  const w = document.createElement('div');
  w.id = 'agFoglio'; w.className = 'ag-fg-w';
  w.innerHTML = '<div class="ag-fg ' + (cls || '') + '" role="dialog" aria-modal="true"><div class="ag-fg-man" aria-hidden="true"></div>' + html + '</div>';
  w.addEventListener('click', function(e){ if (e.target === w) agFoglioChiudi(); });
  document.body.appendChild(w);
  requestAnimationFrame(function(){ w.classList.add('in'); });
  return w;
}
function agFoglioChiudi(subito){
  const w = document.getElementById('agFoglio'); if (!w) return;
  w.id = '';
  if (subito === true){ w.remove(); return; }
  w.classList.remove('in');
  setTimeout(function(){ w.remove(); }, 220);
}
function agFoglioRiga(ico, testo, azione, cls){
  return '<button type="button" class="ag-fg-r ' + (cls || '') + '" onclick="' + azione + '">' + (ico.indexOf('<') === 0 ? ico : agSvg(ico, 22)) + '<span>' + agEsc(testo) + '</span></button>';
}
/* il menu ⋯ della chat */
function agMenuApri(){
  /* 0.9.257, Andrea: tre voci, non cinque. Nome, immagine, modello e documenti stanno in UNA pagina. */
  agFoglio(agFoglioRiga(agAvatarHtml('ag-av-r'), 'Personalizza il tuo agente personale', 'agFoglioChiudi(true);agPersApri()')
    + agFoglioRiga('grafico', agT('menu.consumi') || 'Consumi e spesa', 'agFoglioChiudi(true);agConsumiApri()')
    + agFoglioRiga('canali', agT('menu.canali') || 'Parla con il tuo agente personale anche su Telegram e WhatsApp', 'agFoglioChiudi(true);agCanaliApri()'));
}
function agPersApri(){
  goId('s-agente-pers');
  agPersPaint();
}
function agPersPaint(){
  const h = document.getElementById('agPersBody'); if (!h) return;
  const id = agIdentita();
  const mod = agModelloNome(agModelloScelta());
  h.innerHTML = '<div class="sect"><b>Chi è</b></div>'
    + '<button type="button" class="ag-pers-riga" onclick="agIdApri()">' + agAvatarHtml('ag-av-r') + '<span><b>' + agEsc(id.nome || 'Il tuo agente personale') + '</b><small>Nome e immagine</small></span>' + agSvg('avanti', 18) + '</button>'
    + '<div class="sect"><b>Come ragiona</b></div>'
    + '<button type="button" class="ag-pers-riga" onclick="agModelloApri(true)">' + agSvg('modello', 22) + '<span><b>' + agEsc(mod) + '</b><small>Il modello: veloce o più attento</small></span>' + agSvg('avanti', 18) + '</button>'
    + ((typeof rfSezioneHtml === 'function') ? rfSezioneHtml('agente', 'Cosa deve sapere', 'Un file .md con chi sei e cosa vuoi, o delle immagini: li legge prima di rispondere, come un dossier.') : '');
}
/* 0.9.256, Andrea: i documenti di riferimento (riferimenti.js) hanno la loro pagina, dal menu ⋯ */
function agRifApri(){
  goId('s-agente-rif');
  const h = document.getElementById('agRifBody');
  if (h && typeof rfSezioneHtml === 'function') h.innerHTML = rfSezioneHtml('agente', 'Documenti di riferimento', 'Un file .md con chi sei e cosa vuoi, o delle immagini: il tuo agente personale li legge prima di rispondere, come un dossier. Come in Claude Cowork.');
}

/* ---------------------------------------------------------------------------------------
   IL TESTO DELL'AGENTE IN MARKDOWN (0.9.219): grassetto, titoli, elenchi, a capo, link.
   Prima si fa l'escape dell'HTML, poi si aggiungono solo i tag che servono.
   --------------------------------------------------------------------------------------- */
function agMdInline(t){
  t = t.replace(/`([^`\n]+)`/g, '<code>$1</code>');
  t = t.replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, function(m, a, u){ return '<a href="' + u + '" onclick="return agLink(event,this)">' + a + '</a>'; });
  t = t.replace(/(^|[\s(])(https?:\/\/[^\s<)]+[^\s<).,;:!?])/g, function(m, p, u){ return p + '<a href="' + u + '" onclick="return agLink(event,this)">' + u + '</a>'; });
  t = t.replace(/\*\*([^*\n]+?)\*\*/g, '<b>$1</b>').replace(/__([^_\n]+?)__/g, '<b>$1</b>');
  t = t.replace(/(^|[^*\w])\*([^*\s][^*\n]*?)\*(?!\*)/g, '$1<i>$2</i>');
  return t;
}
function agMd(src){
  const righe = agEsc(typeof flAccenti === 'function' ? flAccenti(String(src == null ? '' : src)) : String(src == null ? '' : src)).replace(/\r/g, '').split('\n');
  let out = '', lista = '', para = [], codice = null;
  const chiudiPara = function(){ if (para.length){ out += '<p>' + para.map(agMdInline).join('<br>') + '</p>'; para = []; } };
  const chiudiLista = function(){ if (lista){ out += '</' + lista + '>'; lista = ''; } };
  righe.forEach(function(r){
    if (/^\s*```/.test(r)){
      if (codice){
        const c = codice.join('\n');
        if (!/&quot;(piano|scomponi|iofuturo)&quot;\s*:/.test(c)) out += '<pre>' + c + '</pre>';
        codice = null;
      } else { chiudiPara(); chiudiLista(); codice = []; }
      return;
    }
    if (codice){ codice.push(r); return; }
    let m;
    if ((m = /^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/.exec(r))){
      chiudiPara(); chiudiLista();
      out += '<div class="ag-h ag-h' + Math.min(m[1].length, 3) + '">' + agMdInline(m[2]) + '</div>';
      return;
    }
    if ((m = /^\s*[-*•+]\s+(.*)$/.exec(r))){
      chiudiPara();
      if (lista !== 'ul'){ chiudiLista(); out += '<ul>'; lista = 'ul'; }
      /* 0.9.290, Andrea: "dopo il pallino non ci devono essere le parentesi quadre" ("- [ ] ...") */
      out += '<li>' + agMdInline(m[1].replace(/^\[[ xX]?\]\s*/, '')) + '</li>';
      return;
    }
    if ((m = /^\s*(\d{1,3})[.)]\s+(.*)$/.exec(r))){
      chiudiPara();
      if (lista !== 'ol'){ chiudiLista(); out += '<ol' + (m[1] !== '1' ? ' start="' + Number(m[1]) + '"' : '') + '>'; lista = 'ol'; }
      out += '<li>' + agMdInline(m[2].replace(/^\[[ xX]?\]\s*/, '')) + '</li>';
      return;
    }
    if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(r)){ chiudiPara(); chiudiLista(); out += '<hr>'; return; }
    if (!r.trim()){ chiudiPara(); chiudiLista(); return; }
    chiudiLista();
    para.push(r.trim());
  });
  if (codice && codice.length){ const c = codice.join('\n'); if (!/&quot;(piano|scomponi|iofuturo)&quot;\s*:/.test(c)) out += '<pre>' + c + '</pre>'; }
  chiudiPara(); chiudiLista();
  return out;
}
/** Il testo senza i segni del markdown: per condividere la conversazione. */
function agMdTesto(src){
  return String(src || '').replace(/```[\s\S]*?```/g, '').replace(/^\s{0,3}#{1,6}\s+/gm, '').replace(/\*\*([^*\n]+?)\*\*/g, '$1')
    .replace(/__([^_\n]+?)__/g, '$1').replace(/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g, '$1 ($2)').replace(/^\s*[*+]\s+/gm, '• ').trim();
}
function agLink(e, a){
  try{ if (e) e.preventDefault(); }catch(_){ }
  const u = a && a.getAttribute('href');
  /* 0.9.290: un video di YouTube consigliato dal tuo agente personale si guarda dentro all'app, con il conto alla rovescia */
  const yt = /(?:youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/)|youtu\.be\/)([\w-]{11})/.exec(u || '');
  if (yt && typeof aiVideoId === 'function'){ try{ if (typeof AI !== 'undefined'){ AI.video = []; AI.query = AI.query || ''; } if (AG.pop && typeof agPopChiudi === 'function') agPopChiudi(true); }catch(_){ } aiVideoId(yt[1]); return false; }
  if (u && /^https?:\/\//.test(u)){ try{ window.open(u, '_blank'); }catch(_){ location.href = u; } }
  return false;
}

/* ---------------------------------------------------------------------------------------
   LE CONVERSAZIONI (0.9.214): il cassetto ☰ a sinistra, come le chat di ChatGPT.
   Il server tiene UN filo solo per utente (lo stesso di Telegram e WhatsApp): le conversazioni
   sono un'etichetta messa qui sul telefono. Ogni messaggio ha `ss` = l'id della sua
   conversazione; s.sess = [{ id, at, titolo? }], s.corrente = quella aperta.
   COMPATIBILITA': chi aveva gia' il filo unico lo ritrova intero come prima conversazione
   ('s0'). Un messaggio senza etichetta (scritto da un altro modulo, es. il tutorial della
   Mappa) va nella conversazione aperta; la risposta dell'agente va nella conversazione del
   messaggio a cui risponde (inReplyTo), anche se nel frattempo se n'e' aperta un'altra.
   --------------------------------------------------------------------------------------- */
const AG_MAX_MSGS = 400;
function agSessNorm(s){
  if (!s) return;
  if (!Array.isArray(s.msgs)) s.msgs = [];
  if (!Array.isArray(s.sess) || !s.sess.length){
    s.sess = [{ id: 's0', at: (s.msgs[0] && s.msgs[0].at) || Date.now() }];
    s.corrente = 's0';
  }
  if (!s.corrente || !s.sess.some(function(x){ return x.id === s.corrente; })) s.corrente = s.sess[s.sess.length - 1].id;
  s.msgs.forEach(function(m){ if (m && !m.ss) m.ss = s.corrente; });
  /* le conversazioni rimaste senza messaggi (tagliati dal tetto) spariscono, tranne quella aperta */
  if (s.sess.length > 1){
    const piene = {}; s.msgs.forEach(function(m){ if (m) piene[m.ss] = 1; });
    s.sess = s.sess.filter(function(x){ return piene[x.id] || x.id === s.corrente; });
  }
}
function agSessMsgs(id){
  const s = agStato(); const k = id || s.corrente;
  return s.msgs.filter(function(m){ return m && m.ss === k; });
}
/** Apre una conversazione nuova; se quella aperta e' ancora vuota la riusa. Torna l'id. */
function agSessNuova(titolo){
  const s = agStato();
  const cur = s.sess.filter(function(x){ return x.id === s.corrente; })[0];
  if (cur && !agSessMsgs(cur.id).length){
    cur.at = Date.now();
    if (titolo) cur.titolo = String(titolo).slice(0, 80); else delete cur.titolo;
    agSalva(); return cur.id;
  }
  const id = 's' + Date.now().toString(36);
  const x = { id: id, at: Date.now() };
  if (titolo) x.titolo = String(titolo).slice(0, 80);
  s.sess.push(x); s.corrente = id;
  agSalva();
  return id;
}
function agSessUltima(x){
  const l = agSessMsgs(x.id);
  return l.length ? Math.max.apply(null, l.map(function(m){ return m.at || 0; })) : (x.at || 0);
}
/** Le conversazioni con almeno un messaggio, la piu' recente in cima. */
function agSessLista(){
  const s = agStato();
  return s.sess.filter(function(x){ return agSessMsgs(x.id).length; })
    .map(function(x){ return { id: x.id, titolo: agSessTitolo(x), ultima: agSessUltima(x), fissata: !!x.fissata }; })
    .sort(function(a, b){ return b.ultima - a.ultima; });
}
function agSessTitolo(x){
  if (x.titolo) return x.titolo;
  const l = agSessMsgs(x.id);
  const primo = l.filter(function(m){ return m.direzione === 'in' && String(m.testo || '').trim(); })[0] || l[0];
  const t = primo ? String(primo.testo || '').replace(/\s+/g, ' ').trim() : '';
  if (t) return t.length > 60 ? t.slice(0, 58).trim() + '…' : t;
  return agT('conversazioni.del', { data: agSessData(x.at) }) || ('Conversazione del ' + agSessData(x.at));
}
const AG_MESI = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
function agSessData(t){ const d = new Date(t || Date.now()); return d.getDate() + ' ' + AG_MESI[d.getMonth()]; }
function agSessQuando(t){
  const d = new Date(t || Date.now()), oggi = new Date();
  const g = function(x){ return new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime(); };
  const diff = Math.round((g(oggi) - g(d)) / 86400000);
  if (diff === 0) return agOra(t);
  if (diff === 1) return agT('conversazioni.ieri') || 'Ieri';
  return agSessData(t) + (d.getFullYear() !== oggi.getFullYear() ? ' ' + d.getFullYear() : '');
}
function agSessApri(id){
  const s = agStato();
  if (!s.sess.some(function(x){ return x.id === id; })) return;
  s.corrente = id; agSalva();
  AG.vista = 'chat';
  agCassettoChiudi(true);
  agPaint();
}
/* il cassetto: si costruisce sul body (le schermate hanno un transform, e dentro un transform
   position:fixed non sta piu' fermo) e si toglie quando si chiude */
/* 0.9.219, come Gemini: in cima la ricerca (titolo e testo dei messaggi) e la matita per una
   conversazione nuova; le conversazioni fissate stanno sopra, sotto «Fissate». Un tocco apre,
   una pressione lunga (450 ms, dito o mouse) apre il menu dal basso: Condividi, Fissa,
   Rinomina, Elimina. */
function agCassettoApri(){
  agCassettoChiudi(true);
  const w = document.createElement('div');
  w.id = 'agCassetto'; w.className = 'ag-cas-w';
  w.innerHTML = '<aside class="ag-cas" role="dialog" aria-modal="true" aria-label="' + agEsc(agT('conversazioni.titolo') || 'Conversazioni') + '">'
    + '<div class="ag-cas-chi">' + agAvatarHtml('ag-av-s') + '<b>' + agEsc(agT('conversazioni.con', { nome: agNomeSoggetto() }) || agNomeSoggetto()) + '</b>'
    +   '<button type="button" class="ag-cas-altro" onclick="agCassettoChiudi(true);agMenuApri()" aria-label="Altre impostazioni del tuo agente personale">' + agSvg('altro', 20) + '</button></div>'
    + '<div class="ag-cas-t">'
    +   '<label class="ag-cas-cerca">' + agSvg('cerca', 18)
    +     '<input type="search" id="agCasQ" autocomplete="off" placeholder="' + agEsc(agT('conversazioni.cerca') || 'Cerca nelle conversazioni') + '" oninput="agCassettoLista()" aria-label="' + agEsc(agT('conversazioni.cerca') || 'Cerca nelle conversazioni') + '"></label>'
    + '</div>'
    + '<div class="ag-cas-lista" id="agCasLista"></div>'
    + '</aside>';
  w.addEventListener('click', function(e){ if (e.target === w) agCassettoChiudi(); });
  document.body.appendChild(w);
  agCassettoLista();
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
function agNorm(t){ return String(t || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/\s+/g, ' ').trim(); }
/** La lista del cassetto: filtrata dalla ricerca, con le fissate in cima. */
function agCassettoLista(){
  const host = document.getElementById('agCasLista'); if (!host) return;
  const s = agStato();
  const qEl = document.getElementById('agCasQ');
  const q = agNorm(qEl ? qEl.value : '');
  const tutte = agSessLista();
  const voce = function(x, frammento){
    const on = x.id === s.corrente && AG.vista === 'chat';
    return '<button type="button" class="ag-cas-i' + (on ? ' on' : '') + '" data-id="' + x.id + '">'
      + '<span class="ag-cas-i-t"><b>' + agEsc(x.titolo) + '</b>' + (x.fissata ? '<i class="ag-cas-pin" aria-label="' + agEsc(agT('conversazioni.fissata') || 'Fissata') + '">' + agSvg('fissa', 14) + '</i>' : '') + '</span>'
      + (frammento ? '<em>' + agEsc(frammento) + '</em>' : '')
      + '<small>' + agEsc(agSessQuando(x.ultima)) + '</small></button>';
  };
  let html = '';
  if (q){
    const trovate = [];
    tutte.forEach(function(x){
      if (agNorm(x.titolo).indexOf(q) >= 0){ trovate.push(voce(x, '')); return; }
      const m = agSessMsgs(x.id).filter(function(y){ return agNorm(y.testo).indexOf(q) >= 0; })[0];
      if (!m) return;
      const t = agMdTesto(m.testo).replace(/\s+/g, ' ');
      const i = agNorm(t).indexOf(q);
      const da = Math.max(0, i - 24);
      trovate.push(voce(x, (da > 0 ? '…' : '') + t.slice(da, da + 70).trim() + (t.length > da + 70 ? '…' : '')));
    });
    html = trovate.length ? trovate.join('') : '<p class="ag-cas-vuoto">' + agEsc(agT('conversazioni.cercaVuoto', { q: qEl.value.trim() }) || 'Le tue conversazioni non contengono queste parole.') + '</p>';
  } else if (!tutte.length){
    html = '<p class="ag-cas-vuoto">' + agEsc(agT('conversazioni.vuoto') || 'La prima conversazione parte dal campo qui sotto.') + '</p>';
  } else {
    const fisse = tutte.filter(function(x){ return x.fissata; });
    const altre = tutte.filter(function(x){ return !x.fissata; });
    if (fisse.length) html += '<div class="ag-cas-sez">' + agEsc(agT('conversazioni.fissate') || 'Fissate') + '</div>' + fisse.map(function(x){ return voce(x, ''); }).join('');
    if (altre.length) html += (fisse.length ? '<div class="ag-cas-sez">' + agEsc(agT('conversazioni.recenti') || 'Recenti') + '</div>' : '') + altre.map(function(x){ return voce(x, ''); }).join('');
  }
  host.innerHTML = html;
  host.querySelectorAll('.ag-cas-i').forEach(function(el){
    const id = el.getAttribute('data-id');
    agPressione(el, function(){ agSessApri(id); }, function(){ agSessMenu(id); });
  });
}
/**
 * Tocco e pressione lunga sullo stesso elemento (dito e mouse). Dopo una pressione lunga il
 * «click» che segue non apre la conversazione.
 */
function agPressione(el, tocco, lungo){
  let t = 0, x0 = 0, y0 = 0, fatto = false;
  const via = function(){ if (t){ clearTimeout(t); t = 0; } };
  const scatta = function(){ via(); if (fatto) return; fatto = true; try{ flVibra(18); }catch(_){ } el.classList.remove('premuto'); lungo(); };
  el.addEventListener('pointerdown', function(e){
    if (e.button > 0) return;
    fatto = false; x0 = e.clientX; y0 = e.clientY; via();
    el.classList.add('premuto');
    t = setTimeout(scatta, 450);
  });
  el.addEventListener('pointermove', function(e){ if (t && (Math.abs(e.clientX - x0) > 8 || Math.abs(e.clientY - y0) > 8)){ via(); el.classList.remove('premuto'); } });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function(n){ el.addEventListener(n, function(){ via(); el.classList.remove('premuto'); }); });
  el.addEventListener('contextmenu', function(e){ e.preventDefault(); if (!fatto) scatta(); });
  el.addEventListener('click', function(e){
    if (fatto){ e.preventDefault(); e.stopPropagation(); fatto = false; return; }
    tocco();
  });
}
function agCassettoChiudi(subito){
  const w = document.getElementById('agCassetto'); if (!w) return;
  w.id = '';
  if (subito === true){ w.remove(); return; }
  w.classList.remove('in');
  setTimeout(function(){ w.remove(); }, 240);
}
/** Il tasto indietro di Android chiude prima il foglio dal basso, poi il cassetto (nav.js). */
function agCassettoBack(){
  if (document.getElementById('agFoglio')){ agFoglioChiudi(); return true; }
  if (!document.getElementById('agCassetto')) return false;
  agCassettoChiudi(); return true;
}

/* ---- il menu di una conversazione (pressione lunga) ---- */
function agSessDi(id){ return agStato().sess.filter(function(x){ return x.id === id; })[0] || null; }
function agSessMenu(id){
  const x = agSessDi(id); if (!x) return;
  agFoglio('<p class="ag-fg-tit">' + agEsc(agSessTitolo(x)) + '</p>'
    + agFoglioRiga('condividi', agT('conversazioni.condividi') || 'Condividi conversazione', 'agSessCondividi(\'' + id + '\')')
    + agFoglioRiga(x.fissata ? 'sfissa' : 'fissa', x.fissata ? (agT('conversazioni.sfissa') || 'Togli dalle fissate') : (agT('conversazioni.fissa') || 'Fissa'), 'agSessFissa(\'' + id + '\')')
    + agFoglioRiga('matita', agT('conversazioni.rinomina') || 'Rinomina', 'agSessRinominaApri(\'' + id + '\')')
    + agFoglioRiga('cestino', agT('conversazioni.elimina') || 'Elimina', 'agSessEliminaChiedi(\'' + id + '\')', 'rosso'));
}
/** Il testo della conversazione, condiviso con l'aiuto del telefono (o copiato). */
async function agSessCondividi(id){
  const x = agSessDi(id); if (!x) return;
  agFoglioChiudi();
  const chi = agNomeSoggetto();
  const testo = agSessTitolo(x) + '\n\n' + agSessMsgs(id).map(function(m){
    return (m.direzione === 'in' ? (agT('conversazioni.io') || 'Io') : chi) + ': ' + agMdTesto(m.testo);
  }).join('\n\n');
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText){ await NATIVE.shareText({ text: testo, title: agSessTitolo(x) }); return; }
    if (navigator.share){ await navigator.share({ title: agSessTitolo(x), text: testo }); return; }
  }catch(_){ return; }
  try{ await navigator.clipboard.writeText(testo); if (typeof toast === 'function') toast(agT('conversazioni.copiata') || 'Conversazione copiata: incollala dove vuoi'); }catch(_){ }
}
function agSessFissa(id){
  const x = agSessDi(id); if (!x) return;
  x.fissata = !x.fissata; if (x.fissata) x.fissataAt = Date.now(); else delete x.fissataAt;
  agSalva();
  try{ flVibra(12); }catch(_){ }
  agFoglioChiudi();
  agCassettoLista();
  if (typeof toast === 'function') toast(x.fissata ? (agT('conversazioni.fissataOk') || 'Conversazione fissata in cima') : (agT('conversazioni.sfissataOk') || 'Conversazione tolta dalle fissate'));
}
function agSessRinominaApri(id){
  const x = agSessDi(id); if (!x) return;
  agFoglio('<p class="ag-fg-tit">' + agEsc(agT('conversazioni.rinominaTitolo') || 'Rinomina la conversazione') + '</p>'
    + '<input class="fin ag-fg-in" id="agRinomina" maxlength="80" autocomplete="off" value="' + agEsc(agSessTitolo(x).replace(/…$/, '')) + '" onkeydown="if(event.key===\'Enter\'){event.preventDefault();agSessRinomina(\'' + id + '\');}">'
    + '<div class="ag-fg-az"><button type="button" class="ag-fg-no" onclick="agFoglioChiudi()">' + agEsc(agT('foglio.annulla') || 'Annulla') + '</button>'
    + '<button type="button" class="ag-fg-si" onclick="agSessRinomina(\'' + id + '\')">' + agEsc(agT('foglio.salva') || 'Salva') + '</button></div>');
  setTimeout(function(){ const i = document.getElementById('agRinomina'); if (i){ try{ i.focus(); i.select(); }catch(_){ } } }, 80);
}
function agSessRinomina(id){
  const x = agSessDi(id); const i = document.getElementById('agRinomina'); if (!x || !i) return;
  const v = i.value.replace(/\s+/g, ' ').trim().slice(0, 80);
  if (v) x.titolo = v; else delete x.titolo;
  agSalva();
  agFoglioChiudi();
  agCassettoLista();
}
function agSessEliminaChiedi(id){
  const x = agSessDi(id); if (!x) return;
  agFoglio('<p class="ag-fg-tit">' + agEsc(agT('conversazioni.eliminaDomanda', { titolo: agSessTitolo(x) }) || 'Vuoi eliminare questa conversazione?') + '</p>'
    + '<p class="ag-fg-sotto">' + agEsc(agT('conversazioni.eliminaSotto') || 'I messaggi di questa conversazione spariscono da questo telefono.') + '</p>'
    + '<div class="ag-fg-az"><button type="button" class="ag-fg-no" onclick="agFoglioChiudi()">' + agEsc(agT('foglio.annulla') || 'Annulla') + '</button>'
    + '<button type="button" class="ag-fg-si rosso" onclick="agSessElimina(\'' + id + '\')">' + agEsc(agT('conversazioni.elimina') || 'Elimina') + '</button></div>');
}
function agSessElimina(id){
  const s = agStato();
  const eraAperta = s.corrente === id;
  s.msgs = s.msgs.filter(function(m){ return m && m.ss !== id; });
  s.sess = s.sess.filter(function(x){ return x.id !== id; });
  if (eraAperta){
    const l = agSessLista();
    if (l.length) s.corrente = l[0].id;
    else { const nid = 's' + Date.now().toString(36); s.sess.push({ id: nid, at: Date.now() }); s.corrente = nid; }
  }
  agSalva();
  try{ flVibra(20); }catch(_){ }
  agFoglioChiudi();
  agCassettoLista();
  if (eraAperta && document.getElementById('agBody')){ AG.vista = 'benvenuto'; agPaint(); }
  if (typeof toast === 'function') toast(agT('conversazioni.eliminata') || 'Conversazione eliminata');
}
/* «+ Nuova conversazione»: la pagina vuota del benvenuto, «Ciao, cosa hai in mente?» */
function agCassettoNuova(){
  agSessNuova();
  AG.vista = 'benvenuto';
  agCassettoChiudi(true);
  agPaint();
  setTimeout(function(){ const t = document.getElementById('agTesto'); if (t) try{ t.focus(); }catch(_){ } }, 60);
}
/** Dal benvenuto ogni messaggio apre una conversazione nuova (quella vuota si riusa). */
function agInviaNuova(testo, opz){
  if (AG.vista !== 'chat') agSessNuova();
  agInvia(testo, null, opz);
}
/**
 * La porta per gli altri moduli: apre la pagina dell'agente, comincia una conversazione NUOVA e
 * manda subito `testo` come messaggio dell'utente — niente campo precompilato, niente toast.
 * opz.titolo: il nome della conversazione nel cassetto (se manca, e' il testo stesso).
 * Torna true se il messaggio e' partito.
 */
async function agNuovaConversazione(testo, opz){
  opz = opz || {};
  testo = String(testo || '').trim();
  const s = agStato();
  if (!s.impostato){ await agApri(); return false; }       // prima si crea l'agente
  agPollFerma();
  agPopChiudi(true);
  goId('s-agente');
  agTitoloPaint();
  agCassettoChiudi(true);
  const id = agSessNuova(opz.titolo);
  AG.vista = 'chat';
  agPaint();
  if (!(await agAbilitato())){ if (typeof guidaApri === 'function') guidaApri(); return false; }
  agCrediti();
  if (!testo){ agSync(true); agPollAvvia(); return false; }
  /* un invio gia' in volo (AG.invio) farebbe cadere questo: si aspetta che finisca */
  const da = Date.now();
  while (AG.invio && Date.now() - da < 10000) await new Promise(function(ok){ setTimeout(ok, 150); });
  if (agStato().corrente !== id){ agStato().corrente = id; agSalva(); }
  AG.vista = 'chat';
  /* 0.9.261, Andrea: il messaggio NON parte da solo. Si scrive nel campo, l'utente lo legge, lo cambia se
     vuole, e lo manda lui con invio. Vale per tutte le porte che arrivano qui (Mappa, report settimanale,
     task, roadmap, rientro). 0.9.347: l'eccezione e' chi lo chiede con un pulsante che dice gia' cosa fa ("Scomponilo in passi",
     "Guarda un tutorial"): li' il pulsante e' l'invio (opz.invia) */
  if (opz.invia && typeof agInvia === 'function'){ try{ await agInvia(testo); return true; }catch(_){ } }
  agBozza(testo);
  return false;
}
/** Il messaggio pronto nel campo della chat, con il cursore in fondo: parte solo quando l'utente tocca invio. */
function agBozza(testo, campo){
  testo = String(testo || '');
  let n = 0;
  (function metti(){
    const t = document.getElementById(campo || 'agTesto');
    if (!t){ if (++n < 30) setTimeout(metti, 100); return; }
    t.value = testo;
    try{ agCampoCresce(t); }catch(_){ }
    try{ t.dispatchEvent(new Event('input', { bubbles: true })); }catch(_){ }
    try{ t.focus(); t.setSelectionRange(testo.length, testo.length); t.scrollTop = t.scrollHeight; }catch(_){ }
  })();
}

/* ---------------------------------------------------------------------------------------
   LA CHAT IN UN FOGLIO SOPRA LA PAGINA (0.9.219), come Notion AI: angoli tondi in alto, la
   maniglia, l'85% dell'altezza, in testa l'immagine e il nome dell'agente, la X e «Apri a
   tutto schermo». Comincia una conversazione NUOVA con `testo` gia' mandato, mostra la
   risposta (con il markdown e il pulsante «Applica la roadmap») e ha il campo per
   continuare. Chiudere riporta alla pagina sotto, intatta; il tasto indietro di Android
   chiude (nav.js -> agPopoverBack).
   opz.titolo: il nome della conversazione nel cassetto.
   Torna (Promise) true se il messaggio e' partito; false se l'agente non c'e' (chi chiama
   puo' allora fare la sua strada di riserva).
   --------------------------------------------------------------------------------------- */
async function agPopover(testo, opz){
  opz = opz || {};
  testo = String(testo || '').trim();
  if (!agPuo()){ if (typeof toast === 'function') toast(agT('chat.offline')); return false; }
  if (!(await agAbilitato())){ if (typeof guidaApri === 'function') guidaApri(); return false; }
  const s = agStato();
  /* chi non ha ancora creato l'agente parte dal Genio (il nome e l'immagine si cambiano dal menu ⋯) */
  if (!s.impostato && !(await agCreaSilenzioso())){ if (typeof toast === 'function') toast(agT('chat.errore')); return false; }
  const id = agSessNuova(opz.titolo);
  AG.pop = { id: id };
  agPopApri();
  agCrediti();
  if (!testo){ agSync(true); agPollAvvia(); return true; }
  /* 0.9.261, Andrea: anche qui il messaggio si scrive e basta: lo manda l'utente, dopo averlo letto o cambiato */
  agBozza(testo, 'agTesto');
  try{ agCompStato(); }catch(_){ }
  return true;
}
/** L'agente creato senza passare dalla sua pagina: con l'identita' scelta (di serie il Genio). */
async function agCreaSilenzioso(){
  try{ await agApi('POST', '/api/focuslock/agent/chat/profilo', { nome: agNomeAgente(), brief: agBrief() }); }
  catch(_){ return false; }
  const s = agStato(); s.nome = agNomeAgente(); s.impostato = true; agSalva();
  return true;
}
function agPopTestaHtml(){
  return agAvatarHtml('ag-av-p') + '<b class="ag-pop-nome">' + agEsc(agNomeSoggetto()) + '</b>'
    + '<button type="button" class="ag-pop-b" onclick="agPopTuttoSchermo()" aria-label="' + agEsc(agT('popover.tuttoSchermo') || 'Apri a tutto schermo') + '" title="' + agEsc(agT('popover.tuttoSchermo') || 'Apri a tutto schermo') + '">' + agSvg('espandi', 19) + '</button>'
    + '<button type="button" class="ag-pop-b" onclick="agPopChiudi()" aria-label="' + agEsc(agT('popover.chiudi') || 'Chiudi') + '" title="' + agEsc(agT('popover.chiudi') || 'Chiudi') + '">' + agSvg('chiudi', 20) + '</button>';
}
function agPopTesta(){ const h = document.getElementById('agPopTesta'); if (h) h.innerHTML = agPopTestaHtml(); const t = document.getElementById('agPopTesto'); if (t) t.placeholder = agT('popover.scrivi', { nome: agNomeA() }) || ('Rispondi ' + agNomeA() + '…'); }
function agPopApri(){
  agPopChiudi(true);
  agCompPaginaNomi(true);
  const w = document.createElement('div');
  w.id = 'agPop'; w.className = 'ag-pop-w';
  w.innerHTML = '<section class="ag-pop" role="dialog" aria-modal="true" aria-label="' + agEsc(agNomeSoggetto()) + '">'
    + '<div class="ag-pop-man" aria-hidden="true"></div>'
    + '<header class="ag-pop-h" id="agPopTesta">' + agPopTestaHtml() + '</header>'
    + '<div class="ag-pop-lista ag-lista" id="agPopLista"></div>'
    /* 0.9.263, Andrea: lo stesso riquadro della pagina del Genio (allegati, modello, microfono, invio) */
    + '<div class="ag-pop-comp">' + agComposerHtml(agT('popover.scrivi', { nome: agNomeA() }) || ('Rispondi ' + agNomeA() + '…')) + '</div>'
    + '</section>';
  w.addEventListener('click', function(e){ if (e.target === w) agPopChiudi(); });
  document.body.appendChild(w);
  agPopTrascina(w.querySelector('.ag-pop'), w.querySelector('.ag-pop-man'));
  agPopTrascina(w.querySelector('.ag-pop'), w.querySelector('.ag-pop-h'));
  agPopPaint();
  try{ agModBtnPaint(); }catch(_){ }   /* il selettore del modello, come nella pagina */
  try{ flVibra(12); }catch(_){ }
  requestAnimationFrame(function(){ w.classList.add('in'); });
}
/* trascinare la maniglia (o la testa) verso il basso chiude il foglio */
function agPopTrascina(foglio, presa){
  if (!foglio || !presa) return;
  let y0 = null, dy = 0;
  presa.addEventListener('pointerdown', function(e){ if (e.target.closest('button')) return; y0 = e.clientY; dy = 0; foglio.style.transition = 'none'; try{ presa.setPointerCapture(e.pointerId); }catch(_){ } });
  presa.addEventListener('pointermove', function(e){ if (y0 === null) return; dy = Math.max(0, e.clientY - y0); foglio.style.transform = 'translateY(' + dy + 'px)'; });
  const fine = function(){
    if (y0 === null) return;
    y0 = null; foglio.style.transition = ''; foglio.style.transform = '';
    if (dy > 110) agPopChiudi();
  };
  presa.addEventListener('pointerup', fine); presa.addEventListener('pointercancel', fine);
}
function agPopPaint(){
  const l = document.getElementById('agPopLista'); if (!l || !AG.pop) return;
  const msgs = agSessMsgs(AG.pop.id);
  const ultimo = msgs[msgs.length - 1];
  const aspetta = AG.attesa && ultimo && ultimo.direzione === 'in';
  l.innerHTML = msgs.map(agMsgHtml).join('') + (aspetta ? agPensaHtml() : '');
  /* una risposta nuova si legge dall'inizio (la spiegazione, poi la roadmap): si scorre fino
     al suo inizio, non in fondo */
  const risp = (ultimo && ultimo.direzione === 'out') ? l.querySelectorAll('.ag-m.lui') : null;
  const el = risp && risp.length ? risp[risp.length - 1] : null;
  l.scrollTop = el ? Math.max(0, el.offsetTop - l.offsetTop - 8) : l.scrollHeight;
}
/* Mentre la chat sopra e' aperta, il riquadro della pagina dell'agente (sotto) cambia nome ai suoi pezzi: cosi'
   allegati, microfono e invio lavorano su quello del popover. Chiuso il popover, i nomi tornano. */
const AG_COMP_ID = ['agComp', 'agAllBox', 'agTesto', 'agModBtn', 'agRecT', 'agMicBtn', 'agInviaBtn'];
function agCompPaginaNomi(nascondi){
  AG_COMP_ID.forEach(function(id){
    if (nascondi){ const e = document.getElementById(id); if (e && !e.closest('#agPop')) e.id = id + '_pag'; }
    else { const e = document.getElementById(id + '_pag'); if (e) e.id = id; }
  });
}
function agPopChiudi(subito){
  const w = document.getElementById('agPop'); if (!w) return;
  w.id = '';
  AG.pop = null;
  AG_COMP_ID.forEach(function(id){ const e = w.querySelector('#' + id); if (e) e.removeAttribute('id'); });
  agCompPaginaNomi(false);
  try{ agModBtnPaint(); }catch(_){ }
  if (subito === true){ w.remove(); return; }
  w.classList.remove('in');
  setTimeout(function(){ w.remove(); }, 260);
}
function agPopInvia(){
  if (document.querySelector('#agPop #agTesto')){ agInviaDaCampo(); return; }
  const t = document.getElementById('agPopTesto'); if (!t || !AG.pop) return;
  const v = t.value.trim(); if (!v) return;
  t.value = ''; agCampoCresce(t);
  agInvia(v, AG.pop.id);
}
/** «Apri a tutto schermo»: la stessa conversazione, nella pagina dell'agente. */
function agPopTuttoSchermo(){
  const id = AG.pop && AG.pop.id;
  agPopChiudi(true);
  const s = agStato();
  if (id && s.sess.some(function(x){ return x.id === id; })){ s.corrente = id; agSalva(); }
  goId('s-agente');
  agCassettoChiudi(true);
  AG.vista = 'chat';
  agTitoloPaint();
  agPaint();
  agPollAvvia();
}
/** Il tasto indietro di Android (nav.js): prima il foglio dal basso, poi la chat sopra la pagina. */
function agPopoverBack(){
  if (!document.getElementById('agPop')) return false;
  if (document.getElementById('agFoglio')){ agFoglioChiudi(); return true; }
  agPopChiudi(); return true;
}
/* 0.9.263, Andrea: come Claude. L'altezza di partenza resta quella; con tanto testo il campo cresce fino a
   circa meta' schermo (prima si fermava a 120 px e non si vedeva quello che si era scritto). */
function agCampoCresce(t){ if (!t) return; const max = Math.max(160, Math.round((window.visualViewport ? window.visualViewport.height : window.innerHeight) * 0.45)); t.style.height = 'auto'; t.style.height = Math.min(max, t.scrollHeight + 2) + 'px'; t.style.overflowY = t.scrollHeight + 2 > max ? 'auto' : 'hidden'; }

/* ---------------------------------------------------------------------------------------
   RIENTRA IN ROTTA CON PREMIUM (0.9.219): il questionario ha trovato la causa; l'agente
   rimette in piedi la roadmap partendo da quella. Il primo messaggio lo scrive l'app, come
   lo scriverebbe l'utente.
   dati = { giorni, causa, causaTesto, dettaglio, dettaglioTesto, testoLibero, task }
   --------------------------------------------------------------------------------------- */
function agRientroTesto(d){
  d = d || {};
  const pulito = function(x, n){ return String(x == null ? '' : x).replace(/\s+/g, ' ').trim().slice(0, n || 300); };
  const r = [];
  let g = '';
  if (typeof d.giorni === 'number' && d.giorni > 0) g = d.giorni === 1 ? 'un giorno' : Math.round(d.giorni) + ' giorni';
  else if (typeof d.giorni === 'string' && d.giorni.trim()) g = pulito(d.giorni, 40);
  r.push(g ? 'Negli ultimi giorni ho perso il ritmo: la mia data di arrivo si è spostata di ' + g + '.' : 'Negli ultimi giorni ho perso il ritmo del mio percorso.');
  if (pulito(d.task)) r.push('La cosa che dovevo fare era: «' + pulito(d.task, 200) + '».');
  /* 0.9.221: il rientro col Genio manda cosa ha visto l'app, cosa mi ha portato fuori strada,
     la contromisura scelta e il patto «se… allora…» */
  if (pulito(d.causaTesto)) r.push('Ecco cosa ha visto l’app: ' + pulito(d.causaTesto, 600));
  const dt = pulito(d.dettaglioTesto, 600);
  if (dt) r.push('Cosa mi ha portato fuori strada: «' + dt + '».');
  if (pulito(d.testoLibero)) r.push('Con parole mie: «' + pulito(d.testoLibero, 2000) + '».');
  if (pulito(d.contromisura)) r.push('Da domani ho deciso: «' + pulito(d.contromisura, 300) + '».');
  if (pulito(d.patto)) r.push('Il mio patto: «' + pulito(d.patto, 400) + '».');
  r.push('Ricalcola la mia roadmap partendo da questo.');
  r.push('Prima spiegami in poche righe cosa cambi e perché. Poi dammi la roadmap aggiornata da applicare: i passi di oggi e di questa settimana devono tenere conto di quello che mi ha fermato.');
  return r.join(' ');
}
async function agRientro(dati){
  dati = dati || {};
  try{ if (String(dati.testoLibero || '').trim()) agRientroImpara(dati.causa, dati.testoLibero); }catch(_){ }
  return agPopover(agRientroTesto(dati), { titolo: agT('rientro.titolo') || 'Rientra in rotta' });
}
/* IL GENIO IMPARA LE CAUSE (come Akinator): le cause scritte a mano vanno al server, e quelle
   scritte da almeno tre persone tornano come risposte pronte per tutti. Nessun account: un
   id casuale del telefono. */
function agDevice(){
  try{ if (typeof frDevice === 'function' && frDevice()) return frDevice(); }catch(_){ }
  let d = ''; try{ d = localStorage.getItem('fl_genio_dev') || ''; }catch(_){ }
  if (!d){ d = 'd' + Math.random().toString(36).slice(2) + Date.now().toString(36); try{ localStorage.setItem('fl_genio_dev', d); }catch(_){ } }
  return d;
}
async function agPubblica(method, path, body){
  if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.publicApi) return NATIVE.publicApi({ method: method, path: path, body: body ? JSON.stringify(body) : '' });
  const base = (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app';
  const r = await fetch(base + path, { method: method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  return r.ok ? r.json() : null;
}
/** Manda una causa scritta a mano. causa = la chiave della categoria (app, stanco, idee, …). */
function agRientroImpara(causa, testo){
  const t = String(testo || '').replace(/\s+/g, ' ').trim().slice(0, 200);
  if (!t) return Promise.resolve(false);
  return agPubblica('POST', '/api/focuslock/rientro/causa', { device: agDevice(), causa: String(causa || 'altro').slice(0, 24), testo: t })
    .then(function(){ return true; }, function(){ return false; });
}
/** Le cause scritte piu' spesso dagli altri, per categoria: [{ causa, testo, n }]. Tenute un giorno. */
async function agRientroCause(){
  const K = 'fl_rientro_cause';
  let c = null; try{ c = JSON.parse(localStorage.getItem(K) || 'null'); }catch(_){ c = null; }
  if (c && Array.isArray(c.cause) && Date.now() - (c.at || 0) < 86400000) return c.cause;
  try{
    const r = await agPubblica('GET', '/api/focuslock/rientro/cause');
    const cause = (r && Array.isArray(r.cause)) ? r.cause : [];
    try{ localStorage.setItem(K, JSON.stringify({ at: Date.now(), cause: cause })); }catch(_){ }
    return cause;
  }catch(_){ return (c && c.cause) || []; }
}

/* ---- chi ce l'ha: lo dice il server, e si ricorda per sei ore ---- */
function agAbilCache(){ return AG.abil || agLeggi('abil', null); }
function agAbilitatoOra(){ const c = agAbilCache(); return !!(c && c.enabled); }
async function agAbilitato(forza){
  if (!agPuo()) return false;
  const c = agAbilCache();
  if (!forza && c && Date.now() - (c.at || 0) < AG_ABIL_MS) return !!c.enabled;
  try{
    const r = await agApi('GET', '/api/focuslock/agent/chat/enabled');
    AG.abil = { enabled: !!(r && r.enabled), telegramBot: (r && r.telegramBot) || '', whatsappNumero: (r && r.whatsappNumero) || '', at: Date.now() };
    agScrivi('abil', AG.abil);
    return AG.abil.enabled;
  }catch(_){ return !!(c && c.enabled); }
}

/* ---------------------------------------------------------------------------------------
   IL BRIEF: quello che l'agente sa, composto dalle stesse cose che l'utente vede
   --------------------------------------------------------------------------------------- */
function agDati(){
  const d = {};
  try{ const g = (typeof gnDati === 'function') ? gnDati() : {}; d.nome = g.nome || ''; d.quando = g.scadenzaTxt || ''; d.target = g.target || ''; }catch(_){ }
  try{ const L = (typeof gnLettura === 'function') ? gnLettura() : null; if (L){ d.sogno = L.sogno || ''; d.profilo = (L.prof && L.prof.name) || ''; d.pct = L.pct || 0; d.modalita = L.modalita || ''; } }catch(_){ }
  try{ if (!d.target){ const o = (typeof orLast === 'function') ? orLast() : null; d.target = (o && o.target) || ''; } }catch(_){ }
  try{ d.tipo = (typeof orTargetName === 'function' && d.target) ? orTargetName(d.target) : ''; }catch(_){ }
  try{ const r = (typeof rtStato === 'function') ? rtStato() : null; if (r && r.a){ const n = function(x){ return x ? (typeof x === 'string' ? x : (x.nome || x.n || x.name || '')) : ''; }; d.da = n(r.da); d.a = n(r.a); } }catch(_){ }
  try{ const p = (typeof etaPiano === 'function') ? etaPiano() : null; if (p){ d.ore = p.oreSettimana; d.giorni = p.nGiorni; d.modalita = d.modalita || p.modalita; } }catch(_){ }
  try{ const s = (typeof ETA !== 'undefined' && ETA && ETA.stato) ? ETA.stato : null; if (s && isFinite(s.p50)){ d.arrivo = (typeof etaDataTxt === 'function') ? etaDataTxt(s.p50) : ''; d.pctVia = Math.round((s.pct || 0) * 100); d.R = Math.round(s.R || 0); d.rate = Math.round((s.rate || 0) * 100) / 100; d.calib = !!s.calibrazione; } }catch(_){ }
  try{
    const oz = (typeof ozLeggi === 'function') ? ozLeggi() : {};
    d.orizzonti = AG_ANELLI.concat(['ungiorno']).map(function(k){ const a = oz[k]; if (!a || (!a.testo && !(a.passi || []).length)) return null;
      return { k: k, testo: a.testo || '', passi: (a.passi || []).map(function(p){ return (p.fatto ? '✓ ' : '· ') + (p.t || ''); }) }; }).filter(Boolean);
  }catch(_){ d.orizzonti = []; }
  try{ const day = (typeof stDayKey === 'function') ? stDayKey('today') : ''; d.righe = (typeof stRigheDi === 'function' && day) ? stRigheDi(day).map(function(r){ return ((typeof stIsDone === 'function' && stIsDone(r, day)) ? '✓ ' : '· ') + r; }) : []; }catch(_){ d.righe = []; }
  try{
    const h = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [];
    const da = Date.now() - 7 * 86400000;
    const rec = h.filter(function(x){ return x && x.ok && x.at >= da; });
    d.sessioni = rec.length; d.minuti = Math.round(rec.reduce(function(a, x){ return a + (x.spentMs || 0) / 60000; }, 0));
    /* 0.9.315: le note scritte a fine sessione, le ultime dieci */
    d.noteSessioni = h.filter(function(x){ return x && x.nota; }).slice(-10).map(function(x){
      return new Date(x.at).toLocaleDateString('it-IT') + ', ' + Math.round((x.spentMs || 0) / 60000) + ' min' + (x.ok ? '' : ' (mollata)') + (x.intent ? ', ' + x.intent : '') + ': ' + x.nota;
    });
  }catch(_){ }
  try{ d.lingua = (typeof flLingua === 'function') ? flLingua() : 'it'; }catch(_){ d.lingua = 'it'; }
  try{ d.freni = (typeof bqPerAgente === 'function') ? bqPerAgente() : ''; }catch(_){ }
  try{ d.rimpianto = (typeof rfPerAgente === 'function') ? rfPerAgente() : ''; }catch(_){ }
  try{ d.ritmo = (typeof rstPerAgente === 'function') ? rstPerAgente() : ''; }catch(_){ }
  try{ d.uscite = (typeof rnPerAgente === 'function') ? rnPerAgente() : ''; }catch(_){ }
  return d;
}
/* 0.9.322, Andrea: "al posto di Cosa faccio oggi: una pill che incrocia i dati e capisce quando rendo di piu', con un questionario sul
   cronotipo e un master plan della giornata". Qui i fatti, gia' contati: il modello li incrocia. */
function agQuandoRendo(){
  const r = [];
  try{
    const lista = JSON.parse(localStorage.getItem('fl_ff_hist') || '[]') || [], da = Date.now() - 30 * 86400000;
    const h = lista.filter(function(x){ return x && x.at >= da && !x.meditazione; });
    const fasce = [['5-9', 5, 9], ['9-12', 9, 12], ['12-15', 12, 15], ['15-18', 15, 18], ['18-21', 18, 21], ['21-24', 21, 24]];
    const f = fasce.map(function(b){ const l = h.filter(function(x){ const o = new Date(x.start || x.at).getHours(); return o >= b[1] && o < b[2]; }); return l.length ? b[0] + ': ' + l.filter(function(x){ return x.ok; }).length + ' finite su ' + l.length : ''; }).filter(Boolean);
    if (f.length) r.push('Sessioni di Full Focus per fascia oraria, ultimi 30 giorni: ' + f.join('; '));
    const giorni = JSON.parse(localStorage.getItem('fl_dopa_giorni_v2') || '{}') || {}, chiavi = Object.keys(giorni).sort().slice(-14);
    if (chiavi.length) r.push('Carburante a fine giornata, ultimi giorni: ' + chiavi.map(function(k){ return k.slice(5) + '=' + Math.round(giorni[k].fine || 0); }).join(', '));
    if (typeof umTutti === 'function'){ const u = umTutti(), k = Object.keys(u).sort().slice(-14).filter(function(x){ return u[x] && u[x].sodd; }); if (k.length) r.push('Umore della giornata da 1 a 5: ' + k.map(function(x){ return x.slice(5) + '=' + u[x].sodd; }).join(', ')); }
  }catch(_){ }
  if (!r.length) return '';
  return 'QUANDO RENDO DI PIU (dati veri dell\'app):\n' + r.join('\n')
    + '\nSe chiedo di aumentare la mia produttivita\': incrocia questi dati con la mia giornata e, se non conosci il mio cronotipo, fammi prima poche domande una alla volta (a che ora mi sveglierei senza sveglia, quando mi sento piu\' lucido, quando crollo) per capire se sono leone, orso, lupo o delfino. Poi proponi un piano della giornata ora per ora: cosa fare in quale fascia e perche\'.';
}
/* 0.9.335, Andrea: "chiede a che ora ti sei svegliato oggi, ma l'app lo traccia gia': e' stupido". La notte la misura il
   motore del sonno (sonno.js): l'ora del risveglio va nel brief, con l'ordine di non chiederla. */
function agSvegliaTesto(){
  try{
    const d0 = new Date(); d0.setHours(0, 0, 0, 0); const k = d0.getTime();
    if (typeof snNotteDi === 'function') snNotteDi(k).catch(function(){ });
    const m = (typeof SN_MEM !== 'undefined') ? SN_MEM[String(k)] : null, n = m && m.n;
    if (!(n && n.ok && n.sveglia && n.inizio)) return 'ORA DEL RISVEGLIO: il telefono stanotte non l’ha misurata. Se ti serve, chiedila una volta sola.';
    const hm = function(t){ const x = new Date(t); return String(x.getHours()).padStart(2, '0') + ':' + String(x.getMinutes()).padStart(2, '0'); };
    const min = Math.round((n.sveglia - n.inizio) / 60000);
    return 'SONNO DI STANOTTE (lo misura il telefono): a letto alle ' + hm(n.inizio) + ', sveglio alle ' + hm(n.sveglia) + ', ' + Math.floor(min / 60) + ' ore e ' + (min % 60) + ' minuti. NON chiedere a che ora si è svegliato o quanto ha dormito: lo sai già, usalo. Puoi chiedere solo come si sentiva.';
  }catch(_){ return ''; }
}
function agBrief(){
  const d = agDati();
  const r = [];
  const qr = agQuandoRendo(); if (qr) r.push(qr);
  try{ const sv = agSvegliaTesto(); if (sv) r.push(sv); }catch(_){ }
  try{ if (typeof CLO_FORMATO !== 'undefined') r.push(CLO_FORMATO); }catch(_){ }
  try{ const pn = (typeof pntBriefTesto === 'function') ? pntBriefTesto() : ''; if (pn) r.push(pn); }catch(_){ }
  try{ const st = (typeof ffStimeTesto === 'function') ? ffStimeTesto() : ''; if (st) r.push(st); }catch(_){ }
  const ctx = String(agStato().contesto || '').trim();
  if (ctx) r.push('QUELLO CHE MI HA CHIESTO DI SAPERE (vale piu’ di tutto il resto: la roadmap deve tenerne conto):\n' + ctx.slice(0, 4000));
  try{ const rif = (typeof rfTesto === 'function') ? rfTesto('agente', 20000) : ''; if (rif) r.push('DOCUMENTI DI RIFERIMENTO CHE MI HA DATO (li ha scritti lui: valgono come sua voce):\n' + rif); }catch(_){ }
  if (d.nome) r.push('Nome: ' + d.nome);
  if (d.sogno) r.push('Sogno: ' + d.sogno + (d.tipo ? ' (tipo: ' + d.tipo + ')' : ''));
  /* 0.9.307: le risposte del livello dell'Io Futuro, con l'ordine di importanza scelto dall'utente (io-futuro-livello.js) */
  try{ const nf = (typeof nfPerAgente === 'function') ? nfPerAgente() : ''; if (nf) r.push(nf); }catch(_){ }
  if (d.a) r.push('Destinazione (rotta): ' + (d.da ? d.da + ' → ' : '') + d.a);
  if (d.quando) r.push('Entro quando vorrebbe arrivare: ' + d.quando);
  if (d.profilo) r.push('Profilo del Genio: ' + d.profilo + (d.pct ? ' (' + d.pct + '% di probabilita’ stimata)' : ''));
  if (d.ore) r.push('Ore a settimana pianificate: ' + d.ore + ' su ' + d.giorni + ' giorni; modalita’ ' + (d.modalita || 'normale'));
  if (typeof d.sessioni === 'number') r.push('Sessioni di concentrazione negli ultimi 7 giorni: ' + d.sessioni + ' (' + d.minuti + ' min)');
  try{
    const g = (typeof gfGusti === 'function') ? gfGusti() : null;
    if (g && g.opere && g.opere.length) r.push('Film e libri di cui ha parlato con il Genio, e cosa ha scelto di fare:\n' + g.opere.slice(-5).map(function(x){ return x.t + ': ' + (x.azione || ''); }).join('\n'));
  }catch(_){ }
  if (d.noteSessioni && d.noteSessioni.length) r.push('Note scritte a fine sessione, usale per capire come aiutarlo:\n' + d.noteSessioni.join('\n'));
  /* 0.9.344, Andrea: "nella prima settimana la data non si vede, eppure il Genio fa gia' la previsione" */
  let velata = false; try{ velata = (typeof evVelata === 'function') && evVelata(); }catch(_){ }
  try{ r.push('IL PONTE CON LE ALTRE AI: ' + ((typeof pntOn === 'function' && pntOn()) ? 'acceso (i resoconti delle sue AI arrivano qui sotto quando ne scrivono).' : 'spento. Si accende da "Legati all’albero maestro", interruttore "Fai sapere al Genio cosa fai".')); }catch(_){ }
  if (velata) r.push('LA DATA DI ARRIVO NON È ANCORA VISIBILE PER LUI: il Genio sta imparando le sue abitudini' + ((typeof evGiorniMancanti === 'function' && evGiorniMancanti() > 0) ? ' (mancano ' + evGiorniMancanti() + ' giorni)' : '') + '. Non dirgli nessuna data di arrivo e nessuna previsione di anticipo o ritardo.');
  else if (d.arrivo) r.push('Arrivo stimato dal navigatore: ' + d.arrivo + ' (' + d.pctVia + '% del percorso, ' + d.R + ' ore di strada; esecuzione media ' + d.rate + (d.calib ? ', ancora in calibrazione' : '') + ')');
  if (d.orizzonti && d.orizzonti.length){
    r.push('Orizzonti gia’ scritti:');
    d.orizzonti.forEach(function(o){ r.push('  [' + o.k + '] ' + o.testo + (o.passi.length ? ' | passi: ' + o.passi.join('; ') : '')); });
  } else r.push('Orizzonti: nessuno scritto.');
  if (d.righe && d.righe.length) r.push('Righe del foglio di oggi: ' + d.righe.join('; '));
  /* 0.9.212: la radiografia del paradigma, il rimpianto da evitare, il ritmo e le uscite di rotta
     (prima stavano in agDati ma non arrivavano mai all'agente) */
  if (d.freni) r.push('Paradigma (radiografia iniziale, sfida «Indovina il mio sabotatore»): ' + d.freni);
  if (d.rimpianto) r.push(d.rimpianto);
  if (d.ritmo) r.push('Ritmo: ' + d.ritmo);
  if (d.uscite) r.push(d.uscite + ' Usale per capire lo schema e proporre blocchi o programmi che lo rendano impossibile.');
  /* 0.9.273: le scelte dell'effetto farfalla e la seconda chance: se la strada scelta non funziona, l'agente propone di cambiarla */
  try{ const fa = (typeof faContestoAgente === 'function') ? faContestoAgente() : ''; if (fa) r.push(fa); }catch(_){ }
  r.push('Lingua dell’app: ' + (d.lingua || 'it'));
  return r.join('\n').slice(0, 12000);
}

/* ---------------------------------------------------------------------------------------
   LA PAGINA
   --------------------------------------------------------------------------------------- */
if (typeof registerScreen === 'function'){
  registerScreen('s-agente',
    /* 0.9.252, Andrea: il pulsante Indietro sta da solo in alto; sotto, da sinistra, le tre
       lineette al bordo, il nome dell'agente e i tre puntini. La scelta del modello non sta
       qui: sta nel pannello della chat, accanto al +. */
    /* 0.9.281, Andrea: una riga sola, piu' spazio per la chat. A sinistra le tre lineette (dove stava la freccia
       indietro), poi il Genio, a destra la X che chiude la pagina. Si torna indietro anche con il tasto del telefono.
       I tre puntini stanno nel cassetto delle conversazioni. */
    '<div class="ag-hd ag-hd1">'
    + '<button type="button" class="iconbtn ag-menu" id="agMenuBtn" onclick="agCassettoApri()" aria-label="Conversazioni" hidden>' + agSvg('menu', 20) + '</button>'
    + '<b class="blk-title" id="agTitolo">Il tuo agente personale</b>'
    + '<button type="button" class="iconbtn ag-chiudi" onclick="agChiudiPagina()" aria-label="Chiudi">' + agSvg('chiudi', 20) + '</button></div>'
    + '<div id="agBody" class="ag-page"></div>', { back: function(){ if (agStato().impostato && AG.vista === 'chat'){ AG.vista = 'benvenuto'; agPaint(); return null; } agPollFerma(); return 's-home'; } });
  registerScreen('s-agente-id',
    '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-agente-pers\');agPersPaint()" aria-label="Indietro">' + agSvg('indietro', 20) + '</button><b class="blk-title">Chi è il tuo agente personale</b></div>'
    + '<div id="agIdPag" class="dp-page ag-id-pag"></div>', { back: 's-agente-pers' });
  registerScreen('s-agente-id-mio',
    '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-agente-id\');agIdApri()" aria-label="Indietro">' + agSvg('indietro', 20) + '</button><b class="blk-title">Nome e immagine</b></div>'
    + '<div id="agIdMioPag" class="dp-page ag-id-pag-mio"></div>', { back: 's-agente-id' });
  registerScreen('s-agente-pers',
    '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-agente\')" aria-label="Indietro">' + agSvg('indietro', 20) + '</button><b class="blk-title">Personalizza il tuo agente personale</b></div>'
    + '<div id="agPersBody" class="dp-page"></div>', { back: 's-agente' });
  registerScreen('s-agente-rif',
    '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-agente\')" aria-label="Indietro">' + agSvg('indietro', 20) + '</button><b class="blk-title">Documenti di riferimento</b></div>'
    + '<div id="agRifBody" class="dp-page"></div>', { back: 's-agente' });
  registerScreen('s-agente-consumi',
    '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-agente\')" aria-label="Indietro">' + agSvg('indietro', 20) + '</button><b class="blk-title" id="agConsTitolo">Consumi e spesa</b></div>'
    + '<div id="agConsBody" class="dp-page ag-cons"></div>', { back: 's-agente' });
  registerScreen('s-agente-canali',
    '<div class="topbar"><button class="iconbtn" onclick="goId(\'s-agente\')" aria-label="Indietro">' + agSvg('indietro', 20) + '</button><b class="blk-title" id="agCanTitolo">Dove parlargli</b></div>'
    + '<div id="agCanBody" class="dp-page"></div>', { back: 's-agente' });
}
function agChiudiPagina(){
  agPollFerma();
  if (AG.mic && AG.mic.on) agMicAnnulla();
  agCassettoChiudi(true);
  AG.vista = 'benvenuto';
  agTornaDovEri();
}
/* 0.9.290, Andrea: "chiudo la chat con la X e mi ritrovo in cima alla Roadmap". Si torna alla pagina e alla scheda da
   cui si era arrivati; la scheda rimette da sola il punto in cui l'avevi lasciata (nav.js, NAV_SCROLL). */
function agTornaDovEri(){
  let e = null; try{ e = NAV_STORIA.length ? NAV_STORIA[NAV_STORIA.length - 1] : null; }catch(_){ }
  if (e && e.s && e.s !== 's-home' && e.s !== 's-agente'){ try{ NAV_INDIETRO = true; goId(e.s); }finally{ NAV_INDIETRO = false; } try{ NAV_STORIA.pop(); }catch(_){ } return; }
  const tab = (e && e.tab) || (typeof navTabOra === 'function' && navTabOra()) || 'mappa';
  goId('s-home'); if (typeof switchTab === 'function') switchTab(tab);
}
function agIndietro(){
  agPollFerma();
  if (AG.mic && AG.mic.on) agMicAnnulla();
  agCassettoChiudi(true);
  /* dalla conversazione si torna al benvenuto; dal benvenuto (o dalla creazione) alla Roadmap */
  if (agStato().impostato && AG.vista === 'chat'){ AG.vista = 'benvenuto'; agPaint(); return; }
  agTornaDovEri();
}
async function agApri(){
  agPopChiudi(true);
  goId('s-agente');
  agCassettoChiudi(true);
  AG.vista = 'benvenuto';
  agTitoloPaint();
  agPaint();
  if (!(await agAbilitato())){ if (typeof guidaApri === 'function') guidaApri(); return; }
  agCrediti();
  agModelloCarica();
  if (agStato().impostato){ agSync(true); agPollAvvia(); }
}
/** Il saldo dei messaggi: per chi non ha un conto illimitato si vede sotto al campo. */
async function agCrediti(){
  try{ AG.crediti = await agApi('GET', '/api/focuslock/agent/chat/crediti'); }catch(_){ AG.crediti = null; }
  const el = document.getElementById('agSaldo');
  if (el) el.outerHTML = agSaldoHtml();
}
function agSaldoHtml(){
  const c = AG.crediti;
  if (!c || c.illimitato) return '<p id="agSaldo" hidden></p>';
  return '<p id="agSaldo" class="ag-saldo">' + agEsc(c.saldo > 0 ? agT('crediti.saldo', { n: c.saldo }) : agT('crediti.finiti')) + '</p>';
}
function agPaint(){
  const host = document.getElementById('agBody');
  if (!host) return;
  const s = agStato();
  host.classList.toggle('benvenuto', !!s.impostato && AG.vista !== 'chat');
  /* 0.9.280, Andrea: dentro una conversazione niente tre lineette, e il nome sta sulla riga del pulsante indietro:
     piu' spazio per leggere. Le tre lineette restano nella pagina iniziale delle conversazioni. */
  /* le tre lineette ci sono sempre quando l'agente e' creato: aprono le conversazioni */
  const menu = document.getElementById('agMenuBtn'); if (menu) menu.hidden = !s.impostato;
  agTitoloPaint();
  /* 0.9.242: ridisegnare la pagina non deve buttare quello che stavi scrivendo o dettando */
  const prima = document.getElementById('agTesto');
  const bozza = prima ? prima.value : '';
  host.innerHTML = !s.impostato ? agSetupHtml() : (AG.vista === 'chat' ? agChatHtml() : agBenvenutoHtml());
  if (bozza){ const t = document.getElementById('agTesto'); if (t){ t.value = bozza; agCampoCresce(t); } }
  if (s.impostato && AG.vista === 'chat') agScorri();
  agModBtnPaint();
}
/* ---- il primo incontro: cosa sa, il nome, e via ---- */
function agSetupHtml(){
  const d = agDati();
  const pronto = !!(d.sogno || d.profilo);
  const R = agT('setup.righe') || {};
  const riga = function(k, v){ return '<div class="ag-sa-r"><small>' + (R[k] || k) + '</small><b>' + (v ? agEsc(v) : (R.vuoto || 'Non ancora')) + '</b></div>'; };
  if (!AG.idBozza) AG.idBozza = agIdentita();
  return '<div class="ag-setup">'
    + '<div class="ag-hero">🧞</div>'
    + '<h2>' + agT('setup.titolo') + '</h2><p>' + agT('setup.sotto') + '</p>'
    + '<div class="sect"><b>' + agT('setup.sa') + '</b></div>'
    + '<div class="ag-sa">'
    +   riga('nome', d.nome) + riga('sogno', d.sogno) + riga('dest', d.a ? (d.da ? d.da + ' → ' : '') + d.a : '') + riga('quando', d.quando)
    +   riga('profilo', d.profilo) + riga('piano', d.ore ? d.ore + ' ore in ' + d.giorni + ' giorni' : '') + riga('arrivo', d.arrivo || '')
    +   riga('orizzonti', d.orizzonti && d.orizzonti.length ? d.orizzonti.length + '' : '')
    + '</div>'
    + (pronto
        ? '<div class="sect"><b>' + agEsc(agT('identita.domanda') || 'Con chi vuoi parlare?') + '</b></div>'
          + '<div id="agIdBox">' + agIdHtml() + '</div>'
          + '<label class="ag-nome"><span>' + agT('setup.contesto') + '</span><textarea class="fin ag-ctx" id="agCtx" rows="4" maxlength="4000" placeholder="' + agEsc(agT('setup.contestoEsempio')) + '">' + agEsc(agStato().contesto || '') + '</textarea></label>'
          + '<button type="button" class="cta" id="agCrea" onclick="agCrea()">' + agT('setup.crea') + '</button>'
        : '<p class="hintline">' + agT('setup.manca') + '</p><button type="button" class="cta" onclick="goId(\'s-home\');switchTab(\'severa\')">' + agT('setup.vaiGenio') + '</button>')
    + '</div>';
}
async function agCrea(){
  if (!agIdBozzaOk()) return;
  agIdScrivi(AG.idBozza || agIdentita());
  AG.idBozza = null;
  const nome = agNomeAgente();
  const cx = document.getElementById('agCtx'); if (cx){ agStato().contesto = cx.value.trim().slice(0, 4000); agSalva(); }
  const btn = document.getElementById('agCrea'); if (btn){ btn.disabled = true; btn.textContent = agT('setup.creando'); }
  if (!agPuo()){ if (typeof toast === 'function') toast(agT('chat.offline')); if (btn){ btn.disabled = false; btn.textContent = agT('setup.crea'); } return; }
  try{
    await agApi('POST', '/api/focuslock/agent/chat/profilo', { nome: nome, brief: agBrief() });
  }catch(_){
    if (typeof toast === 'function') toast(agT('chat.errore'));
    if (btn){ btn.disabled = false; btn.textContent = agT('setup.crea'); }
    return;
  }
  const s = agStato(); s.nome = nome; s.impostato = true; agSalva();
  AG.vista = 'chat';
  agTitoloPaint();
  agPaint();
  agInvia(agT('setup.primo'));
  agPollAvvia();
}
/* ---- la chat ---- */
function agOra(t){ const x = new Date(t || Date.now()); return String(x.getHours()).padStart(2, '0') + ':' + String(x.getMinutes()).padStart(2, '0'); }
function agPianoHtml(piano, id){
  const A = agT('anelli') || {};
  const righe = AG_ANELLI.filter(function(k){ return piano[k] && piano[k].testo; });
  if (!righe.length) return '';
  return '<div class="jd-piano ag-piano"><div class="jd-top"><span>🧭</span><b>' + agT('chat.roadmap') + '</b></div>'
    + '<p class="jd-piano-sub">' + agT('chat.roadmapSotto') + '</p>'
    /* 0.9.222: un orizzonte per riga, e i suoi passi chiusi dentro un elenco che si apre.
       Tutti i passi di tutti gli orizzonti insieme erano un muro: Andrea, «l'utente va in tilt». */
    + righe.slice().reverse().map(function(k){ const x = piano[k]; const passi = Array.isArray(x.passi) ? x.passi : [];
        const testa = '<small>' + (A[k] || k) + '</small><b>' + agEsc(String(x.testo)) + '</b>';
        if (!passi.length) return '<div class="jd-anello">' + testa + '</div>';
        return '<details class="jd-anello ag-anello"><summary><div>' + testa + '<i>' + passi.length + (passi.length === 1 ? ' passo' : ' passi') + '</i></div>' + agSvg('giu', 18) + '</summary>'
          + '<ul>' + passi.map(function(t){ return '<li>' + agEsc(String(t)) + '</li>'; }).join('') + '</ul></details>'; }).join('')
    + '<button type="button" class="jd-applica ag-applica" onclick="agApplica(' + id + ')"><span>' + agT('chat.applica') + '</span>' + agSvg('avanti', 16) + '</button>'
    + '</div>';
}
/* I PROGRAMMI CREATI DAL GENIO (0.9.279). Andrea: "gli ho chiesto un programma che blocca Instagram dopo
   10 minuti all'ora, massimo mezz'ora al giorno, e mi ha spiegato le impostazioni del telefono. Deve
   crearlo e basta, come se l'avessi fatto io a mano, nella pagina Proteggi i tuoi sogni".
   Il Genio chiude la risposta con {"programma": {...}}; qui si crea UNA volta per messaggio (si ricorda
   l'id), e nella chat resta la scheda con cosa e' stato creato e "Annulla". */
const AG_APP_NOTE = { instagram: 'com.instagram.android', tiktok: 'com.zhiliaoapp.musically', youtube: 'com.google.android.youtube', facebook: 'com.facebook.katana',
  whatsapp: 'com.whatsapp', telegram: 'org.telegram.messenger', snapchat: 'com.snapchat.android', twitter: 'com.twitter.android', x: 'com.twitter.android', reddit: 'com.reddit.frontpage',
  netflix: 'com.netflix.mediaclient', twitch: 'tv.twitch.android.app', threads: 'com.instagram.barcelona', pinterest: 'com.pinterest', linkedin: 'com.linkedin.android',
  'prime video': 'com.amazon.avod.thirdpartyclient', 'disney+': 'com.disney.disneyplus', spotify: 'com.spotify.music', chrome: 'com.android.chrome', discord: 'com.discord', tinder: 'com.tinder' };
function agProgFatti(){ try{ return JSON.parse(localStorage.getItem('fl_ag_prog') || '{}') || {}; }catch(_){ return {}; } }
async function agProgPacchetti(nomi){
  let inst = [];
  try{ if (typeof APPS_CACHE !== 'undefined' && APPS_CACHE.length) inst = APPS_CACHE; else if (NATIVE && NATIVE.getInstalledApps){ const r = await flApps(); inst = (r && r.apps) || []; } }catch(_){ }
  return (nomi || []).map(function(n){
    const s = String(n || '').trim(); if (!s) return '';
    if (/^[a-z0-9_]+(\.[a-z0-9_]+){1,}$/i.test(s) && s.indexOf('.') > 0 && !/\.(com|it|net|org)$/i.test(s)) return s;
    const k = s.toLowerCase();
    const trovata = inst.filter(function(a){ return String(a.label || '').toLowerCase() === k; })[0] || inst.filter(function(a){ return String(a.label || '').toLowerCase().indexOf(k) === 0; })[0];
    return trovata ? trovata.packageName : (AG_APP_NOTE[k] || '');
  }).filter(Boolean);
}
async function agProgApplica(p, id){
  const fatti = agProgFatti(); if (fatti[id]) return;
  fatti[id] = 'in corso'; try{ localStorage.setItem('fl_ag_prog', JSON.stringify(fatti)); }catch(_){ }
  const app = await agProgPacchetti(p.app);
  const pid = (typeof frProgrammaDaAgente === 'function') ? frProgrammaDaAgente({ nome: p.nome, app: app, siti: p.siti || [], parole: p.parole || [], dove: p.dove,
    dalle: p.dalle, alle: p.alle, giorni: p.giorni, tuttoIlGiorno: p.tuttoIlGiorno !== false && !p.dalle, minutiOra: p.minutiOra, minutiGiorno: p.minutiGiorno, zitto: true }, false) : '';
  fatti[id] = pid || 'no'; try{ localStorage.setItem('fl_ag_prog', JSON.stringify(fatti)); }catch(_){ }
  const el = document.querySelector('.ag-prog[data-id="' + id + '"]'); if (el) el.outerHTML = agProgHtml(p, id);
}
function agProgMostra(id){
  const pid = agProgFatti()[id];
  goId('s-home'); try{ switchTab('blocco'); }catch(_){ }
  if (pid && typeof blkEvidenzia === 'function') blkEvidenzia(pid);
}
async function agProgAnnulla(id){
  if (typeof blkEliminaChiedi === 'function' && !(await blkEliminaChiedi())) return;
  const fatti = agProgFatti(), pid = fatti[id];
  try{
    if (typeof PROGRAMS !== 'undefined'){ const i = PROGRAMS.findIndex(function(x){ return x.id === pid; }); if (i >= 0){ PROGRAMS.splice(i, 1); saveProgramsLocal(); try{ renderPrograms(); }catch(_){ } try{ pushRules(); }catch(_){ } try{ syncNative(); }catch(_){ } } }
  }catch(_){ }
  fatti[id] = 'annullato'; try{ localStorage.setItem('fl_ag_prog', JSON.stringify(fatti)); }catch(_){ }
  const el = document.querySelector('.ag-prog[data-id="' + id + '"]'); if (el) el.outerHTML = '';
  if (typeof toast === 'function') toast('Programma tolto');
}
function agProgHtml(p, id){
  const st = agProgFatti()[id];
  if (st === 'annullato') return '';
  if (!st) setTimeout(function(){ agProgApplica(p, id); }, 0);
  const cosa = (p.app || []).concat(p.siti || []).concat((p.parole || []).map(function(x){ return '"' + x + '"'; })).join(', ') || 'le app scelte';
  const quando = [];
  if (+p.minutiOra > 0) quando.push(p.minutiOra + ' minuti all’ora');
  if (+p.minutiGiorno > 0) quando.push(p.minutiGiorno + ' minuti al giorno');
  if (!quando.length) quando.push(p.dalle && p.alle ? 'dalle ' + p.dalle + ' alle ' + p.alle : 'tutto il giorno');
  return '<div class="jd-piano ag-piano ag-prog" data-id="' + id + '"><div class="jd-top"><span>🛡️</span><b>' + agEsc(st === 'no' ? 'Non sono riuscito a crearlo' : 'Programma creato') + '</b></div>'
    + '<p class="jd-piano-sub"><b>' + agEsc(p.nome || 'Dal tuo agente personale') + '</b>: ' + agEsc(cosa) + ', ' + agEsc(quando.join(', massimo ')) + '.</p>'
    + '<div class="ag-prog-az"><button type="button" class="jd-applica ag-applica" onclick="agProgMostra(' + id + ')"><span>Mostra il programma</span>' + agSvg('avanti', 16) + '</button>'
    + (st && st !== 'no' && st !== 'in corso' ? '<button type="button" class="ag-prog-no" onclick="agProgAnnulla(' + id + ')">Annulla</button>' : '') + '</div></div>';
}
/* L'IMPREVISTO STIMATO DALL'AGENTE (0.9.285): la risposta porta {"imprevisto": {"giorni", "ore", "motivo"}}.
   Si applica una volta sola per messaggio: l'arrivo previsto si ricalcola, e la card lo dice con il suo Annulla. */
function agImprFatti(){ try{ return JSON.parse(localStorage.getItem('fl_ag_imprevisti') || '{}') || {}; }catch(_){ return {}; } }
function agImprHtml(a, id){
  if (typeof etaImprevistoDaAgente !== 'function' || !a) return '';
  const f = agImprFatti();
  let st = f[id];
  if (st === 'annullato') return '';
  if (!st){ st = etaImprevistoDaAgente(a) || 'no'; f[id] = st; try{ localStorage.setItem('fl_ag_imprevisti', JSON.stringify(f)); }catch(_){ } }
  if (st === 'no') return '';
  const x = (typeof etaDev === 'function' ? etaDev() : []).filter(function(v){ return v && v.id === st; })[0];
  const g = Math.max(1, Math.round(+(x ? x.giorni : a.giorni) || 1));
  const ore = Math.round((x ? +x.ore : +a.ore || 0) * 10) / 10;
  return '<div class="jd-piano ag-piano ag-prog"><div class="jd-top"><span>🧭</span><b>Arrivo ricalcolato</b></div>'
    + '<p class="jd-piano-sub">L’imprevisto si prende <b>' + agEsc(String(ore).replace('.', ',')) + (ore === 1 ? ' ora' : ' ore') + '</b> di strada ' + (g === 1 ? 'oggi' : 'nei prossimi ' + g + ' giorni') + '. La nuova data la vedi nella scheda Sogno.</p>'
    + '<div class="ag-prog-az"><button type="button" class="ag-prog-no" onclick="agImprAnnulla(' + id + ')">Annulla</button></div></div>';
}
function agImprAnnulla(id){
  const f = agImprFatti(); const st = f[id];
  if (st && st !== 'no' && st !== 'annullato' && typeof etaDevTogli === 'function') etaDevTogli(st, 'annullato');
  f[id] = 'annullato'; try{ localStorage.setItem('fl_ag_imprevisti', JSON.stringify(f)); }catch(_){ }
  agRidisegna();
}
function agMsgHtml(m){
  const mio = m.direzione === 'in';
  const canale = (!mio || m.canale === 'app') ? '' : (agT('chat.daCanale.' + m.canale) || '');
  /* i messaggi dell'agente arrivano in markdown (0.9.219); i miei restano come li ho scritti */
  const allegati = mio ? (m.allegati || (m.azioni && m.azioni.allegati) || []) : [];
  let html = '<div class="ag-m ' + (mio ? 'io' : 'lui') + '"' + (m.id ? ' data-id="' + m.id + '"' : '') + '>' + (allegati.length ? agAllMsgHtml(allegati) : '') + '<div class="ag-b' + (mio ? '' : ' ag-md') + '">' + (mio ? agEsc(String(m.testo || '').replace(/^\[intervista\]\s*/, '').replace(/^\[correzione\]\s*/, '')).replace(/\n/g, '<br>') : agMd(m.testo)) + '</div>'
    + '<small>' + agOra(m.at) + (canale ? ' · ' + canale : '') + '</small></div>';
  if (!mio && m.azioni && m.azioni.piano) html += agPianoHtml(m.azioni.piano, m.id);
  if (!mio && m.azioni && m.azioni.programma) html += agProgHtml(m.azioni.programma, m.id);
  /* 0.9.344: quando l'agente spiega come collegare le altre AI, il pulsante porta li' */
  if (!mio && m.azioni && m.azioni.apri === 'ponte') html += '<button type="button" class="ag-az-btn" onclick="try{amApri()}catch(_){}">Collega la tua AI</button>';
  /* 0.9.302: la durata della Roadmap proposta dal tuo agente personale, con il pulsante per applicarla (sentiero-mappa.js) */
  if (!mio && m.azioni && m.azioni.durata && typeof sdDurataAgenteHtml === 'function') html += sdDurataAgenteHtml(m.azioni.durata, m.id);
  /* 0.9.285: le regole su misura della partita (regole-misura.js) e l'imprevisto con la sua stima (eta.js) */
  if (!mio && m.azioni && m.azioni.regola && typeof rgmAgenteHtml === 'function') html += rgmAgenteHtml(m.azioni.regola, m.id);
  if (!mio && m.azioni && m.azioni.imprevisto) html += agImprHtml(m.azioni.imprevisto, m.id);
  /* 0.9.299: la scheda su misura per le statistiche della partita (partita-stats.js) */
  if (!mio && m.azioni && m.azioni.statistica && typeof pstAgenteHtml === 'function') html += pstAgenteHtml(m.azioni.statistica, m.id);
  /* il tutorial cercato dalla tappa della Roadmap (0.9.210): si guarda dentro all'app */
  if (!mio && m.azioni && m.azioni.tutorial){ const tu = m.azioni.tutorial; html += '<button type="button" class="cta ag-tut" onclick="AI.task=' + agEsc(JSON.stringify(String(tu.task || ''))) + ';AI.query=' + agEsc(JSON.stringify(String(tu.q || ''))) + ';AI.min=20;if(typeof aiPaint===\'function\')aiPaint();aiVideoVia()">' + agSvg('play', 16) + '<span>' + agEsc(agT('chat.tutorial') || 'Guarda il tutorial: 20 minuti') + '</span></button>'; }
  return html;
}
/** «Il Genio sta scrivendo…» / «Leo sta scrivendo…» */
function agPensaHtml(){
  return '<div class="ag-m lui ag-pensa"><div class="ag-b"><i></i><i></i><i></i></div><small>' + agEsc(agNomeSoggetto()) + ' ' + agEsc(agT('chat.pensa') || 'sta scrivendo…') + '</small></div>';
}
function agChatHtml(){
  /* 0.9.280, Andrea: nella conversazione del piano su misura niente pill: il focus e' solo sul piano */
  /* 0.9.281, Andrea: le pill compaiono solo nella pagina d'inizio delle conversazioni, mai dentro una chat */
  const sug = [];
  const msgs = agSessMsgs();
  /* «sta scrivendo» solo nella conversazione che aspetta davvero: quella con l'ultima parola mia */
  const ultimo = msgs[msgs.length - 1];
  const aspetta = AG.attesa && ultimo && ultimo.direzione === 'in';
  return '<div class="ag-lista" id="agLista">'
    + (msgs.length ? msgs.map(agMsgHtml).join('') : '<p class="hintline">' + agT('chat.vuoto') + '</p>')
    + (aspetta ? agPensaHtml() : '')
    + '</div>'
    + '<div class="ag-sug" role="list">' + sug.map(function(t){ return '<button type="button" role="listitem" data-t="' + agEsc(t) + '" onclick="agInvia(this.dataset.t)">' + agSugIco(t) + '<span>' + agEsc(t) + '</span></button>'; }).join('') + '</div>'
    + agSaldoHtml()
    + agComposerHtml(agT('chat.scrivi', { nome: agNomeA() }));
}
function agNomeUtente(){ try{ const g = (typeof gnDati === 'function') ? gnDati() : {}; return String(g.nome || '').trim(); }catch(_){ return ''; } }
function agBenvenutoHtml(){
  const nome = agNomeUtente();
  /* 0.9.335, Andrea: "dopo che la roadmap c'e', al posto di Costruisci la mia roadmap: individua il mio collo di bottiglia" */
  let haRoadmap = false; try{ haRoadmap = ((agDati().orizzonti || []).length > 0) || !!localStorage.getItem('fl_capitoli'); }catch(_){ }
  const sug = (agT('chat.suggerimenti') || []).map(function(x){ return haRoadmap && /roadmap/i.test(x) ? 'Trova il mio collo di bottiglia' : x; });
  return '<div class="ag-ben">'
    + '<div class="ag-ben-t">' + agAvatarHtml('ag-ben-ico')
    +   '<h2>' + agEsc(nome ? agT('benvenuto.ciao', { nome: nome }) : agT('benvenuto.ciaoSenza')) + '</h2>'
    + '</div>'
    + '<div class="ag-ben-sug">' + sug.map(function(x){ return '<button type="button" data-t="' + agEsc(x) + '" onclick="agInviaNuova(/collo di bottiglia/i.test(this.dataset.t) && typeof CLO_RICHIESTA !== \'undefined\' ? CLO_RICHIESTA : this.dataset.t)">' + agSugIco(x) + '<span>' + agEsc(x) + '</span></button>'; }).join('') + '</div>'
    + (agSessLista().length ? '<button type="button" class="ag-ben-storia" onclick="agRiprendi()">🕘 ' + agEsc(agT('benvenuto.storia')) + '</button>' : '')
    + '</div>'
    + agSaldoHtml()
    + agComposerHtml(agT('benvenuto.campo', { nome: agNomeA() }));
}
/* 0.9.289, Andrea: "premendo Invio per andare a capo manda il messaggio". Sul telefono Invio va a capo (si manda con la
   freccia); sul computer, con una tastiera vera, Invio manda e Maiuscolo+Invio va a capo. */
function agTastoInvio(e){
  if (e.key !== 'Enter' || e.shiftKey) return;
  let tocco = false; try{ tocco = window.matchMedia('(pointer: coarse)').matches; }catch(_){ }
  if (tocco) return;
  e.preventDefault(); agInviaDaCampo();
}
/* 0.9.289, Andrea: "quando si apre la tastiera la pagina non scorre: l'ultimo messaggio resta sotto". Quando la tastiera
   cambia l'altezza visibile, la conversazione torna in fondo, cosi' l'ultimo messaggio sale insieme alla casella. */
(function(){
  if (typeof window === 'undefined' || !window.visualViewport) return;
  let h0 = window.visualViewport.height, t = 0;
  window.visualViewport.addEventListener('resize', function(){
    const h = window.visualViewport.height, cala = h < h0 - 80; h0 = h;
    const a = document.activeElement;
    if (!a || a.id !== 'agTesto') return;
    clearTimeout(t);
    t = setTimeout(function(){ agScorri(); try{ a.scrollIntoView({ block: 'end' }); }catch(_){ } }, cala ? 60 : 30);
  });
})();
/* 0.9.289, Andrea: "la risposta deve comparire scritta dal vivo, come fanno Gemini, ChatGPT e Claude". La risposta
   appena arrivata si scrive a poco a poco (in tutto da 1 a 4 secondi, secondo quanto e' lunga); i pulsanti sotto
   (piano, programma) compaiono a testo finito. Una risposta gia' vista non si riscrive. */
const AG_SCRITTI = {};
function agScriviDalVivo(id){
  if (!id || AG_SCRITTI[id]) return;
  AG_SCRITTI[id] = true;
  const m = document.querySelector('#agLista .ag-m[data-id="' + id + '"]'); if (!m) return;
  const b = m.querySelector('.ag-b'); if (!b) return;
  const nodi = [];
  const w = document.createTreeWalker(b, NodeFilter.SHOW_TEXT, { acceptNode: function(n){ return n.parentElement && n.parentElement.closest('small') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } });
  let n; while ((n = w.nextNode())) nodi.push([n, n.nodeValue]);
  const tot = nodi.reduce(function(a, x){ return a + x[1].length; }, 0);
  if (tot < 2) return;
  nodi.forEach(function(x){ x[0].nodeValue = ''; });
  /* 0.9.309, Andrea: "il testo viene tagliato in basso, la vista non segue quello che si scrive". CAUSA VERA: i pulsanti
     sotto alla risposta (la roadmap, il programma...) erano nascosti con visibility:hidden, quindi occupavano il loro
     spazio; la lista scorreva fino in fondo, cioe' fino alla fine di quel blocco invisibile, e la riga che si stava
     scrivendo restava a meta' schermo con il vuoto sotto e la parte di sopra tagliata. Lo stesso facevano i paragrafi
     e i punti elenco ancora vuoti (margini e pallini). Adesso quello che non e' ancora scritto non occupa spazio
     (display:none) e la vista segue l'ultima riga scritta, non il fondo della lista. */
  const dopo = []; let s = m.nextElementSibling;
  while (s && !s.classList.contains('ag-m')){ dopo.push([s, s.style.display]); s.style.display = 'none'; s = s.nextElementSibling; }
  const ora = m.querySelector('small'); const oraDisp = ora ? ora.style.display : '';
  if (ora) ora.style.display = 'none';
  /* i blocchi del markdown (paragrafi, elenchi, titoli): ognuno compare quando arriva la sua prima lettera */
  const blocchi = [];
  b.querySelectorAll('p,li,ul,ol,h1,h2,h3,h4,h5,h6,blockquote,pre,table,hr').forEach(function(el){
    let da = 0, trovato = false;
    for (let i = 0; i < nodi.length; i++){
      const nd = nodi[i][0];
      if (el.contains(nd) || (el.compareDocumentPosition(nd) & Node.DOCUMENT_POSITION_FOLLOWING)){ trovato = true; break; }
      da += nodi[i][1].length;
    }
    blocchi.push([el, trovato ? da : tot, el.style.display]);
    el.style.display = 'none';
  });
  m.classList.add('ag-scrive');
  /* 0.9.290, Andrea: "va troppo veloce, non e' come Claude". Prima tutta la risposta usciva in 4 secondi al massimo, anche
     se era lunga una pagina (fino a 400 lettere al secondo). Adesso il passo e' costante, circa 45 lettere al secondo,
     parola per parola come in Claude; un tocco sul messaggio lo mostra tutto. La lista segue il testo solo se sei in
     fondo: se scorri su per rileggere, resta dove sei. */
  const D = Math.min(40000, Math.max(1200, tot * 22)), t0 = performance.now();
  let fine = false;
  const tutto = function(){ fine = true; };
  m.addEventListener('click', tutto, { once: true });
  /* 0.9.292: un tocco in qualunque punto della conversazione (non solo sul messaggio) mostra tutto */
  const lista = document.getElementById('agLista'); if (lista) lista.addEventListener('click', tutto, { once: true });
  /* chi scorre a mano verso l'alto per rileggere resta dove si e' messo; se torna giu' fino all'ultima riga, la vista
     riprende a seguirla */
  const segui = { on: true, st: lista ? lista.scrollTop : 0 };
  const suScroll = function(){
    if (!lista) return;
    if (lista.scrollTop < segui.st - 6) segui.on = false;
    else if (!segui.on && agFondoRiga(lista, nodi) - agFondoVisibile(lista) < 24) segui.on = true;
    segui.st = lista.scrollTop;
  };
  if (lista) lista.addEventListener('scroll', suScroll, { passive: true });
  const passo = function(t){
    if (!m.isConnected){ if (lista) lista.removeEventListener('scroll', suScroll); return; }
    const q = fine ? 1 : Math.min(1, (t - t0) / D);
    const scritti = Math.round(tot * q);
    let quanti = scritti;
    for (let i = 0; i < nodi.length; i++){
      const testo = nodi[i][1]; let k = Math.max(0, Math.min(testo.length, quanti));
      /* a parole intere: la parola compare quando e' completa, come nello streaming di Claude */
      if (k > 0 && k < testo.length && q < 1){ const sp = testo.lastIndexOf(' ', k); k = sp > 0 ? sp : k; }
      nodi[i][0].nodeValue = testo.slice(0, k); quanti -= testo.length;
    }
    blocchi.forEach(function(x){ x[0].style.display = (q >= 1 || x[1] < scritti) ? x[2] : 'none'; });
    if (q < 1){
      if (segui.on && lista){ agSeguiRiga(lista, nodi); segui.st = lista.scrollTop; }
      requestAnimationFrame(passo);
    } else {
      m.classList.remove('ag-scrive'); m.removeEventListener('click', tutto);
      if (lista){ lista.removeEventListener('click', tutto); lista.removeEventListener('scroll', suScroll); }
      if (ora) ora.style.display = oraDisp;
      dopo.forEach(function(x){ x[0].style.display = x[1]; });
      if (segui.on) agScorri();
    }
  };
  requestAnimationFrame(passo);
}
/** Dove finisce, sullo schermo, l'ultima lettera gia' scritta della risposta. */
function agFondoRiga(lista, nodi){
  for (let i = nodi.length - 1; i >= 0; i--){
    const nd = nodi[i][0], v = nd.nodeValue || '';
    if (!v.length) continue;
    try{ const r = document.createRange(); r.setStart(nd, v.length - 1); r.setEnd(nd, v.length); const q = r.getBoundingClientRect(); if (q.bottom) return q.bottom; }catch(_){ }
  }
  return lista.getBoundingClientRect().top;
}
/** Il bordo basso di quello che si legge: la fine della lista, o il campo di scrittura se le passa sopra. */
function agFondoVisibile(lista){
  let y = lista.getBoundingClientRect().bottom;
  try{ const c = lista.parentElement && lista.parentElement.querySelector('.ag-comp'); if (c){ const t = c.getBoundingClientRect().top; if (t > 0 && t < y) y = t; } }catch(_){ }
  return y;
}
/** La vista scende quanto basta perche' l'ultima riga scritta stia tutta sopra al campo di scrittura (mai su). */
function agSeguiRiga(lista, nodi){
  const sotto = agFondoRiga(lista, nodi) + 16 - agFondoVisibile(lista);
  if (sotto > 0) lista.scrollTop = Math.min(lista.scrollHeight - lista.clientHeight, lista.scrollTop + sotto);
}
function agScorri(seInFondo){
  const l = document.getElementById('agLista'); if (!l) return;
  if (seInFondo && l.scrollHeight - l.scrollTop - l.clientHeight > 140) return;
  l.scrollTop = l.scrollHeight;
}
/* 0.9.242: con gli allegati si puo' mandare anche senza testo (il testo lo mette l'app) */
function agInviaDaCampo(){
  const t = document.getElementById('agTesto'); if (!t) return;
  if (AG.invio || (AG.mic && AG.mic.on)) return;
  const all = AG.allegati || [];
  const v = t.value.trim();
  if (!v && !all.length) return;
  const testo = v || (all.length === 1 ? (agT('composer.soloUno') || "Guarda l'allegato.") : (agT('composer.soloTanti') || 'Guarda gli allegati.'));
  t.value = ''; agCampoCresce(t);
  AG.allegati = [];
  agAllPaint();
  if (AG.pop && t.closest('#agPop')){ agInvia(testo, AG.pop.id, { allegati: all, bozza: v }); return; }
  agInviaNuova(testo, { allegati: all, bozza: v });
}
/* «Riprendi la conversazione»: la piu' recente */
function agRiprendi(){ const l = agSessLista(); if (l.length) agSessApri(l[0].id); else { AG.vista = 'chat'; agPaint(); } }
/** Ridisegna dove la conversazione si vede: la pagina dell'agente e la chat sopra la pagina. */
function agRidisegna(){
  if (document.getElementById('agBody')) agPaint();
  if (AG.pop && document.getElementById('agPop')) agPopPaint();
}
/** ss: la conversazione del messaggio (di serie quella aperta; la chat sopra la pagina passa la sua). */
async function agInvia(testo, ss, opz){
  opz = opz || {};
  let allegati = Array.isArray(opz.allegati) ? opz.allegati : [];
  /* 0.9.253: le immagini di riferimento (riferimenti.js) vanno con il primo messaggio di ogni conversazione nuova */
  try{ if (!agSessMsgs().length && typeof rfAllegati === 'function'){ const rif = rfAllegati('agente').filter(function(a){ return !allegati.some(function(b){ return b.dati === a.dati; }); }); if (rif.length) allegati = allegati.concat(rif).slice(0, 6); } }catch(_){ }
  testo = String(testo || '').trim();
  if (!testo || AG.invio) return;
  /* 0.9.282: dentro l'intervista del piano su misura ogni risposta va al modello del piano, con le sue regole */
  try{ if (testo.indexOf('[intervista]') !== 0 && typeof ivInCorso === 'function' && ivInCorso()) testo = '[intervista] ' + testo; }catch(_){ }
  if (!agPuo()){ if (typeof toast === 'function') toast(agT('chat.offline')); return; }
  /* SEGNALA UN OSTACOLO (0.9.221): l'agente fa le domande una alla volta (regola sul server);
     il racconto dell'ostacolo, cioe' il messaggio dopo il pulsante, va anche al Genio (senza
     nome), perche' impari quali ostacoli capitano e costruisca roadmap migliori per tutti. */
  if (/^segnala (un )?ostacolo/i.test(testo)) AG.ostacolo = true;
  else if (AG.ostacolo){ AG.ostacolo = false; try{ agRientroImpara('ostacolo', testo); }catch(_){ }
    /* 0.9.285: un imprevisto che dice quanto tempo porta via ("due giorni in meno") ricalcola subito l'arrivo;
       senza durata lo stima l'agente nella risposta (azioni.imprevisto) */
    try{ if (typeof etaDurataDaTesto === 'function' && etaDurataDaTesto(testo).trovato) etaImprevistoSegnalato(testo, 'agente'); }catch(_){ } }
  /* l'imprevisto della revisione della giornata, quando lo mandi tu (revisione.js, rvImprevistoAlGenio) */
  try{ const mi = /^oggi c.{1,2}è stato un imprevisto:\s*([\s\S]*?)(\nRicalcola|$)/i.exec(testo); if (mi && typeof etaImprevistoSegnalato === 'function') etaImprevistoSegnalato(mi[1].trim(), 'revisione'); }catch(_){ }
  AG.invio = true;
  AG.vista = 'chat';
  const s = agStato();
  const sid = (ss && s.sess.some(function(x){ return x.id === ss; })) ? ss : s.corrente;
  const locale = { id: 0, direzione: 'in', canale: 'app', testo: testo, at: Date.now(), locale: true, ss: sid };
  /* gli allegati: nel telefono resta solo l'anteprima piccola, il file intero va al server */
  if (allegati.length) locale.allegati = allegati.map(function(a){ return { tipo: a.tipo, nome: a.nome, mime: a.mime, anteprima: a.anteprima || '' }; });
  s.msgs.push(locale); AG.attesa = true; agRidisegna();
  try{ flVibra(10); }catch(_){ }
  try{
    const corpo = { testo: testo, brief: agBrief(), nomeAgente: agNomeAgente(), modello: agModelloScelta() };
    if (allegati.length) corpo.allegati = allegati.map(function(a){ return { mime: a.mime, nome: a.nome, dati: a.dati }; });
    const r = await agApi('POST', '/api/focuslock/agent/chat', corpo);
    if (r && r.id){ locale.id = r.id; locale.locale = false; if (r.id > s.ultimoId) s.ultimoId = r.id; }
    agSalva();
  }catch(e){
    s.msgs = s.msgs.filter(function(m){ return m !== locale; }); AG.attesa = false;
    /* gli allegati e il testo tornano nel campo, cosi' si puo' riprovare */
    if (allegati.length) AG.allegati = allegati;
    agRidisegna();
    if (allegati.length || opz.bozza){ const t = document.getElementById('agTesto'); if (t && !t.value && opz.bozza){ t.value = opz.bozza; agCampoCresce(t); } }
    const msg = String((e && (e.message || e.data && e.data.message)) || e);
    const limite = /429|daily limit/.test(msg);
    const grande = /troppo grand|troppi allegati|413/.test(msg);
    const tipo = /tipo di file|non corrisponde/.test(msg);
    if (typeof toast === 'function') toast(limite ? agT('chat.limite') : grande ? (agT('composer.grande') || 'Questo file è troppo grande') : tipo ? agT('composer.tipo') : agT('chat.errore'));
  }
  AG.invio = false;
  agPollAvvia(true);
}
/* ---- la lettura: quello che e' arrivato dopo l'ultimo id, da qualunque canale ---- */
async function agSync(forza){
  if (!agPuo() || AG.sincro) return;
  AG.sincro = true;
  const s = agStato();
  try{
    const r = await agApi('GET', '/api/focuslock/agent/chat?after=' + (s.ultimoId || 0));
    const nuovi = (r && r.messaggi) || [];
    let cambiato = false;
    const daScrivere = [];
    nuovi.forEach(function(m){
      if (agEScomponi(m)){ if (m.id > s.ultimoId) s.ultimoId = m.id; return; }
      if (s.msgs.some(function(x){ return x.id === m.id; })) return;
      /* il messaggio scritto qui un attimo fa ha gia' la sua bolla: gli si da' solo l'id */
      const loc = s.msgs.filter(function(x){ return x.locale && x.direzione === 'in' && x.testo === m.testo; })[0];
      if (loc){ loc.id = m.id; loc.locale = false; loc.at = m.at || loc.at; }
      else {
        /* la risposta va nella conversazione della domanda; il resto (Telegram, WhatsApp) in quella aperta */
        let ss = s.corrente;
        if (m.inReplyTo){ const q = s.msgs.filter(function(x){ return x.id === m.inReplyTo; })[0]; if (q && q.ss) ss = q.ss; }
        s.msgs.push({ id: m.id, direzione: m.direzione, canale: m.canale, testo: m.testo, azioni: m.azioni || null, at: m.at || Date.now(), ss: ss });
        if (m.direzione === 'out' && !forza && Date.now() - (m.at ? new Date(m.at).getTime() : Date.now()) < 5 * 60000) daScrivere.push(m.id);
      }
      if (m.id > s.ultimoId) s.ultimoId = m.id;
      cambiato = true;
    });
    s.msgs.sort(function(a, b){ return (a.id || 1e15) - (b.id || 1e15); });
    if (s.msgs.length > AG_MAX_MSGS) s.msgs = s.msgs.slice(-AG_MAX_MSGS);
    const attesaPrima = AG.attesa;
    AG.attesa = !!(r && r.inAttesa);
    if (cambiato || attesaPrima !== AG.attesa){
      agSalva();
      if (document.getElementById('agLista')){ agPaint(); daScrivere.forEach(agScriviDalVivo); }
      if (AG.pop && document.getElementById('agPop')) agPopPaint();
      if (cambiato && !AG.attesa && attesaPrima) try{ flVibra([12, 60, 12]); }catch(_){ }
    }
  }catch(_){ }
  AG.sincro = false;
}
function agPollAvvia(veloce){
  agPollFerma();
  AG.pollDa = Date.now();
  const giro = function(){
    const pagina = document.getElementById('agBody') && document.getElementById('s-agente').classList.contains('active');
    if (!pagina && !document.getElementById('agPop')){ agPollFerma(); return; }
    agSync(false);
    /* stretto finche' aspetto una risposta, poi ogni quindici secondi per i messaggi dagli altri canali */
    const ms = AG.attesa && Date.now() - AG.pollDa < 4 * 60000 ? 2000 : 15000;   // 0.9.288: la risposta si vede appena arriva (prima fino a 4 s dopo)
    AG.poll = setTimeout(giro, ms);
  };
  AG.poll = setTimeout(giro, veloce ? 3000 : 1500);
}
function agPollFerma(){ if (AG.poll){ clearTimeout(AG.poll); AG.poll = 0; } }

/* ---- «Scomponi in passi»: una riga del foglio va all'agente e torna spaccata in micro-passi.
   Parte come un messaggio con il prefisso [scomponi] (il server lo fa con Opus e lo conta a
   parte); non compare nella chat: la risposta si applica alla riga e basta. ---- */
const AG_SCOMP = '[scomponi] ';
/* le richieste di servizio (scomponi in passi, lettera dell'io futuro) e le loro risposte non
   compaiono nella chat: si applicano dove servono */
/* 0.9.264: le richieste nascoste (le frasi per la schermata di blocco): la risposta arriva con inReplyTo */
function agNascosti(){ try{ return JSON.parse(localStorage.getItem('fl_ag_nascosti') || '[]') || []; }catch(_){ return []; } }
function agNascondi(id){ try{ const l = agNascosti(); l.push(id); localStorage.setItem('fl_ag_nascosti', JSON.stringify(l.slice(-40))); }catch(_){ } }
function agEScomponi(m){
  if (!m) return false;
  const t = String(m.testo || '');
  if (t.indexOf('[frasi]') === 0 || (m.inReplyTo && agNascosti().indexOf(m.inReplyTo) >= 0)) return true;
  /* [umore]: la chat del controllo dell'umore e' una conversazione a parte (umore.js) */
  /* 0.9.285: [turni]: la foto dei turni che il telefono manda da solo (TurniFoto.java), e la risposta con i turni */
  return t.indexOf('[scomponi]') === 0 || t.indexOf('[iofuturo]') === 0 || t.indexOf('[umore]') === 0 || t.indexOf('[turni]') === 0 || !!(m.azioni && (m.azioni.scomponi || m.azioni.iofuturo || m.azioni.umore || m.azioni.turni));
}
async function agScomponi(q){
  try{
    if (!q.msgId){
      const r = await agApi('POST', '/api/focuslock/agent/chat', { testo: AG_SCOMP + q.testo, brief: agBrief() });
      if (!r || !r.id) throw new Error('nessun id');
      const l = stScompLista();
      const x = l.filter(function(y){ return y.id === q.id; })[0];
      if (x){ x.msgId = r.id; stScompSalva(l); }
      q.msgId = r.id;
    }
    agScompAttendi(q, Date.now());
  }catch(e){
    const limite = /429|daily limit|crediti/i.test(String((e && (e.message || e.data && e.data.message)) || e));
    if (typeof toast === 'function') toast(limite ? agT('chat.limite') : 'Il tuo agente personale non risponde: te li porta il verdetto della sera');
    try{ if (typeof jdDeposita === 'function') jdDeposita(true); }catch(_){ }
  }
}
function agScompAttendi(q, da){
  const giro = async function(){
    let fatto = false;
    try{
      const r = await agApi('GET', '/api/focuslock/agent/chat?after=' + (q.msgId - 1));
      const risp = ((r && r.messaggi) || []).filter(function(m){
        return m.direzione === 'out' && (m.inReplyTo === q.msgId || (m.id > q.msgId && m.azioni && m.azioni.scomponi));
      })[0];
      if (risp){
        const passi = (risp.azioni && risp.azioni.scomponi && risp.azioni.scomponi.passi) || [];
        stScompApplica({ scomposizioni: [{ id: q.id, passi: passi, motivo: passi.length ? '' : String(risp.testo || '') }] });
        if (!passi.length && typeof toast === 'function') toast('Il tuo agente personale non l’ha scomposta: riprova');
        try{ if (typeof stRigaPaint === 'function' && typeof STR !== 'undefined' && STR.line === q.testo) stRigaPaint(); }catch(_){ }
        try{ if (typeof stListPaint === 'function') stListPaint(); }catch(_){ }
        fatto = true;
      }
    }catch(_){ }
    if (!fatto && Date.now() - da < 8 * 60000) setTimeout(giro, 5000);
  };
  setTimeout(giro, 4000);
}
/* all'avvio: le richieste partite e non ancora tornate si riprendono */
setTimeout(function(){
  try{
    if (!agPuo() || typeof stScompLista !== 'function') return;
    stScompLista().filter(function(x){ return x.stato === 'attesa' && x.msgId && Date.now() - x.at < 24 * 3600000; })
      .forEach(function(x){ agScompAttendi(x, Date.now()); });
  }catch(_){ }
}, 6000);
/* ---- applicare la roadmap proposta: come l'itinerario di Jordan, piu' le righe di oggi ---- */
function agApplica(id){
  const s = agStato();
  const m = s.msgs.filter(function(x){ return x.id === id; })[0];
  agApplicaPiano(m && m.azioni && m.azioni.piano);
}
/** 0.9.310: la stessa applicazione per il percorso nuovo proposto nella revisione (conversa.js, cvPercorsoSi). */
function agApplicaPiano(piano){
  if (!piano || typeof ozAnello !== 'function' || typeof ozSalvaAnello !== 'function') return;
  /* 0.9.222: la roadmap nuova SOSTITUISCE i passi ancora da fare (quelli fatti restano). Prima
     si aggiungevano solo i passi con un testo mai visto, e un ricalcolo diceva «Era gia' tutto al
     suo posto» senza mostrare niente. */
  const esito = (typeof rmlApplica === 'function') ? rmlApplica(piano) : { nuovi: 0, tolti: 0, cambiati: 0 };
  /* i passi di oggi entrano anche nel foglio di oggi: e' li' che si spuntano e si misurano */
  try{
    const oggi = piano.oggi && Array.isArray(piano.oggi.passi) ? piano.oggi.passi : [];
    if (oggi.length && typeof stRigheDi === 'function' && typeof stDayKey === 'function'){
      const day = stDayKey('today');
      const righe = stRigheDi(day);
      const norm = function(t){ return String(t || '').trim().toLowerCase(); };
      const have = {}; righe.forEach(function(r){ have[norm(r)] = 1; });
      const agg = oggi.map(function(t){ return (typeof flAccenti === 'function' ? flAccenti(String(t)) : String(t)).trim().slice(0, 160); }).filter(function(t){ return t && !have[norm(t)]; });
      if (agg.length){
        localStorage.setItem('fl_notes_' + day, righe.concat(agg).join('\n'));
        try{ document.dispatchEvent(new CustomEvent('fl:piano', { detail: { day: day, righe: righe.length + agg.length } })); }catch(_){ }
      }
    }
  }catch(_){ }
  try{ if (typeof ozPaint === 'function') ozPaint(); }catch(_){ }
  try{ if (typeof mpPaint === 'function') mpPaint(); }catch(_){ }
  try{ if (typeof stListPaint === 'function') stListPaint(); }catch(_){ }
  try{ if (typeof etaEvento === 'function') etaEvento('roadmap', {}); }catch(_){ }
  try{ flVibra([12, 40, 20]); }catch(_){ }
  /* la chat si chiude e la roadmap aggiornata si vede, con i livelli nuovi che entrano */
  try{ if (AG.pop && typeof agPopChiudi === 'function') agPopChiudi(true); }catch(_){ }
  try{ if (typeof sdPianoApplicato === 'function') sdPianoApplicato(); }catch(_){ }
  /* 0.9.290: chi segue il sentiero vede la mappa ridisegnarsi capitolo per capitolo, poi il livello del piano si chiude
     (i punti, il livello dopo che si sblocca); chi pianifica da se' vede la sua roadmap come prima */
  const sulSentiero = typeof sdRicostruisci === 'function' && typeof mppVistaCur === 'function' && mppVistaCur() === 'rotta';
  if (sulSentiero) sdRicostruisci(function(){ try{ sdAggiorna(true); }catch(_){ } });
  else if (typeof rmlMostra === 'function'){ rmlMostra(); setTimeout(function(){ try{ if (typeof sdAggiorna === 'function') sdAggiorna(true); }catch(_){ } }, 1600); }
  const frase = esito.nuovi ? 'La roadmap è aggiornata: ' + esito.nuovi + (esito.nuovi === 1 ? ' livello nuovo' : ' livelli nuovi') + (esito.tolti ? ', ' + esito.tolti + ' tolti' : '')
    : (esito.cambiati ? 'La roadmap è aggiornata: traguardi nuovi' : 'La roadmap è questa: eccola');
  if (typeof toast === 'function') setTimeout(function(){ toast(frase); }, 500);
}

/* ---------------------------------------------------------------------------------------
   I CANALI: Telegram e WhatsApp si agganciano con un codice
   --------------------------------------------------------------------------------------- */
async function agCanaliApri(){
  goId('s-agente-canali');
  const t = document.getElementById('agCanTitolo'); if (t) t.textContent = agT('canali.titolo');
  agCanaliPaint();
  await agCanaliSync();
  agCanaliPaint();
}
async function agCanaliSync(){
  if (!agPuo()) return;
  try{ const r = await agApi('GET', '/api/focuslock/agent/chat/link'); if (r){ AG.link = r; agStato().canali = r.canali || {}; agSalva(); } }catch(_){ }
}
function agCanaliPaint(){
  const host = document.getElementById('agCanBody');
  if (!host) return;
  const abil = agAbilCache() || {};
  const c = (AG.link && AG.link.canali) || agStato().canali || {};
  const riga = function(k, nome, ico, disponibile){
    const st = c[k] || {};
    let corpo;
    if (!disponibile) corpo = '<span class="ag-can-st">' + agT('canali.inArrivo') + '</span><small>' + agT('canali.inArrivoSotto') + '</small>';
    else if (st.collegato) corpo = '<span class="ag-can-st ok">✓ ' + agT('canali.collegato') + '</span><button type="button" class="ghostmini" onclick="agScollega(\'' + k + '\')">' + agT('canali.scollega') + '</button>';
    else if (st.codice) corpo = '<b class="ag-codice">' + agEsc(agT('canali.codice', { codice: st.codice })) + '</b><small>' + agT('canali.codiceSotto') + '</small>'
      + '<button type="button" class="btn primary" onclick="agApriCanale(\'' + k + '\')">' + agT('canali.apri', { canale: nome }) + '</button><small class="ag-attesa">' + agT('canali.attesa') + '</small>';
    else corpo = '<button type="button" class="btn primary" onclick="agCollega(\'' + k + '\')">' + agT('canali.collega') + '</button>';
    return '<div class="ag-can"><div class="ag-can-t"><span>' + ico + '</span><b>' + nome + '</b></div>' + corpo + '</div>';
  };
  host.innerHTML = '<p class="hintline">' + agT('canali.sotto') + '</p>'
    + '<div class="ag-can"><div class="ag-can-t"><span>📱</span><b>' + agT('canali.app') + '</b></div><span class="ag-can-st ok">✓ ' + agT('canali.appSotto') + '</span></div>'
    + riga('telegram', agT('canali.telegram'), '✈️', !!abil.telegramBot)
    + riga('whatsapp', agT('canali.whatsapp'), '💬', !!abil.whatsappNumero)
    + '<div class="sect"><b>' + agT('setup.contestoTitolo') + '</b></div>'
    + '<div class="ag-can"><small>' + agT('setup.contestoSotto') + '</small>'
    +   '<textarea class="fin ag-ctx" id="agCtxCan" rows="6" maxlength="4000" placeholder="' + agEsc(agT('setup.contestoEsempio')) + '">' + agEsc(agStato().contesto || '') + '</textarea>'
    +   '<button type="button" class="btn primary" onclick="agCtxSalva()">' + agT('setup.contestoSalva') + '</button></div>'
    /* 0.9.253, Andrea: come in Claude Cowork, un file .md o delle immagini per personalizzare l'agente */
    + ((typeof rfSezioneHtml === 'function') ? rfSezioneHtml('agente', 'Documenti di riferimento', 'Un file .md con chi sei e cosa vuoi, o delle immagini: il tuo agente personale li legge prima di rispondere, come un dossier.') : '');
}
function agCtxSalva(){
  const cx = document.getElementById('agCtxCan'); if (!cx) return;
  agStato().contesto = cx.value.trim().slice(0, 4000); agSalva();
  if (agPuo()) agApi('POST', '/api/focuslock/agent/chat/profilo', { nome: agNomeAgente(), brief: agBrief() }).catch(function(){ });
  if (typeof toast === 'function') toast(agT('setup.contestoOk'));
}
async function agCollega(canale){
  if (!agPuo()) return;
  try{
    const r = await agApi('POST', '/api/focuslock/agent/chat/link', { canale: canale });
    AG.link = AG.link || { canali: {} }; AG.link.canali = AG.link.canali || {};
    AG.link.canali[canale] = { collegato: false, codice: r.codice, url: r.url };
    agStato().canali = AG.link.canali; agSalva();
    agCanaliPaint();
    agApriCanale(canale);
    agLinkPoll();
  }catch(_){ if (typeof toast === 'function') toast(agT('canali.errore')); }
}
function agApriCanale(canale){
  const st = (AG.link && AG.link.canali && AG.link.canali[canale]) || {};
  const abil = agAbilCache() || {};
  let url = st.url || '';
  if (!url && st.codice){
    if (canale === 'telegram' && abil.telegramBot) url = 'https://t.me/' + abil.telegramBot + '?start=' + st.codice;
    if (canale === 'whatsapp' && abil.whatsappNumero) url = 'https://wa.me/' + String(abil.whatsappNumero).replace(/^\+/, '') + '?text=' + encodeURIComponent('COLLEGA ' + st.codice);
  }
  if (url){ try{ window.open(url, '_blank'); }catch(_){ location.href = url; } }
}
function agLinkPoll(){
  clearTimeout(AG.pollLink);
  const da = Date.now();
  const giro = async function(){
    if (!document.getElementById('s-agente-canali').classList.contains('active')) return;
    await agCanaliSync();
    agCanaliPaint();
    const c = (AG.link && AG.link.canali) || {};
    const aperti = Object.keys(c).some(function(k){ return c[k] && c[k].codice && !c[k].collegato; });
    if (aperti && Date.now() - da < 3 * 60000) AG.pollLink = setTimeout(giro, 5000);
  };
  AG.pollLink = setTimeout(giro, 5000);
}
async function agScollega(canale){
  try{ await agApi('DELETE', '/api/focuslock/agent/chat/link/' + canale); }catch(_){ }
  await agCanaliSync(); agCanaliPaint();
}
document.addEventListener('visibilitychange', function(){ if (!document.hidden && document.getElementById('s-agente-canali') && document.getElementById('s-agente-canali').classList.contains('active')) agLinkPoll(); });

/* ---------------------------------------------------------------------------------------
   IL CAMPO IN BASSO COME GEMINI E CLAUDE (0.9.242): una barra fissa con il testo sopra e, sotto,
   il "+" (foto e file dal telefono), il microfono e Invia. Il microfono detta DENTRO al campo:
   la pillola che galleggia (dettatura.js) qui non compare (data-no-dettatura e dtAvviaSu con
   nascosto), e lo stato si vede nel campo stesso: il microfono diventa l'onda azzurra con il tempo.
   Gli allegati: le foto si riducono a 1568 pixel (JPEG), i PDF fino a 8 MB, i file di testo fino
   a 300 KB; al massimo 4 per messaggio. Il server li passa al modello come immagini e documenti.
   --------------------------------------------------------------------------------------- */
const AG_ALL_MAX = 4;
const AG_REC_BARRE = 18;
function agComposerHtml(ph){
  const rec = !!(AG.mic && AG.mic.on);
  const pieno = !!((AG.allegati || []).length);
  return '<div class="ag-comp' + (rec ? ' reg' : '') + (pieno ? ' pieno' : '') + '" id="agComp" data-no-dettatura>'
    + '<div class="ag-comp-all" id="agAllBox">' + agAllChipsHtml() + '</div>'
    + '<textarea id="agTesto" rows="1" placeholder="' + agEsc(ph || '') + '" oninput="agCampoCresce(this);agCompStato()" onkeydown="agTastoInvio(event)"></textarea>'
    + '<div class="ag-comp-riga">'
    +   '<button type="button" class="ag-comp-piu" onclick="agAllegaApri()" aria-label="' + agEsc(agT('composer.piu') || 'Aggiungi foto o file') + '">' + agSvg('piu', 22) + '</button>'
    +   '<button type="button" class="ag-mod-btn" id="agModBtn" onclick="agModelloApri(false)" hidden></button>'
    +   '<div class="ag-comp-reg"><button type="button" class="ag-reg-x" onclick="agMicAnnulla()" aria-label="' + agEsc(agT('composer.annulla') || 'Annulla') + '">' + agSvg('chiudi', 16) + '</button>'
    +     '<div class="ag-reg-onda" aria-label="' + agEsc(agT('composer.ascolto') || 'Ti ascolto') + '">' + Array.from({ length: AG_REC_BARRE }).map(function(){ return '<i></i>'; }).join('') + '</div>'
    +     '<span class="ag-reg-t" id="agRecT">' + agMicTempo() + '</span>'
    /* 0.9.344, Andrea: "premo la spunta e per due o tre secondi non succede niente, e il tempo continua a scorrere: sembra rotto".
       Al tocco il tempo si ferma e al posto dell'onda c'e' la rotella con la scritta */
    +     '<span class="ag-reg-att" aria-live="polite"><i class="ag-spin" aria-hidden="true"></i><b>Scrivo quello che hai detto</b></span>'
    +     '<button type="button" class="ag-reg-ok" onclick="agMicFatto()" aria-label="' + agEsc(agT('composer.fatto') || 'Scrivi quello che ho detto') + '">' + agSvg('spunta', 18) + '</button></div>'
    +   '<span class="ag-comp-sp"></span>'
    +   '<button type="button" class="ag-comp-mic" id="agMicBtn" onclick="agMicTocca()" aria-label="' + agEsc(agT('composer.detta') || 'Detta a voce') + '">' + agSvg('mic', 20) + '</button>'
    +   '<button type="button" class="ag-comp-invia" id="agInviaBtn" onclick="agInviaDaCampo()" aria-label="' + agEsc(agT('chat.invia') || 'Invia') + '">' + agSvg('invia', 20) + '</button>'
    + '</div></div>';
}
/** Invia si accende quando c'e' qualcosa da mandare. */
function agCompStato(){
  const c = document.getElementById('agComp'); if (!c) return;
  const t = document.getElementById('agTesto');
  c.classList.toggle('pieno', !!((t && t.value.trim()) || (AG.allegati || []).length));
}
/* ---- gli allegati ---- */
function agAllChipsHtml(){
  const l = AG.allegati || [];
  const togli = agEsc(agT('composer.togli') || 'Togli');
  return l.map(function(a, i){
    const x = '<button type="button" class="ag-all-x" onclick="agAllTogli(' + i + ')" aria-label="' + togli + ' ' + agEsc(a.nome) + '">' + agSvg('chiudi', 12) + '</button>';
    if (a.tipo === 'image' && a.anteprima) return '<div class="ag-all-c img"><img src="' + agEsc(a.anteprima) + '" alt="' + agEsc(a.nome) + '">' + x + '</div>';
    return '<div class="ag-all-c doc">' + agSvg('doc', 18) + '<span>' + agEsc(a.nome) + '</span>' + x + '</div>';
  }).join('');
}
function agAllPaint(){
  const b = document.getElementById('agAllBox'); if (b) b.innerHTML = agAllChipsHtml();
  agCompStato();
}
function agAllTogli(i){ AG.allegati = (AG.allegati || []).filter(function(_, k){ return k !== i; }); agAllPaint(); }
/** Gli allegati dentro alla mia bolla: le foto in piccolo, i documenti con il nome. */
function agAllMsgHtml(l){
  return '<div class="ag-all-m">' + l.map(function(a){
    if (a.tipo === 'image' && a.anteprima) return '<img src="' + agEsc(a.anteprima) + '" alt="' + agEsc(a.nome || '') + '">';
    return '<span class="ag-all-c doc">' + agSvg(a.tipo === 'image' ? 'galleria' : 'doc', 16) + '<span>' + agEsc(a.nome || '') + '</span></span>';
  }).join('') + '</div>';
}
function agAllegaApri(){
  if ((AG.allegati || []).length >= AG_ALL_MAX){ if (typeof toast === 'function') toast(agT('composer.troppi')); return; }
  agFoglio('<p class="ag-fg-tit">' + agEsc(agT('composer.piu') || 'Aggiungi foto o file') + '</p>'
    + agFoglioRiga('galleria', agT('composer.foto') || 'Foto dalla galleria', "agAllegaScegli('foto')")
    + agFoglioRiga('doc', agT('composer.file') || 'File dal telefono: PDF o testo', "agAllegaScegli('file')"));
}
function agAllegaScegli(modo){
  agFoglioChiudi(true);
  const inp = document.createElement('input');
  inp.type = 'file'; inp.multiple = true; inp.style.display = 'none';
  inp.accept = modo === 'foto' ? 'image/*' : 'application/pdf,text/plain,text/markdown,text/csv,.pdf,.txt,.md,.csv';
  inp.addEventListener('change', function(){ const f = Array.prototype.slice.call(inp.files || []); inp.remove(); agAllegaFile(f); });
  document.body.appendChild(inp);
  inp.click();
}
async function agAllegaFile(files){
  for (let i = 0; i < files.length; i++){
    if ((AG.allegati || []).length >= AG_ALL_MAX){ if (typeof toast === 'function') toast(agT('composer.troppi')); break; }
    try{
      const a = await agAllegatoDa(files[i]);
      if (a){ AG.allegati = (AG.allegati || []).concat([a]); agAllPaint(); }
    }catch(e){
      const k = e && e.message;
      if (typeof toast === 'function') toast(agT(k === 'grande' ? 'composer.grande' : k === 'tipo' ? 'composer.tipo' : 'composer.illeggibile'));
    }
  }
}
function agMimeDi(f){
  const t = String(f.type || '').toLowerCase();
  if (t === 'text/x-markdown') return 'text/markdown';
  if (t) return t;
  const n = String(f.name || '').toLowerCase();
  if (/\.pdf$/.test(n)) return 'application/pdf';
  if (/\.md$/.test(n)) return 'text/markdown';
  if (/\.csv$/.test(n)) return 'text/csv';
  if (/\.txt$/.test(n)) return 'text/plain';
  if (/\.(jpe?g|png|webp|gif|heic)$/.test(n)) return 'image/jpeg';
  return '';
}
async function agAllegatoDa(f){
  const mime = agMimeDi(f);
  const nome = String(f.name || 'file').slice(0, 120);
  if (/^image\//.test(mime)) return agFotoRiduci(f);
  if (mime === 'application/pdf'){ if (f.size > 8 * 1024 * 1024) throw new Error('grande'); return { tipo: 'pdf', mime: mime, nome: nome, dati: await agBase64(f) }; }
  if (/^text\/(plain|markdown|csv)$/.test(mime)){ if (f.size > 300 * 1024) throw new Error('grande'); return { tipo: 'text', mime: mime, nome: nome, dati: await agBase64(f) }; }
  throw new Error('tipo');
}
function agBase64(f){
  return new Promise(function(ok, no){
    const r = new FileReader();
    r.onload = function(){ ok(String(r.result || '').replace(/^data:[^,]*,/, '')); };
    r.onerror = function(){ no(new Error('leggi')); };
    r.readAsDataURL(f);
  });
}
/** La foto ridotta a 1568 pixel sul lato lungo (quello che il modello guarda davvero) e l'anteprima a 160. */
function agFotoRiduci(f){
  return new Promise(function(ok, no){
    const url = URL.createObjectURL(f);
    const img = new Image();
    img.onload = function(){
      try{
        const w0 = img.naturalWidth || 1, h0 = img.naturalHeight || 1;
        const disegna = function(lato, q){
          const k = Math.min(1, lato / Math.max(w0, h0));
          const c = document.createElement('canvas');
          c.width = Math.max(1, Math.round(w0 * k)); c.height = Math.max(1, Math.round(h0 * k));
          const x = c.getContext('2d'); x.fillStyle = '#FFFFFF'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
          return c.toDataURL('image/jpeg', q);
        };
        const dati = disegna(1568, 0.85).split(',')[1];
        const anteprima = disegna(160, 0.7);
        URL.revokeObjectURL(url);
        if (dati.length * 0.75 > 5 * 1024 * 1024) return no(new Error('grande'));
        ok({ tipo: 'image', mime: 'image/jpeg', nome: String(f.name || 'foto').replace(/\.[^.]+$/, '').slice(0, 100) + '.jpg', dati: dati, anteprima: anteprima });
      }catch(e){ no(e); }
    };
    img.onerror = function(){ URL.revokeObjectURL(url); no(new Error('tipo')); };
    img.src = url;
  });
}
/* ---- il microfono dentro al campo ---- */
function agMicTempo(){
  const s = AG.mic && AG.mic.on ? Math.floor((Date.now() - AG.mic.da) / 1000) : 0;
  return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0');
}
function agMicPaint(){
  const c = document.getElementById('agComp'); if (!c) return;
  c.classList.toggle('reg', !!(AG.mic && AG.mic.on));
  c.toggleAttribute('data-ascolto', !!(AG.mic && AG.mic.on));
  c.classList.toggle('scrivo', !!(AG.mic && AG.mic.fine));
}
async function agMicTocca(){
  if (AG.mic && AG.mic.on){ agMicFatto(); return; }
  const t = document.getElementById('agTesto'); if (!t) return;
  if (typeof dtAvviaSu !== 'function'){ if (typeof toast === 'function') toast(agT('composer.noApp')); return; }
  AG.mic = { on: true, da: Date.now(), giro: 0, fine: false, onda: [] };
  agMicPaint();
  try{ flVibra(12); }catch(_){ }
  const r = await dtAvviaSu(t, agMicTesto, t, { nascosto: true });
  if (r !== 'ok'){
    agMicFine();
    if (r === 'spenta' && typeof toast === 'function') toast(agT('composer.spenta'));
    else if (r === 'no' && typeof toast === 'function') toast(agT('composer.noApp'));
    return;
  }
  AG.mic.giro = setInterval(agMicGiro, 70);
}
/** Ogni 70 ms: l'onda azzurra (dal volume della voce) e il tempo; se la dettatura si e' chiusa da sola, si chiude anche qui. */
function agMicGiro(){
  if (!AG.mic || !AG.mic.on) return;
  const dt = (typeof DT !== 'undefined') ? DT : null;
  if (!dt || (!dt.on && !dt.fatto)){ agMicFine(); return; }
  if (AG.mic.fine) return;                                   // la spunta e' stata toccata: il tempo e l'onda si fermano
  const v = dt.lvl < 0.12 ? 0 : dt.lvl;
  const o = AG.mic.onda; o.push(v); if (o.length > AG_REC_BARRE) o.shift();
  const bb = document.querySelectorAll('#agComp .ag-reg-onda i');
  for (let i = 0; i < bb.length; i++){ const x = o[i - (AG_REC_BARRE - o.length)] || 0; bb[i].style.height = (x ? Math.round(4 + 16 * Math.min(1, x)) : 3) + 'px'; bb[i].style.opacity = x ? '1' : '.5'; }
  const t = document.getElementById('agRecT'); if (t) t.textContent = agMicTempo();
  agMicPaint();
}
/** La frase finale arriva qui (dettatura.js la passa a DT.fatto): va in coda al testo del campo. */
function agMicTesto(t){
  const el = document.getElementById('agTesto');
  if (el && t){ const p = el.value; el.value = p + (p && !/\s$/.test(p) ? ' ' : '') + t; agCampoCresce(el); }
  agMicFine();
  agCompStato();
}
function agMicFatto(){
  if (!AG.mic || !AG.mic.on || AG.mic.fine) return;
  AG.mic.fine = true; agMicPaint();
  if (typeof dtFatto === 'function') dtFatto(); else agMicFine();
}
function agMicAnnulla(){
  try{ if (typeof DT !== 'undefined' && DT.on && typeof dtAnnulla === 'function') dtAnnulla(); else if (typeof dtSoloFine === 'function') dtSoloFine(); }catch(_){ }
  agMicFine();
}
function agMicFine(){
  if (AG.mic) clearInterval(AG.mic.giro);
  AG.mic = null;
  agMicPaint();
}

/* ---------------------------------------------------------------------------------------
   IL MODELLO (0.9.242). Solo i modelli che il server usa gia': "Veloce" (quello della chat) e
   "Piu' attento" (quello della roadmap). Di serie la scelta NON si vede nella chat, per non
   aggiungere una decisione a ogni messaggio: si cambia dal menu in alto. Chi la vuole a portata
   di mano accende "Mostra la scelta del modello nella chat" e in alto compare il menu a tendina.
   --------------------------------------------------------------------------------------- */
const AG_MODK = 'fl_agente_modello';
const AG_MODCHATK = 'fl_agente_modello_chat';
function agModelloInfo(){ return AG.modInfo || agLeggi(AG_MODK, null) || { scelta: 'veloce', modelli: [] }; }
function agModelloScelta(){
  const i = agModelloInfo();
  return i.scelta === 'profondo' && (i.modelli || []).some(function(m){ return m.id === 'profondo'; }) ? 'profondo' : 'veloce';
}
function agModelloNome(id){ return agT('modello.' + id + '.nome') || (id === 'profondo' ? 'Più attento' : 'Veloce'); }
function agModelloInChat(){ return !!agLeggi(AG_MODCHATK, false); }
async function agModelloCarica(){
  if (!agPuo()) return;
  try{
    const r = await agApi('GET', '/api/focuslock/agent/chat/modello');
    if (r && Array.isArray(r.modelli)){ AG.modInfo = { scelta: r.scelta || 'veloce', modelli: r.modelli }; agScrivi(AG_MODK, AG.modInfo); agModBtnPaint(); }
  }catch(_){ }
}
function agModBtnPaint(){
  const b = document.getElementById('agModBtn'); if (!b) return;
  const vedi = !!(agStato().impostato && agModelloInChat() && (agModelloInfo().modelli || []).length > 1);
  b.hidden = !vedi;
  if (vedi){ b.innerHTML = '<span>' + agEsc(agModelloNome(agModelloScelta())) + '</span>' + agSvg('giu', 14); b.setAttribute('aria-label', (agT('modello.titolo') || 'Il modello del tuo agente personale') + ': ' + agModelloNome(agModelloScelta())); }
}
function agModelloOpHtml(){
  const i = agModelloInfo();
  const illimitato = !!(AG.crediti && AG.crediti.illimitato);
  return (i.modelli || []).map(function(m){
    const on = m.id === agModelloScelta();
    const descr = agT('modello.' + m.id + '.descr') + (m.crediti > 1 && !illimitato ? ' ' + agT('modello.crediti', { n: m.crediti }) : '');
    return '<button type="button" class="ag-mod-op' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" onclick="agModelloScegli(\'' + (m.id === 'profondo' ? 'profondo' : 'veloce') + '\')">'
      + '<span class="ag-mod-pal" aria-hidden="true">' + (on ? agSvg('spunta', 14) : '') + '</span>'
      + '<span class="ag-mod-txt"><b>' + agEsc(agModelloNome(m.id)) + '</b><small>' + agEsc(descr) + '</small></span></button>';
  }).join('');
}
/** conImpostazioni: dal menu in alto (con l'interruttore); senza: il menu a tendina della chat. */
function agModelloApri(conImpostazioni){
  const i = agModelloInfo();
  const piu = (i.modelli || []).length > 1;
  agFoglio('<p class="ag-fg-tit">' + agEsc(agT('modello.titolo') || 'Il modello del tuo agente personale') + '</p>'
    + '<p class="ag-mod-sotto">' + agEsc(piu ? agT('modello.sotto') : agT('modello.unico')) + '</p>'
    + (piu ? '<div role="radiogroup" id="agModOp">' + agModelloOpHtml() + '</div>' : '')
    + (conImpostazioni && piu
        ? '<label class="ag-mod-sw"><span><b>' + agEsc(agT('modello.mostra') || 'Mostra la scelta del modello nella chat') + '</b><small>' + agEsc(agT('modello.mostraSotto')) + '</small></span>'
          + '<input type="checkbox"' + (agModelloInChat() ? ' checked' : '') + ' onchange="agModelloInChatSet(this.checked)"><i aria-hidden="true"></i></label>'
        : ''));
  /* i modelli disponibili li dice il server: se sono cambiati, il foglio si aggiorna */
  agModelloCarica().then(function(){ const box = document.getElementById('agModOp'); if (box) box.innerHTML = agModelloOpHtml(); });
}
function agModelloInChatSet(v){ agScrivi(AG_MODCHATK, !!v); agModBtnPaint(); }
async function agModelloScegli(id){
  const prima = agModelloScelta();
  if (id === prima){ agFoglioChiudi(); return; }
  const i = agModelloInfo();
  AG.modInfo = { scelta: id, modelli: i.modelli || [] }; agScrivi(AG_MODK, AG.modInfo);
  agModBtnPaint();
  agFoglioChiudi();
  try{
    await agApi('POST', '/api/focuslock/agent/chat/modello', { scelta: id });
    if (typeof toast === 'function') toast(agT('modello.salvato', { nome: agModelloNome(id) }));
  }catch(_){
    AG.modInfo = { scelta: prima, modelli: i.modelli || [] }; agScrivi(AG_MODK, AG.modInfo); agModBtnPaint();
    if (typeof toast === 'function') toast(agT('modello.errore'));
  }
}

/* ---------------------------------------------------------------------------------------
   CONSUMI E SPESA (0.9.242): gli ultimi 30 giorni dell'agente personale. Il server registra a
   ogni risposta i token letti e scritti, la cache e il modello; qui si vedono la spesa STIMATA
   (prezzi di listino, non una fattura), i messaggi, il testo letto e scritto, quanto testo e'
   stato riletto dalla memoria, la spesa giorno per giorno e per modello.
   --------------------------------------------------------------------------------------- */
async function agConsumiApri(){
  goId('s-agente-consumi');
  const tit = document.getElementById('agConsTitolo'); if (tit) tit.textContent = agT('consumi.titolo') || 'Consumi e spesa';
  const host = document.getElementById('agConsBody'); if (!host) return;
  if (!agPuo()){ host.innerHTML = '<p class="hintline">' + agEsc(agT('chat.offline')) + '</p>'; return; }
  host.innerHTML = '<p class="hintline">' + agEsc(agT('consumi.carica') || 'Sto leggendo i consumi') + '</p>';
  try{
    const r = await agApi('GET', '/api/focuslock/agent/chat/consumi?giorni=30');
    host.innerHTML = agConsumiHtml(r || {});
  }catch(_){ host.innerHTML = '<p class="hintline">' + agEsc(agT('consumi.errore')) + '</p>'; }
}
function agSoldi(x){
  x = Number(x) || 0;
  return x.toLocaleString('it-IT', { minimumFractionDigits: 2, maximumFractionDigits: x > 0 && x < 1 ? 3 : 2 }) + ' $';
}
function agNumero(n){ return (Number(n) || 0).toLocaleString('it-IT'); }
function agConsModNome(modello){
  const m = (agModelloInfo().modelli || []).filter(function(x){ return x.modello === modello; })[0];
  return m ? agModelloNome(m.id) : modello;
}
function agConsGraficoHtml(giorni){
  const n = giorni.length || 1;
  const max = Math.max.apply(null, giorni.map(function(g){ return g.costo || 0; }).concat([0]));
  const W = 300, H = 110, passo = W / n, larga = Math.max(2, passo - 3);
  const barre = giorni.map(function(g, i){
    const h = max > 0 && g.costo > 0 ? Math.max(3, Math.round((g.costo / max) * (H - 6))) : 2;
    return '<rect x="' + (i * passo + (passo - larga) / 2).toFixed(1) + '" y="' + (H - h) + '" width="' + larga.toFixed(1) + '" height="' + h + '" rx="2" class="' + (g.costo > 0 ? 'si' : 'no') + '"><title>' + agEsc(agConsData(g.data) + ': ' + agSoldi(g.costo) + ', ' + agNumero(g.messaggi) + ' messaggi') + '</title></rect>';
  }).join('');
  return '<div class="ag-cons-graf"><div class="ag-cons-max">' + agEsc(agSoldi(max)) + '</div>'
    + '<svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" role="img" aria-label="' + agEsc(agT('consumi.perGiorno') || 'Spesa giorno per giorno') + '">' + barre + '</svg>'
    + '<div class="ag-cons-x"><span>' + agEsc(agConsData(giorni[0] && giorni[0].data)) + '</span><span>' + agEsc(agConsData(giorni[giorni.length - 1] && giorni[giorni.length - 1].data)) + '</span></div></div>';
}
function agConsData(s){
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(s || ''));
  return m ? (+m[3]) + ' ' + AG_MESI[(+m[2]) - 1] : '';
}
function agConsumiHtml(r){
  const t = r.totale || {};
  const giorni = Array.isArray(r.perGiorno) ? r.perGiorno : [];
  const mod = Array.isArray(r.perModello) ? r.perModello : [];
  const tile = function(etichetta, valore){ return '<div class="ag-cons-tile"><small>' + agEsc(etichetta) + '</small><b>' + agEsc(valore) + '</b></div>'; };
  const vuoto = !(t.chiamate || t.messaggi);
  return '<p class="ag-cons-sotto">' + agEsc(agT('consumi.sotto') || 'Il tuo agente personale negli ultimi 30 giorni') + '</p>'
    + '<div class="ag-cons-hero"><small>' + agEsc(agT('consumi.costo') || 'Spesa stimata') + '</small><b>' + agEsc(agSoldi(t.costo)) + '</b>'
    +   '<p>' + agEsc(r.abbonamento ? agT('consumi.stimaMax') : agT('consumi.stima')) + '</p></div>'
    + (vuoto ? '<p class="hintline">' + agEsc(agT('consumi.vuoto')) + '</p>' : '')
    + '<div class="ag-cons-griglia">'
    +   tile(agT('consumi.messaggi') || 'Messaggi che hai scritto', agNumero(t.messaggi))
    +   tile(agT('consumi.memoria') || 'Testo riletto dalla memoria', (Number(t.cachePct) || 0).toLocaleString('it-IT') + '%')
    +   tile(agT('consumi.letto') || 'Testo letto dal modello', agT('consumi.pezzi', { n: agNumero((t.in || 0) + (t.cacheLetti || 0) + (t.cacheScritti || 0)) }))
    +   tile(agT('consumi.scritto') || 'Testo scritto dal modello', agT('consumi.pezzi', { n: agNumero(t.out) }))
    + '</div>'
    + '<div class="sect"><b>' + agEsc(agT('consumi.perGiorno') || 'Spesa giorno per giorno') + '</b></div>'
    + agConsGraficoHtml(giorni)
    + (mod.length ? '<div class="sect"><b>' + agEsc(agT('consumi.perModello') || 'Per modello') + '</b></div>'
        + '<div class="ag-cons-mod">' + mod.map(function(m){
            return '<div class="ag-cons-mr"><div><b>' + agEsc(agConsModNome(m.modello)) + '</b><small>' + agEsc(m.modello + ' · ' + agT('consumi.risposte', { n: agNumero(m.chiamate) })) + '</small></div>'
              + '<span>' + agEsc(m.prezzoNoto ? agSoldi(m.costo) : (agT('consumi.senzaPrezzo') || 'prezzo non noto')) + '</span></div>';
          }).join('') + '</div>'
        : '')
    + '<p class="ag-cons-nota">' + agEsc(agT('consumi.unita')) + '</p>';
}

/* ---------------------------------------------------------------------------------------
   LE PORTE: il pannello «Ottieni una guida 1-1» e la pagina Premium diventano l'agente
   --------------------------------------------------------------------------------------- */
(function agPorte(){
  /* PRIMA che l'agente esista: il pannello «Ottieni una guida 1-1» e la sua pagina, con il genio e
     le tre promesse; in fondo «Crea il mio agente» (a chi ce l'ha) o «Arriva con Premium».
     DOPO: il pannello diventa l'agente (il suo nome, una riga) e porta dritto alla sua pagina.
     Una guida gia' ottenuta non si offre di nuovo. */
  if (typeof guidaApri === 'function'){
    const orig = guidaApri;
    guidaApri = function(){
      if (agStato().impostato && agAbilitatoOra()) return agApri();
      return orig.apply(this, arguments);
    };
  }
  if (typeof guidaPaint === 'function'){
    const orig = guidaPaint;
    guidaPaint = function(){
      const r = orig.apply(this, arguments);
      try{
        const s = agStato();
        if (!s.impostato || !agAbilitatoOra()) return r;
        const host = document.getElementById('guidaHost');
        if (!host) return r;
        const h = host.querySelector('.gd-h'); if (h) h.textContent = agT('card.titoloFatto');
        const card = host.querySelector('.gd-card div');
        if (card) card.innerHTML = '<b>' + agEsc(agNomeSoggetto()) + '</b><small>' + agEsc(agT('card.sotto')) + '</small>';
      }catch(_){ }
      return r;
    };
  }
})();
function agGuidaPiede(){
  const host = document.getElementById('guidaPag');
  if (!host || !agAbilitatoOra()) return;
  host.querySelectorAll('.dp-fine, .cta, .ag-guida-cta').forEach(function(e){ e.remove(); });
  const b = document.createElement('button');
  b.type = 'button'; b.className = 'cta ag-guida-cta';
  b.textContent = agT('guida.crea') || 'Crea il mio agente';
  b.addEventListener('click', agApri);
  host.appendChild(b);
}
document.addEventListener('DOMContentLoaded', function(){
  agTestiCarica();
  setTimeout(function(){ agAbilitato().then(function(){ try{ if (typeof guidaPaint === 'function') guidaPaint(); }catch(_){ } }); }, 2500);
});

(function agStile(){
  const st = document.createElement('style');
  st.textContent = [
    '.ag-page{display:flex;flex-direction:column;height:calc(100% - 60px);padding:0 6px 2px}',
    /* 0.9.256, Andrea: il benvenuto cresce con la pagina (prima sbordava SOPRA all'intestazione: le pill
       finivano sopra a ☰ e ⋯); l'intestazione sta comunque sopra a tutto, con il suo fondo */
    '.ag-page.benvenuto{height:calc(100% - 60px)}',
    '.ag-hd1{display:flex;align-items:center;gap:10px;min-height:48px;margin:0 0 8px!important;padding-top:4px}.ag-hd1 .blk-title{flex:1;min-width:0}',
    /* 0.9.295, Andrea: "al buio nell'intestazione della chat c'e' una barra di un altro colore; e il nome dell'agente va al
       centro". Lo sfondo e' quello della pagina in tutti e due i temi, e il nome sta al centro fra le tre lineette e la X. */
    '.ag-hd1 .blk-title{display:flex;align-items:center;justify-content:center;gap:8px;text-align:center}.ag-hd1 .ag-menu[hidden]{display:inline-flex!important;visibility:hidden}',
    '.ag-chiudi{flex:none;margin-left:auto}.ag-cas-altro{flex:none;margin-left:auto;width:40px;height:40px;border:0;border-radius:50%;background:rgba(0,30,68,.06);color:var(--navy);display:grid;place-items:center;cursor:pointer}body.dark .ag-cas-altro{background:rgba(255,255,255,.08);color:#fff}',
    '.ag-hd{display:flex;align-items:center;gap:10px;min-height:38px;margin:0 0 10px;position:relative;z-index:20;background:var(--bg,#F3F6FB)}body.dark .ag-hd{background:var(--bg)}',
    '.ag-hd .ag-menu{margin-left:0}',
    '.ag-hd .blk-title{min-width:0}',
    '.ag-setup{padding:8px 4px 24px;overflow:auto}',
    '.ag-hero{font-size:48px;text-align:center;margin:8px 0 4px}',
    '.ag-setup h2{margin:0;text-align:center;font:800 22px/1.2 var(--font-display);font-style:italic;color:var(--navy)}',
    'body.dark .ag-setup h2{color:#fff}',
    '.ag-setup > p{margin:8px 0 14px;text-align:center;font:500 13px/1.55 var(--font-body);color:var(--muted)}',
    '.ag-sa{border:1px solid var(--line);border-radius:16px;padding:4px 14px;background:var(--card,#fff)}',
    'body.dark .ag-sa{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.12)}',
    '.ag-sa-r{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-top:1px solid var(--line)}',
    '.ag-sa-r:first-child{border-top:0}',
    '.ag-sa-r small{flex:none;font:600 11.5px var(--font-body);color:var(--muted)}',
    '.ag-sa-r b{font:700 12.5px/1.4 var(--font-body);color:var(--navy);text-align:right;min-width:0;overflow-wrap:anywhere}',
    'body.dark .ag-sa-r b{color:#fff}',
    '.ag-nome{display:block;margin:18px 0 12px}',
    '.ag-nome span{display:block;margin-bottom:6px;font:700 12.5px var(--font-body);color:var(--navy)}',
    'body.dark .ag-nome span{color:#fff}',
    '.ag-lista{flex:1;overflow:auto;padding:10px 2px;display:flex;flex-direction:column;gap:10px}',
    '.ag-m{display:flex;flex-direction:column;max-width:86%}',
    '.ag-m.io{align-self:flex-end;align-items:flex-end}.ag-m.lui{align-self:flex-start;align-items:flex-start}',
    '.ag-b{padding:10px 13px;border-radius:16px;font:500 13.5px/1.5 var(--font-body);color:var(--navy);background:#EAF2FB;overflow-wrap:anywhere}',
    '.ag-m.io .ag-b{background:var(--navy);color:#fff;border-bottom-right-radius:6px}',
    '.ag-m.lui .ag-b{border-bottom-left-radius:6px}',
    'body.dark .ag-b{background:rgba(255,255,255,.1);color:#fff}body.dark .ag-m.io .ag-b{background:#0075E3}',
    '.ag-m small{margin:3px 6px 0;font:600 10.5px var(--font-body);color:var(--faint)}',
    '.ag-pensa .ag-b{display:flex;gap:5px;padding:12px 14px}',
    '.ag-pensa i{width:7px;height:7px;border-radius:50%;background:var(--muted);animation:agPunto 1.2s infinite}',
    '.ag-pensa i:nth-child(2){animation-delay:.2s}.ag-pensa i:nth-child(3){animation-delay:.4s}',
    '@keyframes agPunto{0%,80%,100%{opacity:.25}40%{opacity:1}}',
    '.ag-piano{margin:6px 0 0;max-width:100%}',
    /* i suggerimenti: una fila che scorre di lato, da bordo a bordo, con il margine dentro (0.9.219) */
    '.ag-sug{display:flex;flex-wrap:nowrap;gap:8px;overflow-x:auto;overflow-y:hidden;margin:0 -34px;padding:8px 34px;scroll-snap-type:x proximity;scroll-padding:0 34px;scrollbar-width:none;-webkit-overflow-scrolling:touch;overscroll-behavior-x:contain}',
    '.ag-sug::-webkit-scrollbar{display:none}',
    '.ag-sug button{display:inline-flex;align-items:center;gap:7px;flex:0 0 auto;scroll-snap-align:start;white-space:nowrap;border:1px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:9px 15px;font:700 13px var(--font-body);color:var(--navy);cursor:pointer;box-shadow:0 1px 2px rgba(0,30,68,.06)}',
    '.ag-sug button:active{transform:scale(.97)}',
    '.ag-sug button .ag-ic,.ag-ben-sug button .ag-ic{color:var(--blue,#0075E3);stroke-width:2.2}',
    'body.dark .ag-sug button{background:rgba(255,255,255,.06);color:#fff;border-color:rgba(255,255,255,.25)}',
    '.ag-input{display:flex;gap:8px;align-items:flex-end;padding-top:6px}',
    '.ag-input button{display:flex;align-items:center;justify-content:center}',
    '.ag-ic{display:block;flex:none}',
    '.iconbtn .ag-ic{margin:auto}',
    /* il markdown nelle risposte dell'agente */
    '.ag-md p{margin:0 0 8px}.ag-md p:last-child,.ag-md ul:last-child,.ag-md ol:last-child{margin-bottom:0}',
    '.ag-md b{font-weight:800}',
    '.ag-md ul,.ag-md ol{margin:2px 0 8px;padding-left:20px}.ag-md li{margin:3px 0}',
    '.ag-md .ag-h{margin:10px 0 6px;font:800 15px/1.3 var(--font-display);color:var(--navy)}.ag-md .ag-h:first-child{margin-top:0}',
    '.ag-md .ag-h1{font-size:17px}.ag-md .ag-h3{font-size:14px}',
    'body.dark .ag-md .ag-h{color:#fff}',
    '.ag-md a{color:var(--blue,#0075E3);text-decoration:underline;overflow-wrap:anywhere}',
    'body.dark .ag-md a{color:#7CC0FF}',
    '.ag-md code{font:600 12.5px ui-monospace,monospace;background:rgba(0,30,68,.07);border-radius:5px;padding:1px 4px}',
    '.ag-md pre{margin:6px 0;padding:8px 10px;border-radius:10px;background:rgba(0,30,68,.07);font:500 12px/1.45 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere}',
    '.ag-md hr{border:0;border-top:1px solid var(--line);margin:10px 0}',
    '.ag-applica{display:flex!important;align-items:center;justify-content:center;gap:6px;text-align:center}',
    '.ag-prog-az{display:flex;flex-direction:column;gap:6px;margin-top:14px}.ag-prog-no{border:0;background:none;padding:10px;font:700 14px var(--font-body);color:var(--muted);cursor:pointer}',
    /* 0.9.222: gli orizzonti della roadmap proposta, chiusi; si aprono toccandoli */
    '.ag-anello summary{display:flex;align-items:center;gap:10px;list-style:none;cursor:pointer}.ag-anello summary::-webkit-details-marker{display:none}.ag-anello summary > div{flex:1;min-width:0}.ag-anello summary i{display:block;margin-top:3px;font:600 12px var(--font-body);font-style:normal;color:#0075E3}.ag-anello summary .ag-ic{flex:none;color:var(--muted,#7A8AA3);transition:transform .2s}.ag-anello[open] summary .ag-ic{transform:rotate(180deg)}',
    '.ag-tut{display:flex!important;align-items:center;justify-content:center;gap:8px}',
    '.blk-title .ag-tit{display:inline-flex;align-items:center;gap:8px;min-width:0}',
    '.blk-title .ag-tit > span:last-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    /* l'immagine dell'agente */
    '.ag-av{display:inline-flex;align-items:center;justify-content:center;flex:none;border-radius:50%;overflow:hidden;background:linear-gradient(135deg,#0E2350,#0B3E86);line-height:1}',
    '.ag-av img{width:100%;height:100%;object-fit:cover;display:block}',
    '.ag-av-s{width:28px;height:28px;font-size:17px}',
    '.ag-av-p{width:34px;height:34px;font-size:20px}',
    '.ag-av-r{width:24px;height:24px;font-size:14px}',
    '.ag-av-m{width:30px;height:30px;font-size:18px}',
    '.ag-ben-ico.ag-av{display:flex;align-items:center;justify-content:center;width:72px;height:72px;font-size:42px;margin:0 auto 14px;box-shadow:0 8px 24px rgba(0,30,68,.18)}.ag-ben-ico.ag-av img{width:100%;height:100%;object-fit:cover;display:block}',
    /* la scelta: il Genio o il tuo agente personale */
    '.ag-id{display:flex;flex-direction:column;gap:10px;margin:4px 0 6px}',
    '.ag-id-op{display:flex;align-items:center;gap:12px;width:100%;padding:13px 14px;border:2px solid var(--line);border-radius:16px;background:var(--card,#fff);text-align:left;cursor:pointer}',
    '.ag-id-op.on{border-color:var(--blue,#0075E3);background:rgba(0,117,227,.06)}',
    'body.dark .ag-id-op{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.14)}body.dark .ag-id-op.on{border-color:#4DA3FF;background:rgba(77,163,255,.12)}',
    '.ag-id-ico{flex:none;width:36px;display:flex;justify-content:center;font-size:26px}',
    '.ag-id-txt b{display:block;font:800 15px var(--font-display);color:var(--navy)}body.dark .ag-id-txt b{color:#fff}',
    '.ag-id-txt small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.ag-id-mio{padding:2px 2px 4px}',
    '.ag-id-mio .ag-nome{margin:10px 0 12px}',
    '.ag-id-lab{display:block;margin:0 0 8px;font:700 12.5px var(--font-body);color:var(--navy)}body.dark .ag-id-lab{color:#fff}',
    '.ag-id-emo{display:grid;grid-template-columns:repeat(6,1fr);gap:8px}',
    '.ag-id-emo button{aspect-ratio:1;border:2px solid var(--line);border-radius:14px;background:var(--card,#fff);font-size:24px;cursor:pointer;padding:0}',
    '.ag-id-emo button.on{border-color:var(--blue,#0075E3);background:rgba(0,117,227,.08)}',
    'body.dark .ag-id-emo button{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.14)}',
    '.ag-id-foto{display:flex;align-items:center;gap:10px;width:100%;margin-top:10px;padding:11px 14px;border:2px dashed var(--line);border-radius:14px;background:none;font:700 13px var(--font-body);color:var(--blue,#0075E3);cursor:pointer}',
    '.ag-id-foto.on{border-style:solid;border-color:var(--blue,#0075E3)}',
    '.ag-id-foto img{width:40px;height:40px;border-radius:50%;object-fit:cover}',
    /* il foglio dal basso, come Gemini */
    '.ag-fg-w{position:fixed;inset:0;z-index:9550;background:rgba(0,14,34,0);transition:background .2s;display:flex;align-items:flex-end;justify-content:center}',
    '.ag-fg-w.in{background:rgba(0,14,34,.45)}',
    '.ag-fg{width:100%;max-width:560px;max-height:88%;overflow-y:auto;box-sizing:border-box;padding:8px 14px calc(env(safe-area-inset-bottom,0px) + 16px);background:var(--card,#fff);border-radius:22px 22px 0 0;box-shadow:0 -10px 30px rgba(0,0,0,.18);transform:translateY(100%);transition:transform .24s cubic-bezier(.2,.8,.3,1)}',
    'body.dark .ag-fg{background:#0B1A33}',
    '.ag-fg-w.in .ag-fg{transform:none}',
    '.ag-fg-man{width:38px;height:4px;border-radius:4px;background:rgba(0,30,68,.18);margin:2px auto 12px}body.dark .ag-fg-man{background:rgba(255,255,255,.25)}',
    '.ag-fg-tit{margin:0 4px 10px;font:800 16px/1.35 var(--font-display);color:var(--navy);overflow-wrap:anywhere}body.dark .ag-fg-tit{color:#fff}',
    '.ag-fg-sotto{margin:-4px 4px 14px;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.ag-fg-r{display:flex;align-items:center;gap:16px;width:100%;padding:14px 8px;border:0;border-radius:12px;background:none;font:600 15px var(--font-body);color:var(--navy);text-align:left;cursor:pointer}',
    '.ag-fg-r:active{background:rgba(0,30,68,.06)}body.dark .ag-fg-r{color:#fff}',
    '.ag-fg-r.rosso{color:#E63946}',
    '.ag-fg-in{width:100%;box-sizing:border-box;margin:0 0 14px}',
    '.ag-fg-az{display:flex;gap:10px;justify-content:flex-end;margin-top:14px}',
    '.ag-fg-az button{min-width:96px;padding:12px 18px;border-radius:99px;border:0;font:800 14px var(--font-body);cursor:pointer}',
    '.ag-fg-no{background:rgba(0,30,68,.07);color:var(--navy)}body.dark .ag-fg-no{background:rgba(255,255,255,.1);color:#fff}',
    '.ag-fg-si{background:var(--blue,#0075E3);color:#fff}.ag-fg-si.rosso{background:#E63946}',
    /* la chat sopra la pagina, come Notion AI */
    '.ag-pop-w{position:fixed;inset:0;z-index:9450;background:rgba(0,14,34,0);transition:background .25s;display:flex;align-items:flex-end;justify-content:center}',
    '.ag-pop-w.in{background:rgba(0,14,34,.5)}',
    '.ag-pop{position:relative;width:100%;max-width:640px;height:85%;max-height:calc(100% - 24px);display:flex;flex-direction:column;box-sizing:border-box;padding:6px 12px calc(env(safe-area-inset-bottom,0px) + 10px);background:var(--bg,#F6F8FB);border-radius:24px 24px 0 0;box-shadow:0 -14px 40px rgba(0,0,0,.25);transform:translateY(100%);transition:transform .3s cubic-bezier(.2,.8,.3,1)}',
    'body.dark .ag-pop{background:#07142B}',
    '.ag-pop-w.in .ag-pop{transform:none}',
    '.ag-pop-man{width:42px;height:5px;border-radius:5px;background:rgba(0,30,68,.2);margin:4px auto 6px;touch-action:none;cursor:grab}body.dark .ag-pop-man{background:rgba(255,255,255,.28)}',
    '.ag-pop-h{display:flex;align-items:center;gap:10px;padding:4px 2px 10px;border-bottom:1px solid var(--line);touch-action:none}',
    '.ag-pop-nome{flex:1;min-width:0;font:800 17px var(--font-display);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}body.dark .ag-pop-nome{color:#fff}',
    '.ag-pop-b{flex:none;width:38px;height:38px;border:0;border-radius:50%;background:rgba(0,30,68,.07);color:var(--navy);display:flex;align-items:center;justify-content:center;cursor:pointer}',
    'body.dark .ag-pop-b{background:rgba(255,255,255,.1);color:#fff}',
    '.ag-pop-lista{flex:1;min-height:0}',
    '.ag-pop-in{padding-top:8px}',
    '.ag-pop-comp{flex:none;padding:8px 12px calc(10px + env(safe-area-inset-bottom))}.ag-pop-comp .ag-comp{margin:0}',
    '.ag-input textarea{flex:1;resize:none;border:1px solid var(--line);border-radius:16px;padding:10px 14px;font:500 14px/1.4 var(--font-body);color:var(--navy);background:var(--card,#fff);max-height:45vh}',
    'body.dark .ag-input textarea{background:rgba(255,255,255,.08);color:#fff;border-color:rgba(255,255,255,.2)}',
    '.ag-input button{flex:none;width:44px;height:44px;border:0;border-radius:50%;background:var(--blue,#0075E3);color:#fff;font-size:18px;cursor:pointer}',
    '.ag-canali-btn{margin-left:auto}',
    '.ag-guida-cta{margin-top:32px!important}',
    '.ag-page.benvenuto{justify-content:flex-end}',
    '.ag-ben{flex:1;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;padding:0 12px;min-height:0}.ag-page.benvenuto .ag-ben{justify-content:flex-start;padding-top:14px;overflow-y:auto;scrollbar-width:none}',
    '.ag-ben-ico{display:block;font-size:44px;margin-bottom:14px}',
    '.ag-ben h2{margin:0;font:600 26px/1.25 var(--font-display);color:var(--navy)}',
    'body.dark .ag-ben h2{color:#fff}',
    '.ag-ben p{margin:10px 0 0;font:500 13.5px/1.5 var(--font-body);color:var(--muted)}',
    '.ag-ben-sug{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:28px}',
    '.ag-ben-sug button{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--line);background:var(--card,#fff);border-radius:99px;padding:8px 14px;font:600 12.5px var(--font-body);color:var(--navy);cursor:pointer}',
    'body.dark .ag-ben-sug button{background:rgba(255,255,255,.06);border-color:rgba(255,255,255,.18);color:#fff}',
    '.ag-ben-storia{margin:18px 0 10px;border:0;background:none;font:600 11px var(--font-body);color:var(--blue,#0075E3);cursor:pointer}',
    '.ag-pers-riga{display:flex;align-items:center;gap:12px;width:100%;margin:0 0 10px;padding:12px 14px;border:0;border-radius:16px;background:var(--card,#fff);box-shadow:0 0 0 1.5px var(--line,#E5ECF6);text-align:left;cursor:pointer}body.dark .ag-pers-riga{background:rgba(255,255,255,.06);box-shadow:0 0 0 1.5px rgba(255,255,255,.18)}',
    /* 0.9.290, Andrea: "le frecce e le stelline sono scure nel tema scuro". Il pulsante non aveva un colore suo: le icone
       (currentColor) prendevano il nero di serie dei pulsanti. */
    '.ag-pers-riga{color:var(--navy,#14234A)}body.dark .ag-pers-riga{color:#fff}.ag-pers-riga > svg{flex:none;opacity:.85}',
    '.ag-pers-riga .ag-av-r{flex:none;width:44px;height:44px;border-radius:50%;overflow:hidden;font-size:22px;display:grid;place-items:center}.ag-pers-riga .ag-av-r img{width:100%;height:100%;object-fit:cover}',
    '.ag-id-pag .ag-id-mio{display:none}.ag-id-pag-mio .ag-id-op{display:none}.ag-id-pag .ag-id-op{margin-bottom:12px}',
    '.ag-pers-riga > span{flex:1;min-width:0}.ag-pers-riga b{display:block;font:800 14.5px var(--font-body);color:var(--navy,#14234A)}.ag-pers-riga small{display:block;font:500 12.5px var(--font-body);color:var(--muted,#5B6B86)}body.dark .ag-pers-riga b{color:#fff}body.dark .ag-pers-riga small{color:#C9D6EE}',
    '.ag-input-ben textarea{border-radius:28px;padding:14px 18px}',
    '.ag-input-ben button{width:48px;height:48px}',
    '.ag-saldo{margin:2px 0 0;text-align:center;font:600 11px var(--font-body);color:var(--faint)}',
    '.ag-can{margin:0 0 12px;padding:14px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff)}',
    'body.dark .ag-can{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.12)}',
    '.ag-can-t{display:flex;align-items:center;gap:10px;margin-bottom:8px}.ag-can-t span{font-size:20px}',
    '.ag-can-t b{font:800 15px var(--font-display);color:var(--navy)}body.dark .ag-can-t b{color:#fff}',
    '.ag-can-st{display:inline-block;font:700 12px var(--font-body);color:var(--muted);margin-right:10px}',
    '.ag-can-st.ok{color:#1B9E6A}',
    '.ag-can small{display:block;margin:6px 0 8px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.ag-can .btn,.ag-can .ghostmini{margin-top:4px}',
    '.ag-codice{display:block;font:800 20px var(--font-display);letter-spacing:.08em;color:var(--navy)}body.dark .ag-codice{color:#fff}',
    '.ag-attesa{color:#B8860B!important}',
    /* il cassetto delle conversazioni (0.9.214) */
    '.ag-menu{font-size:17px;margin-left:-6px}.ag-menu[hidden]{display:none}',
    '.ag-cas-w{position:fixed;inset:0;z-index:9300;background:rgba(0,14,34,0);transition:background .22s}',
    '.ag-cas-w.in{background:rgba(0,14,34,.45)}',
    '.ag-cas{position:absolute;left:0;top:0;bottom:0;width:min(84vw,330px);display:flex;flex-direction:column;box-sizing:border-box;',
    '  padding:calc(env(safe-area-inset-top,0px) + 16px) 12px calc(env(safe-area-inset-bottom,0px) + 12px);background:var(--card,#fff);',
    '  box-shadow:8px 0 30px rgba(0,0,0,.22);transform:translateX(-100%);transition:transform .26s cubic-bezier(.2,.8,.3,1)}',
    '.ag-cas-w.in .ag-cas{transform:none}',
    'body.dark .ag-cas{background:#0B1A33}',
    '.ag-cas-chi{display:flex;align-items:center;gap:10px;padding:0 4px 14px}',
    '.ag-cas-chi b{font:800 17px var(--font-display);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}body.dark .ag-cas-chi b{color:#fff}',
    '.ag-cas-t{display:flex;align-items:center;gap:8px;padding:0 0 12px}',
    '.ag-cas-cerca{flex:1;min-width:0;display:flex;align-items:center;gap:8px;height:44px;padding:0 14px;border-radius:99px;background:rgba(0,30,68,.06);color:var(--muted)}',
    'body.dark .ag-cas-cerca{background:rgba(255,255,255,.08)}',
    '.ag-cas-cerca input{flex:1;min-width:0;border:0;outline:0;background:none;font:500 14.5px var(--font-body);color:var(--navy)}',
    'body.dark .ag-cas-cerca input{color:#fff}',
    '.ag-cas-cerca input::-webkit-search-cancel-button{-webkit-appearance:none}',
    '.ag-cas-nuova{flex:none;width:44px;height:44px;display:flex;align-items:center;justify-content:center;border:0;border-radius:50%;background:rgba(0,30,68,.06);color:var(--navy);cursor:pointer}',
    'body.dark .ag-cas-nuova{background:rgba(255,255,255,.08);color:#fff}',
    '.ag-cas-sez{margin:12px 12px 4px;font:800 11.5px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:var(--muted)}',
    '.ag-cas-sez:first-child{margin-top:2px}',
    '.ag-cas-lista{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:2px;margin:0 -4px;padding:0 4px}',
    '.ag-cas-i{display:block;width:100%;padding:10px 12px;border:0;border-radius:12px;background:none;text-align:left;cursor:pointer;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none;touch-action:manipulation;transition:background .15s,transform .15s}',
    '.ag-cas-i.premuto{background:rgba(0,30,68,.07);transform:scale(.985)}',
    '.ag-cas-i-t{display:flex;align-items:center;gap:6px;min-width:0}',
    '.ag-cas-i b{flex:1;min-width:0;display:block;font:600 14px/1.35 var(--font-body);color:var(--navy);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    'body.dark .ag-cas-i b{color:#fff}',
    '.ag-cas-pin{flex:none;color:var(--muted);font-style:normal}',
    '.ag-cas-i em{display:block;margin-top:2px;font:500 12px/1.4 var(--font-body);font-style:normal;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.ag-cas-i small{display:block;margin-top:2px;font:600 11px var(--font-body);color:var(--muted)}',
    '.ag-cas-i.on{background:rgba(0,117,227,.1)}.ag-cas-i.on b{font-weight:800}',
    'body.dark .ag-cas-i.on{background:rgba(255,255,255,.08)}',
    '.ag-cas-vuoto{margin:8px 4px;font:500 12.5px/1.5 var(--font-body);color:var(--muted)}',
    /* 0.9.242: il campo in basso come Gemini e Claude */
    '.ag-comp{flex:none;margin-top:6px;border:1px solid var(--line);border-radius:24px;background:var(--card,#fff);padding:6px 6px 6px 6px;box-shadow:0 2px 10px rgba(15,32,65,.08)}',
    'body.dark .ag-comp{background:#14234A;border-color:rgba(255,255,255,.16);box-shadow:none}',
    '.ag-comp textarea{display:block;width:100%;box-sizing:border-box;resize:none;border:0;outline:0;background:none;min-height:58px;padding:10px 10px 6px;font:500 15px/1.4 var(--font-body);color:var(--navy);max-height:45vh}',
    'body.dark .ag-comp textarea{color:#fff}',
    '.ag-comp textarea::placeholder{color:var(--muted)}',
    '.ag-comp-riga{display:flex;align-items:center;gap:6px;min-height:40px}',
    '.ag-comp-sp{flex:1}',
    '.ag-comp-riga button{flex:none;display:flex;align-items:center;justify-content:center;border:0;cursor:pointer}',
    '.ag-comp-piu{width:40px;height:40px;border-radius:50%;background:rgba(15,32,65,.06);color:#0F2041}',
    'body.dark .ag-comp-piu{background:rgba(255,255,255,.1);color:#fff}',
    '.ag-comp-mic{width:40px;height:40px;border-radius:50%;background:#E3F1FF;color:#0075E3}',
    '.ag-comp-invia{width:40px;height:40px;border-radius:50%;background:rgba(0,117,227,.3);color:#fff;transition:background .15s}',
    '.ag-comp.pieno .ag-comp-invia{background:#0075E3}',
    '.ag-comp-reg{display:none;flex:1;align-items:center;gap:8px;min-width:0;height:40px;padding:0 4px;border-radius:99px;background:#E3F1FF;color:#0075E3}',
    '.ag-comp.reg .ag-comp-reg{display:flex}',
    '.ag-comp.reg .ag-comp-piu,.ag-comp.reg .ag-comp-sp,.ag-comp.reg .ag-comp-mic,.ag-comp.reg .ag-comp-invia{display:none}',
    '.ag-reg-x,.ag-reg-ok{width:32px!important;height:32px!important;border-radius:50%}',
    '.ag-reg-x{background:rgba(0,117,227,.14);color:#0075E3}',
    '.ag-reg-ok{background:#0075E3;color:#fff}',
    '.ag-reg-onda{flex:1;min-width:0;display:flex;align-items:center;justify-content:space-between;height:22px;padding:0 4px}',
    '.ag-reg-onda i{flex:none;width:3px;height:3px;border-radius:2px;background:#0075E3;opacity:.5;transition:height .07s linear}',
    '.ag-reg-t{flex:none;min-width:34px;font:700 13px var(--font-body);font-variant-numeric:tabular-nums;color:#0075E3}',
    '.ag-comp.scrivo .ag-reg-onda i{animation:agRecPulsa .9s ease-in-out infinite}',
    '.ag-reg-att{display:none;flex:1;min-width:0;align-items:center;gap:10px;padding:0 8px;font:700 13.5px var(--font-body);color:#0075E3}.ag-reg-att b{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.ag-comp.reg .ag-mod-btn{display:none!important}.ag-comp.scrivo .ag-reg-att{display:flex}.ag-comp.scrivo .ag-reg-onda,.ag-comp.scrivo .ag-reg-t,.ag-comp.scrivo .ag-reg-ok{display:none}',
    '.ag-spin{flex:none;width:18px;height:18px;border-radius:50%;border:2.5px solid rgba(0,117,227,.25);border-top-color:#0075E3;animation:agSpin .7s linear infinite}@keyframes agSpin{to{transform:rotate(360deg)}}',
    /* 0.9.344, Andrea: "come su Claude: la casella resta bassa, e la scelta del modello compare solo quando la tocco". Chiusa (non
       toccata, vuota, senza registrazione) e' una riga sola: il piu', il campo, il microfono e Invia */
    '.ag-comp:not(.aperto):not(.pieno):not(.reg){display:flex;align-items:center;gap:6px}.ag-comp:not(.aperto):not(.pieno):not(.reg) .ag-comp-riga{display:contents}',
    '.ag-comp:not(.aperto):not(.pieno):not(.reg) .ag-comp-piu{order:-1}.ag-comp:not(.aperto):not(.pieno):not(.reg) textarea{flex:1;min-width:0;width:auto}',
    '.ag-comp:not(.aperto):not(.pieno):not(.reg) .ag-mod-btn,.ag-comp:not(.aperto):not(.pieno):not(.reg) .ag-comp-sp,.ag-comp:not(.aperto):not(.pieno):not(.reg) .ag-comp-all:empty{display:none!important}',
    /* 0.9.344, Andrea: "il foglio del modello ha il titolo troppo piccolo ed e' tutto attaccato ai bordi" */
    '.ag-fg{padding:10px 22px calc(env(safe-area-inset-bottom,0px) + 26px)!important}.ag-fg-tit{margin:10px 0 8px!important;font-size:21px!important;line-height:1.25!important}.ag-mod-sotto{margin:0 0 20px!important;font-size:14.5px!important}',
    '.ag-az-btn{display:block;width:100%;margin:10px 0 2px;padding:14px;border:0;border-radius:16px;background:#0075E3;color:#fff;font:800 15px var(--font-body);box-shadow:0 6px 16px rgba(0,117,227,.3);cursor:pointer}',
    '@keyframes agRecPulsa{50%{opacity:.25}}',
    '.ag-comp-all{display:flex;gap:8px;overflow-x:auto;padding:0 4px}',
    '.ag-comp-all:not(:empty){padding:4px 4px 6px}',
    '.ag-all-c{position:relative;flex:none;display:flex;align-items:center;gap:6px;border-radius:12px;background:#EAF2FB;color:#0F2041;font:600 12px var(--font-body)}',
    'body.dark .ag-all-c{background:rgba(255,255,255,.1);color:#fff}',
    '.ag-all-c.img{width:58px;height:58px;overflow:hidden}',
    '.ag-all-c.img img{width:100%;height:100%;object-fit:cover;display:block}',
    '.ag-all-c.doc{max-width:190px;height:40px;padding:0 30px 0 10px}',
    '.ag-all-c.doc span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.ag-all-x{position:absolute;top:4px;right:4px;width:20px;height:20px;border:0;border-radius:50%;background:rgba(15,32,65,.72);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}',
    '.ag-all-c.doc .ag-all-x{top:10px;right:6px}',
    '.ag-all-m{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:6px;margin-bottom:4px}',
    '.ag-all-m img{width:120px;height:120px;object-fit:cover;border-radius:14px;display:block}',
    '.ag-all-m .ag-all-c.doc{padding:0 12px}',
    /* 0.9.242: il modello */
    '.ag-mod-btn{margin-left:2px;display:flex;align-items:center;gap:4px;height:32px;padding:0 10px 0 12px;border:1px solid var(--line);border-radius:99px;background:var(--card,#fff);font:700 12.5px var(--font-body);color:#0F2041;cursor:pointer}',
    '.ag-mod-btn[hidden]{display:none}',
    'body.dark .ag-mod-btn{background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.18);color:#fff}',
    '.ag-comp-riga .ag-mod-btn{height:30px;padding:0 9px 0 11px;font-size:12px}.ag-comp[data-ascolto] .ag-mod-btn{display:none}',
    '.ag-mod-sotto{margin:-4px 4px 12px;font:500 13px/1.5 var(--font-body);color:var(--muted)}',
    '.ag-mod-op{display:flex;align-items:flex-start;gap:12px;width:100%;margin-bottom:8px;padding:12px 14px;border:2px solid var(--line);border-radius:16px;background:none;text-align:left;cursor:pointer}',
    '.ag-mod-op.on{border-color:#0075E3;background:rgba(0,117,227,.06)}',
    'body.dark .ag-mod-op{border-color:rgba(255,255,255,.16)}body.dark .ag-mod-op.on{border-color:#0075E3;background:rgba(0,117,227,.16)}',
    '.ag-mod-pal{flex:none;width:22px;height:22px;margin-top:1px;border-radius:50%;border:2px solid var(--line);display:flex;align-items:center;justify-content:center;color:#fff;box-sizing:border-box}',
    '.ag-mod-op.on .ag-mod-pal{background:#0075E3;border-color:#0075E3}',
    '.ag-mod-txt b{display:block;font:800 15px var(--font-display);color:#0F2041}body.dark .ag-mod-txt b{color:#fff}',
    '.ag-mod-txt small{display:block;margin-top:3px;font:500 12.5px/1.45 var(--font-body);color:var(--muted)}',
    '.ag-mod-sw{display:flex;align-items:center;gap:12px;margin-top:8px;padding:14px 4px 4px;border-top:1px solid var(--line);cursor:pointer}',
    '.ag-mod-sw span{flex:1;min-width:0}',
    '.ag-mod-sw b{display:block;font:700 14px/1.35 var(--font-body);color:#0F2041}body.dark .ag-mod-sw b{color:#fff}',
    '.ag-mod-sw small{display:block;margin-top:3px;font:500 12px/1.45 var(--font-body);color:var(--muted)}',
    '.ag-mod-sw input{position:absolute;opacity:0;width:1px;height:1px}',
    '.ag-mod-sw i{flex:none;position:relative;width:46px;height:28px;border-radius:99px;background:rgba(15,32,65,.18);transition:background .15s}',
    '.ag-mod-sw i::after{content:"";position:absolute;top:3px;left:3px;width:22px;height:22px;border-radius:50%;background:#fff;box-shadow:0 1px 3px rgba(15,32,65,.3);transition:transform .15s}',
    '.ag-mod-sw input:checked + i{background:#0075E3}.ag-mod-sw input:checked + i::after{transform:translateX(18px)}',
    'body.dark .ag-mod-sw i{background:rgba(255,255,255,.2)}',
    /* 0.9.242: consumi e spesa */
    '.ag-cons{padding-bottom:28px}',
    '.ag-cons-sotto{margin:4px 2px 12px;font:600 13px var(--font-body);color:var(--muted)}',
    '.ag-cons-hero{padding:18px;border-radius:20px;background:#14234A;color:#fff}',
    '.ag-cons-hero small{display:block;font:700 12px var(--font-body);color:#8CC6FF;letter-spacing:.02em}',
    '.ag-cons-hero b{display:block;margin-top:4px;font:800 34px/1.1 var(--font-display)}',
    '.ag-cons-hero p{margin:8px 0 0;font:500 12px/1.5 var(--font-body);color:rgba(255,255,255,.78)}',
    '.ag-cons-griglia{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}',
    '.ag-cons-tile{padding:12px 14px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff)}',
    'body.dark .ag-cons-tile{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.12)}',
    '.ag-cons-tile small{display:block;font:600 11.5px/1.35 var(--font-body);color:var(--muted)}',
    '.ag-cons-tile b{display:block;margin-top:6px;font:800 18px/1.2 var(--font-display);color:#0F2041;overflow-wrap:anywhere}',
    'body.dark .ag-cons-tile b{color:#fff}',
    '.ag-cons-graf{padding:12px 14px 10px;border:1px solid var(--line);border-radius:16px;background:var(--card,#fff)}',
    'body.dark .ag-cons-graf{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.12)}',
    '.ag-cons-graf svg{display:block;width:100%;height:120px}',
    '.ag-cons-graf rect.si{fill:#0075E3}.ag-cons-graf rect.no{fill:#0075E3;opacity:.18}',
    '.ag-cons-max{margin-bottom:6px;font:700 11px var(--font-body);color:var(--muted)}',
    '.ag-cons-x{display:flex;justify-content:space-between;margin-top:6px;font:600 11px var(--font-body);color:var(--muted)}',
    '.ag-cons-mod{border:1px solid var(--line);border-radius:16px;background:var(--card,#fff);padding:0 14px}',
    'body.dark .ag-cons-mod{background:rgba(255,255,255,.05);border-color:rgba(255,255,255,.12)}',
    '.ag-cons-mr{display:flex;align-items:center;gap:12px;padding:12px 0;border-top:1px solid var(--line)}.ag-cons-mr:first-child{border-top:0}',
    '.ag-cons-mr div{flex:1;min-width:0}',
    '.ag-cons-mr b{display:block;font:800 14px var(--font-display);color:#0F2041}body.dark .ag-cons-mr b{color:#fff}',
    '.ag-cons-mr small{display:block;margin-top:2px;font:500 11.5px var(--font-body);color:var(--muted);overflow-wrap:anywhere}',
    '.ag-cons-mr > span{flex:none;font:800 14px var(--font-body);color:#0075E3}',
    '.ag-cons-nota{margin:14px 2px 0;font:500 12px/1.55 var(--font-body);color:var(--muted)}'
  ].join('');
  document.head.appendChild(st);
})();

/* INCOLLARE GLI SCREENSHOT NELLA CHAT (0.9.282, Andrea): un'immagine copiata negli Appunti (tastiera Samsung o Gboard)
   diventa un allegato del messaggio, come con il +. La tastiera la consegna con __notaIncollaImmagine (WebViewImmagini.java):
   qui si prende solo se il cursore e' nel campo della chat, altrimenti passa alle note. */
function agIncollaImmagine(blob){
  try{
    const f = new File([blob], 'screenshot.' + ((blob.type || 'image/png').split('/')[1] || 'png'), { type: blob.type || 'image/png' });
    agFotoRiduci(f).then(function(x){ AG.allegati = (AG.allegati || []).concat([x]).slice(0, 6); agAllPaint(); if (typeof toast === 'function') toast('Immagine allegata'); })
      .catch(function(){ if (typeof toast === 'function') toast('Non sono riuscito ad allegare l\u2019immagine'); });
  }catch(_){ }
}
window.__notaIncollaImmagine = function(d){
  const a = document.activeElement;
  if (!a || a.id !== 'agTesto') return false;
  fetch(d).then(function(r){ return r.blob(); }).then(agIncollaImmagine).catch(function(){ });
  return true;
};
document.addEventListener('paste', function(e){
  const t = e.target; if (!t || t.id !== 'agTesto') return;
  const items = (e.clipboardData && e.clipboardData.items) || [];
  for (let i = 0; i < items.length; i++){
    if (items[i].kind === 'file' && /^image\//.test(items[i].type)){ const b = items[i].getAsFile(); if (b){ e.preventDefault(); agIncollaImmagine(b); } return; }
  }
}, true);

/* ===========================================================================================
   0.9.344 — QUANDO LA RISPOSTA CI METTE MINUTI
   Andrea: "ha risposto dopo 5 minuti: l'utente pensa che si sia bloccato. Deve dire 'intanto fai questo, ti avviso io', e
   mostrare che il lavoro e' in corso anche fuori dalla chat". Dopo 20 secondi di attesa, sotto a "sta scrivendo" compare un
   cartello con il tempo passato. Uscendo dalla chat l'app continua a chiedere la risposta, una pillola in alto dice che il
   lavoro e' in corso, e quando la risposta arriva la pillola diventa "E' pronta" e si tocca.
   =========================================================================================== */
const AGW = { da: 0, bar: null, pronta: 0 };
function agwMinuti(){ const s = Math.max(0, Math.round((Date.now() - AGW.da) / 1000)); return s < 60 ? s + ' secondi' : Math.floor(s / 60) + (Math.floor(s / 60) === 1 ? ' minuto' : ' minuti'); }
function agwCartello(){
  const l = document.getElementById('agLista'); const p = l && l.querySelector('.ag-pensa');
  let c = document.getElementById('agwCart');
  if (!p || !AG.attesa || Date.now() - AGW.da < 20000){ if (c) c.remove(); return; }
  if (!c){
    c = document.createElement('div'); c.id = 'agwCart'; c.className = 'agw-cart';
    c.innerHTML = '<i class="agw-barra" aria-hidden="true"></i><b>Ci sto lavorando</b>'
      + '<p>Una risposta ragionata può volerci qualche minuto. Puoi uscire dalla chat e fare altro.</p><p class="agw-poi">Ti avviso io appena è pronta.</p><small id="agwT"></small>';
    p.after(c);
    try{ if (l.scrollHeight - l.scrollTop - l.clientHeight < 260) l.scrollTop = l.scrollHeight; }catch(_){ }
  } else if (c.previousElementSibling !== p) p.after(c);
  const t = document.getElementById('agwT'); if (t) t.textContent = 'In lavoro da ' + agwMinuti();
}
function agwInChat(){ try{ return document.getElementById('s-agente').classList.contains('active') || !!document.getElementById('agPop'); }catch(_){ return false; } }
function agwZitto(){ try{ return (typeof spZitto === 'function') && spZitto(); }catch(_){ return false; } }
function agwPillola(){
  const fuori = !agwInChat();
  let b = document.getElementById('agwPill');
  const mostra = fuori && !agwZitto() && ((AG.attesa && Date.now() - AGW.da > 8000) || (AGW.pronta && Date.now() - AGW.pronta < 30000));
  if (!mostra){ if (b) b.remove(); return; }
  if (!b){
    b = document.createElement('button'); b.type = 'button'; b.id = 'agwPill'; b.className = 'agw-pill';
    b.onclick = function(){ AGW.pronta = 0; try{ b.remove(); }catch(_){ } try{ agApri(); }catch(_){ } };
    document.body.appendChild(b);
  }
  const pronta = !AG.attesa && AGW.pronta;
  b.classList.toggle('pronta', !!pronta);
  b.innerHTML = pronta ? '<span aria-hidden="true">✅</span><b>La risposta ' + agEsc(agwDel()) + ' è pronta</b>' : '<i class="ag-spin" aria-hidden="true"></i><b>' + agEsc(agNomeSoggetto()) + ' sta preparando la tua risposta</b>';
}
function agwDel(){ try{ const n = agNomeSoggetto(); return /^Il /.test(n) ? 'del ' + n.slice(3) : 'di ' + n; }catch(_){ return 'del Genio'; } }
setInterval(function(){
  try{
    if (typeof AG === 'undefined') return;
    if (AG.attesa && !AGW.da) AGW.da = Date.now();
    if (!AG.attesa && AGW.da){
      /* e' arrivata: se non ero nella chat, la pillola lo dice */
      if (!agwInChat() && Date.now() - AGW.da > 8000){ AGW.pronta = Date.now(); try{ flVibra([12, 60, 12]); }catch(_){ } }
      AGW.da = 0;
    }
    if (AG.attesa && !agwInChat() && !AG.sincro && !AG.poll && (!AGW.giro || Date.now() - AGW.giro > 6000)){ AGW.giro = Date.now(); try{ agSync(false); }catch(_){ } }
    agwCartello(); agwPillola();
  }catch(_){ }
}, 1000);
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '.agw-cart{position:relative;overflow:hidden;margin:6px 0 10px;padding:16px 16px 14px;border-radius:18px;background:var(--card,#fff);border:1.5px solid #CFE3FA;max-width:88%}.agw-cart b{display:block;font:800 15.5px var(--font-display);color:var(--navy)}.agw-cart p{margin:8px 0 0;font:500 14px/1.5 var(--font-body);color:var(--muted)}.agw-cart .agw-poi{margin-top:4px;font-weight:700;color:var(--navy)}.agw-cart small{display:block;margin-top:10px;font:700 12px var(--font-body);color:#0075E3}',
    '.agw-barra{position:absolute;left:0;top:0;height:3px;width:40%;border-radius:3px;background:#0075E3;animation:agwScorre 1.4s ease-in-out infinite}@keyframes agwScorre{0%{transform:translateX(-100%)}100%{transform:translateX(250%)}}',
    'body.dark .agw-cart{background:#12203A;border-color:#22345A}body.dark .agw-cart b,body.dark .agw-cart .agw-poi{color:#fff}body.dark .agw-cart small{color:#8CC6FF}',
    '.agw-pill{position:fixed;left:50%;top:calc(env(safe-area-inset-top,0px) + 8px);transform:translateX(-50%);z-index:8800;display:flex;align-items:center;gap:10px;max-width:calc(100% - 28px);padding:10px 16px;border:0;border-radius:99px;background:#001E44;color:#fff;font:700 13px var(--font-body);box-shadow:0 10px 26px rgba(0,30,68,.35);cursor:pointer;animation:agwGiu .3s ease}.agw-pill b{font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.agw-pill .ag-spin{border-color:rgba(255,255,255,.3);border-top-color:#fff;width:16px;height:16px}.agw-pill.pronta{background:#0075E3}',
    '@keyframes agwGiu{from{opacity:0;transform:translate(-50%,-14px)}to{opacity:1;transform:translateX(-50%)}}'
  ].join('\n');
  document.head.appendChild(st);
})();
