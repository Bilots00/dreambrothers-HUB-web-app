/* ===========================================================================================
   GLI EFFETTI SONORI DEL GIOCO (0.9.308)

   Andrea: "non c'e' ancora nessun suono per gli esercizi di respirazione anche se il suono e'
   attivo, nonostante abbia creato apposta la sezione music nella web app [...] come in un
   videogioco o in Duolingo: all'apertura delle schermate, quando si sblocca qualcosa,
   all'aumento di livello, al riempimento di una barra".

   LE CAUSE VERE.
   1. La libreria (web app, /music/libreria) produce ogni notte un pacchetto di nove effetti e
      quattro tracce, ma nessuno era pubblicato su Dream Map: il manifest pubblico
      (/api/focuslock/music/manifest) era vuoto. Dal 0.9.308 il server pubblica da solo i
      pezzi notturni (server/music/service.ts, autoPublish).
   2. L'app quel manifest non lo leggeva da nessuna parte. I "suoni" erano bip sintetizzati sul
      momento (respiro.js, musica.js, genio-intro.js), a volume bassissimo e in un registro che
      l'altoparlante di un telefono quasi non riproduce: il respiro suonava una sinusoide a
      330-523 Hz con il picco a 0,12 (-18 dBFS), il tic dei trenta respiri a 0,04 (-28 dBFS).
      Sul telefono vuol dire silenzio.

   COME FUNZIONA.
   - fxCatalogo() scarica il manifest (al massimo ogni mezz'ora, con l'ETag) e lo tiene in
     fl_fx_catalogo. Per ogni tipo di effetto si usa il piu' recente (quelli scelti a mano da
     Andrea vincono su quelli pubblicati da soli): ogni notte arriva un suono nuovo.
   - I file finiscono nella Cache API (fx-libreria-1): la seconda volta suonano senza rete.
   - Senza rete e senza cache suona la copia dentro all'APK (audio/sfx/<tipo>.mp3, il pacchetto
     della notte del 30/10/2026); se manca anche quella, il bip sintetizzato di prima.
   - fxSuona(evento) e' l'unica porta: un canale solo, niente suoni sovrapposti. Un suono piu'
     importante interrompe uno meno importante; uno di pari importanza (>= 3) aspetta che
     finisca quello in corso; uno meno importante si salta.
   - Tace con l'interruttore "Effetti sonori" spento (Personalizza), con la suoneria del
     telefono in silenzioso o in vibrazione, e durante una telefonata. Il respiro guidato fa
     eccezione per la suoneria: lo accendi tu con l'altoparlante della sessione.
   =========================================================================================== */
const FX = { ctx: null, master: null, man: null, buf: {}, url: {}, cur: null, coda: null, ultimo: {}, suoneria: 'normale', chiamata: false,
             spegni: 0, brano: null, branoId: '', branoCache: {}, partenza: Date.now(), tabPrima: '' };
const FX_KEY = 'fl_effetti';
const FX_CAT_KEY = 'fl_fx_catalogo';
const FX_SENTITI_KEY = 'fl_fx_sentiti';
const FX_CACHE = 'fx-libreria-1';
const FX_VOL = 0.62;            // volume moderato: la libreria esce a -16 LUFS, qui circa -20
const FX_TIPI = ['reward', 'coin', 'level-up', 'success', 'fail', 'chest-open', 'mystery-box', 'click', 'whoosh'];
/* evento -> [tipo della libreria, volume, velocita', importanza] */
const FX_EVENTI = {
  giusta:          ['success', .9, 1, 2],
  sbagliata:       ['fail', .8, 1, 2],
  moneta:          ['coin', .8, 1, 2],
  barra:           ['coin', .7, 1.12, 2],
  sblocco:         ['success', 1, 1.12, 4],
  missione:        ['success', 1, 1, 3],
  xp:              ['coin', 1, 1, 3],
  serie:           ['reward', .9, 1.06, 3],
  fine:            ['reward', 1, 1, 4],
  livello:         ['level-up', 1, 1, 5],
  scrigno:         ['chest-open', 1, 1, 5],
  mystery:         ['mystery-box', 1, 1, 5],
  tic:             ['click', .35, 1.2, 0],
  scelta:          ['click', .6, 1, 1],
  punto:           ['success', .85, 1, 2],
  schermata:       ['whoosh', .32, 1.25, 0],
  'respiro-in':    ['whoosh', .95, .95, 1],
  'respiro-out':   ['whoosh', .85, .72, 1],
  'respiro-soffio':['whoosh', .95, .62, 1],
  'respiro-tieni': ['click', .75, .9, 1],
  'respiro-tic':   ['click', .5, 1.1, 1],
  'respiro-apnea': ['click', .85, .75, 1],
  'respiro-fine':  ['reward', 1, 1, 4]
};
/* i nomi dei jingle di musica.js -> gli eventi qui sopra */
const FX_JINGLE = { giusta: 'giusta', sbagliata: 'sbagliata', moneta: 'moneta', tappa: 'fine', capitolo: 'livello', scrigno: 'scrigno',
                    serie: 'serie', barra: 'barra', missione: 'missione', tic: 'tic', livello: 'livello' };
const FX_CATEGORIE = [
  { k: 'concentrarti', t: 'Musica per concentrarti', scopi: ['focus', 'study', 'work'] },
  { k: 'rilassarti', t: 'Musica per rilassarti', scopi: ['relax', 'meditate'] },
  { k: 'dormire', t: 'Musica per dormire', scopi: ['sleep'] }
];
const FX_SCOPO = { focus: 'Concentrazione', study: 'Studio', work: 'Lavoro', relax: 'Rilassamento', meditate: 'Meditazione', sleep: 'Sonno' };

function fxBase(){ return (typeof FL_BACKEND !== 'undefined') ? FL_BACKEND : 'https://meta-ai-media-buyer-production.up.railway.app'; }
function fxEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }

/* ---------- l'interruttore e il silenzio ---------- */
function fxAppAttivi(){
  try{ if (localStorage.getItem(FX_KEY) === '0') return false; }catch(_){ }
  try{ if (typeof muMuto === 'function' && muMuto()) return false; }catch(_){ }
  return true;
}
function fxImposta(on){
  try{ localStorage.setItem(FX_KEY, on ? '1' : '0'); }catch(_){ }
  if (!on) fxFerma();
  else { fxSblocca(); setTimeout(function(){ fxSuona('giusta'); }, 60); }
  fxPaginaRidisegna();
}
/** Possono suonare adesso? forza = il respiro guidato, che ignora la suoneria del telefono. */
function fxPossono(forza){
  if (!fxAppAttivi()) return false;
  if (FX.chiamata) return false;
  if (!forza && FX.suoneria !== 'normale') return false;
  return true;
}
/* la suoneria si chiede al telefono ogni tanto (e al rientro nell'app), non a ogni suono */
async function fxLeggiSuoneria(){
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.silenzioOra){
      const r = await NATIVE.silenzioOra();
      if (r && typeof r.suoneria === 'string') FX.suoneria = r.suoneria;
      FX.chiamata = !!(r && r.chiamata);
    }
  }catch(_){ }
}

/* ---------- l'audio ---------- */
function fxCtx(){
  if (!FX.ctx){
    try{
      const C = window.AudioContext || window.webkitAudioContext; if (!C) return null;
      FX.ctx = new C(); FX.master = FX.ctx.createGain(); FX.master.gain.value = FX_VOL; FX.master.connect(FX.ctx.destination);
    }catch(_){ FX.ctx = null; }
  }
  return FX.ctx;
}
/* al primo tocco l'audio si sblocca (le regole del browser vogliono un gesto) */
function fxSblocca(){
  const c = fxCtx();
  if (c && c.state === 'suspended'){ try{ c.resume(); }catch(_){ } }
}
/* a riposo il canale si spegne: un AudioContext acceso tiene sveglio l'audio del telefono */
function fxRiposo(){
  clearTimeout(FX.spegni);
  FX.spegni = setTimeout(function(){ try{ if (FX.ctx && FX.ctx.state === 'running' && !FX.cur) FX.ctx.suspend(); }catch(_){ } }, 20000);
}

/* ---------- il catalogo della libreria ---------- */
function fxCatLeggi(){ try{ return JSON.parse(localStorage.getItem(FX_CAT_KEY) || 'null'); }catch(_){ return null; } }
function fxItems(){ const c = FX.man || fxCatLeggi(); return (c && c.man && Array.isArray(c.man.items)) ? c.man.items : []; }
/** L'effetto di oggi per un tipo: il piu' recente, e quelli scelti a mano prima di quelli automatici. */
function fxDaLibreria(tipo){
  const l = fxItems().filter(function(x){ return x && x.kind === 'sfx' && x.sfxType === tipo && x.url && (!x.uses || !x.uses.length || x.uses.indexOf('game_sfx') >= 0); });
  l.sort(function(a, b){ return ((a.auto ? 1 : 0) - (b.auto ? 1 : 0)) || (Date.parse(b.publishedAt || 0) - Date.parse(a.publishedAt || 0)); });
  return l[0] || null;
}
async function fxCatalogo(forza){
  const vecchio = fxCatLeggi();
  if (!forza && vecchio && Date.now() - (vecchio.at || 0) < 30 * 60000){ FX.man = vecchio; return vecchio; }
  let man = null, etag = '';
  try{
    const h = {}; if (vecchio && vecchio.etag) h['If-None-Match'] = vecchio.etag;
    const r = await fetch(fxBase() + '/api/focuslock/music/manifest', { headers: h, cache: 'no-store' });
    if (r.status === 304 && vecchio){ vecchio.at = Date.now(); FX.man = vecchio; try{ localStorage.setItem(FX_CAT_KEY, JSON.stringify(vecchio)); }catch(_){ } return vecchio; }
    if (r.ok){ man = await r.json(); etag = r.headers.get('ETag') || ''; }
  }catch(_){ }
  if (!man){
    try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.publicApi) man = await NATIVE.publicApi({ method: 'GET', path: '/api/focuslock/music/manifest' }); }catch(_){ man = null; }
  }
  if (!man || !Array.isArray(man.items)){ if (vecchio) FX.man = vecchio; return vecchio; }
  const nuovo = { at: Date.now(), etag: etag, man: man };
  FX.man = nuovo;
  try{ localStorage.setItem(FX_CAT_KEY, JSON.stringify(nuovo)); }catch(_){ }
  /* se un tipo ha un file nuovo, il suono decodificato di prima non vale piu' */
  FX_TIPI.forEach(function(t){ const it = fxDaLibreria(t); if (it && FX.url[t] && FX.url[t] !== it.url){ delete FX.buf[t]; delete FX.url[t]; } });
  fxScaricaEffetti();
  fxPaginaRidisegna();
  return nuovo;
}
/* i nove effetti di oggi (una ventina di KB l'uno) si scaricano subito; le tracce lunghe solo quando le ascolti */
async function fxScaricaEffetti(){
  if (typeof caches === 'undefined') return;
  try{
    const c = await caches.open(FX_CACHE);
    const tieni = {};
    for (const t of FX_TIPI){
      const it = fxDaLibreria(t); if (!it) continue;
      tieni[it.url] = 1;
      if (!(await c.match(it.url))){ try{ const r = await fetch(it.url); if (r.ok) await c.put(it.url, r); }catch(_){ } }
    }
    fxItems().forEach(function(x){ if (x.kind === 'track' && x.url) tieni[x.url] = 1; });
    /* via dalla cache quello che la libreria non pubblica piu' */
    for (const req of await c.keys()){ if (!tieni[req.url]) await c.delete(req); }
  }catch(_){ }
}
async function fxByte(url){
  if (typeof caches !== 'undefined'){
    try{
      const c = await caches.open(FX_CACHE);
      const hit = await c.match(url);
      if (hit) return await hit.arrayBuffer();
      const r = await fetch(url);
      if (r.ok){ try{ await c.put(url, r.clone()); }catch(_){ } return await r.arrayBuffer(); }
    }catch(_){ }
  }
  try{ const r = await fetch(url); if (r.ok) return await r.arrayBuffer(); }catch(_){ }
  return null;
}
async function fxDecodifica(ab){
  const c = fxCtx(); if (!c || !ab) return null;
  return await new Promise(function(ok){ try{ c.decodeAudioData(ab.slice(0), ok, function(){ ok(null); }); }catch(_){ ok(null); } });
}
/** Il suono di un tipo, decodificato: libreria (cache o rete), poi la copia nell'APK. */
async function fxBuffer(tipo){
  if (FX.buf[tipo]) return FX.buf[tipo];
  const it = fxDaLibreria(tipo);
  let b = null;
  if (it){ b = await fxDecodifica(await fxByte(it.url)); if (b) FX.url[tipo] = it.url; }
  if (!b){ try{ const r = await fetch('audio/sfx/' + tipo + '.mp3'); if (r.ok) b = await fxDecodifica(await r.arrayBuffer()); }catch(_){ b = null; } if (b) FX.url[tipo] = 'apk'; }
  if (b) FX.buf[tipo] = b;
  return b;
}
/** Decodifica in anticipo, cosi' il primo suono non arriva in ritardo (il respiro, appena parte). */
function fxScalda(tipi){ (tipi || FX_TIPI).forEach(function(t){ fxBuffer(t).catch(function(){ }); }); }

/* ---------- suonare ---------- */
function fxFerma(){
  const c = FX.cur; FX.cur = null; FX.coda = null;
  if (!c) return;
  try{ const t = FX.ctx.currentTime; c.g.gain.cancelScheduledValues(t); c.g.gain.setValueAtTime(Math.max(0.0001, c.g.gain.value), t); c.g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05); c.src.stop(t + 0.06); }catch(_){ }
}
/**
 * Suona un evento. opz: { forza (ignora la suoneria: il respiro), ripiego (funzione da chiamare se non c'e' nessun
 * file da suonare), velocita' (cambia l'altezza: le scelte che salgono). Ritorna true se l'evento e' stato preso
 * in carico (anche quando e' giusto che taccia), false se non lo conosce.
 */
function fxSuona(ev, opz){
  opz = opz || {};
  const e = FX_EVENTI[ev]; if (!e) return false;
  if (!fxPossono(!!opz.forza)) return true;
  const ora = performance.now();
  /* lo stesso evento due volte di fila (un gancio doppio, un ridisegno) suona una volta sola */
  if (FX.ultimo[ev] && ora - FX.ultimo[ev] < (e[3] >= 3 ? 1500 : 90)) return true;
  if (FX.cur && FX.cur.fine > ora){
    if (FX.cur.pri > e[3] || (FX.cur.pri === e[3] && e[3] < 3)){ if (e[3] >= 3) FX.coda = { ev: ev, opz: opz }; return true; }
    if (FX.cur.pri === e[3]){ FX.coda = { ev: ev, opz: opz }; return true; }
  }
  FX.ultimo[ev] = ora;
  const c = fxCtx(); if (!c){ if (opz.ripiego) opz.ripiego(); return true; }
  fxSblocca();
  const prenota = { pri: e[3], fine: ora + 400, src: null, g: null, ev: ev };
  /* il posto si prenota subito: un secondo evento mentre il file si decodifica non passa davanti */
  if (FX.cur) fxFerma();
  FX.cur = prenota;
  fxBuffer(e[0]).then(function(b){
    if (FX.cur !== prenota) return;
    if (!b){ FX.cur = null; if (opz.ripiego) try{ opz.ripiego(); }catch(_){ } return; }
    try{
      const vel = (opz.velocita || 1) * e[2];
      const src = c.createBufferSource(); src.buffer = b; src.playbackRate.value = vel;
      const g = c.createGain(); g.gain.value = e[1];
      src.connect(g); g.connect(FX.master);
      src.start();
      prenota.src = src; prenota.g = g; prenota.fine = performance.now() + (b.duration / vel) * 1000;
      src.onended = function(){
        if (FX.cur !== prenota) return;
        FX.cur = null;
        const q = FX.coda; FX.coda = null;
        if (q) fxSuona(q.ev, q.opz); else fxRiposo();
      };
    }catch(_){ FX.cur = null; if (opz.ripiego) try{ opz.ripiego(); }catch(__){ } }
  });
  return true;
}

/* ---------- le tracce della libreria nella pagina Suoni ---------- */
function fxSentiti(){ try{ return JSON.parse(localStorage.getItem(FX_SENTITI_KEY) || '[]') || []; }catch(_){ return []; } }
function fxNuovo(x){
  const t = Date.parse(x.publishedAt || 0);
  return t && Date.now() - t < 3 * 86400000 && fxSentiti().indexOf(x.id) < 0;
}
/* 0.9.340, Andrea: "le tracce partono in quinta, senza un'intro": il volume sale da zero in sei secondi (piano all'inizio,
   come un crescendo) e quando la fermi scende in due. */
function fxSfuma(a, da, a2, ms, poi){
  const t0 = Date.now();
  clearInterval(a._fx);
  a._fx = setInterval(function(){
    const u = Math.min(1, (Date.now() - t0) / ms), k = da < a2 ? u * u : u;
    try{ a.volume = Math.max(0, Math.min(1, da + (a2 - da) * k)); }catch(_){ }
    if (u >= 1){ clearInterval(a._fx); if (poi) poi(); }
  }, 50);
}
function fxBranoFerma(){
  const a = FX.brano; FX.brano = null; const id = FX.branoId; FX.branoId = '';
  const url = FX.branoUrl; FX.branoUrl = '';
  if (a){ fxSfuma(a, a.volume, 0, 2000, function(){ try{ a.pause(); a.removeAttribute('src'); a.load(); }catch(_){ } if (url){ try{ URL.revokeObjectURL(url); }catch(_){ } } }); }
  else if (url){ try{ URL.revokeObjectURL(url); }catch(_){ } }
  return id;
}
async function fxBrano(id){
  try{ if (typeof suoStaccata === 'function') suoStaccata(); }catch(_){ }
  const x = fxItems().filter(function(i){ return i.id === id; })[0]; if (!x) return;
  if (FX.branoId === id){ fxBranoFerma(); fxPaginaRidisegna(); return; }
  fxBranoFerma();
  /* un suono alla volta: la natura o le musiche per la testa si fermano */
  try{ if (typeof sndStop === 'function' && typeof SND !== 'undefined' && SND.id !== 'none'){ sndStop(); SND.id = 'none'; SND.playing = false; } }catch(_){ }
  const s = fxSentiti(); if (s.indexOf(id) < 0){ s.push(id); try{ localStorage.setItem(FX_SENTITI_KEY, JSON.stringify(s.slice(-200))); }catch(_){ } }
  const a = new Audio();
  a.loop = true; a.preload = 'auto';
  let liv = 0.5; try{ liv = (typeof sndLevel === 'function') ? Math.max(0.05, sndLevel()) : 0.5; }catch(_){ liv = 0.5; }
  a.volume = 0;
  FX.brano = a; FX.branoId = id;
  /* gia' in cache: si suona senza rete. Altrimenti si ascolta subito dalla rete e, dopo mezzo minuto, si salva. */
  let src = x.url;
  try{
    if (typeof caches !== 'undefined'){
      const hit = await (await caches.open(FX_CACHE)).match(x.url);
      if (hit){ FX.branoUrl = URL.createObjectURL(await hit.blob()); src = FX.branoUrl; }
    }
  }catch(_){ }
  if (FX.branoId !== id) return;
  a.src = src;
  a.play().then(function(){ if (FX.brano === a) fxSfuma(a, 0, liv, 6000); }).catch(function(){ if (FX.branoId === id){ fxBranoFerma(); try{ toast('Questa traccia adesso non parte: riprova con la connessione'); }catch(_){ } fxPaginaRidisegna(); } });
  if (src === x.url) setTimeout(function(){
    if (FX.branoId !== id || typeof caches === 'undefined') return;
    caches.open(FX_CACHE).then(function(c){ return c.match(x.url).then(function(h){ if (h) return; return fetch(x.url).then(function(r){ if (r.ok) return c.put(x.url, r); }); }); }).catch(function(){ });
  }, 30000);
  fxPaginaRidisegna();
}
function fxBranoVolume(v){ try{ if (FX.brano) FX.brano.volume = Math.max(0.05, Math.min(1, v)); }catch(_){ } }
function fxMin(sec){ const m = Math.round((sec || 0) / 60); return m <= 1 ? '1 minuto' : m + ' minuti'; }
/* ---------- la pagina: le categorie della libreria ----------
   fxMusicaHtml: le tracce nuove, in cima alla lista dei suoni della tendina della Sveglia. */
function fxMusicaHtml(){
  const items = fxItems();
  const tracce = items.filter(function(x){ return x.kind === 'track' && x.url && !(typeof suoChiusa === 'function' && suoChiusa(x.id)); });
  let h = '';
  FX_CATEGORIE.forEach(function(cat){
    const l = tracce.filter(function(x){ return cat.scopi.indexOf(x.purpose) >= 0; })
      .sort(function(a, b){ return Date.parse(b.publishedAt || 0) - Date.parse(a.publishedAt || 0); }).slice(0, 4);
    if (!l.length) return;
    h += '<div class="snd-g fx-g"><h5>' + cat.t + '</h5>' + l.map(function(x){
      const on = FX.branoId === x.id;
      return '<button type="button" class="snd-row' + (on ? ' on' : '') + '" onclick="fxBrano(\'' + fxEsc(x.id) + '\')">'
        + '<span class="ico">' + (cat.k === 'dormire' ? '🌙' : (cat.k === 'rilassarti' ? '🌤️' : '🎯')) + '</span>'
        + '<div><b>' + fxEsc(x.title) + (fxNuovo(x) ? ' <em class="fx-nuovo">Nuova</em>' : '') + '</b><small>' + fxEsc((FX_SCOPO[x.purpose] || 'Musica') + ' · ' + fxMin(x.durationSec) + ' in loop') + '</small></div>'
        + '<span class="play">' + (on ? '❚❚' : '▶') + '</span></button>';
    }).join('') + '</div>';
  });
  return h;
}
/* 0.9.311, Andrea: gli effetti non si scelgono e non si ascoltano da una lista: sono di serie. Resta solo
   l'interruttore, in Personalizza. */
function fxInterruttorePaint(){
  const el = document.getElementById('psEffetti'); if (!el) return;
  const on = fxAppAttivi();
  el.innerHTML = '<div class="blk-swrow fx-sw"><div><b>🔊 Effetti sonori</b><small>Quando finisci una tappa, sali di livello o apri una mystery box. Tacciono con il telefono in silenzioso.</small></div>'
    + '<button type="button" class="switch' + (on ? ' on' : '') + '" onclick="fxImposta(' + (on ? 'false' : 'true') + ')" aria-label="Effetti sonori"></button></div>';
}
document.addEventListener('fl:screen', function(e){ if (e.detail === 's-personalize') fxInterruttorePaint(); });
function fxPaginaRidisegna(){
  try{ fxInterruttorePaint(); }catch(_){ }
  try{ if (document.querySelector('#s-suoni.active') && typeof sndPaint === 'function') sndPaint(); }catch(_){ }
}

/* ---------- i ganci: dove suonano ---------- */
(function(){
  /* i jingle sintetizzati di musica.js diventano i suoni della libreria; il sintetizzato resta il ripiego */
  if (typeof muJingle === 'function'){
    const muVecchio = muJingle;
    window.muJingle = muJingle = function(nome){
      const self = this, args = arguments;
      const ev = FX_JINGLE[nome] || 'giusta';
      if (fxSuona(ev, { ripiego: function(){ muVecchio.apply(self, args); } })) return;
      return muVecchio.apply(self, args);
    };
  }
  /* il Genio: il punto e le scelte (che salgono di tono) dalla libreria, se il Genio non e' muto */
  try{
    if (typeof gnAu !== 'undefined' && gnAu){
      const punto = gnAu.punto, scelta = gnAu.scelta;
      gnAu.punto = function(){ if (typeof GN !== 'undefined' && GN && GN.audio === false) return; const self = this; fxSuona('punto', { ripiego: function(){ punto.call(self); } }); };
      gnAu.scelta = function(i){ if (typeof GN !== 'undefined' && GN && GN.audio === false) return; const self = this; fxSuona('scelta', { velocita: 1 + Math.min(6, i || 0) * 0.06, ripiego: function(){ scelta.call(self, i); } }); };
    }
  }catch(_){ }
  const avvolgi = function(nome, prima, dopo){
    const f = window[nome]; if (typeof f !== 'function') return;
    window[nome] = function(){
      try{ if (prima) prima.apply(this, arguments); }catch(_){ }
      const r = f.apply(this, arguments);
      try{ if (dopo) dopo.apply(this, arguments); }catch(_){ }
      return r;
    };
  };
  /* fine tappa e fine episodio: tutte e due passano da sdFineDisegna */
  avvolgi('sdFineDisegna', function(){ fxSuona('fine'); });
  avvolgi('sdRiceviXp', function(){ fxSuona('xp'); });
  avvolgi('lvFestaApri', function(){ fxSuona('livello'); });
  /* 0.9.322, Andrea: "il suono non c'entra niente": all'apertura il forziere; dopo il nero la fanfara del premio (scrigni.js, mbNeroPoi) */
  avvolgi('mbTocca', null, function(){ try{ if (MB && MB.tocchi === 3) fxSuona('scrigno'); }catch(_){ } });
  /* la barra del carburante che sale: il suono quando arriva in cima (450 ms di attesa + 1800 di salita) */
  avvolgi('fcSalitaApri', null, function(){ setTimeout(function(){ if (document.getElementById('fcSalita')) fxSuona('barra'); }, 2250); });
  /* il respiro: i file si decodificano appena si apre il foglio, cosi' il primo "Inspira" non arriva in ritardo */
  avvolgi('rsPrimaDiIniziare', function(){ fxSblocca(); fxScalda(['whoosh', 'click', 'reward']); });

  /* l'apertura delle schermate principali: le schede in basso, e le pagine piene */
  const PAGINE = { 's-respiro': 1, 's-suoni': 1, 's-levels': 1 };
  document.addEventListener('fl:tab', function(e){
    const t = e.detail;
    if (t === FX.tabPrima){ return; }
    const prima = FX.tabPrima; FX.tabPrima = t;
    if (!prima || Date.now() - FX.partenza < 3000) return;
    let gesto = true; try{ if (navigator.userActivation) gesto = navigator.userActivation.isActive; }catch(_){ }
    if (gesto) fxSuona('schermata');
  });
  document.addEventListener('fl:screen', function(e){
    if (PAGINE[e.detail] && Date.now() - FX.partenza > 3000) fxSuona('schermata');
    if (e.detail === 's-suoni') fxCatalogo(false).then(fxPaginaRidisegna);
  });

  /* il primo tocco sblocca l'audio; la suoneria si rilegge al rientro nell'app */
  const primo = function(){ fxSblocca(); document.removeEventListener('pointerdown', primo, true); setTimeout(function(){ fxScalda(); }, 1500); };
  document.addEventListener('pointerdown', primo, true);
  document.addEventListener('visibilitychange', function(){ if (!document.hidden){ fxLeggiSuoneria(); fxCatalogo(false); } else fxFerma(); });
  setInterval(function(){ if (!document.hidden) fxLeggiSuoneria(); }, 20000);
  /* all'avvio, quando l'app ha finito di disegnare: suoneria, catalogo, effetti in cache */
  const idle = window.requestIdleCallback || function(f){ setTimeout(f, 2500); };
  setTimeout(function(){ idle(function(){ fxLeggiSuoneria(); fxCatalogo(false); }); }, 4000);

  const st = document.createElement('style');
  st.textContent = [
    '.fx-g h5,.snd-g h5{text-align:center}',
    '.fx-nuovo{display:inline-block;margin-left:6px;padding:2px 8px;border-radius:99px;background:#E63946;color:#fff;font:800 10px var(--font-body);font-style:normal;letter-spacing:.04em;vertical-align:2px}',
    '.fx-sw{display:flex;align-items:center;gap:12px;padding:12px 2px;border-bottom:1px solid var(--line);margin:4px 0 4px}.fx-sw > div{flex:1;min-width:0}',
    '.fx-sw b{display:block;font:700 15px var(--font-body);color:var(--navy)}body.dark .fx-sw b{color:#fff}.fx-sw small{display:block;margin-top:2px;font:500 12px var(--font-body);color:var(--muted)}',
    /* nove righe leggere, non nove card: una lista dentro al pannello */
    ''
  ].join('\n');
  document.head.appendChild(st);
})();
