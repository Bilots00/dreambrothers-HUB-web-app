/* ===========================================================================================
   IL MOTORE UNICO DEL SONNO (0.9.236)

   PERCHE' ESISTE. Il 13/10/2026 il Profilo diceva "Sonno —", "Primo sblocco 00:00" e
   "Ultimo sblocco (sera prima) —", la Focus Box diceva "Il telefono non ha ancora i dati di
   stanotte", e intanto la Cronologia ora per ora mostrava la notte intera: ultimo uso alle
   00:20, poi 7 ore e 43 minuti senza telefono. Tre schermate, tre conti diversi della stessa
   notte, e due su tre sbagliati.

   LE DUE CAUSE VERE.
   1. Il punteggio leggeva la notte dalla SORGENTE DEL REPORT. Con "Tutti e due insieme" (o
      "Dati del computer") `NATIVE.getDayReport` non e' piu' il telefono ma la ricostruzione
      di motore-web.js, che per costruzione risponde sleepMs 0, sleepStart 0 e
      wakeAt = il primo granello del giorno di calendario. Un uso cominciato alle 23:40 e
      finito alle 00:05 viene tagliato a mezzanotte (mwSomma: Math.max(g.s, from)): il primo
      granello comincia alle 00:00 in punto, ed ecco "Primo sblocco 00:00". Il Sonno, che e'
      del telefono e basta, non deve mai passare da li'.
   2. La Focus Box chiedeva getDayReport al motore con un tetto di tre secondi, mentre la
      stessa pagina gli metteva in coda altre dieci letture (il motore le serve una alla volta):
      la risposta arrivava tardi, valeva come "nessun dato", e usciva la frase sbagliata.

   LA REGOLA, una sola per tutte le schermate (Profilo, Focus Box, riserva di dopamina, Io
   futuro, il rapporto pubblicato al computer):
   - La notte va dall'ultimo uso vero della sera al risveglio.
   - Il risveglio e' il primo uso SOSTENUTO: piu' di 5 minuti di uso dentro 15 minuti
     (SN_CFG.usoVeroMs / usoFinestraMs), a qualunque ora dopo l'inizio della notte. Chi si
     sveglia alle quattro e lavora, alle quattro e' sveglio.
   - Un'interazione breve nella notte (spegnere una suoneria, guardare l'ora) NON finisce il
     sonno: resta scritta come interruzione ("sonno interrotto alle 3:02 per 1 minuto") e
     toglie qualche punto.
   - LA SVEGLIA HA LA PRECEDENZA. Il telefono sa a che ora suona la prossima sveglia, di
     qualunque app (AlarmManager.getNextAlarmClock): il nativo ne tiene un registro
     (SonnoSveglie.java). Se una sveglia suona alle T, tu la tocchi entro 10 minuti e entro
     altri 20 cominci a usare il telefono davvero, ti sei svegliato quando l'hai toccata. Se
     invece torni a dormire (rimandi, nessun uso vero), la sveglia non e' il risveglio: il
     risveglio resta il primo uso vero, e il tempo dopo la sveglia e' sonno leggero, vale
     meta' ("mezz'ora in piu' non e' sonno profondo", Andrea).
   - La Focus Box ("vado a letto", "la scatola si apre") suggerisce solo DOVE cercare la
     notte quando ce ne sono due possibili; non sostituisce mai un dato vero.

   Questo file e' puro: niente DOM, niente rete, niente telefono. Lo provano
   tools/test-sonno.js e lo usano sonno.js (che raccoglie i dati) e scores.js (che fa il voto).
   =========================================================================================== */

const SN_MIN = 60000, SN_H = 3600000;

/* Le soglie, tutte qui. Cambiarne una cambia il conto di tutte le schermate insieme. */
const SN_CFG = {
  primaMs: 6 * SN_H,              // la notte si cerca dalle 18 del giorno prima...
  dopoMs: 14 * SN_H,              // ...alle 14 del giorno
  usoVeroMs: 5 * SN_MIN,          // piu' di 5 minuti di uso...
  usoFinestraMs: 15 * SN_MIN,     // ...dentro 15 minuti: sei sveglio
  accesoMinMs: 45 * 1000,         // schermo acceso a telefono bloccato per meno di cosi': una notifica, non una persona
  gruppoMs: 15 * SN_MIN,          // gesti piu' vicini di cosi' sono una interruzione sola
  quieteMs: 90 * SN_MIN,          // dopo l'ora del letto, la sera finisce prima di un'ora e mezza senza nessun uso
  notteMinMs: 2 * SN_H,           // un tratto fermo piu' corto e' una pausa, non una notte
  svegliaRispostaMs: 10 * SN_MIN, // la sveglia conta se la tocchi entro 10 minuti...
  svegliaUsoMs: 20 * SN_MIN,      // ...e l'uso vero comincia entro 20 minuti da li'
  svegliaAccesoMs: 60 * 1000,     // lo schermo lo accende la sveglia: un'accensione dopo un minuto e' tua
  rimandoMaxMs: 2 * SN_H,         // dopo una sveglia rimandata, fino a 2 ore di sonno leggero
  accesoMaxMs: 3 * SN_MIN,        // schermo acceso a telefono bloccato: nessuno lo guarda per ore (manca lo "spento")
  sopraMaxMs: 10 * SN_MIN,        // un'app sopra al blocco senza sblocco: al massimo dieci minuti contano
  nottePienaMs: 5 * SN_H,         // con almeno 5 ore dormite, la sveglia spenta (e non risuonata) e' il risveglio
  leggeroPeso: 0.5,               // il sonno leggero vale meta'
  cuoreDaMs: 0, cuoreAMs: 6 * SN_H, // senza Focus Box la notte si cerca fra mezzanotte e le sei
  penaInterruzione: 2, penaMax: 6 // punti tolti per interruzione, al massimo
};

/* Il codice degli eventi e' quello di Android (UsageEvents.Event). */
const SN_EV = { RES: 1, PAU: 2, ON: 15, OFF: 16, LOCK: 17, UNLOCK: 18, SHUT: 26, BOOT: 27 };

/* IL SONNO E' UNA COLLINA, NON UNA SCALA (12/10/2026, Andrea). [ore, punti]: fra due righe si
   va in linea retta; sotto la prima 0, sopra l'ultima 0. */
const SN_CURVA = [[4, 0], [5, 40], [6, 70], [7, 90], [7.5, 100], [8.5, 100], [9.5, 85],
                  [10, 78], [11, 65], [12, 50], [14, 20], [16, 0]];
function snCurva(ore){
  const c = SN_CURVA;
  if (!(ore > c[0][0]) || ore >= c[c.length - 1][0]) return 0;
  for (let i = 1; i < c.length; i++){
    if (ore <= c[i][0]){
      const a = c[i - 1], b = c[i];
      return a[1] + (b[1] - a[1]) * (ore - a[0]) / (b[0] - a[0]);
    }
  }
  return 0;
}

function snMinDelGiorno(ts){ const d = new Date(ts); return d.getHours() * 60 + d.getMinutes(); }
/* "alle 3:02", ma "alle 00:20": "alle 0:20" non lo scrive nessuno */
function snOra(ts){ const d = new Date(ts), h = d.getHours(); return (h ? String(h) : '00') + ':' + String(d.getMinutes()).padStart(2, '0'); }
function snSomma(lista, da, a){
  let t = 0;
  for (const x of lista){ const s = Math.max(x[0], da), e = Math.min(x[1], a); if (e > s) t += e - s; }
  return t;
}

/**
 * Dagli eventi grezzi a tre elenchi: l'uso vero (telefono sbloccato e schermo acceso), lo
 * schermo acceso a telefono bloccato, le app che vivono sopra al blocco (sveglia, chiamata),
 * piu' i gesti di una persona (sblocco, sveglia chiusa, schermo riacceso).
 *
 * @param ev [[t, tipo, sopra]] con tipo come SN_EV e sopra = 1 per le app sopra al blocco
 */
function snLeggiEventi(ev, da, a){
  const E = (ev || []).filter(function(e){ return e && isFinite(e[0]) && e[0] < a; })
    .map(function(e){ return [+e[0], +e[1], +(e[2] || 0)]; })
    .sort(function(x, y){ return x[0] - y[0]; });
  const uso = [], acceso = [], sopra = [], gesti = [];
  const lockAware = E.some(function(e){ return e[1] === SN_EV.LOCK || e[1] === SN_EV.UNLOCK; });
  /* 0.9.284, la notte del 18/10 di Andrea: "sonno interrotto alle 1:25 per 6 ore e 36 minuti". All'1:25 un'app sopra
     al blocco (systemui, una schermata di DreamMap) si riapriva A SCHERMO SPENTO: veniva presa per "schermo acceso",
     l'accensione vera delle 8:00 veniva saltata (risultava gia' acceso) e l'interruzione restava aperta fino alla
     sveglia spenta alle 8:01. Se il telefono dice quando lo schermo si accende e si spegne, un'app che si apre a schermo
     spento non conta: nessuno la sta guardando. */
  const screenAware = E.some(function(e){ return e[1] === SN_EV.ON || e[1] === SN_EV.OFF; });
  /* lo stato all'inizio della finestra, dedotto dal primo evento che lo cambia */
  let on = false, bloccato = lockAware;
  for (const e of E){
    if (e[1] === SN_EV.ON){ on = false; break; }
    if (e[1] === SN_EV.OFF || e[1] === SN_EV.UNLOCK || e[1] === SN_EV.LOCK){ on = e[1] !== SN_EV.UNLOCK; break; }
  }
  for (const e of E){
    if (e[1] === SN_EV.UNLOCK){ bloccato = true; break; }
    if (e[1] === SN_EV.LOCK){ bloccato = false; break; }
  }
  let usoDa = 0, accesoDa = 0, sopraDa = 0;
  if (on && !bloccato) usoDa = da;
  const chiudiUso = function(t){ if (usoDa && t > usoDa) uso.push([usoDa, t]); usoDa = 0; };
  const chiudiAcceso = function(t){ if (accesoDa && t > accesoDa) acceso.push([accesoDa, t]); accesoDa = 0; };
  const chiudiSopra = function(t, gesto){
    if (sopraDa && t > sopraDa){ sopra.push([sopraDa, t]); if (gesto) gesti.push({ t: t, k: 'chiude' }); }
    sopraDa = 0;
  };
  for (const e of E){
    const t = Math.max(da, e[0]), k = e[1], s = e[2];
    if (k === SN_EV.ON){
      if (on) continue;
      on = true;
      if (lockAware && bloccato){ accesoDa = t; gesti.push({ t: t, k: 'accende' }); }
      else if (!lockAware) accesoDa = t;
      else usoDa = usoDa || t;
    } else if (k === SN_EV.OFF || k === SN_EV.SHUT || k === SN_EV.BOOT){
      chiudiUso(t); chiudiAcceso(t); chiudiSopra(t, k === SN_EV.OFF);
      on = false;
      if (k !== SN_EV.OFF) bloccato = lockAware;
    } else if (k === SN_EV.LOCK){
      bloccato = true; chiudiUso(t);
      if (on && !accesoDa) accesoDa = t;
    } else if (k === SN_EV.UNLOCK){
      bloccato = false; on = true;
      chiudiAcceso(t); chiudiSopra(t, true);
      usoDa = usoDa || t;
      gesti.push({ t: t, k: 'sblocco' });
    } else if (k === SN_EV.RES){
      if (screenAware && !on) continue;
      on = true;
      if (s === 1 || (lockAware && bloccato)){
        if (!lockAware) chiudiUso(t);
        sopraDa = sopraDa || t;
      } else {
        chiudiSopra(t, true);
        if (!lockAware){ chiudiAcceso(t); if (!usoDa) gesti.push({ t: t, k: 'apre' }); }
        usoDa = usoDa || t;
      }
    } else if (k === SN_EV.PAU){
      if (s === 1) chiudiSopra(t, true);
    }
  }
  chiudiUso(a); chiudiAcceso(a); chiudiSopra(a, false);
  return { uso: snUnisci(uso, 2000), acceso: acceso, sopra: sopra, gesti: gesti, eventi: E.length };
}

/** Intervalli in ordine, uniti quando si toccano (o quasi). */
function snUnisci(l, tolleranza){
  const s = (l || []).filter(function(x){ return x[1] > x[0]; }).map(function(x){ return [x[0], x[1]]; })
    .sort(function(x, y){ return x[0] - y[0]; });
  const out = [];
  for (const x of s){
    const p = out[out.length - 1];
    if (p && x[0] - p[1] <= (tolleranza || 0)) p[1] = Math.max(p[1], x[1]);
    else out.push(x);
  }
  return out;
}

/**
 * Le sveglie che hanno suonato davvero, dal registro del nativo: ogni riga dice da quando
 * (`at`) la prossima sveglia del telefono era `next`. Una sveglia T ha suonato se era la
 * prossima prima di T e lo e' rimasta fino a T (la riga dopo arriva a T o piu' tardi: quando
 * suona, Android passa alla sveglia successiva). Una sveglia tolta prima non conta.
 */
function snSveglieSuonate(registro, da, a, adesso){
  const r = (registro || []).filter(function(x){ return x && isFinite(x.at); })
    .slice().sort(function(x, y){ return x.at - y.at; });
  const out = [];
  for (let i = 0; i < r.length; i++){
    const T = +r[i].next || 0;
    if (!T || T < da || T > a || r[i].at >= T) continue;
    const dopo = r[i + 1];
    const suonata = dopo ? dopo.at >= T - 60000 : (adesso || Date.now()) >= T;
    if (suonata && out.indexOf(T) < 0) out.push(T);
  }
  return out.sort(function(x, y){ return x - y; });
}

/**
 * LA NOTTE.
 *
 * @param inp {
 *   dayStart  mezzanotte del giorno di cui si cerca la notte (quella che finisce quella mattina)
 *   adesso    l'ora di adesso (la finestra si ferma qui)
 *   eventi    [[t, tipo, sopra]] dal nativo (getNightEvents), oppure
 *   uso       [[s, e]] gia' pronti (dalla Cronologia, quando il nativo e' vecchio)
 *   sveglie   [T] le sveglie che hanno suonato (snSveglieSuonate + quelle di DreamMap)
 *   indizio   {da, a} la finestra della Focus Box, se c'e'
 * }
 */
function snNotte(inp, cfgIn){
  const C = Object.assign({}, SN_CFG, cfgIn || {});
  const ds = inp.dayStart;
  const adesso = inp.adesso || Date.now();
  const da = ds - C.primaMs;
  const a = Math.min(adesso, ds + C.dopoMs);
  const vuoto = function(motivo, extra){
    return Object.assign({ ok: false, motivo: motivo, inizio: 0, sveglia: 0, notteMs: 0, sonnoMs: 0, leggeroMs: 0,
      leggeroDa: 0, effettivoMs: 0, interruzioni: [], rimandi: 0, allarme: 0, svegliaDa: '', fonte: inp.fonte || '' }, extra || {});
  };
  if (!(a > da)) return vuoto('corso');

  let L;
  if (Array.isArray(inp.eventi) && inp.eventi.length) L = snLeggiEventi(inp.eventi, da, a);
  else if (Array.isArray(inp.uso)) L = { uso: snUnisci(inp.uso.map(function(x){ return [Math.max(da, x[0]), Math.min(a, x[1])]; }), 5000),
                                         acceso: [], sopra: [], gesti: [], eventi: inp.uso.length };
  else return vuoto('dati');
  if (!L.eventi) return vuoto('dati');
  const uso = L.uso;

  /* l'indizio: dove cercare la notte, e l'ora oltre la quale un uso breve non e' piu' "sera" */
  const ind = (inp.indizio && inp.indizio.a > inp.indizio.da) ? inp.indizio : { da: ds + C.cuoreDaMs, a: ds + C.cuoreAMs };
  const oraLetto = (inp.indizio && inp.indizio.a > inp.indizio.da) ? inp.indizio.da : ds;

  /* 1. GLI INIZI DI USO SOSTENUTO. Un uso che comincia a t e' sveglia vera se dentro i 15
        minuti da t ci sono piu' di 5 minuti di uso. Oggi, se l'uso e' ancora in corso e la
        finestra non e' ancora chiusa, basta che sia acceso da piu' di 2 minuti quasi di fila. */
  const sostenuto = function(t){
    const fine = t + C.usoFinestraMs;
    if (snSomma(uso, t, fine) > C.usoVeroMs) return true;
    if (fine > a && adesso <= a + 1000){
      const fatto = snSomma(uso, t, a);
      return a - t >= 2 * SN_MIN && fatto >= 0.6 * (a - t) && uso.some(function(u){ return u[1] >= a - 1000; });
    }
    return false;
  };
  const inizi = uso.map(function(u){ return u[0]; }).filter(sostenuto);
  /* i blocchi di veglia: da ogni inizio sostenuto fino alla fine dell'ultimo uso che comincia
     dentro i suoi 15 minuti; blocchi vicini (meno di 15 minuti) diventano uno solo */
  const blocchi = [];
  inizi.forEach(function(t){
    let e = t;
    uso.forEach(function(u){ if (u[0] >= t && u[0] < t + C.usoFinestraMs) e = Math.max(e, u[1]); });
    const p = blocchi[blocchi.length - 1];
    if (p && t - p[1] <= C.gruppoMs) p[1] = Math.max(p[1], e);
    else blocchi.push([t, e]);
  });
  const usiBrevi = uso.filter(function(u){ return !blocchi.some(function(b){ return u[0] >= b[0] && u[0] <= b[1]; }); });

  /* 2. LE NOTTI POSSIBILI: i tratti fra un blocco di veglia e il successivo (il primo comincia
        dall'inizio della finestra, l'ultimo puo' non avere ancora una fine). */
  const candidati = [];
  for (let j = 0; j <= blocchi.length; j++){
    const g0 = j === 0 ? da : blocchi[j - 1][1];
    const ancorata = j > 0;
    const g1 = j < blocchi.length ? blocchi[j][0] : 0;
    const dentro = usiBrevi.filter(function(u){ return u[0] >= g0 && (!g1 || u[0] < g1); });
    /* la sera: gli usi brevi prima dell'ora del letto sono ancora sera; dopo, solo se arrivano
       entro un'ora e mezza dall'uso precedente (sei ancora in piedi) */
    let s = ancorata ? g0 : 0;
    let k = 0;
    for (; k < dentro.length; k++){
      const u = dentro[k];
      if (u[0] < oraLetto || (s && u[0] - s < C.quieteMs)) s = Math.max(s, u[1]);
      else break;
    }
    let w = g1, debole = false;
    if (!w){
      /* nessun uso vero dopo: il risveglio, se c'e', e' il primo uso breve seguito da un
         altro entro un'ora (chi tocca il telefono di continuo e' sveglio) */
      const resto = dentro.slice(k);
      for (let i = 0; i < resto.length; i++){
        if ((s && resto[i][0] - s < C.notteMinMs) || resto[i][0] < ds) continue;
        if (resto[i + 1] && resto[i + 1][0] - resto[i][1] <= SN_H){ w = resto[i][0]; debole = true; break; }
      }
    }
    candidati.push({ s: s, w: w, debole: debole, g0: g0 });
  }

  /* 3. QUALE: quella che sta piu' dentro la finestra della notte (la Focus Box, o mezzanotte -
        sei), e a parita' la piu' lunga. Deve finire nel giorno giusto ed essere lunga
        almeno due ore. */
  const sovrapp = function(x, y){ return Math.max(0, Math.min(y, ind.a) - Math.max(x, ind.da)); };
  let scelta = null, perche = '';
  candidati.forEach(function(c){
    const fine = c.w || a;
    const inizio = c.s || c.g0;
    if (fine <= ds - SN_H || fine - inizio < C.notteMinMs) return;
    const voto = sovrapp(inizio, fine);
    if (!scelta || voto > scelta.voto || (voto === scelta.voto && fine - inizio > scelta.lung)){
      scelta = { c: c, voto: voto, lung: fine - inizio };
    }
  });
  if (!scelta){
    perche = uso.length ? 'sveglio' : 'dati';
    return vuoto(perche);
  }
  const c = scelta.c;
  if (!c.w){
    const fermo = c.s ? a - c.s : 0;
    return vuoto(adesso < ds + C.dopoMs ? 'corso' : 'mattina', { inizio: c.s, notteMs: fermo });
  }
  if (!c.s) return vuoto('sera', { sveglia: c.w });

  let inizio = c.s, sveglia = c.w, svegliaDa = c.debole ? 'debole' : 'uso';

  /* 4. LA SVEGLIA HA LA PRECEDENZA */
  const gesti = L.gesti.concat(uso.map(function(u){ return { t: u[0], k: 'uso' }; }))
    .sort(function(x, y){ return x.t - y.t; });
  let leggeroDa = 0, allarme = 0, rimandi = 0, finoA = 0;
  const svegliOrd = (inp.sveglie || []).slice().sort(function(x, y){ return x - y; });
  svegliOrd.forEach(function(T, iT){
    if (allarme || !(T > inizio + 30 * SN_MIN) || T >= sveglia) return;
    const g = gesti.filter(function(x){
      return x.t >= T && x.t <= T + C.svegliaRispostaMs && (x.k !== 'accende' || x.t >= T + C.svegliaAccesoMs);
    })[0];
    if (!g || g.t >= sveglia + 1000) return;
    const vero = inizi.some(function(t){ return t >= g.t && t <= g.t + C.svegliaUsoMs; })
              || (sveglia >= g.t && sveglia <= g.t + C.svegliaUsoMs && !c.debole);
    if (vero){ allarme = T; finoA = T; sveglia = g.t; svegliaDa = 'sveglia'; return; }
    /* 0.9.281, Andrea: "mi sono alzato alle 8 e mi dice che sono rimasto a letto 45 minuti". Spegnere la sveglia e
       non usare il telefono non vuol dire restare a letto: e' un "rimanda" solo se la sveglia suona DI NUOVO dopo
       (lo snooze). Se dopo non suona piu' niente, ti sei alzato quando l'hai spenta. */
    const risuona = svegliOrd.slice(iT + 1).some(function(T2){ return T2 > g.t && T2 < sveglia && T2 - T <= C.rimandoMaxMs; });
    /* 0.9.284, Andrea: "mi sono svegliato alle 8, e dice 12:15". Spenta la sveglia, lavorava al computer: il telefono
       l'ha usato davvero solo a mezzogiorno. Il limite delle due ore fra la sveglia e il primo uso vero non c'e' piu':
       una sveglia spenta che non risuona e' il risveglio se a quell'ora hai gia' dormito una notte intera (5 ore): la
       sveglia delle 3 di notte, spenta per tornare a dormire, resta un'interruzione. */
    if (!risuona && !rimandi && (sveglia - T <= C.rimandoMaxMs || T - inizio >= C.nottePienaMs)){ allarme = T; finoA = T; sveglia = g.t; svegliaDa = 'sveglia'; return; }
    if (sveglia - T <= C.rimandoMaxMs){
      if (!leggeroDa) leggeroDa = T;
      rimandi++;
    }
  });
  if (leggeroDa && leggeroDa >= sveglia) leggeroDa = 0;

  /* 5. LE INTERRUZIONI: ogni gesto di una persona fra l'inizio della notte e il sonno leggero
        (o la sveglia): l'uso breve, lo schermo acceso piu' di 45 secondi, l'app sopra al blocco */
  const limite = leggeroDa || finoA || sveglia;
  const segni = []
    .concat(uso.filter(function(u){ return u[0] > inizio && u[0] < limite; }))
    .concat(L.acceso.filter(function(x){ return x[1] - x[0] >= C.accesoMinMs && x[0] > inizio && x[0] < limite; })
      .map(function(x){ return [x[0], Math.min(x[1], x[0] + C.accesoMaxMs)]; }))
    .concat(L.sopra.filter(function(x){ return x[0] > inizio && x[0] < limite; })
      .map(function(x){ return [x[0], Math.min(x[1], x[0] + C.sopraMaxMs)]; }))
    .map(function(x){ return [x[0], Math.min(x[1], limite)]; })
    .sort(function(x, y){ return x[0] - y[0]; });
  const interruzioni = [];
  let gruppo = null;
  segni.forEach(function(x){
    if (gruppo && x[0] - gruppo.fine <= C.gruppoMs){ gruppo.pezzi.push(x); gruppo.fine = Math.max(gruppo.fine, x[1]); }
    else { gruppo = { at: x[0], fine: x[1], pezzi: [x] }; interruzioni.push(gruppo); }
  });
  /* L'ULTIMO GESTO PRIMA DELL'USO VERO FA PARTE DEL RISVEGLIO. Una sveglia che il registro non
     conosce (un telefono appena aggiornato, una app che non la dichiara) suona alle 7:50, la
     spegni alle 7:55 e alle 8:03 apri il telefono: ti sei svegliato alle 7:55, non alle 8:03,
     e il gesto delle 7:55 non e' un'interruzione. Vale per un gesto finito al massimo 10
     minuti prima dell'uso vero; l'ora e' il primo gesto tuo (non lo schermo che si accende da
     solo per la suoneria). */
  const ultimo = interruzioni[interruzioni.length - 1];
  if (ultimo && svegliaDa !== 'sveglia' && !leggeroDa && ultimo.fine >= sveglia - C.svegliaRispostaMs){
    interruzioni.pop();
    const mio = gesti.filter(function(x){ return x.t >= ultimo.at && x.t <= ultimo.fine && x.k !== 'accende'; })[0];
    sveglia = mio ? mio.t : ultimo.at;
  }
  const inter = interruzioni.map(function(g){
    const ms = snSomma(snUnisci(g.pezzi, 0), g.at, g.fine);
    return { at: g.at, ms: Math.max(1000, ms) };
  });
  const interMs = inter.reduce(function(t, x){ return t + x.ms; }, 0);

  const notteMs = sveglia - inizio;
  const leggeroMs = leggeroDa ? sveglia - leggeroDa : 0;
  const sonnoMs = Math.max(0, notteMs - interMs);
  const effettivoMs = Math.max(0, sonnoMs - leggeroMs * (1 - C.leggeroPeso));
  return { ok: true, motivo: '', inizio: inizio, sveglia: sveglia, notteMs: notteMs, sonnoMs: sonnoMs,
           leggeroMs: leggeroMs, leggeroDa: leggeroDa, effettivoMs: effettivoMs, interruzioni: inter,
           rimandi: rimandi, allarme: allarme, svegliaDa: svegliaDa, fonte: inp.fonte || '' };
}

/**
 * Il voto del Sonno, 0-100, da una notte del motore. La collina sulle ore effettive (il
 * sonno leggero vale meta'), meno 8 punti se la notte comincia dopo l'una e 12 dopo le tre,
 * meno 2 punti per interruzione (al massimo 6).
 */
function snPunteggio(n, cfgIn){
  const C = Object.assign({}, SN_CFG, cfgIn || {});
  if (!n || !n.ok || !(n.sonnoMs > 0)) return null;
  let s = snCurva((n.effettivoMs || n.sonnoMs) / SN_H);
  const bed = n.inizio ? snMinDelGiorno(n.inizio) : -1;
  if (bed >= 0 && bed < 12 * 60){
    if (bed >= 3 * 60) s -= 12;
    else if (bed >= 60) s -= 8;
  }
  s -= Math.min(C.penaMax, (n.interruzioni || []).length * C.penaInterruzione);
  return Math.round(Math.max(0, Math.min(100, s)));
}

/**
 * La notte dentro a un rapporto del giorno: i campi che le schermate leggono da sempre
 * (sleepMs, sleepStart, wakeAt, prevLastUse) diventano quelli del motore. Il primo uso del
 * giorno di calendario (firstUse) NON e' mai il risveglio: per chi e' sveglio a mezzanotte e'
 * la sera prima, tagliata alle 00:00.
 */
function snNelReport(r, n){
  if (!r || !n) return r;
  const o = Object.assign({}, r);
  o.notte = snSnella(n);
  o.sleepMs = n.ok ? n.sonnoMs : 0;
  o.sleepStart = n.inizio || 0;
  o.prevLastUse = n.inizio || 0;
  o.wakeAt = n.sveglia || 0;
  if (n.sveglia && (!o.awakeFrom || o.daMotoreWeb)) o.awakeFrom = n.sveglia;
  return o;
}
/** La notte senza niente di superfluo: viaggia nel rapporto salvato e in quello pubblicato. */
function snSnella(n){
  if (!n) return null;
  return { ok: !!n.ok, motivo: n.motivo || '', inizio: n.inizio || 0, sveglia: n.sveglia || 0, notteMs: n.notteMs || 0,
           sonnoMs: n.sonnoMs || 0, leggeroMs: n.leggeroMs || 0, leggeroDa: n.leggeroDa || 0, effettivoMs: n.effettivoMs || 0,
           interruzioni: (n.interruzioni || []).slice(0, 12).map(function(x){ return { at: x.at, ms: x.ms }; }),
           rimandi: n.rimandi || 0, allarme: n.allarme || 0, svegliaDa: n.svegliaDa || '', fonte: n.fonte || '' };
}

/* ---- le parole: le stesse frasi in tutte le schermate ---- */
function snDurata(ms){
  const m = Math.max(1, Math.round(ms / SN_MIN));
  if (m < 60) return m === 1 ? '1 minuto' : m + ' minuti';
  const h = Math.floor(m / 60), r = m % 60;
  return (h === 1 ? '1 ora' : h + ' ore') + (r ? ' e ' + (r === 1 ? '1 minuto' : r + ' minuti') : '');
}
/** "Sonno interrotto alle 3:02 per 1 minuto." una riga per interruzione (al massimo tre). */
function snFraseInterruzioni(n){
  const l = (n && n.interruzioni) || [];
  if (!l.length) return '';
  const righe = l.slice(0, 3).map(function(x){ return 'Sonno interrotto alle ' + snOra(x.at) + ' per ' + snDurata(x.ms) + '.'; });
  if (l.length > 3) righe.push('E altre ' + (l.length - 3) + ' volte.');
  return righe.join(' ');
}
/** La frase del sonno leggero dopo una sveglia rimandata. */
function snFraseLeggero(n){
  if (!n || !(n.leggeroMs > 0) || !n.leggeroDa) return '';
  return 'Dopo la sveglia delle ' + snOra(n.leggeroDa) + ' sei rimasto a letto ancora ' + snDurata(n.leggeroMs)
    + ': è sonno leggero, vale metà.';
}
/** Perche' la notte non c'e', detto a una persona. */
function snFraseManca(n){
  const m = n ? n.motivo : 'dati';
  if (m === 'sera') return 'Manca l\'ultimo uso di ieri sera: senza quello la notte non si può misurare.';
  if (m === 'corso') return 'La notte non è ancora finita: finisce quando usi il telefono per qualche minuto.';
  if (m === 'mattina') return 'Stamattina il telefono non è stato ancora usato davvero: la notte non ha una fine.';
  if (m === 'sveglio') return 'Stanotte il telefono non è mai rimasto fermo per due ore di fila.';
  return 'Il telefono non ha ancora i dati di stanotte.';
}

if (typeof module !== 'undefined' && module.exports){
  module.exports = { SN_CFG: SN_CFG, SN_EV: SN_EV, SN_CURVA: SN_CURVA, snCurva: snCurva, snLeggiEventi: snLeggiEventi,
    snUnisci: snUnisci, snSveglieSuonate: snSveglieSuonate, snNotte: snNotte, snPunteggio: snPunteggio,
    snNelReport: snNelReport, snSnella: snSnella, snOra: snOra, snDurata: snDurata,
    snFraseInterruzioni: snFraseInterruzioni, snFraseLeggero: snFraseLeggero, snFraseManca: snFraseManca };
}
