/* ===========================================================================================
   I GRUPPI — Sempre consentiti, Mai consentiti, Distrazioni

   Le Categorie qui sopra sono liste che arrivano già scritte: Social, Video, Scommesse. Sono
   utili e sono di tutti. Questi tre invece sono TUOI, e servono a una cosa che le categorie non
   sanno fare: dire una volta sola cosa vale sempre, invece di ridirlo a ogni sessione.

   · Sempre consentiti — quello che ti serve per lavorare. Un tocco nella concentrazione
     intensiva e sono dentro all'elenco dei permessi, senza rispuntarli uno per uno.
   · Mai consentiti — quello che non deve passare mai, nemmeno quando sei tu a dire di sì.
   · Distrazioni — quello che ti frega di solito. È la lista che il Blocco rapido riempie in un
     colpo, ed è quella che un domani l'arbitro leggerà per capire da solo cosa bloccare.

   Ogni gruppo tiene TRE cose: programmi (o app, sul telefono), siti e PAROLE CHIAVE. Le parole
   mancavano ovunque, e senza di loro un gruppo è monco: "fattura" non è un sito, ma è
   esattamente quello che deve passare mentre lavori.

   Vivono nel localStorage con il prefisso fl_, quindi viaggiano nel backup come tutto il resto.
   =========================================================================================== */

const FL_GROUP_KEY = 'fl_groups';

const FL_GROUP_DEFS = [
  { id: 'always',   ic: '✅', name: 'Sempre consentiti',
    hint: 'Quello che ti serve per lavorare. Nella concentrazione intensiva entra tutto insieme.' },
  { id: 'never',    ic: '🚫', name: 'Mai consentiti',
    hint: 'Non passa mai, nemmeno se in quel momento ti convinci del contrario.' },
  { id: 'distract', ic: '🌀', name: 'Distrazioni',
    hint: 'Quello che ti frega di solito. Il Blocco rapido lo prende da qui in un colpo.' }
];

function flGroups(){
  try{ return JSON.parse(localStorage.getItem(FL_GROUP_KEY) || '{}') || {}; }catch(_){ return {}; }
}
function flGroup(id){
  const g = flGroups()[id] || {};
  return { apps: g.apps || [], sites: g.sites || [], words: g.words || [] };
}
function flGroupSave(id, val){
  const all = flGroups();
  all[id] = val;
  try{ localStorage.setItem(FL_GROUP_KEY, JSON.stringify(all)); }catch(_){ }
  if (id === 'always') flGroupPush();
}

/**
 * «SEMPRE CONSENTITI» ARRIVA AL MOTORE.
 *
 * <p>Finora questo elenco restava dov'era scritto: serviva a riempire la lista della
 * concentrazione intensiva, e basta. Sul computer voleva dire che Notion e Telegram, messi
 * qui dentro, continuavano a essere chiusi da una parola chiave che guarda nel testo della
 * pagina — perche' nel motore non esisteva nessun permesso, e un permesso che non c'e' non
 * puo' vincere su niente.</p>
 *
 * <p>Sul computer l'elenco diventa subito una regola di permesso. Sul telefono parte la foto
 * delle regole, che il computer legge dal suo account: la stessa strada, un minuto piu'
 * lunga.</p>
 */
function flGroupPush(){
  try{
    const g = flGroup('always');
    const siti = (g.sites || []).map(function(s){ return String(s || '').trim().toLowerCase(); })
                                .filter(Boolean);
    const desktop = (typeof pcQui === 'function') && pcQui() === 'desktop';
    if (desktop && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.setAllowSites){
      NATIVE.setAllowSites({ sites: siti });
      return;
    }
    if (typeof rsPubblica === 'function') rsPubblica();
  }catch(_){ }
}

/* All'avvio, una volta: cosi' un elenco scritto prima di oggi diventa un permesso senza che
   nessuno debba riaprire la pagina e toccare qualcosa. */
setTimeout(flGroupPush, 6000);
function flGroupCount(id){
  const g = flGroup(id);
  return g.apps.length + g.sites.length + g.words.length;
}

/* ---------------------------------------------------------------------------------------
   Le cartelle quadrate, in fondo alla pagina Categorie
   --------------------------------------------------------------------------------------- */

function flGroupsCardsHtml(){
  const cards = FL_GROUP_DEFS.map(function(d){
    const g = flGroup(d.id);
    const n = g.apps.length + g.sites.length + g.words.length;

    /* Le quattro caselle dell'anteprima: le prime tre cose dentro, e il "+resto". */
    const anteprima = [];
    g.apps.slice(0, 3).forEach(function(p){
      const letter = flGroupLabel(p).charAt(0).toUpperCase();
      anteprima.push('<span class="grp-chip"><span class="ub-appico ub-appico-fb">' + esc(letter)
        + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(p) + '" alt=""></span></span>');
    });
    g.sites.slice(0, Math.max(0, 3 - anteprima.length)).forEach(function(s){
      anteprima.push('<span class="grp-chip">🌐</span>');
    });
    g.words.slice(0, Math.max(0, 3 - anteprima.length)).forEach(function(w){
      anteprima.push('<span class="grp-chip">🔤</span>');
    });
    while (anteprima.length < 3) anteprima.push('<span class="grp-chip grp-chip-void"></span>');
    anteprima.push('<span class="grp-chip grp-chip-more">' + (n > 3 ? '+' + (n - 3) : d.ic) + '</span>');

    return '<button type="button" class="grp-card" onclick="flGroupOpen(\'' + d.id + '\')">'
      + '<span class="grp-grid">' + anteprima.join('') + '</span>'
      + '<b class="grp-name">' + esc(d.name) + '</b>'
      + '<small class="grp-count">' + (n ? n + (n === 1 ? ' voce' : ' voci') : 'vuoto') + '</small>'
      + '</button>';
  }).join('');

  return '<div class="sect" style="margin-top:26px"><b>I tuoi gruppi</b></div>'
    + '<div class="hintline" style="padding:0 2px 12px">Tre liste tue, con dentro programmi, siti e parole chiave. Si scrivono una volta e si riusano a ogni sessione.</div>'
    + '<div class="grp-row">' + cards + '</div>';
}

function flGroupLabel(pkg){
  if (typeof flCatAppLabel === 'function') return String(flCatAppLabel(pkg) || pkg);
  return String(pkg || '?');
}

/* ---------------------------------------------------------------------------------------
   La pagina di un gruppo: tre schede, come il Blocco rapido
   --------------------------------------------------------------------------------------- */

let FL_GROUP_CUR = 'always';
let FL_GROUP_TAB = 'apps';
let FL_GROUP_APPS = null;

registerScreen('s-group', `
  <div class="topbar"><button class="iconbtn" onclick="goId('s-cats')">‹</button><b class="blk-title" id="grpTitle">Gruppo</b></div>
  <div class="hintline" id="grpHint" style="padding:0 2px 12px"></div>
  <div class="ff-seg" id="grpTabs"></div>
  <div id="grpBody"></div>
  <div class="spacer"></div>
`, { back: 's-cats' });

async function flGroupOpen(id){
  FL_GROUP_CUR = id || 'always';
  FL_GROUP_TAB = 'apps';
  goId('s-group');
  flGroupPaint();
  if (!FL_GROUP_APPS && typeof NATIVE !== 'undefined' && NATIVE && NATIVE.getInstalledApps){
    try{ const r = await flApps(); FL_GROUP_APPS = (r && r.apps) || []; }
    catch(_){ FL_GROUP_APPS = []; }
    FL_GROUP_APPS.sort(function(a, b){ return (a.label || '').localeCompare(b.label || '', 'it'); });
    flGroupPaint();
  }
}

function flGroupTab(t){ FL_GROUP_TAB = t; flGroupPaint(); }

function flGroupPaint(){
  const def = FL_GROUP_DEFS.filter(function(d){ return d.id === FL_GROUP_CUR; })[0] || FL_GROUP_DEFS[0];
  const g = flGroup(def.id);

  const t = document.getElementById('grpTitle');
  if (t) t.textContent = def.ic + '  ' + def.name;
  const h = document.getElementById('grpHint');
  if (h) h.textContent = def.hint;

  const tabs = document.getElementById('grpTabs');
  if (tabs){
    tabs.innerHTML = [['apps', 'Programmi', g.apps.length], ['sites', 'Siti', g.sites.length], ['words', 'Parole', g.words.length]]
      .map(function(x){
        return '<button type="button" class="' + (FL_GROUP_TAB === x[0] ? 'on' : '') + '" onclick="flGroupTab(\'' + x[0] + '\')">'
          + x[1] + (x[2] ? ' · ' + x[2] : '') + '</button>';
      }).join('');
  }

  const box = document.getElementById('grpBody');
  if (!box) return;

  if (FL_GROUP_TAB === 'apps'){
    const elenco = FL_GROUP_APPS;
    if (!elenco){ box.innerHTML = '<p class="ff-empty">Leggo i programmi…</p>'; return; }
    if (!elenco.length){ box.innerHTML = '<p class="ff-empty">Nessun programma da elencare.</p>'; return; }
    box.innerHTML = '<div class="fl-search">' + (typeof FF_ICO_SEARCH !== 'undefined' ? FF_ICO_SEARCH : '🔎')
      + '<input id="grpQ" placeholder="Cerca…" oninput="flGroupFilter()" autocomplete="off"></div>'
      + '<div class="ff-picklist" id="grpList">' + elenco.map(function(a){
          const on = g.apps.indexOf(a.packageName) >= 0;
          const letter = esc((a.label || '?').charAt(0).toUpperCase());
          return '<label class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + letter
            + '<img class="ub-appico ub-appico-img" data-pkg="' + esc(a.packageName) + '" alt=""></span>'
            + '<span class="ff-pickname">' + esc(a.label || a.packageName) + '</span>'
            + '<input type="checkbox" value="' + esc(a.packageName) + '"' + (on ? ' checked' : '')
            + ' onchange="flGroupToggleApp(this)"></label>';
        }).join('') + '</div>';
    if (typeof ubFillIcons === 'function') ubFillIcons(document.getElementById('grpList'));
    return;
  }

  const siti = FL_GROUP_TAB === 'sites';
  const list = siti ? g.sites : g.words;
  box.innerHTML = '<div class="fl-search"><span class="fl-plus">＋</span><input id="grpIn" placeholder="'
      + (siti ? 'Aggiungi un sito (es. gmail.com)' : 'Aggiungi una parola (es. fattura)')
      + '" autocomplete="off" onkeydown="if(event.key===\'Enter\'){event.preventDefault();flGroupAdd();}"></div>'
    + '<button type="button" class="ghostmini ff-addsite" onclick="flGroupAdd()">Aggiungi</button>'
    + (list.length
        ? '<div class="ff-picklist">' + list.map(function(v){
            return '<div class="ff-pickrow"><span class="ub-appico ub-appico-fb">' + (siti ? '🌐' : '🔤') + '</span>'
              + '<span class="ff-pickname">' + esc(v) + '</span>'
              + '<button type="button" class="ff-rm" onclick="flGroupDel(\'' + esc(v) + '\')" aria-label="Togli">✕</button></div>';
          }).join('') + '</div>'
        : '<p class="ff-empty">' + (siti ? 'Nessun sito in questo gruppo.' : 'Nessuna parola in questo gruppo.') + '</p>');
}

function flGroupFilter(){
  const q = (document.getElementById('grpQ').value || '').toLowerCase();
  document.querySelectorAll('#grpList .ff-pickrow').forEach(function(r){
    r.style.display = r.textContent.toLowerCase().indexOf(q) >= 0 ? '' : 'none';
  });
}

function flGroupToggleApp(cb){
  const g = flGroup(FL_GROUP_CUR);
  const i = g.apps.indexOf(cb.value);
  if (cb.checked && i < 0) g.apps.push(cb.value);
  if (!cb.checked && i >= 0) g.apps.splice(i, 1);
  flGroupSave(FL_GROUP_CUR, g);
  flGroupPaint();
}

function flGroupAdd(){
  const inp = document.getElementById('grpIn');
  let v = String(inp ? inp.value : '').trim().toLowerCase();
  if (!v) return;

  const g = flGroup(FL_GROUP_CUR);
  if (FL_GROUP_TAB === 'sites'){
    /* Un indirizzo arriva in tutte le forme: con https, con www, con la barra in fondo. */
    v = v.replace(/^[a-z]+:\/\//, '').replace(/^www\./, '').split('/')[0].split('?')[0].replace(/\.$/, '');
    if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(v)){ toast('Scrivi un indirizzo, per esempio gmail.com'); return; }
    if (g.sites.indexOf(v) < 0) g.sites.push(v);
  } else {
    if (v.length < 2){ toast('Scrivi una parola di almeno due lettere'); return; }
    if (g.words.indexOf(v) < 0) g.words.push(v);
  }
  flGroupSave(FL_GROUP_CUR, g);
  flGroupPaint();
}

function flGroupDel(v){
  const g = flGroup(FL_GROUP_CUR);
  g.sites = g.sites.filter(function(x){ return x !== v; });
  g.words = g.words.filter(function(x){ return x !== v; });
  flGroupSave(FL_GROUP_CUR, g);
  flGroupPaint();
}

/* ---------------------------------------------------------------------------------------
   I gruppi dentro al Blocco rapido e ai Programmi

   Le categorie pronte (Social, Video, Scommesse) rispondono a "cosa blocca la gente"; i gruppi
   rispondono a "cosa blocco io". Nelle due schermate dove si sceglie cosa bloccare devono
   stare fianco a fianco, altrimenti un gruppo lo si scrive una volta e poi non lo si usa mai —
   che e' lo stesso che non averlo.

   Un gruppo porta anche le PAROLE CHIAVE, che una categoria non ha: e' la differenza fra
   "blocca i siti di calcio" e "blocca qualunque indirizzo contenga la parola calciomercato".
   --------------------------------------------------------------------------------------- */

function flGroupChips(where){
  const target = (typeof flCatTarget === 'function') ? flCatTarget(where) : null;
  if (!target) return '';

  const pieni = FL_GROUP_DEFS.filter(function(d){ return flGroupCount(d.id) > 0; });
  if (!pieni.length) return '';

  return '<div class="cat-head" style="margin-top:16px"><b>I tuoi gruppi</b>'
    + '<button type="button" onclick="flCatsOpen(\'' + (where === 'quick' ? 's-quick' : 's-editor') + '\')">Gestisci</button></div>'
    + '<div class="cat-scroll">' + pieni.map(function(d){
        const st = flGroupState(d.id, target);
        return '<button type="button" class="cat-card ' + st + '" onclick="flGroupToggleIn(\'' + where + '\',\'' + d.id + '\')">'
          + '<span class="cat-ic">' + d.ic + '<i class="cat-chk"></i></span>'
          + '<span class="cat-nm">' + esc(d.name) + '</span></button>';
      }).join('') + '</div>';
}

/* Acceso, spento o a meta': la stessa lettura delle categorie, cosi' il gesto e' lo stesso. */
function flGroupState(id, target){
  const g = flGroup(id);
  const voci = g.apps.length + g.sites.length + g.words.length;
  if (!voci) return 'empty';
  let dentro = 0;
  g.apps.forEach(function(a){ if (target.apps.indexOf(a) >= 0) dentro++; });
  g.sites.forEach(function(s){ if (target.sites.indexOf(s) >= 0) dentro++; });
  g.words.forEach(function(w){ if (flWordIn(target.keywords, w)) dentro++; });
  return dentro === 0 ? 'off' : (dentro === voci ? 'on' : 'half');
}

function flWordIn(arr, w){
  return (arr || []).some(function(k){ return ((k && k.t) ? k.t : k) === w; });
}

function flGroupToggleIn(where, id){
  const target = (typeof flCatTarget === 'function') ? flCatTarget(where) : null;
  if (!target) return;
  const g = flGroup(id);
  const acceso = flGroupState(id, target) === 'on';

  if (acceso){
    g.apps.forEach(function(a){ const i = target.apps.indexOf(a); if (i >= 0) target.apps.splice(i, 1); });
    g.sites.forEach(function(s){ const i = target.sites.indexOf(s); if (i >= 0) target.sites.splice(i, 1); });
    g.words.forEach(function(w){
      for (let i = (target.keywords || []).length - 1; i >= 0; i--){
        const k = target.keywords[i];
        if (((k && k.t) ? k.t : k) === w) target.keywords.splice(i, 1);
      }
    });
  } else {
    g.apps.forEach(function(a){ if (target.apps.indexOf(a) < 0) target.apps.push(a); });
    g.sites.forEach(function(s){ if (target.sites.indexOf(s) < 0) target.sites.push(s); });
    target.keywords = target.keywords || [];
    g.words.forEach(function(w){ if (!flWordIn(target.keywords, w)) target.keywords.push({ t: w, m: 'url' }); });
  }

  /* "Mai consentiti" in un elenco di blocco vuol dire proprio bloccarli: e' la stessa lista
     letta dal verso giusto. Quello che non si puo' fare e' metterli fra i consentiti, e da li'
     questa funzione non passa mai. */
  if (where === 'quick'){ if (typeof paintQuick === 'function') paintQuick(); }
  else if (typeof refreshEditorCounts === 'function') refreshEditorCounts();
  if (typeof flCatsPaint === 'function') flCatsPaint(where);
}

/* ---------------------------------------------------------------------------------------
   Il gruppo dentro alla concentrazione: un tocco invece di venti
   --------------------------------------------------------------------------------------- */

function flGroupIntoAllow(){
  if (typeof ffPref !== 'function'){ toast('Disponibile nella scheda della concentrazione'); return; }
  const g = flGroup('always');
  if (!g.apps.length && !g.sites.length && !g.words.length){
    toast('Il gruppo "Sempre consentiti" è vuoto: riempilo da Categorie');
    return;
  }
  const p = ffPref();
  p.allow = p.allow || []; p.allowSites = p.allowSites || []; p.allowWords = p.allowWords || [];
  g.apps.forEach(function(x){ if (p.allow.indexOf(x) < 0) p.allow.push(x); });
  g.sites.forEach(function(x){ if (p.allowSites.indexOf(x) < 0) p.allowSites.push(x); });
  g.words.forEach(function(x){ if (p.allowWords.indexOf(x) < 0) p.allowWords.push(x); });
  ffSavePref();
  if (typeof ffAllowPaint === 'function') ffAllowPaint();
  toast('Aggiunti i "Sempre consentiti"');
}


/* ---------------------------------------------------------------------------------------
   Lo stile: cartelle quadrate che scorrono di lato, come sul telefono
   --------------------------------------------------------------------------------------- */

(function flGroupStyle(){
  const css = [
    '.grp-row{display:flex;gap:14px;overflow-x:auto;padding:2px 2px 10px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch}',
    '.grp-row::-webkit-scrollbar{display:none}',
    '.grp-card{flex:none;width:158px;scroll-snap-align:start;border:1px solid var(--line);background:#fff;border-radius:22px;padding:16px 14px 14px;text-align:left;cursor:pointer}',
    'body.dark .grp-card{background:#12203A;border-color:#22345A}',
    '.grp-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}',
    '.grp-chip{display:flex;align-items:center;justify-content:center;width:100%;aspect-ratio:1;border-radius:14px;background:#EEF2F7;font-size:20px;overflow:hidden}',
    'body.dark .grp-chip{background:#0E1B33}',
    '.grp-chip .ub-appico{width:100%;height:100%;border-radius:14px}',
    '.grp-chip-void{background:transparent;border:1px dashed var(--line)}',
    '.grp-chip-more{font:700 14px var(--font-body);color:var(--muted)}',
    '.grp-name{display:block;font:700 14px var(--font-body);color:var(--navy);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    'body.dark .grp-name{color:#fff}',
    '.grp-count{display:block;margin-top:3px;font:500 12px var(--font-body);color:var(--muted)}',
    '.grp-use{width:100%;margin-bottom:16px}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
