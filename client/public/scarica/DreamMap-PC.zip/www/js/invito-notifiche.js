/* =========================================================================================
   L'INVITO ALLE NOTIFICHE A FINE TAPPA (0.9.300), come Duolingo

   Andrea, 24/10, con lo screenshot di Duolingo: "Crea un'abitudine di studio piu' efficace con i
   promemoria di ripasso", un telefono disegnato con dentro la notifica "Ciao, sono Duo!", il
   pulsante "Abilita le notifiche" e sotto "Non ora". Copiato come un ritratto: stesso ordine,
   stessa forma; il titolo e' nostro (la tappa di ogni giorno) e la notifica e' quella vera che
   l'app manda (sentiero.js snAvviso: titolo "Il Genio", testo serie_rischio con la serie vera).

   Quando: a fine tappa (sentiero-mappa.js, sdSerieAvanti, subito dopo "Tieni il ritmo"), solo se
   le notifiche sono spente. Non a ogni tappa: la prima volta subito; dopo un "Non ora" di nuovo
   fra 3 tappe o 3 giorni (quello che arriva prima); dopo tre "Non ora" una volta ogni 14 giorni.
   Mai nella stessa fine tappa in cui si e' appena vista la schermata del calendario.
   "Abilita le notifiche" chiede davvero il permesso (Android 13+ POST_NOTIFICATIONS, plugin
   notifChiedi); se Android non mostra piu' il dialogo, si apre la pagina delle notifiche dell'app.
   ========================================================================================= */
const IVN_KEY = 'fl_invito_notifiche';
let IVN_POI = null;
function ivnStato(){ try{ return JSON.parse(localStorage.getItem(IVN_KEY) || '{}') || {}; }catch(_){ return {}; } }
function ivnSalva(s){ try{ localStorage.setItem(IVN_KEY, JSON.stringify(s)); }catch(_){ } }
function ivnNativo(){ return typeof NATIVE !== 'undefined' && NATIVE && (typeof NATIVE.notifChiedi === 'function' || typeof NATIVE.requestAlarmAccess === 'function'); }

/** Se e' il momento, apre l'invito e chiama `poi` alla fine. Torna true se l'ha aperto. */
function ivnForse(poi){
  try{
    if (!ivnNativo() && !window.__ivnProva) return false;
    /* lo stato del permesso lo tiene notifiche.js (letto all'avvio e a ogni rientro): finche' non si sa, si tace */
    const nt = typeof NT_STATO !== 'undefined' ? NT_STATO : null;
    if (!window.__ivnProva && (!nt || nt.granted)) return false;
    const s = ivnStato();
    s.tappe = (s.tappe || 0) + 1;
    /* la schermata del calendario si e' appena vista: due richieste di fila sono troppe */
    let rt = null; try{ rt = typeof ritmoStato === 'function' ? ritmoStato() : null; }catch(_){ }
    if (rt && rt.visto && Date.now() - rt.visto < 10 * 60000){ ivnSalva(s); return false; }
    const giorni = s.visto ? (Date.now() - s.visto) / 86400000 : 999;
    const ora = !s.visto || ((s.no || 0) >= 3 ? giorni >= 14 : (s.tappe >= 3 || giorni >= 3));
    if (!ora){ ivnSalva(s); return false; }
    s.visto = Date.now(); s.tappe = 0; ivnSalva(s);
    IVN_POI = poi || null;
    goId('s-ivn'); ivnPaint();
    return true;
  }catch(_){ return false; }
}

/* La notifica vera: dalla 0.9.310 quella delle 22 quando la serie e' a rischio (SerieAvvisi.java, testi del livello 1:
   stesse parole, stessi numeri: giorni di fila della mappa, congelazioni della serie, nome) */
function ivnNotifica(){
  try{
    if (typeof svaStato === 'function'){
      const st = svaStato(); const n = Math.max(2, st.serie || 0), r = st.gettoni || 0;
      return { titolo: '🔥 La tua serie di ' + n + ' giorni sta per spegnersi',
        testo: (r === 1 ? 'Ti resta 1 protezione della serie' : 'Ti restano ' + r + ' protezioni della serie') + (st.nome ? ', ' + st.nome : '') + '. Basta una tappa prima di mezzanotte.' };
    }
  }catch(_){ }
  let n = 2;
  try{ if (typeof snStato === 'function'){ const st = snStato(); n = Math.max(2, (st && st.serie && st.serie.n) || 0); } }catch(_){ }
  let testo = '';
  try{ if (typeof snT === 'function') testo = String(snT('serie_rischio', { n: n })).replace(/\*/g, ''); }catch(_){ }
  if (!testo) testo = n + ' giorni in rotta, e oggi manca una tappa. Dieci minuti, e restano tutti tuoi.';
  return { titolo: 'Il Genio', testo: testo };
}

function ivnEsc(t){ return String(t).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

function ivnPaint(){
  const h = document.getElementById('ivnBody'); if (!h) return;
  const nt = ivnNotifica();
  h.innerHTML = '<h2 class="ivn-h">Fai la tua tappa ogni giorno con i promemoria del Genio</h2>'
    + '<div class="ivn-scena">'
    +   '<div class="ivn-tel"><i class="ivn-notch"></i></div>'
    +   '<div class="ivn-notif">'
    +     '<img class="ivn-ico" src="icons/icon-192.png" alt="">'
    +     '<div class="ivn-txt"><div class="ivn-riga"><b>' + ivnEsc(nt.titolo) + '</b><small>ora</small></div>'
    +     '<span>' + ivnEsc(nt.testo) + '</span></div>'
    +   '</div>'
    + '</div>'
    + '<button type="button" class="ivn-si" onclick="ivnAbilita()">Abilita le notifiche</button>'
    + '<button type="button" class="ivn-no" onclick="ivnNonOra()">Non ora</button>';
}

async function ivnAbilita(){
  let r = null;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.notifChiedi === 'function') r = await NATIVE.notifChiedi();
    else if (typeof ntChiedi === 'function') r = { granted: await ntChiedi(), impostazioni: true };
  }catch(_){ }
  const fine = function(){
    try{ if (typeof ntStato === 'function') ntStato(true).then(function(st){ if (st && !st.granted) ivnContaNo(); try{ ntAvvisoPaint(); }catch(_){ } }); }catch(_){ }
    ivnChiudi();
  };
  /* dalla pagina delle impostazioni di Android si torna qui: si va avanti al rientro */
  if (r && r.impostazioni && !r.granted){
    const rientro = function(){ if (document.hidden) return; document.removeEventListener('visibilitychange', rientro); setTimeout(fine, 400); };
    document.addEventListener('visibilitychange', rientro);
    return;
  }
  if (r && !r.granted) ivnContaNo();
  fine();
}
function ivnContaNo(){ const s = ivnStato(); s.no = (s.no || 0) + 1; ivnSalva(s); }
function ivnNonOra(){ ivnContaNo(); ivnChiudi(); }
function ivnChiudi(){
  const f = IVN_POI; IVN_POI = null;
  if (f) f(); else { goId('s-home'); try{ switchTab('mappa'); }catch(_){ } }
}

registerScreen('s-ivn', '<div class="ivn-in" id="ivnBody"></div>', { back: function(){ ivnNonOra(); return null; } });
(function ivnStile(){
  const st = document.createElement('style');
  st.textContent = [
    '#s-ivn{background:#F3F7FD!important}',
    'body.dark #s-ivn{background:#0E1B33!important}',
    '.ivn-in{min-height:100%;display:flex;flex-direction:column;padding:56px 2px calc(env(safe-area-inset-bottom,0px) + 8px);box-sizing:border-box}',
    '.ivn-h{margin:0;text-align:center;font:800 26px/1.3 var(--font-display);color:#0E2350}',
    'body.dark .ivn-h{color:#fff}',
    /* il telefono disegnato: cornice spessa, notch a pillola, sfuma verso il basso */
    '.ivn-scena{position:relative;flex:1;min-height:340px;margin:72px 0 24px}',
    '.ivn-tel{position:absolute;left:50%;top:0;width:min(76%,320px);height:330px;transform:translateX(-50%);box-sizing:border-box;border:14px solid #C9D8EE;border-bottom:0;border-radius:52px 52px 0 0;background:linear-gradient(180deg,#E3ECF8,rgba(227,236,248,0));-webkit-mask-image:linear-gradient(180deg,#000 60%,transparent);mask-image:linear-gradient(180deg,#000 60%,transparent)}',
    'body.dark .ivn-tel{border-color:#2E4466;background:linear-gradient(180deg,#1A2D4D,rgba(26,45,77,0))}',
    '.ivn-notch{position:absolute;left:50%;top:22px;width:92px;height:22px;transform:translateX(-50%);border-radius:999px;background:#C9D8EE}',
    'body.dark .ivn-notch{background:#2E4466}',
    /* la notifica: piu\' larga del telefono da tutte e due le parti, come nel modello */
    '.ivn-notif{position:absolute;left:50%;top:150px;width:min(88%,380px);transform:translateX(-50%);box-sizing:border-box;display:flex;align-items:center;gap:14px;padding:16px;border-radius:20px;background:#FFFFFF;border:2px solid #C9D8EE;box-shadow:0 14px 34px rgba(14,35,80,.14)}',
    'body.dark .ivn-notif{background:#14243F;border-color:#3A5478;box-shadow:0 14px 34px rgba(0,0,0,.35)}',
    '.ivn-ico{width:60px;height:60px;border-radius:14px;flex:none}',
    '.ivn-txt{flex:1;min-width:0}',
    '.ivn-riga{display:flex;align-items:baseline;gap:8px}',
    '.ivn-riga b{flex:1;min-width:0;font:800 17px var(--font-body);color:#0E2350}',
    'body.dark .ivn-riga b{color:#fff}',
    '.ivn-riga small{flex:none;font:500 15px var(--font-body);color:#4A5F80}',
    'body.dark .ivn-riga small{color:#C3D3EA}',
    '.ivn-txt span{display:block;margin-top:6px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:500 15px var(--font-body);color:#2A3D5C}',
    'body.dark .ivn-txt span{color:#DCE6F5}',
    /* i due pulsanti in fondo: il grande pieno, e "Non ora" scritto */
    '.ivn-si{display:block;width:100%;margin-top:auto;padding:17px;border:0;border-radius:18px;background:#0075E3;box-shadow:0 5px 0 #005BB0;font:800 17px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#FFFFFF;cursor:pointer}',
    '.ivn-si:active{transform:translateY(3px);box-shadow:0 2px 0 #005BB0}',
    '.ivn-no{display:block;width:100%;margin-top:18px;padding:14px;border:0;background:none;font:800 17px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#0075E3;cursor:pointer}',
    'body.dark .ivn-no{color:#8CC6FF}'
  ].join('\n');
  document.head.appendChild(st);
})();
