/* =========================================================================================
   L'INVITO ALLE NOTIFICHE A FINE TAPPA (0.9.300), come Duolingo

   Andrea, 24/10, con lo screenshot di Duolingo: "Crea un'abitudine di studio piu' efficace con i
   promemoria di ripasso", un telefono disegnato con dentro la notifica "Ciao, sono Duo!", il
   pulsante "Abilita le notifiche" e sotto "Non ora". Copiato come un ritratto: stesso ordine,
   stessa forma; il titolo e' nostro (la tappa di ogni giorno) e la notifica e' quella vera che
   l'app manda (sentiero.js snAvviso: titolo "Il Genio", testo serie_rischio con la serie vera).

   Quando: a fine tappa (sentiero-mappa.js, sdSerieAvanti, subito dopo "Tieni il ritmo"), solo se
   le notifiche sono spente. Non a ogni tappa: la prima volta subito; dopo un "Non ora" di nuovo
   fra 3 tappe o 3 giorni (quello che arriva prima); dopo tre "Non ora" una volta ogni 14 giorni.
   Mai nella stessa fine tappa in cui si e' appena vista la schermata del calendario.
   "Abilita le notifiche" chiede davvero il permesso (Android 13+ POST_NOTIFICATIONS, plugin
   notifChiedi); se Android non mostra piu' il dialogo, si apre la pagina delle notifiche dell'app.
   ========================================================================================= */
const IVN_KEY = 'fl_invito_notifiche';
let IVN_POI = null;
function ivnStato(){ try{ return JSON.parse(localStorage.getItem(IVN_KEY) || '{}') || {}; }catch(_){ return {}; } }
function ivnSalva(s){ try{ localStorage.setItem(IVN_KEY, JSON.stringify(s)); }catch(_){ } }
function ivnNativo(){ return typeof NATIVE !== 'undefined' && NATIVE && (typeof NATIVE.notifChiedi === 'function' || typeof NATIVE.requestAlarmAccess === 'function'); }

/** Se e' il momento, apre l'invito e chiama `poi` alla fine. Torna true se l'ha aperto. */
function ivnForse(poi){
  try{
    if (!ivnNativo() && !window.__ivnProva) return false;
    /* lo stato del permesso lo tiene notifiche.js (letto all'avvio e a ogni rientro): finche' non si sa, si tace */
    const nt = typeof NT_STATO !== 'undefined' ? NT_STATO : null;
    if (!window.__ivnProva && (!nt || nt.granted)) return false;
    const s = ivnStato();
    s.tappe = (s.tappe || 0) + 1;
    /* la schermata del calendario si e' appena vista: due richieste di fila sono troppe */
    let rt = null; try{ rt = typeof ritmoStato === 'function' ? ritmoStato() : null; }catch(_){ }
    if (rt && rt.visto && Date.now() - rt.visto < 10 * 60000){ ivnSalva(s); return false; }
    const giorni = s.visto ? (Date.now() - s.visto) / 86400000 : 999;
    const ora = !s.visto || ((s.no || 0) >= 3 ? giorni >= 14 : (s.tappe >= 3 || giorni >= 3));
    if (!ora){ ivnSalva(s); return false; }
    s.visto = Date.now(); s.tappe = 0; ivnSalva(s);
    IVN_POI = poi || null;
    goId('s-ivn'); ivnPaint();
    return true;
  }catch(_){ return false; }
}

/* 0.9.350, Andrea: "come Clarify". Il titolo dice che cosa fa l'app per te, sotto un telefono disegnato con la sua
   barra (12:30, wifi, batteria) e la notifica di Android che scende dall'alto: icona, "DreamMap · adesso", titolo in
   grassetto, testo, freccia per aprirla. Sotto "Sì, avvisami" e "Non ora", con gli stessi gestori di prima. */
function ivnEsc(t){ return String(t).replace(/[&<>"]/g, function(c){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

const IVN_SVG = {
  wifi: '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><path d="M12 20l-11-12a16 16 0 0 1 22 0z" fill="currentColor"/></svg>',
  batteria: '<svg viewBox="0 0 24 24" width="13" height="13" aria-hidden="true"><rect x="7" y="3" width="10" height="19" rx="2" fill="currentColor"/><rect x="10" y="1" width="4" height="3" rx="1" fill="currentColor"/></svg>',
  giu: '<svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true"><path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

function ivnPaint(){
  const h = document.getElementById('ivnBody'); if (!h) return;
  h.innerHTML = '<h2 class="ivn-h">Ti avviso io quando è il momento</h2>'
    + '<p class="ivn-sub">Ricevi un avviso all’ora della tua tappa.</p>'
    + '<div class="ivn-tel">'
    +   '<div class="ivn-sch">'
    +     '<i class="ivn-foro"></i>'
    +     '<div class="ivn-stato"><b>12:30</b><span>' + IVN_SVG.wifi + IVN_SVG.batteria + '</span></div>'
    +     '<div class="ivn-notif">'
    +       '<div class="ivn-riga"><img class="ivn-ico" src="icons/icon-192.png" alt=""><small>DreamMap · adesso</small><i class="ivn-giu">' + IVN_SVG.giu + '</i></div>'
    +       '<b>È l’ora del tuo sogno</b>'
    +       '<span>Ricordati perché è importante per te</span>'
    +     '</div>'
    +   '</div>'
    + '</div>'
    + '<button type="button" class="ivn-si" onclick="ivnAbilita()">Sì, avvisami</button>'
    + '<button type="button" class="ivn-no" onclick="ivnNonOra()">Non ora</button>';
}

async function ivnAbilita(){
  let r = null;
  try{
    if (typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.notifChiedi === 'function') r = await NATIVE.notifChiedi();
    else if (typeof ntChiedi === 'function') r = { granted: await ntChiedi(), impostazioni: true };
  }catch(_){ }
  const fine = function(){
    try{ if (typeof ntStato === 'function') ntStato(true).then(function(st){ if (st && !st.granted) ivnContaNo(); try{ ntAvvisoPaint(); }catch(_){ } }); }catch(_){ }
    ivnChiudi();
  };
  /* dalla pagina delle impostazioni di Android si torna qui: si va avanti al rientro */
  if (r && r.impostazioni && !r.granted){
    const rientro = function(){ if (document.hidden) return; document.removeEventListener('visibilitychange', rientro); setTimeout(fine, 400); };
    document.addEventListener('visibilitychange', rientro);
    return;
  }
  if (r && !r.granted) ivnContaNo();
  fine();
}
function ivnContaNo(){ const s = ivnStato(); s.no = (s.no || 0) + 1; ivnSalva(s); }
function ivnNonOra(){ ivnContaNo(); ivnChiudi(); }
function ivnChiudi(){
  const f = IVN_POI; IVN_POI = null;
  if (f) f(); else { goId('s-home'); try{ switchTab('mappa'); }catch(_){ } }
}

registerScreen('s-ivn', '<div class="ivn-in" id="ivnBody"></div>', { back: function(){ ivnNonOra(); return null; } });
(function ivnStile(){
  const st = document.createElement('style');
  st.textContent = [
    /* scura di proposito, di giorno e di notte: il testo resta bianco fisso */
    '#s-ivn{background:linear-gradient(180deg,#0A1632 0%,#001E44 55%,#0A1632 100%)!important;color:#FFFFFF}',
    '.ivn-in{min-height:100%;display:flex;flex-direction:column;padding:40px 2px calc(env(safe-area-inset-bottom,0px) + 8px);box-sizing:border-box}',
    '.ivn-h{margin:0;text-align:center;font:800 26px/1.25 var(--font-display);font-style:italic;color:#FFFFFF}',
    '.ivn-sub{margin:10px 0 0;text-align:center;font:500 14px/1.5 var(--font-body);color:#C8EFFD}',
    /* il telefono: cornice con il foro della fotocamera, sfondo notturno, sfuma verso il basso */
    '.ivn-tel{position:relative;flex:1 1 auto;min-height:320px;max-height:500px;width:min(90%,316px);margin:28px auto 0;box-sizing:border-box;border:9px solid #1B3A6B;border-bottom:0;border-radius:42px 42px 0 0;background:#1B3A6B;-webkit-mask-image:linear-gradient(180deg,#000 75%,transparent);mask-image:linear-gradient(180deg,#000 75%,transparent)}',
    '.ivn-sch{position:absolute;inset:0;overflow:hidden;border-radius:33px 33px 0 0;background:linear-gradient(180deg,rgba(0,30,68,.35),rgba(0,30,68,.05) 40%,rgba(10,22,50,.55)),url(img/dream-night.jpg) center 30%/cover no-repeat,#001E44}',
    '.ivn-foro{position:absolute;left:50%;top:9px;width:12px;height:12px;margin-left:-6px;border-radius:50%;background:#0A1632;box-shadow:0 0 0 2px rgba(240,251,255,.12)}',
    '.ivn-stato{display:flex;justify-content:space-between;align-items:center;height:30px;padding:0 20px;color:#FFFFFF}',
    '.ivn-stato b{font:600 12px var(--font-body);color:#FFFFFF}',
    '.ivn-stato span{display:flex;gap:4px}',
    /* la notifica di Android: scende dall'alto e resta */
    '.ivn-notif{margin:14px 8px 0;padding:12px 13px 14px;border-radius:20px;background:#F0FBFF;box-shadow:0 14px 30px rgba(0,13,31,.45);animation:ivnScende .7s cubic-bezier(.2,.9,.25,1.15) .5s both}',
    '@keyframes ivnScende{from{opacity:0;transform:translateY(-130%)}to{opacity:1;transform:none}}',
    '.ivn-riga{display:flex;align-items:center;gap:7px}',
    '.ivn-ico{width:18px;height:18px;border-radius:5px;flex:none}',
    '.ivn-riga small{flex:1;min-width:0;font:500 11.5px var(--font-body);color:#3D5476}',
    '.ivn-giu{flex:none;width:24px;height:24px;border-radius:50%;background:#C8EFFD;color:#001E44;display:grid;place-items:center}',
    '.ivn-notif b{display:block;margin-top:7px;font:700 14.5px/1.3 var(--font-body);color:#001E44}',
    '.ivn-notif span{display:block;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font:500 13px/1.4 var(--font-body);color:#3D5476}',
    /* i due pulsanti in fondo: il pieno, e "Non ora" scritto */
    '.ivn-si{display:block;width:100%;margin-top:28px;padding:17px;border:0;border-radius:99px;background:#0075E3;box-shadow:0 12px 26px rgba(0,117,227,.4);font:700 16px var(--font-body);color:#FFFFFF;cursor:pointer}',
    '.ivn-si:active{transform:scale(.97)}',
    '.ivn-no{display:block;width:100%;margin-top:8px;padding:14px;border:0;background:none;font:700 15px var(--font-body);color:#8CC6FF;cursor:pointer}',
    '@media (prefers-reduced-motion: reduce){.ivn-notif{animation:none}}',
    '@media (max-width:379px){.ivn-notif span{font-size:12px}}',
    '@media (max-height:800px){.ivn-in{padding-top:28px}.ivn-h{font-size:24px}.ivn-tel{margin-top:24px;min-height:290px}}'
  ].join('\n');
  document.head.appendChild(st);
})();
