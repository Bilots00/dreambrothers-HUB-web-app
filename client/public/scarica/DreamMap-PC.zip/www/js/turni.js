/* ===========================================================================================
   I TURNI DAL GRUPPO WHATSAPP DEL LAVORO (0.9.285, Andrea)

   Andrea fa il corriere: i turni arrivano come foto nel gruppo WhatsApp "Forservice". Li vuole nel
   calendario da soli: "deve leggere le foto della galleria inviate dal gruppo, analizzarle in
   automatico e programmare i turni nel calendario, senza che io le mandi a mano all'agente".

   Il lavoro lo fa il telefono anche ad app chiusa (TurniFoto.java): vede la notifica del gruppo,
   prende la foto dalla galleria, la manda al tuo agente personale, aspetta la risposta e scrive i turni nel
   calendario del telefono, poi lo dice con una notifica. Qui ci sono le impostazioni (nella pagina
   del calendario, vicino a "Collega a Google Calendar"), i permessi, la prova e il diario.
   Per ora solo per chi ha creato l'app: l'agente che legge le foto e' il suo (sul VPS).
   =========================================================================================== */
const TU = { stato: null };
function tuNativo(){ return typeof NATIVE !== 'undefined' && NATIVE && typeof NATIVE.turniStato === 'function'; }
function tuPuo(){ return typeof flAdmin === 'function' && flAdmin(); }
function tuEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
const TU_INDIETRO = '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';

registerScreen('s-turni',
  '<div class="topbar"><button class="iconbtn" onclick="flIndietro()" aria-label="Indietro">' + TU_INDIETRO + '</button><b class="blk-title">Turni da WhatsApp</b></div>'
  + '<div id="tuBody"></div><div class="spacer"></div>');

async function tuApri(){
  try{ if (typeof calChiudi === 'function') calChiudi(); }catch(_){ }
  goId('s-turni');
  await tuLeggi();
  tuPaint();
}
async function tuLeggi(){
  if (!tuNativo()){ TU.stato = null; return; }
  try{ TU.stato = await NATIVE.turniStato(); }catch(_){ TU.stato = null; }
  try{ TU.notif = await NATIVE.isNotificationAccessGranted(); TU.notif = !!(TU.notif && (TU.notif.granted || TU.notif.value || TU.notif === true)); }catch(_){ TU.notif = false; }
}
function tuRiga(ok, titolo, sotto, bottone, azione){
  return '<div class="tu-perm' + (ok ? ' ok' : '') + '"><span class="tu-perm-i">' + (ok ? '✓' : '!') + '</span><div><b>' + tuEsc(titolo) + '</b><small>' + tuEsc(sotto) + '</small></div>'
    + (ok ? '' : '<button type="button" class="tu-perm-b" onclick="' + azione + '">' + tuEsc(bottone) + '</button>') + '</div>';
}
function tuPaint(){
  const host = document.getElementById('tuBody'); if (!host) return;
  const s = TU.stato;
  if (!tuNativo() || !s){ host.innerHTML = '<p class="tu-intro">I turni si leggono dalle foto solo nell’app installata sul telefono.</p>'; return; }
  if (!s.disponibile){ host.innerHTML = '<p class="tu-intro">Questa versione dell’app non legge le foto della galleria. Installa DreamMap dal sito per usare i turni da WhatsApp.</p>'; return; }
  const acceso = !!String(s.gruppo || '').trim();
  const ore = Math.round((+s.durataMin || 540) / 60);
  const diario = (s.diario || []).slice().reverse().map(function(d){
    const t = new Date(+d.at || 0);
    return '<li><span>' + t.toLocaleDateString('it-IT', { day: 'numeric', month: 'short' }) + ' · ' + String(t.getHours()).padStart(2, '0') + ':' + String(t.getMinutes()).padStart(2, '0') + '</span>' + tuEsc(d.t) + '</li>';
  }).join('');
  host.innerHTML = '<p class="tu-intro">Quando nel gruppo del lavoro arriva <b>la foto dei turni</b>, il tuo agente personale la legge e mette i tuoi turni nel calendario.</p>'
    + '<div class="tu-box">'
    +   '<label class="tu-l" for="tuGruppo">Il nome del gruppo WhatsApp</label>'
    +   '<input id="tuGruppo" class="fin" placeholder="Per esempio Forservice" value="' + tuEsc(s.gruppo || '') + '" autocomplete="off">'
    +   '<label class="tu-l" for="tuNome">Il tuo nome nella tabella dei turni</label>'
    +   '<input id="tuNome" class="fin" placeholder="Per esempio Bilotta Andrea" value="' + tuEsc(s.nome || '') + '" autocomplete="off">'
    +   '<div class="md-row tu-durata"><span>Quanto dura un turno se la foto dice solo l’inizio</span><div class="md-step"><button type="button" onclick="tuDurata(-1)" aria-label="Un’ora in meno">−</button><b id="tuOre">' + ore + ' ore</b><button type="button" onclick="tuDurata(1)" aria-label="Un’ora in più">+</button></div></div>'
    +   '<button type="button" class="am-cta" onclick="tuSalva()">' + (acceso ? 'Salva' : 'Accendi i turni da WhatsApp') + '</button>'
    + '</div>'
    + '<p class="tu-sez">Cosa serve al telefono</p>'
    + tuRiga(TU.notif, 'Leggere le notifiche', 'Così vede quando nel gruppo arriva una foto.', 'Concedi', "openPerm('notif')")
    + (s.fotoLimitata
        ? tuRiga(false, 'Leggere tutte le foto', 'Adesso DreamMap vede solo alcune foto: le foto nuove del gruppo restano invisibili. Scegli "Consenti tutte".', 'Cambia', 'tuPermFoto()')
        : tuRiga(!!s.foto, 'Leggere le foto', 'Così prende la foto dei turni dalla galleria.', 'Concedi', 'tuPermFoto()'))
    + tuRiga(!!s.calendario, 'Scrivere nel calendario', 'Così i turni entrano nel calendario del telefono.', 'Concedi', 'tuPermCal()')
    /* 0.9.286: la foto si puo' anche scegliere a mano (nessun permesso), e la ricerca guarda gli ultimi 7 giorni */
    /* 0.9.290, Andrea: "non voglio toccare Scegli la foto ogni volta: deve mettermi lui i turni nel calendario". Il servizio
       guarda da solo le foto nuove di WhatsApp ogni mezz'ora (anche con il gruppo silenziato): qui lo si dice, e la scelta
       a mano resta in fondo, solo per una foto che manca. */
    + (acceso ? '<div class="tu-auto"><span>✓</span><div><b>I turni entrano da soli</b><small>Ogni mezz’ora DreamMap guarda le foto nuove di WhatsApp e mette i tuoi turni nel calendario.</small></div></div>' : '')
    + (+s.inAttesa ? '<p class="tu-attesa">Il tuo agente personale sta leggendo ' + (+s.inAttesa === 1 ? 'una foto' : s.inAttesa + ' foto') + '.</p>' : '')
    + (diario ? '<p class="tu-sez">Le ultime cose successe</p><ul class="tu-diario">' + diario + '</ul>' : '')
    + (acceso ? '<details class="tu-mano"><summary>Manca un turno? Mandalo tu</summary>'
        + '<button type="button" class="am-cta tu-scegli" onclick="tuScegli()">Scegli la foto dei turni</button>'
        + '<button type="button" class="tu-prova" onclick="tuProva()">Cerca nelle foto di WhatsApp degli ultimi 7 giorni</button>'
        + (TU.esito ? '<p class="tu-esito' + (TU.esito.ok ? ' ok' : '') + '">' + tuEsc(TU.esito.t) + '</p>' : '') + '</details>' : '')
    + (acceso ? '<button type="button" class="am-link" onclick="tuSpegni()">Spegni i turni da WhatsApp</button>' : '');
}
function tuDurata(d){
  const s = TU.stato; if (!s) return;
  s.durataMin = Math.max(60, Math.min(960, (+s.durataMin || 540) + d * 60));
  const b = document.getElementById('tuOre'); if (b) b.textContent = Math.round(s.durataMin / 60) + ' ore';
}
async function tuSalva(){
  const g = (document.getElementById('tuGruppo') || {}).value || '';
  const n = (document.getElementById('tuNome') || {}).value || '';
  if (!g.trim()){ toast('Scrivi il nome del gruppo WhatsApp'); return; }
  if (!n.trim()){ toast('Scrivi il tuo nome come compare nella tabella dei turni'); return; }
  let calId = -1;
  try{ const gc = (typeof calGcal === 'function') ? calGcal() : null; if (gc && gc.collegato && gc.scrivi && gc.scrivi.id != null) calId = +gc.scrivi.id; }catch(_){ }
  try{ TU.stato = await NATIVE.turniImposta({ gruppo: g.trim(), nome: n.trim(), durataMin: +(TU.stato && TU.stato.durataMin) || 540, calId: calId }); }catch(_){ toast('Non sono riuscito a salvare'); return; }
  try{ flVibra([10, 30, 10]); }catch(_){ }
  toast('Turni da WhatsApp accesi: la prossima foto del gruppo entra nel calendario');
  tuPaint();
}
async function tuSpegni(){
  try{ TU.stato = await NATIVE.turniImposta({ gruppo: '' }); }catch(_){ }
  toast('Turni da WhatsApp spenti');
  tuPaint();
}
async function tuPermFoto(){
  try{ TU.stato = await NATIVE.turniPermessoFoto(); }
  catch(e){
    if (e && e.code === 'limitato'){
      toast('Hai dato accesso solo ad alcune foto: nelle impostazioni scegli Foto e video, poi Consenti tutte');
      try{ if (NATIVE.openAppDetailsSettings) await NATIVE.openAppDetailsSettings(); }catch(_){ }
    } else toast(e && e.code === 'unavailable' ? 'Questa versione dell’app non legge le foto' : 'Senza il permesso delle foto i turni non si leggono');
    await tuLeggi();
  }
  tuPaint();
}
async function tuPermCal(){
  try{ if (typeof calCollega === 'function'){ calCollega(); } else if (NATIVE.calendarioCollega) await NATIVE.calendarioCollega(); }catch(_){ }
  setTimeout(async function(){ await tuLeggi(); tuPaint(); }, 1500);
}
/* 0.9.286, Andrea: "mi dice Nessuna foto nuova del gruppo nelle ultime 24 ore, ma l'album e' pieno di turni".
   Adesso si dice il motivo vero, con i numeri (TurniFoto.cercaAMano). */
function tuEsitoTesto(r){
  if (!r) return { ok: false, t: 'La ricerca non è partita: riprova.' };
  const n = +r.trovate || 0;
  if (n) return { ok: true, t: (n === 1 ? 'Ho mandato al tuo agente personale la foto dei turni più recente' : 'Ho mandato al tuo agente personale le ' + n + ' foto dei turni più recenti') + ': i turni entrano nel calendario fra qualche minuto.' };
  if (r.errore) return { ok: false, t: r.errore };
  const v = +r.viste || 0, gia = +r.gia || 0;
  if (!v) return { ok: false, t: 'Negli ultimi 7 giorni non è arrivata nessuna foto su WhatsApp. Se la foto dei turni è più vecchia, toccala con "Scegli la foto dei turni".' };
  if (gia && !(+r.altre)) return { ok: true, t: 'Le foto dei turni degli ultimi 7 giorni le ha già lette il tuo agente personale.' };
  return { ok: false, t: 'Fra le ' + v + ' foto di WhatsApp degli ultimi 7 giorni nessuna sembra una tabella di turni. Toccala tu con "Scegli la foto dei turni".' };
}
async function tuProva(){
  toast('Cerco la foto dei turni fra le foto di WhatsApp…');
  let r = null;
  try{ r = await NATIVE.turniCerca({ ore: 24 * 7 }); TU.stato = r; }catch(_){ r = null; }
  TU.esito = tuEsitoTesto(r);
  try{ flVibra(TU.esito.ok ? [10, 30, 10] : 20); }catch(_){ }
  tuPaint();
}
async function tuScegli(){
  if (!NATIVE || typeof NATIVE.turniScegliFoto !== 'function'){ toast('Aggiorna DreamMap per scegliere la foto'); return; }
  let r = null;
  try{ r = await NATIVE.turniScegliFoto(); }
  catch(e){ if (e && e.code === 'cancelled') return; TU.esito = { ok: false, t: 'Il selettore delle foto non si è aperto: riprova.' }; tuPaint(); return; }
  TU.stato = r;
  TU.esito = r && r.mandata ? { ok: true, t: 'Foto mandata al tuo agente personale: i turni entrano nel calendario fra qualche minuto.' } : { ok: false, t: (r && r.errore) || 'La foto non è partita: riprova.' };
  try{ flVibra(TU.esito.ok ? [10, 30, 10] : 20); }catch(_){ }
  tuPaint();
}
/* la riga nelle impostazioni del calendario, sotto a "Collega a Google Calendar" */
(function(){
  setTimeout(function(){
    try{
      if (typeof calImpHtml !== 'function' || calImpHtml.__tu) return;
      const vero = calImpHtml;
      const h = function(){
        const html = vero.apply(this, arguments);
        if (!tuPuo() || !tuNativo()) return html;
        return html + '<div class="cal-sez"><button type="button" class="tu-entra" onclick="tuApri()"><span class="tu-entra-i">💼</span><span><b>Turni da WhatsApp</b><small>La foto dei turni del gruppo di lavoro entra nel calendario da sola</small></span><span class="chev"></span></button></div>';
      };
      h.__tu = true; window.calImpHtml = h; try{ calImpHtml = h; }catch(_){ }
    }catch(_){ }
  }, 1200);
  /* all'apertura e al ritorno nell'app: le foto ancora da trovare e le risposte ancora da leggere */
  const riprendi = function(){ if (!tuNativo() || !tuPuo() || typeof NATIVE.turniRiprendi !== 'function') return; NATIVE.turniRiprendi().then(function(s){ TU.stato = s; if (document.getElementById('tuBody') && document.getElementById('s-turni').classList.contains('active')) tuPaint(); }, function(){ }); };
  setTimeout(riprendi, 8000);
  document.addEventListener('visibilitychange', function(){ if (!document.hidden) setTimeout(riprendi, 1500); });
  const css = [
    '.tu-intro{margin:4px 2px 16px;font:500 14px/1.5 var(--font-body);color:var(--muted);text-align:center}.tu-intro b{color:var(--navy)}body.dark .tu-intro b{color:#fff}',
    '.tu-box{display:flex;flex-direction:column;gap:8px;padding:16px;border-radius:20px;background:var(--card,#fff);border:1px solid var(--line);margin-bottom:22px}body.dark .tu-box{background:#12203A;border-color:#22345A}',
    '.tu-l{font:700 13px var(--font-body);color:var(--navy);margin-top:6px}body.dark .tu-l{color:#fff}',
    '.tu-durata{margin-top:8px;padding:12px 0;border:0;background:transparent}.tu-durata > span{font:600 13px/1.35 var(--font-body);max-width:52%}',
    '.tu-sez{margin:6px 4px 10px;font:800 12px var(--font-body);letter-spacing:.08em;text-transform:uppercase;color:var(--muted)}',
    '.tu-scegli{width:100%;margin-top:18px}',
    '.tu-auto{display:flex;gap:14px;align-items:flex-start;margin:28px 0 8px;padding:16px;border-radius:18px;background:var(--blue-soft,#E3F1FF)}body.dark .tu-auto{background:rgba(63,159,244,.15)}.tu-auto > span{flex:none;width:28px;height:28px;border-radius:50%;background:#0075E3;color:#fff;display:grid;place-items:center;font:900 14px var(--font-body)}.tu-auto b{display:block;font:800 15px var(--font-body);color:var(--navy)}body.dark .tu-auto b{color:#fff}.tu-auto small{display:block;margin-top:4px;font:500 13px/1.45 var(--font-body);color:var(--muted)}',
    '.tu-mano{margin:24px 0 8px}.tu-mano summary{cursor:pointer;font:700 14px var(--font-body);color:var(--muted);text-align:center;list-style:none;padding:8px}.tu-mano summary::-webkit-details-marker{display:none}',
    '.tu-esito{margin:12px 2px 0;padding:12px 14px;border-radius:14px;font:600 13.5px/1.45 var(--font-body);color:#B3261E;background:rgba(230,57,70,.08)}.tu-esito.ok{color:#0B5CAD;background:rgba(0,117,227,.08)}',
    'body.dark .tu-esito{color:#FF9AA3;background:rgba(230,57,70,.14)}body.dark .tu-esito.ok{color:#8CC8FF;background:rgba(90,174,255,.14)}',
    '.tu-perm{display:flex;align-items:center;gap:12px;padding:12px 14px;border-radius:16px;background:var(--card,#fff);border:1px solid var(--line);margin-bottom:8px}body.dark .tu-perm{background:#12203A;border-color:#22345A}',
    '.tu-perm-i{flex:none;width:28px;height:28px;border-radius:50%;display:grid;place-items:center;font:800 14px var(--font-body);background:#FDE8EA;color:#E63946}.tu-perm.ok .tu-perm-i{background:#E3F1FF;color:#0075E3}',
    '.tu-perm div{flex:1;min-width:0}.tu-perm b{display:block;font:700 14px var(--font-body);color:var(--navy)}body.dark .tu-perm b{color:#fff}.tu-perm small{display:block;font:500 12px var(--font-body);color:var(--muted)}',
    '.tu-perm-b{flex:none;border:0;border-radius:99px;background:#0075E3;color:#fff;font:700 13px var(--font-body);padding:9px 14px;cursor:pointer}',
    '.tu-prova{display:block;width:100%;margin:14px 0 6px;border:1.5px dashed var(--line);background:transparent;border-radius:16px;padding:14px;font:700 14px var(--font-body);color:var(--navy);cursor:pointer}body.dark .tu-prova{color:#fff;border-color:#22345A}',
    '.tu-attesa{margin:8px 4px;font:600 13px var(--font-body);color:#0075E3;text-align:center}',
    '.tu-diario{list-style:none;margin:0 0 16px;padding:0;display:flex;flex-direction:column;gap:6px}.tu-diario li{font:500 13px/1.4 var(--font-body);color:var(--navy);padding:8px 12px;border-radius:12px;background:var(--bg,#F4F9FF)}body.dark .tu-diario li{color:#fff;background:#0F1B33}',
    '.tu-diario li span{display:block;font:700 11px var(--font-body);color:var(--muted);margin-bottom:2px}',
    '.tu-entra{display:flex;align-items:center;gap:12px;width:100%;border:0;background:transparent;text-align:left;padding:4px 0;cursor:pointer}.tu-entra-i{font-size:22px}.tu-entra span:nth-child(2){flex:1;min-width:0}',
    '.tu-entra b{display:block;font:700 14.5px var(--font-body);color:var(--navy)}body.dark .tu-entra b{color:#fff}.tu-entra small{display:block;font:500 12px var(--font-body);color:var(--muted)}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
