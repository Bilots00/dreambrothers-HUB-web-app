/* ===========================================================================================
   DOPO LA TAPPA, COME DUOLINGO (0.9.287, Andrea)

   1. LA LEGA. "Voglio vedere il mio personaggio che scala le posizioni nella classifica della lega":
      i punti della lega comprendono anche l'XP delle tappe (friends.js frPuntiGiorno + ftXpDi), e qui
      la tua riga sale davanti ai tuoi occhi dalla posizione di prima a quella di adesso.
   2. LE OLIMPIADI della tua categoria (degli Imprenditori, degli Studenti...): "guadagna altri N XP per
      salire di livello nella conquista". Una volta al giorno, o quando passi un livello.
   3. LA VELOCITA' rispetto alla settimana scorsa ("Stai procedendo 3,5 volte piu' velocemente"), con
      l'aereo che si sposta sulla percentuale del percorso, e l'immagine da condividere. Una volta al giorno.
   Le schermate arrivano dopo le missioni del giorno (sentiero-mappa.js, sdSerieAvanti).
   =========================================================================================== */
const FT_XP_K = 'fl_xp_giorni';     // { "AAAA-MM-GG": xp delle tappe di quel giorno }
const FT_VISTI_K = 'fl_ft_visti';   // { k: giorno, passo: bool, oli: livello visto }
const FT_OLI = [100, 250, 500, 1000, 2000, 3500, 5000, 7500, 10000, 15000, 20000, 30000, 50000];
const FT_OLI_NOMI = { studenti: 'degli Studenti', imprenditori: 'degli Imprenditori', lavoratori: 'dei Lavoratori', creator: 'dei Creator', sportivi: 'degli Sportivi' };

function ftK(t){ const d = new Date(t); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function ftEsc(s){ return (typeof esc === 'function') ? esc(s) : String(s == null ? '' : s); }
function ftXpGiorni(){ try{ const o = JSON.parse(localStorage.getItem(FT_XP_K) || '{}'); return o && typeof o === 'object' ? o : {}; }catch(_){ return {}; } }
/** L'XP delle tappe fatte in quel giorno (lo scrive sdXpOggiAdd). */
function ftXpDi(dayStart){ return +(ftXpGiorni()[ftK(dayStart)] || 0); }
function ftXpAggiungi(n){
  if (!(n > 0)) return;
  const o = ftXpGiorni(), k = ftK(Date.now());
  o[k] = (+o[k] || 0) + n;
  /* tre settimane bastano: servono la settimana di adesso e quella prima */
  Object.keys(o).sort().slice(0, -21).forEach(function(x){ delete o[x]; });
  try{ localStorage.setItem(FT_XP_K, JSON.stringify(o)); }catch(_){ }
}
function ftVisti(){ try{ const v = JSON.parse(localStorage.getItem(FT_VISTI_K) || '{}') || {}; if (v.k !== ftK(Date.now())) return { k: ftK(Date.now()), oli: v.oli || 0 }; return v; }catch(_){ return { k: ftK(Date.now()) }; } }
function ftVistiScrivi(v){ try{ localStorage.setItem(FT_VISTI_K, JSON.stringify(v)); }catch(_){ } }

/* ---------- il giro: lega, olimpiadi, velocita', poi chi chiama ---------- */
let FT_POI = null;
function ftDopoTappa(poi){
  FT_POI = poi;
  ftPasso(0);
}
function ftPasso(i){
  const passi = [ftLegaApri, ftOliApri, ftVelApri];
  for (let j = i; j < passi.length; j++){
    let mostrata = false;
    try{ mostrata = passi[j](function(){ ftPasso(j + 1); }); }catch(_){ mostrata = false; }
    if (mostrata) return;
  }
  const f = FT_POI; FT_POI = null; if (f) f();
}

registerScreen('s-ft', '<div class="ft" id="ftBody"></div>', { back: function(){ setTimeout(function(){ const b = document.querySelector('#ftBody .ft-cta'); if (b) b.click(); }, 0); return 's-ft'; } });

/* ---------- 1. LA LEGA ---------- */
function ftLegaApri(avanti){
  if (typeof FR === 'undefined' || !FR.lega || !FR.lega.optIn || FR.lega.stato === 'formazione') return false;
  const L = FR.lega, membri = (L.membri || []).slice();
  if (membri.length < 3 || typeof frPuntiLega !== 'function') return false;
  const mioI = membri.findIndex(function(m){ return m.me; }); if (mioI < 0) return false;
  const prima = +(membri[mioI].punti || 0), ora = Math.max(prima, frPuntiLega());
  const classifica = function(punti){
    const l = membri.map(function(m, i){ return { m: m, p: i === mioI ? punti : +(m.punti || 0) }; });
    l.sort(function(a, b){ return b.p - a.p || (a.m.me ? -1 : (b.m.me ? 1 : 0)); });
    return l;
  };
  const l0 = classifica(prima), l1 = classifica(ora);
  const pos0 = l0.findIndex(function(x){ return x.m.me; }) + 1, pos1 = l1.findIndex(function(x){ return x.m.me; }) + 1;
  const tier = (typeof FR_TIERS !== 'undefined' && FR_TIERS.indexOf(L.tier) >= 0) ? L.tier : 'bronzo';
  const nomeTier = (typeof amT === 'function') ? amT('lega.tier.' + tier) : tier;
  const cat = (typeof frLegaNome === 'function') ? frLegaNome(L.goal || (typeof frCategoria === 'function' ? frCategoria() : '')) : 'La tua lega';
  /* le righe intorno a te: tre sopra la posizione di prima, tre sotto quella di adesso */
  const da = Math.max(0, Math.min(pos1, pos0) - 4), a = Math.min(l1.length, Math.max(pos0, pos1) + 3);
  const righe = l1.slice(da, a);
  const riga = function(x, i){
    const pos = da + i + 1;
    return '<div class="ft-l-r' + (x.m.me ? ' me' : '') + '" data-me="' + (x.m.me ? 1 : 0) + '"><span class="ft-l-pos">' + pos + '</span>'
      + (x.m.me ? ((typeof flAvMio === 'function' && flAvMio()) || '<span class="am-av me">Tu</span>') : (typeof frAv === 'function' ? frAv(x.m.nome, x.m.device) : ''))
      + '<b>' + ftEsc(x.m.me ? 'Tu' : x.m.nome) + '</b><span class="ft-l-pt">' + Math.round(x.p).toLocaleString('it-IT') + ' XP</span></div>';
  };
  const salito = pos1 < pos0;
  const quinto = l1[4];
  const sotto = salito ? 'Sei salito di ' + (pos0 - pos1 === 1 ? 'una posizione' : (pos0 - pos1) + ' posizioni') + '.'
    : (pos1 <= 5 ? 'Sei nella zona promozione: alla fine della settimana sali di lega.' : 'Altri ' + Math.max(1, Math.round((quinto ? quinto.p : ora) - ora + 1)) + ' XP per entrare nella zona promozione.');
  const h = document.getElementById('ftBody');
  goId('s-ft');
  if (!h) return true;
  h.className = 'ft ft-lega';
  h.innerHTML = '<div class="ft-in">'
    + '<small class="ft-kick">' + ftEsc('Lega ' + nomeTier) + '</small>'
    + '<h2>' + ftEsc(cat) + '</h2>'
    + '<p class="ft-sotto" id="ftLegaSotto">' + ftEsc('Sei al ' + pos0 + '° posto') + '</p>'
    + '<div class="ft-l" id="ftLega">' + righe.map(riga).join('') + '</div>'
    + '<button type="button" class="ft-cta">Continua</button></div>';
  h.querySelector('.ft-cta').onclick = function(){ try{ flVibra(8); }catch(_){ } avanti(); };
  /* la tua riga parte da dove eri e sale al suo posto (FLIP) */
  const me = h.querySelector('.ft-l-r.me');
  if (me && pos0 !== pos1){
    const altezza = me.getBoundingClientRect().height + 6;
    me.style.transform = 'translateY(' + ((pos0 - pos1) * altezza) + 'px)';
    me.style.zIndex = '2';
    setTimeout(function(){
      me.style.transition = 'transform 1.1s cubic-bezier(.2,.8,.2,1)';
      me.style.transform = 'translateY(0)';
      try{ if (typeof gnAu !== 'undefined') gnAu.punto(); flVibra([10, 40, 20]); }catch(_){ }
      setTimeout(function(){ const t = document.getElementById('ftLegaSotto'); if (t){ t.textContent = 'Sei al ' + pos1 + '° posto! ' + sotto; t.classList.add('su'); } }, 900);
    }, 650);
  } else {
    setTimeout(function(){ const t = document.getElementById('ftLegaSotto'); if (t) t.textContent = 'Sei al ' + pos1 + '° posto. ' + sotto; }, 400);
  }
  return true;
}

/* ---------- 2. LE OLIMPIADI ---------- */
function ftOliNome(){
  let cat = '';
  try{ cat = (typeof FR !== 'undefined' && FR.lega && FR.lega.goal) || (typeof frCategoria === 'function' ? frCategoria() : ''); }catch(_){ }
  return 'Olimpiadi ' + (FT_OLI_NOMI[cat] || 'dei Sognatori');
}
function ftOliApri(avanti){
  const xp = (typeof LV !== 'undefined' && LV.xp) ? LV.xp : 0;
  if (!xp) return false;
  let livello = 0; while (livello < FT_OLI.length && xp >= FT_OLI[livello]) livello++;
  const meta = FT_OLI[Math.min(livello, FT_OLI.length - 1)], primaMeta = livello > 0 ? FT_OLI[livello - 1] : 0;
  const v = ftVisti();
  const nuovo = livello > (v.oli || 0);
  if (!nuovo && v.oliOggi) return false;
  v.oliOggi = true; v.oli = Math.max(v.oli || 0, livello); ftVistiScrivi(v);
  const manca = Math.max(0, meta - xp);
  const h = document.getElementById('ftBody');
  goId('s-ft');
  if (!h) return true;
  h.className = 'ft ft-oli';
  h.innerHTML = '<div class="ft-in">'
    + '<div class="ft-oli-badge' + (nuovo && livello > 0 ? ' nuovo' : '') + '"><span>🏅</span><b>' + (livello >= FT_OLI.length ? FT_OLI[FT_OLI.length - 1] : meta).toLocaleString('it-IT') + '</b></div>'
    + '<div class="ft-oli-barra"><i id="ftOliBarra" style="width:' + Math.round(Math.max(0, Math.min(1, (xp - primaMeta - 30) / Math.max(1, meta - primaMeta))) * 100) + '%"></i><span>' + xp.toLocaleString('it-IT') + '/' + meta.toLocaleString('it-IT') + '</span></div>'
    + '<h2>' + (nuovo && livello > 0 ? ftEsc('Livello ' + livello + ' delle ' + ftOliNome() + '!') : ftEsc('Guadagna altri ' + manca.toLocaleString('it-IT') + ' XP per salire di livello nelle ' + ftOliNome() + '!')) + '</h2>'
    + '<button type="button" class="ft-cta">Continua</button></div>';
  h.querySelector('.ft-cta').onclick = function(){ try{ flVibra(8); }catch(_){ } avanti(); };
  setTimeout(function(){ const b = document.getElementById('ftOliBarra'); if (b) b.style.width = Math.round(Math.max(0, Math.min(1, (xp - primaMeta) / Math.max(1, meta - primaMeta))) * 100) + '%'; try{ if (typeof gnAu !== 'undefined') gnAu.punto(); }catch(_){ } }, 500);
  return true;
}

/* ---------- 3. LA VELOCITA' RISPETTO ALLA SETTIMANA SCORSA ---------- */
function ftPuntiSettimana(daGiorniFa){
  let tot = 0;
  const oggi = new Date(); oggi.setHours(0, 0, 0, 0);
  for (let i = daGiorniFa; i < daGiorniFa + 7; i++){
    const d = new Date(oggi); d.setDate(d.getDate() - i);
    try{ tot += (typeof frPuntiGiorno === 'function') ? frPuntiGiorno(d.getTime()) : ftXpDi(d.getTime()); }catch(_){ }
  }
  return tot;
}
function ftVelocita(){
  const ora = ftPuntiSettimana(0), prima = ftPuntiSettimana(7);
  if (!(prima > 0) || !(ora > 0)) return null;
  return ora / prima;
}
function ftVelFrase(r){
  if (r == null) return 'Ogni tappa ti avvicina alla destinazione.';
  if (r >= 1.15) return 'Stai procedendo ' + String(Math.round(r * 10) / 10).replace('.', ',') + ' volte più velocemente rispetto alla settimana scorsa!';
  if (r <= 0.85) return 'Questa settimana vai più piano: il ' + Math.round((1 - r) * 100) + '% in meno della settimana scorsa.';
  return 'Stai tenendo lo stesso ritmo della settimana scorsa.';
}
function ftPct(x){ const v = x * 100; return (v < 10 ? v.toFixed(1) : String(Math.round(v))).replace('.', ',') + '%'; }
function ftPercorso(){ try{ return (typeof hdPercorso === 'function') ? Math.max(0, Math.min(1, hdPercorso().pct || 0)) : 0; }catch(_){ return 0; } }
function ftVelApri(avanti){
  const v = ftVisti(); if (v.passo) return false;
  v.passo = true; ftVistiScrivi(v);
  const pct = ftPercorso();
  let primaPct = pct;
  try{ primaPct = Math.min(pct, +(localStorage.getItem('fl_ft_pct') || pct)); localStorage.setItem('fl_ft_pct', String(pct)); }catch(_){ }
  const r = ftVelocita(), frase = ftVelFrase(r);
  const h = document.getElementById('ftBody');
  goId('s-ft');
  if (!h) return true;
  h.className = 'ft ft-vel';
  h.innerHTML = '<div class="ft-in">'
    + '<div class="ft-vel-cielo">' + [1, 2, 3].map(function(n){ return '<svg class="ft-nuvola n' + n + '" viewBox="0 0 120 56" aria-hidden="true"><path d="M26 54h70a22 22 0 0 0 2-44 30 30 0 0 0-56 6 20 20 0 0 0-16 38z" fill="#fff"/></svg>'; }).join('') + '<span class="ft-aereo" aria-hidden="true">✈️</span></div>'
    + '<b class="ft-vel-pct" id="ftVelPct">' + ftPct(primaPct) + '</b>'
    + '<small class="ft-vel-eti">del percorso verso il tuo sogno</small>'
    + '<div class="ft-vel-barra"><span>0</span><div><i id="ftVelBarra" style="width:' + (primaPct * 100).toFixed(1) + '%"><em>✈️</em></i></div><span>100</span></div>'
    + '<p class="ft-vel-frase' + (r != null && r <= 0.85 ? ' giu' : '') + '">' + ftEsc(frase) + '</p>'
    + '<div class="ft-bot"><button type="button" class="ft-share" aria-label="Condividi"><svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V3"/><path d="M7 8l5-5 5 5"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/></svg></button>'
    + '<button type="button" class="ft-cta">Continua</button></div></div>';
  h.querySelector('.ft-cta').onclick = function(){ try{ flVibra(8); }catch(_){ } avanti(); };
  h.querySelector('.ft-share').onclick = function(){ ftVelCondividi(r, pct); };
  setTimeout(function(){
    const b = document.getElementById('ftVelBarra'); if (b) b.style.width = (pct * 100).toFixed(1) + '%';
    const t0 = performance.now(), da = primaPct, a = pct;
    const num = function(n){ const q = Math.min(1, (n - t0) / 1200); const e = document.getElementById('ftVelPct'); if (e) e.textContent = ftPct(da + (a - da) * q); if (q < 1) requestAnimationFrame(num); };
    requestAnimationFrame(num);
    try{ if (typeof gnAu !== 'undefined') gnAu.punto(); flVibra([10, 30, 10]); }catch(_){ }
  }, 600);
  return true;
}
/* l'immagine da condividere: il cielo, le nuvole, l'aereo, la frase (come la carta di Duolingo) */
async function ftVelCanvas(r, pct){
  const W = 900, H = 1300, cv = document.createElement('canvas'); cv.width = W; cv.height = H; const x = cv.getContext('2d');
  const sf = x.createLinearGradient(0, 0, 0, H); sf.addColorStop(0, '#0B5FD1'); sf.addColorStop(1, '#5AB0FF'); x.fillStyle = sf; x.fillRect(0, 0, W, H);
  const nuvola = function(cx, cy, s){ x.fillStyle = 'rgba(255,255,255,.92)'; x.beginPath(); x.arc(cx, cy, 60 * s, 0, Math.PI * 2); x.arc(cx + 70 * s, cy - 25 * s, 75 * s, 0, Math.PI * 2); x.arc(cx + 150 * s, cy, 60 * s, 0, Math.PI * 2); x.rect(cx, cy, 150 * s, 60 * s); x.fill(); };
  nuvola(60, 1020, 1.3); nuvola(560, 1080, 1.1); nuvola(620, 300, .7);
  x.textAlign = 'center'; x.fillStyle = '#fff';
  x.font = '900 54px sans-serif'; x.fillText('DreamMap', W / 2, 120);
  x.font = '800 30px sans-serif'; x.globalAlpha = .85; x.fillText('IL MIO VIAGGIO VERSO IL SOGNO', W / 2, 172); x.globalAlpha = 1;
  x.font = '900 190px sans-serif'; x.fillText(ftPct(pct), W / 2, 430);
  x.font = '200px sans-serif'; x.fillText('✈️', W / 2, 700);
  x.font = '800 50px sans-serif';
  const parole = ftVelFrase(r).split(' '); let riga = '', y = 820;
  parole.forEach(function(p){ const prova = riga ? riga + ' ' + p : p; if (x.measureText(prova).width > W - 140){ x.fillText(riga, W / 2, y); y += 64; riga = p; } else riga = prova; });
  if (riga) x.fillText(riga, W / 2, y);
  return cv;
}
function ftVelCondividi(r, pct){
  const code = (typeof FR !== 'undefined' && FR.me && FR.me.code) || '';
  const url = ((typeof FR_URL !== 'undefined') ? FR_URL : 'https://dream-brothers.com/pages/focuslock') + (code ? '?invito=' + encodeURIComponent(code) : '');
  const testo = ftVelFrase(r) + ' Sono al ' + ftPct(pct) + ' del viaggio verso il mio sogno con DreamMap.\n' + url;
  if (typeof flCondividiApri === 'function'){ flCondividiApri(function(){ return ftVelCanvas(r, pct); }, testo, 'Condividi il tuo viaggio'); return; }
  try{ if (typeof NATIVE !== 'undefined' && NATIVE && NATIVE.shareText) NATIVE.shareText({ text: testo, title: 'DreamMap' }); }catch(_){ }
}

(function(){
  const css = [
    /* lo schermo intero, senza i margini delle altre schermate */
    '#s-ft{padding:0 !important;background:#0E1B33}#s-ft:has(.ft-vel){background:#2F8FF0}',
    '#s-ft .ft{min-height:100vh;min-height:100dvh;width:100%;display:flex;align-items:center;justify-content:center;background:#0E1B33;color:#fff;padding:calc(env(safe-area-inset-top,0px) + 24px) 22px calc(env(safe-area-inset-bottom,0px) + 24px);box-sizing:border-box}',
    '.ft-in{width:100%;max-width:440px;display:flex;flex-direction:column;align-items:center;text-align:center}',
    '.ft-kick{font:800 12px var(--font-body);letter-spacing:.16em;text-transform:uppercase;color:#7DBEFF}',
    '#s-ft .ft h2{margin:8px 0 6px;font:800 25px/1.25 var(--font-display,var(--font-body));color:#fff}',
    '.ft-sotto{margin:0 0 18px;min-height:2.8em;font:600 15px/1.45 var(--font-body);color:rgba(220,232,250,.85);transition:color .3s}.ft-sotto.su{color:#9BE8C3}',
    '.ft-l{width:100%;display:flex;flex-direction:column;gap:6px;margin-bottom:26px}',
    '.ft-l-r{position:relative;display:flex;align-items:center;gap:12px;padding:10px 14px;border-radius:14px;background:rgba(255,255,255,.06);text-align:left}',
    '.ft-l-r.me{background:linear-gradient(90deg,#0075E3,#3D8BFF);box-shadow:0 8px 22px rgba(0,117,227,.45)}',
    '.ft-l-pos{width:26px;font:800 15px var(--font-body);color:#9EC1FF;text-align:center}.ft-l-r.me .ft-l-pos{color:#fff}',
    '.ft-l-r b{flex:1;font:700 15px var(--font-body);color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
    '.ft-l-pt{font:700 14px var(--font-body);color:rgba(220,232,250,.85)}.ft-l-r.me .ft-l-pt{color:#fff}',
    '.ft-cta{width:100%;padding:15px 18px;border:0;border-radius:16px;background:#3D9BFF;color:#fff;font:800 16px var(--font-body);letter-spacing:.06em;text-transform:uppercase;box-shadow:0 5px 0 #1F6FCC;cursor:pointer}',
    '.ft-cta:active{transform:translateY(3px);box-shadow:0 2px 0 #1F6FCC}',
    '.ft-oli-badge{position:relative;width:190px;height:190px;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;background:radial-gradient(circle at 50% 35%,#FF8A95,#E63946 70%);box-shadow:0 0 0 10px rgba(230,57,70,.18);margin:10px 0 26px}',
    '.ft-oli-badge span{font-size:78px;line-height:1}.ft-oli-badge b{font:900 40px var(--font-display,var(--font-body));color:#fff;text-shadow:0 3px 0 rgba(0,0,0,.2)}',
    /* 0.9.297, Andrea: "il testo e' troppo attaccato al pulsante Continua" */
    '#s-ft .ft-oli h2{margin:4px 0 32px}',
    '.ft-oli-badge.nuovo{animation:ftPop .8s cubic-bezier(.2,1.6,.4,1)}@keyframes ftPop{0%{transform:scale(.6)}100%{transform:scale(1)}}',
    '.ft-oli-barra{position:relative;width:100%;height:30px;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden;margin-bottom:24px}',
    '.ft-oli-barra i{position:absolute;left:0;top:0;bottom:0;border-radius:99px;background:linear-gradient(90deg,#3D8BFF,#7DBEFF);transition:width 1.1s cubic-bezier(.2,.8,.2,1)}',
    '.ft-oli-barra span{position:relative;display:block;font:800 14px/30px var(--font-body);color:#fff}',
    '.ft-oli h2{margin-bottom:30px}',
    '#s-ft .ft.ft-vel{background:linear-gradient(180deg,#0B5FD1 0%,#2F8FF0 55%,#6BB8FF 100%)}',
    '.ft-vel .ft-vel-eti{color:rgba(255,255,255,.9)}.ft-vel .ft-vel-barra > div{background:rgba(255,255,255,.25)}.ft-vel .ft-vel-barra i{background:linear-gradient(90deg,#FFFFFF,#CFE7FF)}',
    '.ft-vel .ft-cta{background:#fff;color:#0B5FD1;box-shadow:0 5px 0 #A9CFFF}.ft-vel .ft-share{border-color:rgba(255,255,255,.6)}',
    '.ft-vel-cielo{position:relative;width:100%;height:170px;margin-bottom:6px}',
    '.ft-nuvola{position:absolute;width:120px;height:56px;opacity:.95;filter:drop-shadow(0 6px 10px rgba(0,40,110,.18));animation:ftNuv 6s ease-in-out infinite alternate}',
    '.ft-nuvola.n1{left:2%;top:78px}.ft-nuvola.n2{right:2%;top:18px;width:92px;height:44px;animation-delay:-3s}.ft-nuvola.n3{left:30%;top:118px;width:70px;height:34px;opacity:.8;animation-delay:-1.5s}',
    '@keyframes ftNuv{from{translate:-8px 0}to{translate:8px 0}}',
    '.ft-aereo{position:absolute;left:50%;top:40px;font-size:64px;transform:translateX(-50%) rotate(-8deg);animation:ftVola 2.6s ease-in-out infinite alternate}',
    '@keyframes ftVola{from{translate:0 4px}to{translate:0 -8px}}',
    '.ft-vel-pct{font:900 64px/1 var(--font-display,var(--font-body));color:#fff}',
    '.ft-vel-eti{margin:6px 0 18px;font:700 14px var(--font-body);color:rgba(220,232,250,.8)}',
    '.ft-vel-barra{width:100%;display:flex;align-items:center;gap:10px;margin-bottom:20px;font:800 15px var(--font-body);color:#fff}',
    '.ft-vel-barra > div{flex:1;height:22px;border-radius:99px;background:rgba(255,255,255,.12);position:relative}',
    '.ft-vel-barra i{position:absolute;left:0;top:0;bottom:0;border-radius:99px;background:linear-gradient(90deg,#3D8BFF,#7DBEFF);transition:width 1.2s cubic-bezier(.2,.8,.2,1)}',
    '.ft-vel-barra em{position:absolute;right:-14px;top:50%;transform:translateY(-50%);font-style:normal;font-size:24px}',
    '.ft-vel-frase{margin:0 0 26px;font:700 18px/1.45 var(--font-body);color:#fff}.ft-vel-frase.giu{color:#FFB3BB}',
    '.ft-bot{width:100%;display:flex;gap:12px}.ft-bot .ft-cta{flex:1}',
    '.ft-share{flex:none;width:56px;border-radius:16px;border:2px solid rgba(255,255,255,.25);background:transparent;color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}'
  ].join('\n');
  const st = document.createElement('style'); st.textContent = css; document.head.appendChild(st);
})();
