/* =========================================================================================
   IL ROMPICAPO AL POSTO DELL'APP (0.9.283)

   Andrea, 18/10: in "Rientra in rotta" chi sceglie il rompicapo o il mini cruciverba come cambio,
   quando l'app e' bloccata trova sulla schermata di blocco il pulsante che apre il rompicapo qui.
   L'enigma e' alla Professor Layton (logica, intuizione, 2-3 minuti a mente), il cruciverba ha
   4-6 parole; tutti e due parlano del suo obiettivo. Li scrive il server
   (/api/focuslock/agent/chat/rompicapo, che controlla anche gli incroci del cruciverba).
   Se ne tiene uno pronto per tipo (fl_rcp_scorta), cosi' toccando il pulsante si apre subito; senza
   rete o senza account ci sono quelli di scorta qui sotto.
   ========================================================================================= */
const RCP_KEY = 'fl_rcp_scorta';
const RCP = { tipo: '', dato: null, errori: 0, attivo: null, dir: 'o' };
const RCP_RISERVA = {
  enigma: [
    { titolo: 'Il quaderno delle ore', testo_enigma: 'Una studentessa decide di raddoppiare ogni giorno i minuti di studio del giorno prima. Il quinto giorno studia 160 minuti.', domanda: 'Quanti minuti ha studiato in tutto nei cinque giorni?', tipo_risposta: 'numero', opzioni: [], risposta_corretta: '310', effetto_eureka: 'Basta tornare indietro dimezzando: 160, 80, 40, 20, 10. Sommati fanno 310. L’ultimo giorno da solo vale più di tutti gli altri messi insieme: è la forza della costanza.' },
    { titolo: 'Il mercante prudente', testo_enigma: 'Un giovane investitore mette 100 monete in un affare. Il primo anno guadagna il 50%. Il secondo anno perde il 50%.', domanda: 'Con quante monete resta alla fine del secondo anno?', tipo_risposta: 'scelta_multipla', opzioni: ['A) 100', 'B) 75', 'C) 125', 'D) 50'], risposta_corretta: 'B', effetto_eureka: 'Il 50% perso si calcola su 150, non su 100: perde 75 monete e gliene restano 75. Guadagnare e perdere la stessa percentuale non riporta al punto di partenza.' },
    { titolo: 'Le serie dell’atleta', testo_enigma: 'In palestra un’atleta fa 3 serie di esercizi. Ogni serie dura 40 secondi e fra una serie e l’altra recupera 60 secondi.', domanda: 'Quanti secondi passano dall’inizio della prima serie alla fine dell’ultima?', tipo_risposta: 'numero', opzioni: [], risposta_corretta: '240', effetto_eureka: 'Le pause sono una in meno delle serie. Tre serie da 40 fanno 120 secondi, due pause da 60 altri 120: in tutto 240 secondi, cioè 4 minuti.' }
  ],
  cruciverba: [
    { griglia_dimensioni: { righe: 4, colonne: 5 }, parole: [
      { id: 1, direzione: 'orizzontale', x: 0, y: 0, definizione: 'La meta per cui spegni il telefono', risposta: 'SOGNO', lunghezza: 5 },
      { id: 2, direzione: 'verticale', x: 1, y: 0, definizione: 'Sessanta minuti di Full Focus', risposta: 'ORA', lunghezza: 3 },
      { id: 3, direzione: 'verticale', x: 3, y: 0, definizione: 'Si scrive al volo per non perdere un’idea', risposta: 'NOTA', lunghezza: 4 },
      { id: 4, direzione: 'orizzontale', x: 0, y: 2, definizione: 'Il lavoro di oggi, quando l’hai finito', risposta: 'FATTO', lunghezza: 5 }
    ] }
  ]
};
function rcpEsc(s){ return String(s == null ? '' : s).replace(/[&<>"]/g, function(m){ return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]; }); }
function rcpScorta(){ try{ return JSON.parse(localStorage.getItem(RCP_KEY) || '{}') || {}; }catch(_){ return {}; } }
function rcpScortaSalva(s){ try{ localStorage.setItem(RCP_KEY, JSON.stringify(s)); }catch(_){ } }
/** Ne prepara uno nuovo per la prossima volta (in silenzio: se non c'e' rete resta la riserva). */
async function rcpPrepara(tipo){
  try{
    if (typeof agApi !== 'function' || typeof NATIVE === 'undefined' || !NATIVE || !NATIVE.accountApi) return;
    const s = rcpScorta(); if (s[tipo]) return;
    const sogno = (typeof nvSogno === 'function' && nvSogno()) || '';
    const r = await agApi('POST', '/api/focuslock/agent/chat/rompicapo', { tipo: tipo, obiettivo: sogno });
    if (r && r.dato){ const s2 = rcpScorta(); s2[tipo] = r.dato; rcpScortaSalva(s2); }
  }catch(_){ }
}
/* 0.9.283: la scorta a tema (content/rompicapi.json): 22 enigmi e 9 cruciverba gia' controllati, scelti in base al
   sogno (soldi e business, fitness, studio, arte). Valgono senza rete e senza AI; quelli scritti dal server, quando
   c'e' la chiave, passano davanti. */
let RCP_SCORTA_TEMA = null;
async function rcpCaricaTema(){
  if (RCP_SCORTA_TEMA) return RCP_SCORTA_TEMA;
  try{ const r = await fetch('content/rompicapi.json', { cache: 'no-cache' }); if (r.ok) RCP_SCORTA_TEMA = await r.json(); }catch(_){ }
  return RCP_SCORTA_TEMA;
}
function rcpCategoria(){
  const t = String((typeof nvSogno === 'function' && nvSogno()) || '').toLowerCase();
  if (/soldi|ricc|finanz|business|aziend|e-?commerce|vend|startup|invest|libert|negozio|brand|client|fattur|guadagn|impres/.test(t)) return 'finanza';
  if (/peso|muscol|palestr|fisic|dimagr|marator|corsa|salute|allenam|sport|forma/.test(t)) return 'fitness';
  if (/laure|esam|studi|universit|tesi|concors|carrier|promozion|medicin|giurisprud|scuola|maturit/.test(t)) return 'studio';
  if (/libro|scriv|music|canzon|album|film|arte|disegn|youtube|contenut|creator|pittur|fotograf|cantant/.test(t)) return 'creativo';
  return 'generico';
}
function rcpRiserva(tipo){
  const tema = RCP_SCORTA_TEMA, cat = rcpCategoria();
  const gruppo = tipo === 'cruciverba' ? 'cruciverba' : 'enigmi';
  let l = tema && tema[gruppo] && tema[gruppo][cat] && tema[gruppo][cat].length ? tema[gruppo][cat] : null;
  /* finiti quelli del tema si passa a quelli generici, poi si ricomincia */
  if (l && tema[gruppo].generico) l = l.concat(tema[gruppo].generico);
  if (!l) l = RCP_RISERVA[tipo] || RCP_RISERVA.enigma;
  let i = 0; try{ i = (+(localStorage.getItem('fl_rcp_ris_' + tipo) || 0)) || 0; localStorage.setItem('fl_rcp_ris_' + tipo, String(i + 1)); }catch(_){ }
  return JSON.parse(JSON.stringify(l[i % l.length]));
}
async function rcpApri(tipo){
  tipo = tipo === 'cruciverba' ? 'cruciverba' : 'enigma';
  await rcpCaricaTema();
  const s = rcpScorta();
  RCP.tipo = tipo; RCP.dato = s[tipo] || rcpRiserva(tipo); RCP.errori = 0; RCP.attivo = null; RCP.dir = 'o';
  if (s[tipo]){ delete s[tipo]; rcpScortaSalva(s); }
  goId('s-rompicapo');
  rcpPaint();
  setTimeout(function(){ rcpPrepara(tipo); }, 1500);
}
function rcpPaint(){
  const h = document.getElementById('rcpBody'); if (!h) return;
  const t = document.getElementById('rcpTit'); if (t) t.textContent = RCP.tipo === 'cruciverba' ? 'Il tuo cruciverba' : 'Il tuo rompicapo';
  if (RCP.tipo === 'cruciverba') rcpCruciPaint(h); else rcpEnigmaPaint(h);
}

/* ---------- l'enigma ---------- */
function rcpEnigmaPaint(h){
  const d = RCP.dato || {};
  const multi = d.tipo_risposta === 'scelta_multipla' && Array.isArray(d.opzioni) && d.opzioni.length;
  h.innerHTML = '<div class="rcp-card"><small class="rcp-eti">🧩 Enigma</small><b class="rcp-titolo">' + rcpEsc(d.titolo) + '</b>'
    + '<p class="rcp-storia">' + rcpEsc(d.testo_enigma) + '</p><p class="rcp-dom">' + rcpEsc(d.domanda) + '</p></div>'
    + (multi
      ? '<div class="rcp-opz">' + d.opzioni.map(function(o, i){ return '<button type="button" onclick="rcpScegli(' + i + ')">' + rcpEsc(o) + '</button>'; }).join('') + '</div>'
      : '<div class="rcp-risp"><input class="fin" id="rcpIn" ' + (d.tipo_risposta === 'numero' ? 'inputmode="decimal" ' : '') + 'autocomplete="off" placeholder="La tua risposta" onkeydown="if(event.key===\'Enter\')rcpRispondi()"><button type="button" class="cta" onclick="rcpRispondi()">Rispondi</button></div>')
    + '<p class="rcp-esito" id="rcpEsito"></p><div id="rcpFine"></div>';
}
function rcpNorm(s){ return String(s == null ? '' : s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9.,-]/g, ''); }
function rcpGiusta(v){
  const d = RCP.dato || {}, ok = String(d.risposta_corretta || '');
  if (d.tipo_risposta === 'scelta_multipla'){ const a = String(v).trim().charAt(0).toUpperCase(), b = ok.trim().charAt(0).toUpperCase(); return a === b; }
  if (d.tipo_risposta === 'numero'){ const n = parseFloat(String(v).replace(',', '.')), m = parseFloat(ok.replace(',', '.')); if (isFinite(n) && isFinite(m)) return Math.abs(n - m) < 1e-9; }
  return rcpNorm(v) === rcpNorm(ok);
}
function rcpScegli(i){ const d = RCP.dato || {}; rcpVerdetto(rcpGiusta(d.opzioni[i]), document.querySelectorAll('.rcp-opz button')[i]); }
function rcpRispondi(){ const t = document.getElementById('rcpIn'); const v = t ? t.value.trim() : ''; if (!v){ toast('Scrivi la tua risposta'); return; } rcpVerdetto(rcpGiusta(v), t); }
function rcpVerdetto(ok, el){
  const e = document.getElementById('rcpEsito');
  if (!ok){
    RCP.errori++;
    try{ flVibra([20, 40, 20]); }catch(_){ }
    if (el){ el.classList.remove('rcp-no'); void el.offsetWidth; el.classList.add('rcp-no'); }
    if (e) e.innerHTML = 'Non è questa. Rileggi la storia e riprova.' + (RCP.errori >= 2 ? ' <button type="button" class="rcp-link" onclick="rcpSoluzione(false)">Mostra la soluzione</button>' : '');
    return;
  }
  rcpSoluzione(true);
}
function rcpSoluzione(vinto){
  const d = RCP.dato || {};
  const e = document.getElementById('rcpEsito'); if (e) e.innerHTML = '';
  const premio = vinto ? (RCP.errori ? 5 : 10) : 0;
  if (premio){ try{ if (typeof ffAddCoins === 'function') ffAddCoins(premio); }catch(_){ } try{ flVibra([10, 30, 10, 30, 60]); }catch(_){ } }
  if (vinto){ try{ if (typeof gcVittoria === 'function') gcVittoria('rompicapo', 1); }catch(_){ } }
  const f = document.getElementById('rcpFine'); if (!f) return;
  f.innerHTML = '<div class="rcp-eureka' + (vinto ? ' vinto' : '') + '"><b>' + (vinto ? '💡 Eureka!' : 'La soluzione') + '</b>'
    + '<p class="rcp-giusta">Risposta: <b>' + rcpEsc(d.risposta_corretta) + '</b></p><p>' + rcpEsc(d.effetto_eureka) + '</p>'
    + (premio ? '<p class="rcp-premio">🪙 +' + premio + ' monete</p>' : '') + '</div>'
    + '<button type="button" class="cta rcp-torna" onclick="rcpChiudi()">Torna al tuo sogno</button>';
  f.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

/* ---------- il cruciverba ---------- */
function rcpCelle(){
  const d = RCP.dato || {}, celle = {};
  (d.parole || []).forEach(function(w, wi){
    const o = String(w.direzione || '').charAt(0) === 'o', r = String(w.risposta || '').toUpperCase();
    for (let i = 0; i < r.length; i++){ const x = w.x + (o ? i : 0), y = w.y + (o ? 0 : i), k = x + ',' + y; (celle[k] = celle[k] || { x: x, y: y, l: r[i], parole: [] }).parole.push(wi); }
  });
  return celle;
}
function rcpCruciPaint(h){
  const d = RCP.dato || {}, g = d.griglia_dimensioni || {}, R = g.righe || 5, C = g.colonne || 5;
  const celle = rcpCelle();
  /* il numero sulla casella dove comincia una parola, in ordine di lettura */
  const inizi = {}; let n = 0;
  (d.parole || []).map(function(w, i){ return { w: w, i: i }; }).sort(function(a, b){ return a.w.y - b.w.y || a.w.x - b.w.x; }).forEach(function(z){ const k = z.w.x + ',' + z.w.y; if (!inizi[k]) inizi[k] = ++n; z.w._n = inizi[k]; });
  let griglia = '';
  for (let y = 0; y < R; y++) for (let x = 0; x < C; x++){
    const c = celle[x + ',' + y];
    griglia += c ? '<label class="rcp-cel">' + (inizi[x + ',' + y] ? '<i>' + inizi[x + ',' + y] + '</i>' : '') + '<input maxlength="1" autocomplete="off" autocapitalize="characters" data-x="' + x + '" data-y="' + y + '" onfocus="rcpFuoco(this)" oninput="rcpScrive(this)" onkeydown="rcpTasto(event,this)"></label>' : '<span class="rcp-vuota"></span>';
  }
  const def = function(dir){ return (d.parole || []).filter(function(w){ return String(w.direzione).charAt(0) === dir; }).sort(function(a, b){ return a._n - b._n; })
    .map(function(w){ return '<button type="button" class="rcp-def" onclick="rcpVaiParola(' + d.parole.indexOf(w) + ')"><b>' + w._n + '</b><span>' + rcpEsc(w.definizione) + ' <small>(' + String(w.risposta).length + ')</small></span></button>'; }).join(''); };
  h.innerHTML = '<div class="rcp-card"><small class="rcp-eti">✏️ Mini cruciverba</small><p class="rcp-storia">Tocca una definizione o una casella e scrivi. Quando le caselle sono piene, controlla.</p>'
    + '<div class="rcp-griglia" style="grid-template-columns:repeat(' + C + ',1fr);max-width:' + Math.min(360, C * 58) + 'px">' + griglia + '</div></div>'
    + '<div class="rcp-card"><b class="rcp-sez">Orizzontali</b>' + def('o') + '<b class="rcp-sez">Verticali</b>' + def('v') + '</div>'
    + '<button type="button" class="cta" onclick="rcpControlla()">Controlla</button><p class="rcp-esito" id="rcpEsito"></p><div id="rcpFine"></div>';
}
function rcpInput(x, y){ return document.querySelector('.rcp-griglia input[data-x="' + x + '"][data-y="' + y + '"]'); }
function rcpFuoco(el){
  const c = rcpCelle()[el.dataset.x + ',' + el.dataset.y]; if (!c) return;
  if (RCP.attivo === null || c.parole.indexOf(RCP.attivo) < 0) RCP.attivo = c.parole[0];
  rcpEvidenzia();
}
function rcpEvidenzia(){
  document.querySelectorAll('.rcp-cel.on').forEach(function(e){ e.classList.remove('on'); });
  const w = (RCP.dato.parole || [])[RCP.attivo]; if (!w) return;
  const o = String(w.direzione).charAt(0) === 'o';
  for (let i = 0; i < String(w.risposta).length; i++){ const t = rcpInput(w.x + (o ? i : 0), w.y + (o ? 0 : i)); if (t) t.parentNode.classList.add('on'); }
}
function rcpVaiParola(i){
  RCP.attivo = i; const w = RCP.dato.parole[i]; const o = String(w.direzione).charAt(0) === 'o';
  for (let k = 0; k < String(w.risposta).length; k++){ const t = rcpInput(w.x + (o ? k : 0), w.y + (o ? 0 : k)); if (t && !t.value){ t.focus(); rcpEvidenzia(); return; } }
  const t0 = rcpInput(w.x, w.y); if (t0) t0.focus(); rcpEvidenzia();
}
function rcpPasso(el, avanti){
  const w = (RCP.dato.parole || [])[RCP.attivo]; if (!w) return;
  const o = String(w.direzione).charAt(0) === 'o';
  const x = +el.dataset.x + (o ? (avanti ? 1 : -1) : 0), y = +el.dataset.y + (o ? 0 : (avanti ? 1 : -1));
  const t = rcpInput(x, y); if (t){ t.focus(); if (avanti) t.select(); }
}
function rcpScrive(el){
  el.value = String(el.value || '').toUpperCase().replace(/[^A-Z]/g, '').slice(-1);
  el.parentNode.classList.remove('ok', 'no');
  if (el.value) rcpPasso(el, true);
}
function rcpTasto(e, el){ if (e.key === 'Backspace' && !el.value){ e.preventDefault(); rcpPasso(el, false); } }
function rcpControlla(){
  const celle = rcpCelle(); let giuste = 0, tot = 0, vuote = 0;
  Object.keys(celle).forEach(function(k){
    const c = celle[k], t = rcpInput(c.x, c.y); if (!t) return; tot++;
    if (!t.value){ vuote++; return; }
    const ok = t.value === c.l; if (ok) giuste++;
    t.parentNode.classList.toggle('ok', ok); t.parentNode.classList.toggle('no', !ok);
  });
  const e = document.getElementById('rcpEsito');
  if (giuste === tot){ if (e) e.innerHTML = ''; rcpCruciFine(true); return; }
  RCP.errori++;
  try{ flVibra([20, 40, 20]); }catch(_){ }
  if (e) e.innerHTML = (vuote ? 'Mancano ' + vuote + (vuote === 1 ? ' casella' : ' caselle') + '. ' : '') + (tot - giuste - vuote ? 'Le caselle rosse hanno la lettera sbagliata.' : '')
    + (RCP.errori >= 2 ? ' <button type="button" class="rcp-link" onclick="rcpCruciFine(false)">Mostra le parole</button>' : '');
}
function rcpCruciFine(vinto){
  const celle = rcpCelle();
  Object.keys(celle).forEach(function(k){ const c = celle[k], t = rcpInput(c.x, c.y); if (t){ t.value = c.l; t.parentNode.classList.remove('no'); t.parentNode.classList.add('ok'); t.disabled = true; } });
  const premio = vinto ? (RCP.errori ? 5 : 10) : 0;
  if (premio){ try{ if (typeof ffAddCoins === 'function') ffAddCoins(premio); }catch(_){ } try{ flVibra([10, 30, 10, 30, 60]); }catch(_){ } }
  if (vinto){ try{ if (typeof gcVittoria === 'function') gcVittoria('rompicapo', 1); }catch(_){ } }
  const f = document.getElementById('rcpFine'); if (!f) return;
  f.innerHTML = '<div class="rcp-eureka' + (vinto ? ' vinto' : '') + '"><b>' + (vinto ? '🎉 Completato!' : 'Ecco le parole') + '</b>'
    + (premio ? '<p class="rcp-premio">🪙 +' + premio + ' monete</p>' : '<p>La prossima volta parti dalla parola più corta: dà le lettere per le altre.</p>') + '</div>'
    + '<button type="button" class="cta rcp-torna" onclick="rcpChiudi()">Torna al tuo sogno</button>';
  f.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function rcpChiudi(){ if (typeof flIndietro === 'function') flIndietro(); else { goId('s-home'); try{ switchTab('rotta'); }catch(_){ } } }

registerScreen('s-rompicapo',
  '<div class="topbar"><button class="iconbtn" onclick="rcpChiudi()" aria-label="Indietro"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg></button><b class="blk-title" id="rcpTit">Il tuo rompicapo</b></div>'
  + '<div id="rcpBody"></div><div class="spacer"></div>', { back: 's-home' });
(function(){
  const st = document.createElement('style');
  st.textContent = [
    '#rcpBody{display:flex;flex-direction:column;gap:14px;padding-bottom:20px}',
    '.rcp-card{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:18px 16px}',
    '.rcp-eti{display:block;font:800 12px var(--font-body);letter-spacing:.06em;text-transform:uppercase;color:#0075E3;margin-bottom:8px}',
    'body.dark .rcp-eti{color:#7FC0FF}',
    '.rcp-titolo{display:block;font:800 21px/1.25 var(--font-head,var(--font-body));color:var(--navy);margin-bottom:10px}',
    '.rcp-storia{margin:0 0 12px;font:500 15.5px/1.55 var(--font-body);color:var(--ink,var(--navy))}',
    '.rcp-dom{margin:0;font:800 16.5px/1.45 var(--font-body);color:var(--navy)}',
    '.rcp-opz{display:grid;gap:10px}',
    '.rcp-opz button{border:1.5px solid var(--line);background:var(--card);color:var(--navy);border-radius:14px;padding:14px;font:700 15.5px var(--font-body);text-align:left;cursor:pointer}',
    '.rcp-risp{display:flex;gap:10px}.rcp-risp .fin{flex:1}',
    '.rcp-no{animation:rcpScuoti .4s;border-color:#E5484D !important}',
    '@keyframes rcpScuoti{20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}',
    '.rcp-esito{min-height:20px;margin:0;font:600 14px var(--font-body);color:var(--muted);text-align:center}',
    '.rcp-link{border:0;background:none;color:#0075E3;font:700 14px var(--font-body);text-decoration:underline;cursor:pointer;padding:0}',
    '.rcp-eureka{border-radius:20px;padding:18px 16px;background:linear-gradient(135deg,#E3F1FF,#FBE4F1);color:#0E2350}',
    '.rcp-eureka b{display:block;font:800 19px var(--font-body);margin-bottom:6px}.rcp-eureka p{margin:6px 0 0;font:500 15px/1.5 var(--font-body)}',
    '.rcp-premio{font-weight:800 !important}',
    '.rcp-torna{margin-top:14px;width:100%}',
    '.rcp-griglia{display:grid;gap:4px;margin:6px auto 0;width:100%}',
    '.rcp-cel{position:relative;aspect-ratio:1;display:block}',
    '.rcp-cel input{width:100%;height:100%;box-sizing:border-box;border:2px solid #9DB8D6;border-radius:10px;background:var(--card);color:var(--navy);text-align:center;font:800 22px var(--font-body);text-transform:uppercase;padding:0;caret-color:#0075E3}',
    '.rcp-cel i{position:absolute;top:2px;left:5px;font:800 10px var(--font-body);font-style:normal;color:var(--muted);pointer-events:none}',
    '.rcp-cel.on input{border-color:#0075E3;background:#E3F1FF}body.dark .rcp-cel.on input{background:#16305A}',
    '.rcp-cel.ok input{border-color:#1E9E5A}.rcp-cel.no input{border-color:#E5484D;background:#FDECEC}body.dark .rcp-cel.no input{background:#4A1C22}',
    '.rcp-vuota{aspect-ratio:1}',
    '.rcp-sez{display:block;font:800 13px var(--font-body);color:var(--muted);text-transform:uppercase;letter-spacing:.05em;margin:4px 0 6px}',
    '.rcp-def{display:flex;gap:10px;width:100%;border:0;background:none;text-align:left;padding:8px 0;cursor:pointer;color:var(--navy);font:500 15px/1.4 var(--font-body)}',
    '.rcp-def b{flex:none;width:24px;height:24px;border-radius:50%;background:#E3F1FF;color:#0075E3;font:800 12px/24px var(--font-body);text-align:center}',
    'body.dark .rcp-def b{background:#16305A;color:#BCE0FF}.rcp-def small{color:var(--muted)}'
  ].join('\n');
  document.head.appendChild(st);
})();
