/* ===========================================================================================
   LA «i» DI UNA TASK: UN FOGLIO DAL BASSO, NON UNA PAGINA (0.9.217)

   Andrea: la pagina a tutto schermo della riga «fa schifo»: nessuna immagine, «Dove sta» che
   sembra un italiano tradotto male, «I passi» con «Falli scrivere al tuo agente personale» e poi il toast
   «Chiesto al tuo agente personale: i passi arrivano fra poco» che chiude tutto e ti lascia senza sapere
   dove trovarli. Adesso e' lo stesso foglio del tempo («Quanto ci vuole?»): l'immagine della
   task, il nome che si corregge, la PRIORITA' (non «dove sta»), il tempo, i passi. «Scomponi in
   passi» e «Cerca un tutorial» aprono SUBITO una conversazione nuova con il tuo agente personale, con la
   domanda gia' fatta: la risposta arriva li', davanti a te.

   stRigaOpen resta la porta d'ingresso per tutti (START, Mappa, Notion, il foglio grande).
   =========================================================================================== */
const RGF = { line: '', day: '', back: '' };
function stRigaOpen(line, day, back){
  if (typeof line === 'number'){ const r = stLines(); line = r[line] || ''; day = stDayKey(); }
  if (!line || typeof inSheet !== 'function') return;
  RGF.line = line; RGF.day = day || stDayKey(); RGF.back = back || '';
  /* da START si guarda soltanto: la priorita' si decide nel foglio della Mappa (0.9.219) */
  let tab = ''; try{ tab = localStorage.getItem('fl_tab') || ''; }catch(_){ }
  RGF.daStart = tab === 'sveglia' && !(document.querySelector('.screen.active') && document.querySelector('.screen.active').id === 's-notion');
  STR.line = RGF.line; STR.day = RGF.day; STR.back = RGF.back || 's-home';
  inSheet('<div class="am-sheet stt rgf" id="rgfBody"></div>');
  rgfPaint();
}
function stRigaPaint(){ rgfPaint(); }
/* 0.9.290, Andrea: "Scrivere l'offerta ... una pagina sola (60 minuti)": il tempo sta gia' nel selettore sotto, nel titolo e'
   un doppione; e l'agente scrive "piu'" con l'apostrofo. Il titolo si mostra pulito; la riga vera nel foglio resta com'e'. */
function rgfPulito(t){ return flAccenti(String(t || '').replace(/\s*\((?:\d+[.,]?\d*\s*(?:minut[oi]|min|ore|ora|h)|\d+\s*giorn[oi][^)]*|\d+\s*settiman[ae][^)]*)\)\s*$/i, '').trim()); }
function stRigaClose(){ rgfChiudi(); }
const RGF_PRIO = [['one', 'La priorità assoluta'], ['imp', 'Importante'], ['scad', 'Urgente'], ['idee', 'Non urgente']];
function rgfPaint(){
  const host = document.getElementById('rgfBody'); if (!host) return;
  const line = RGF.line, day = RGF.day;
  /* 0.9.259, Andrea: sul telefono il foglio restava un rettangolo grigio (un errore in una di queste letture
     fermava tutto prima di disegnare). Ogni lettura ha il suo riparo: il foglio si disegna comunque. */
  let m = {}, fatta = false, righe = [], sez = '', e = { bg: '#1E2A5A,#0F2041', ico: '📝' };
  try{ m = stMeta(line, day) || {}; }catch(_){ }
  try{ fatta = !!stIsDone(line, day); }catch(_){ }
  try{ righe = stRigheDi(day) || []; }catch(_){ }
  try{ sez = stSezione(line, day, righe) || ''; }catch(_){ }
  try{ const ee = stEmojiDi(line); if (ee && ee.ico) e = ee; }catch(_){ }
  const min = Math.max(1, Math.min(90, m.stima || 25));
  const oggi = day === stDayKey('today');
  const micro = (m.micro || []).filter(Boolean);
  const fatti = m.microFatti || {};
  const cestino = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"/></svg>';
  host.innerHTML = '<button type="button" class="am-x" aria-label="Chiudi" onclick="rgfChiudi()">✕</button>'
    + (fatta || sez === 'one' ? '' : '<button type="button" class="rgf-via" aria-label="Togli dal giorno" onclick="rgfTogli()">' + cestino + '</button>')
    + '<div class="stt-img" style="background:linear-gradient(160deg,' + e.bg + ')">' + e.ico + '</div>'
    + '<textarea class="rgf-nome" id="strTesto" rows="1" oninput="stNoteGrow(this)" onblur="rgfNome()"' + (fatta ? ' readonly' : '') + '>' + esc(rgfPulito(line)) + '</textarea>'
    /* la priorita': quattro scelte, si tocca e basta */
    + (fatta ? '<p class="rgf-fatta">✓ Fatta: sta fra le completate</p>'
        : (RGF.daStart ? '' : '<p class="rgf-eti">Priorità</p><div class="rgf-prio">' + RGF_PRIO.map(function(x){ return '<button type="button" class="' + (sez === x[0] ? 'on ' : '') + 'p-' + x[0] + '" onclick="rgfPrio(\'' + x[0] + '\')">' + x[1] + '</button>'; }).join('') + '</div>'))
    /* il tempo, con lo stesso selettore del foglio «Quanto ci vuole?» */
    + (fatta ? '' : '<p class="rgf-eti">Quanto ci vuole</p><div class="stt-qty"><button type="button" onclick="rgfMin(-5)" aria-label="Meno">−</button><input id="rgfMin" type="number" inputmode="numeric" min="1" max="90" value="' + min + '" onchange="rgfMinScritto(this.value)" onfocus="this.select()"><span>min</span><button type="button" onclick="rgfMin(5)" aria-label="Più">+</button></div>'
        + '<p class="stt-carb">⛽ <b>+' + ((typeof fcPremio === 'function') ? fcPremio(min) : 15) + ' carburante</b> se la chiudi entro ' + min + ' minuti</p>')
    /* i passi: quelli che ci sono, e due modi per averli subito */
    + '<p class="rgf-eti">I passi</p>'
    + (micro.length ? '<div class="rgf-passi">' + micro.map(function(p, i){ return '<button type="button" class="' + (fatti[i] ? 'on' : '') + '" onclick="rgfPasso(' + i + ')"><i>' + (fatti[i] ? '✓' : '') + '</i><span>' + esc(p) + '</span></button>'; }).join('') + '</div>' : '')
    + '<div class="rgf-aiuti">'
    +   '<button type="button" onclick="rgfChiedi(\'passi\')"><span>🪜</span><b>Scomponi in passi</b><small>Il tuo agente personale li scrive adesso</small></button>'
    +   '<button type="button" onclick="rgfChiedi(\'video\')"><span>🎥</span><b>Cerca un tutorial</b><small>Un video che mostra come si fa</small></button>'
    + '</div>'
    + (fatta || !oggi ? '' : '<button type="button" class="stt-via" onclick="rgfInizia()">INIZIA • ' + min + ' min <span class="chev"></span></button>');
  const t = document.getElementById('strTesto'); if (t) stNoteGrow(t);
}
function rgfNome(){
  const a = document.getElementById('strTesto'); if (!a) return;
  const nuovo = a.value.replace(/\s+/g, ' ').trim();
  if (!nuovo || nuovo === RGF.line || nuovo === rgfPulito(RGF.line)) return;
  STR.line = RGF.line; STR.day = RGF.day;
  try{ stRigaSalvaTesto(); }catch(_){ }
  RGF.line = STR.line;
  rgfAggiorna();
}
function rgfPrio(k){ stMetaSave(RGF.line, RGF.day, { sez: k }); try{ flVibra(8); }catch(_){ } rgfPaint(); rgfAggiorna(); }
function rgfMinSet(v){ const n = Math.max(1, Math.min(90, Math.round(+v || 25))); stMetaSave(RGF.line, RGF.day, { stima: n }); try{ flVibra(6); }catch(_){ } rgfPaint(); }
function rgfMin(d){ const m = Math.max(1, Math.min(90, stMeta(RGF.line, RGF.day).stima || 25)); rgfMinSet(d < 0 ? (m <= 5 ? m - 1 : m + d) : (m < 5 ? 5 : m + d)); }
function rgfMinScritto(v){ if (+v > 90) toast('Al massimo un’ora e mezza: più tempo ti dai, più ne sprechi'); rgfMinSet(v); }
function rgfPasso(i){ const m = stMeta(RGF.line, RGF.day); const f = Object.assign({}, m.microFatti || {}); f[i] = !f[i]; stMetaSave(RGF.line, RGF.day, { microFatti: f }); try{ flVibra(f[i] ? [10, 30, 10] : 6); }catch(_){ } rgfPaint(); }
/** I passi o il tutorial: una conversazione NUOVA con il tuo agente personale, con la domanda gia' fatta. */
function rgfChiedi(tipo){
  const t = RGF.line;
  const testo = tipo === 'video'
    ? 'Trovami un tutorial video che mostri come fare questa cosa, e dimmi quanto tempo darmi per guardarlo: "' + rgfPulito(t) + '"'
    : rgfScomponiTesto(t);
  try{ stMetaSave(t, RGF.day, { passiChiesti: true }); }catch(_){ }
  inSheetChiudi();
  if (typeof agNuovaConversazione === 'function'){ agNuovaConversazione(testo); return; }
  if (typeof agApri === 'function'){ agApri(); setTimeout(function(){ const a = document.getElementById('agTesto'); if (a){ a.value = testo; a.focus(); } }, 450); }
}
/* 0.9.290, Andrea: "me la scompone in 20 passi: al massimo 3. Se ne vuole altri li chiede dopo". E niente caporali. */
function rgfScomponiTesto(t){ return 'Scomponi questa cosa da fare in 3 passi al massimo, da pochi minuti ciascuno, così so da dove partire: "' + rgfPulito(t) + '"'; }
function rgfInizia(){
  const t = RGF.line, min = Math.max(1, Math.min(90, stMeta(t, RGF.day).stima || 25));
  inSheetChiudi();
  try{ const p = ffPref(); p.minutes = min; p.intent = String(t).replace(/^[☐☑•\-]\s*/, '').slice(0, 250); ffSavePref(); }catch(_){ }
  try{ ffOpen(); setTimeout(function(){ try{ ffStart(); }catch(_){ } }, 350); }catch(_){ }
}
function rgfTogli(){
  if (window.flPiano) window.flPiano.togli(RGF.day, RGF.line);
  inSheetChiudi(); toast('Tolta dal giorno'); rgfAggiorna();
}
function rgfChiudi(){ rgfNome(); inSheetChiudi(); rgfAggiorna(); }
/** Ridisegna chi mostra le righe: START, il foglio della Mappa, il foglio grande, il Notion. */
function rgfAggiorna(){
  try{ stListPaint(); }catch(_){ }
  try{ if (typeof mfRidisegna === 'function') mfRidisegna(); }catch(_){ }
  try{ if (document.getElementById('stfBody')) stfPaint(); }catch(_){ }
  try{ if (typeof ntAvvisa === 'function') ntAvvisa(); }catch(_){ }
}

/* «Scomponi» chiesto da altre porte (il sentiero, la scheda della riga di prima): niente piu'
   «i passi arrivano fra poco», si apre la conversazione con il tuo agente personale. */
(function(){
  if (typeof stScompChiedi !== 'function') return;
  const vecchio = stScompChiedi;
  stScompChiedi = function(line, day){
    if (typeof agNuovaConversazione !== 'function') return vecchio(line, day);
    line = String(line || '').trim(); if (!line) return false;
    try{ stMetaSave(line, day || stDayKey(), { passiChiesti: true }); }catch(_){ }
    agNuovaConversazione(rgfScomponiTesto(line));
    return true;
  };
})();

(function(){
  const st = document.createElement('style');
  st.textContent = [
    /* il foglio scorre se il telefono e' basso: l'immagine in cima non viene mai tagliata */
    '#inSheet .in-sheet-in{max-height:calc(100vh - 16px);overflow-y:auto;-webkit-overflow-scrolling:touch}',
    '.rgf{padding-bottom:6px;position:relative;text-align:center}.rgf .stt-img{width:76px;height:76px;font-size:40px;border-radius:20px;margin:4px auto 16px}',
    '.rgf-via{position:absolute;left:0;top:0;width:38px;height:38px;border:0;border-radius:50%;background:#FDECEE;color:#E63946;display:flex;align-items:center;justify-content:center;cursor:pointer}body.dark .rgf-via{background:rgba(230,57,70,.18)}',
    '.rgf-nome{display:block;width:100%;border:0;background:transparent;resize:none;text-align:center;font:800 19px/1.3 var(--font-display);color:var(--navy);padding:4px 8px;outline:none}body.dark .rgf-nome{color:#fff}',
    '.rgf-eti{margin:28px 0 12px;font:800 11px var(--font-body);letter-spacing:.12em;text-transform:uppercase;color:var(--muted);text-align:center}',
    '.rgf-prio{display:grid;grid-template-columns:1fr 1fr;gap:8px}.rgf-prio button{border:1.5px solid var(--line);border-radius:14px;background:var(--card,#fff);padding:11px 8px;font:700 13.5px var(--font-body);color:var(--navy);cursor:pointer}body.dark .rgf-prio button{background:#12203A;border-color:#22345A;color:#fff}',
    '.rgf-prio button.on.p-one{background:#FDE7E9;border-color:#E63946;color:#B3202C}.rgf-prio button.on.p-imp{background:#E6F2FF;border-color:#0075E3;color:#0058AB}.rgf-prio button.on.p-scad{background:#FFF1DE;border-color:#F0A030;color:#8A5300}.rgf-prio button.on.p-idee{background:#EEF1F5;border-color:#9AA8BD;color:#4A5A72}',
    '.rgf-fatta{margin:16px 0 0;font:700 14px var(--font-body);color:#0075E3;text-align:center}',
    '.rgf .stt-carb{margin:14px 0 0;text-align:center}.rgf .stt-qty{margin:0 auto}',
    '.rgf-passi{display:flex;flex-direction:column;gap:8px;margin-bottom:14px}.rgf-passi button{display:flex;align-items:flex-start;gap:10px;border:0;background:#F4F8FF;border-radius:12px;padding:10px 12px;text-align:left;font:600 14px/1.4 var(--font-body);color:var(--navy);cursor:pointer}body.dark .rgf-passi button{background:rgba(255,255,255,.06);color:#fff}',
    '.rgf-passi i{flex:none;width:20px;height:20px;border-radius:6px;border:2px solid #9AA8BD;display:flex;align-items:center;justify-content:center;font:900 12px var(--font-body);font-style:normal;color:#fff}.rgf-passi button.on i{background:#0075E3;border-color:#0075E3}.rgf-passi button.on span{text-decoration:line-through;color:var(--muted)}',
    '.rgf-aiuti{display:grid;grid-template-columns:1fr 1fr;gap:12px}.rgf-aiuti button{display:flex;flex-direction:column;align-items:center;gap:6px;border:1.5px solid var(--line);border-radius:16px;background:var(--card,#fff);padding:16px 12px;text-align:center;cursor:pointer}body.dark .rgf-aiuti button{background:#12203A;border-color:#22345A}',
    '.rgf-aiuti span{font-size:22px}.rgf-aiuti b{font:800 13.5px var(--font-body);color:var(--navy)}body.dark .rgf-aiuti b{color:#fff}.rgf-aiuti small{font:500 11.5px/1.3 var(--font-body);color:var(--muted)}',
    '.rgf .stt-via{margin-top:28px}.rgf-togli{display:block;margin:12px auto 0;border:0;background:transparent;color:#E63946;font:700 13.5px var(--font-body);cursor:pointer}'
  ].join('');
  document.head.appendChild(st);
})();
