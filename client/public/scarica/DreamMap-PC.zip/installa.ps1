# DreamMap per PC (ex FocusLock) - installazione su un altro computer.
#
# Cosa fa, in ordine:
#   1. controlla .NET 8 Desktop Runtime e WebView2 (servono all'app); se mancano li scarica
#      dai link ufficiali Microsoft e li installa;
#   2. copia l'app in C:\ProgramData\FocusLock (la stessa cartella del PC principale);
#   3. mette le regole di blocco del PC principale, ma solo se qui non ce ne sono gia';
#   4. crea l'attivita' pianificata "FocusLock AutoStart" (a ogni accesso, dopo 15 secondi,
#      riparte da sola fino a 3 volte): e' quella che tiene i blocchi sempre accesi;
#   5. avvia l'app (icona vicino all'orologio).
param([string]$dest = 'C:\ProgramData\FocusLock', [string]$nomeTask = 'FocusLock AutoStart', [switch]$prova)
$ErrorActionPreference = 'Stop'
$qui    = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe    = Join-Path $dest 'app\FocusLock.exe'

function Passo($t){ Write-Host ''; Write-Host ('>> ' + $t) -ForegroundColor Cyan }

# ---------- 1. i due componenti di Microsoft ----------
Passo 'Controllo .NET 8 Desktop Runtime'
$net8 = Get-ChildItem "$env:ProgramFiles\dotnet\shared\Microsoft.WindowsDesktop.App" -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '8.*' }
if (-not $net8) {
  Write-Host 'Manca: lo scarico da Microsoft e lo installo (qualche minuto)...'
  $tmp = Join-Path $env:TEMP 'windowsdesktop-runtime-8-x64.exe'
  Invoke-WebRequest 'https://aka.ms/dotnet/8.0/windowsdesktop-runtime-win-x64.exe' -OutFile $tmp -UseBasicParsing
  Start-Process $tmp -ArgumentList '/install','/quiet','/norestart' -Wait
  Remove-Item $tmp -ErrorAction SilentlyContinue
  $net8 = Get-ChildItem "$env:ProgramFiles\dotnet\shared\Microsoft.WindowsDesktop.App" -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like '8.*' }
  if (-not $net8) { throw '.NET 8 Desktop Runtime non si e'' installato. Installalo a mano da https://dotnet.microsoft.com/download/dotnet/8.0 (Windows Desktop Runtime x64) e rilancia.' }
}
Write-Host 'OK'

Passo 'Controllo WebView2'
$wv = @('HKLM:\SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'HKLM:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}',
        'HKCU:\SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}') |
      Where-Object { Test-Path $_ }
if (-not $wv) {
  Write-Host 'Manca: lo scarico da Microsoft e lo installo...'
  $tmp = Join-Path $env:TEMP 'MicrosoftEdgeWebview2Setup.exe'
  Invoke-WebRequest 'https://go.microsoft.com/fwlink/p/?LinkId=2124703' -OutFile $tmp -UseBasicParsing
  Start-Process $tmp -ArgumentList '/silent','/install' -Wait
  Remove-Item $tmp -ErrorAction SilentlyContinue
}
Write-Host 'OK'

# ---------- 2. l'app ----------
Passo 'Copio DreamMap in C:\ProgramData\FocusLock'
if (-not $prova) { Get-Process FocusLock -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue }
Start-Sleep -Seconds 1
New-Item -ItemType Directory -Force -Path $dest | Out-Null
if (Test-Path (Join-Path $dest 'app')) { Remove-Item (Join-Path $dest 'app') -Recurse -Force }
if (Test-Path (Join-Path $dest 'www')) { Remove-Item (Join-Path $dest 'www') -Recurse -Force }
Copy-Item (Join-Path $qui 'app') (Join-Path $dest 'app') -Recurse -Force
Copy-Item (Join-Path $qui 'www') (Join-Path $dest 'www') -Recurse -Force
Copy-Item (Join-Path $qui 'blocked.html') $dest -Force
Write-Host 'OK'

# ---------- 3. le regole ----------
Passo 'Regole di blocco'
if (Test-Path (Join-Path $dest 'rules.json')) {
  Write-Host 'Qui ci sono gia'' delle regole: le lascio come sono.'
} else {
  Copy-Item (Join-Path $qui 'rules.json') $dest -Force
  Write-Host 'Messe le stesse regole del PC principale.'
}

# ---------- 4. l'avvio automatico ----------
Passo 'Avvio automatico a ogni accesso'
$utente = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
$azione  = New-ScheduledTaskAction -Execute $exe -WorkingDirectory (Join-Path $dest 'app')
$innesco = New-ScheduledTaskTrigger -AtLogOn -User $utente
$innesco.Delay = 'PT15S'
$chi     = New-ScheduledTaskPrincipal -UserId $utente -LogonType Interactive -RunLevel Limited
$regole  = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable `
             -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1) -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $nomeTask -Action $azione -Trigger $innesco -Principal $chi -Settings $regole `
  -Description 'Avvia DreamMap (FocusLock) in background a ogni accesso, cosi i blocchi sono sempre attivi.' -Force | Out-Null
Write-Host 'OK'

# ---------- 5. via ----------
if ($prova) { Write-Host 'PROVA: niente avvio'; return }
Passo 'Avvio DreamMap'
Start-ScheduledTask -TaskName $nomeTask
Start-Sleep -Seconds 3
if (Get-Process FocusLock -ErrorAction SilentlyContinue) {
  Write-Host ''
  Write-Host 'Fatto. DreamMap e'' acceso: l''icona e'' vicino all''orologio, e da ora parte da solo a ogni accesso.' -ForegroundColor Green
} else {
  Start-Process $exe -WorkingDirectory (Join-Path $dest 'app')
  Write-Host ''
  Write-Host 'Fatto. DreamMap e'' acceso, e da ora parte da solo a ogni accesso.' -ForegroundColor Green
}
